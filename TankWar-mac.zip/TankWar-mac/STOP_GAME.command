#!/bin/bash
# familyplay（Mac）のサーバーを止める / 停止服务器
# v0.29：サーバーが じぶんで はじめた VOICEVOX の エンジンも とめる（Ollama は そのまま。30 分で AI を じぶんで しまう）
# v0.29：也停止服务器自己启动的 VOICEVOX 引擎（Ollama 不动，30 分钟后会自己卸下 AI）
PORT=8090
DATA="${TANK_DATA_DIR:-$HOME/Library/Application Support/OuchiSensha}"
PIDFILE="$DATA/voicevox-engine.pid"
n=0
pids=""
for pid in $(lsof -ti "tcp:$PORT" -sTCP:LISTEN 2>/dev/null); do
  if ps -p "$pid" -o comm= | grep -qi java; then kill "$pid" 2>/dev/null && n=$((n+1)) && pids="$pids $pid"; fi
done
# サーバーが おわるのを まつ（おわる時に じぶんの エンジンを とめる）/ 等服务器结束（结束时会停止自己的引擎）
for i in $(seq 1 20); do
  alive=0
  for pid in $pids; do kill -0 "$pid" 2>/dev/null && alive=1; done
  [ "$alive" = 0 ] && break
  sleep 0.5
done
if [ "$n" -gt 0 ]; then echo "止めました / 已停止"; else echo "動いていません / 没有在运行"; fi
# のこっていたら：サーバーが はじめた エンジン（--host 127.0.0.1 --port で うごく もの）だけ とめる
# 如果还在：只停止服务器启动的引擎
if [ -f "$PIDFILE" ]; then
  vp="$(cat "$PIDFILE" 2>/dev/null)"
  if [ -n "$vp" ] && kill -0 "$vp" 2>/dev/null && ps -p "$vp" -o command= 2>/dev/null | grep -q -- "--host 127.0.0.1 --port"; then
    kill "$vp" 2>/dev/null && echo "VOICEVOX の エンジンを 止めました / 已停止 VOICEVOX 引擎"
  fi
  rm -f "$PIDFILE"
fi
sleep 1

#!/bin/bash
# familyplay（Mac）のサーバーを止める / 停止服务器
PORT=8090
n=0
for pid in $(lsof -ti "tcp:$PORT" -sTCP:LISTEN 2>/dev/null); do
  if ps -p "$pid" -o comm= | grep -qi java; then kill "$pid" 2>/dev/null && n=$((n+1)); fi
done
if [ "$n" -gt 0 ]; then echo "止めました / 已停止"; else echo "動いていません / 没有在运行"; fi
sleep 1

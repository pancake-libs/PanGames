#!/bin/bash
# おうちを守れ！戦車隊 Mac 版の起動。
# ダブルクリックで、ゲームのサーバーを起動し、ブラウザでテレビ用の画面を開く。
# Mac 启动脚本：启动游戏服务器，并用浏览器打开电视画面。
cd "$(dirname "$0")" || exit 1
HERE="$(pwd)"
PORT=8090
# こえで こたえる（v0.28）の https・wss のポート / 语音回答（v0.28）用的 https・wss 端口
TLS_PORT=8443
URL="http://127.0.0.1:$PORT/tank-tv.html"
BASE="http://127.0.0.1:$PORT"
# ボスと おしゃべり（v0.29）：AI（Ollama）と ボスの こえ（VOICEVOX）のポート / 和首领聊天（v0.29）：AI（Ollama）和首领声音（VOICEVOX）
OLLAMA_PORT=11434
VOICEVOX_PORT=50021
# アプリを さがす フォルダ（: で くぎる。ためしの 時だけ TANK_APP_DIRS で かえる）/ 查找应用的文件夹
IFS=: read -r -a APP_DIRS <<< "${TANK_APP_DIRS:-/Applications:$HOME/Applications}"
JAVA_HOME_TOOL="${TANK_JAVA_HOME_TOOL:-/usr/libexec/java_home}"

port_open() { nc -z 127.0.0.1 "$1" >/dev/null 2>&1; }
has_app() { local d; for d in "${APP_DIRS[@]}"; do [ -d "$d/$1.app" ] && return 0; done; return 1; }
# /brain/status などの JSON から 1 つ取り出す（jq なし）。$1=JSON $2=llm|tts|"" $3=名前
jget() {
  local part="$1"
  if [ -n "$2" ]; then part="$(printf '%s' "$1" | sed -n 's/.*"'"$2"'":{\([^}]*\)}.*/\1/p')"; fi
  printf '%s' "$part" | sed -n 's/.*"'"$3"'":"\{0,1\}\([^",}]*\)"\{0,1\}.*/\1/p' | head -1
}

echo "== おうちを守れ！戦車隊（Mac）=="

# 1) Java 21 以上があるか / 检查 Java 21+
if [ -x "$JAVA_HOME_TOOL" ] && JH="$("$JAVA_HOME_TOOL" -v 21+ 2>/dev/null)"; then
  export JAVA_HOME="$JH"
else
  echo ""
  echo "[!] Java 21 が見つかりません。Temurin 21 を入れてから、もう一度ダブルクリックしてください。"
  echo "[!] 没有找到 Java 21。请先安装 Temurin 21，然后再双击一次。"
  echo "    https://adoptium.net/temurin/releases/?os=mac&version=21&package=jdk"
  open "https://adoptium.net/temurin/releases/?os=mac&version=21&package=jdk"
  read -r -p "Enter で閉じる / 按 Enter 关闭 " _
  exit 1
fi
echo "Java: $JAVA_HOME"

# 2) 前のサーバーを止める（ポート 8090 の java だけ）/ 停止旧的服务器
for pid in $(lsof -ti "tcp:$PORT" -sTCP:LISTEN 2>/dev/null); do
  if ps -p "$pid" -o comm= | grep -qi java; then kill "$pid" 2>/dev/null && echo "前のサーバーを止めました / 已停止旧服务器 (PID $pid)"; sleep 1
  else echo "[!] ポート $PORT をほかのアプリが使っています / 端口 $PORT 被其他应用占用：$(ps -p "$pid" -o comm=)"; read -r -p "Enter" _; exit 1; fi
done
# https のポート（8443）も同じ java のサーバーが使う。ほかのアプリなら、こえ（https）なしで起動する
# https 端口（8443）也是同一个 java 服务器。如果被其他应用占用，就不用语音（https）启动
export TANK_TLS_PORT="$TLS_PORT"
for pid in $(lsof -ti "tcp:$TLS_PORT" -sTCP:LISTEN 2>/dev/null); do
  if ps -p "$pid" -o comm= | grep -qi java; then kill "$pid" 2>/dev/null && echo "前のサーバーを止めました / 已停止旧服务器 (PID $pid)"; sleep 1
  else
    echo "[!] ポート $TLS_PORT をほかのアプリが使っています。こえで こたえる は つかえません（タップで あそべます）"
    echo "[!] 端口 $TLS_PORT 被其他应用占用：$(ps -p "$pid" -o comm=)。不能用声音回答（可以用点的方式玩）"
    export TANK_TLS=0
  fi
done

# 2.5) AI（Ollama）と ボスの こえ（VOICEVOX）。ここで 何が あっても ゲームは はじまる
#      AI（Ollama）和首领声音（VOICEVOX）。这里出什么问题游戏都会启动
OLLAMA_NOTE=ok
if port_open "$OLLAMA_PORT"; then
  OLLAMA_NOTE=ok
elif has_app Ollama; then
  open -ga Ollama >/dev/null 2>&1 && echo "🧠 Ollama を はじめました / 已启动 Ollama"
  OLLAMA_NOTE=started
elif command -v ollama >/dev/null 2>&1; then
  nohup ollama serve >/dev/null 2>&1 &
  echo "🧠 ollama serve を はじめました / 已启动 ollama serve"
  OLLAMA_NOTE=started
else
  OLLAMA_NOTE=none
fi
if port_open "$VOICEVOX_PORT"; then
  VOICEVOX_NOTE=ok
elif has_app VOICEVOX || [ -n "$TANK_VOICEVOX_RUN" ]; then
  # エンジンは サーバーが 窓なしで はじめる（だめなら アプリを 隠して はじめる）/ 引擎由服务器在后台启动
  VOICEVOX_NOTE=server
else
  VOICEVOX_NOTE=none
fi

# 3) サーバーを起動 / 启动服务器
export JAVA_OPTS="-Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8"
# 保存はこのフォルダの save に入れる（消すと最初から）/ 存档放在这个文件夹的 save 里（删除就从头开始）
export TANK_SAVE_DIR="$HERE/save"
chmod +x "$HERE/server/bin/desktop" 2>/dev/null
nohup "$HERE/server/bin/desktop" "$PORT" "$HERE/web" > "$HERE/server.log" 2>&1 &
SERVER_PID=$!
echo "サーバーを起動中… / 正在启动服务器…"
ok=0
for i in $(seq 1 60); do
  if nc -z 127.0.0.1 "$PORT" 2>/dev/null; then ok=1; break; fi
  sleep 0.5
done
if [ "$ok" != 1 ]; then
  echo "[!] サーバーが起動しません。server.log を見てください / 服务器没有启动，请查看 server.log"
  tail -20 "$HERE/server.log"
  read -r -p "Enter" _
  exit 1
fi

# ゲームの 間 Mac を スリープさせない（サーバーが とまると いっしょに おわる）/ 游戏期间 Mac 不睡眠（服务器停止时一起结束）
JAVA_PID="$(lsof -ti "tcp:$PORT" -sTCP:LISTEN 2>/dev/null | head -1)"
[ -n "$JAVA_PID" ] || JAVA_PID="$SERVER_PID"
if command -v caffeinate >/dev/null 2>&1 && [ -n "$JAVA_PID" ]; then
  nohup caffeinate -dimsu -w "$JAVA_PID" >/dev/null 2>&1 &
fi

# 4) ブラウザで開く（Chrome があれば Chrome。テレビへのキャストに使う）/ 用浏览器打开（有 Chrome 就用 Chrome）
if [ -d "/Applications/Google Chrome.app" ]; then open -a "Google Chrome" "$URL"; else open "$URL"; fi

echo ""
echo "ゲームを開きました：$URL"
echo "- 全画面：Chrome なら control + command + F"
echo "- テレビへ：HDMI でつなぐ。または Chrome の「⋮」→「キャスト」→ テレビ（タブをキャスト）"
echo "- スマホ：Mac と同じ Wi-Fi で、画面の QR を読む"
echo "- 音がテレビから出ない：システム設定 → サウンド → 出力 でテレビを選ぶ"
echo "- 止める：STOP_GAME.command をダブルクリック"
echo ""
echo "游戏已打开：$URL"
echo "- 全屏：Chrome 按 control + command + F"
echo "- 到电视：用 HDMI 连接。或 Chrome「⋮」→「投放」→ 电视（投放标签页）"
echo "- 手机：连同一个 Wi-Fi，扫画面上的二维码"
echo "- 电视没声音：系统设置 → 声音 → 输出 选电视"
echo "- 停止：双击 STOP_GAME.command"
echo ""
if [ "${TANK_TLS:-1}" != 0 ]; then
  echo "🎤 こえで こたえる：テレビの『🎤 こえの じゅんび』を ひらく（はじめの 1 回だけ、きく ための データ 約 180 MB を ダウンロードします）"
  echo "🎤 用声音回答：打开电视上的『🎤 声音准备』（第一次会下载约 180 MB 的识别数据）"
  echo "   （java の「受信を許可しますか？」が出たら「許可」/ 如果出现 java「是否允许传入连接？」请点「允许」）"
  echo ""
fi

# 5) ボスと おしゃべり（v0.29）：ようすを 1 行ずつ。AI の データが なければ ダウンロード（ゲームは もう あそべる）
#    和首领聊天（v0.29）：每部分一行状态。没有 AI 数据就下载（游戏已经可以玩了）
if [ "$OLLAMA_NOTE" = started ]; then
  for i in $(seq 1 15); do port_open "$OLLAMA_PORT" && break; sleep 2; done
fi
if port_open "$OLLAMA_PORT"; then
  curl -s -m 5 -X POST -H 'Content-Type: application/json' -d '{"retry":true}' "$BASE/brain/config" >/dev/null 2>&1
fi
ST="$(curl -s -m 5 "$BASE/brain/status" 2>/dev/null)"
STT="$(curl -s -m 5 "$BASE/stt/status" 2>/dev/null)"
LLM_STATE="$(jget "$ST" llm state)"
LLM_MODEL="$(jget "$ST" llm model)"
TTS_STATE="$(jget "$ST" tts state)"
TTS_MISSING="$(printf '%s' "$ST" | sed -n 's/.*"missing":\[\([^]]*\)\].*/\1/p' | tr -d '"')"
echo "---- ようす / 状态 ----"
case "$(jget "$STT" "" state)" in
  ready) echo "🎤 きく（whisper）：OK / 识别：OK" ;;
  downloading|loading) echo "🎤 きく（whisper）：じゅんびちゅう（データを ダウンロード中）/ 识别：准备中（正在下载数据）" ;;
  "") echo "🎤 きく（whisper）：なし → カードを タップして あそべます / 识别：无 → 可以点卡片玩" ;;
  *) echo "🎤 きく（whisper）：まだ → テレビの『🎤 こえの じゅんび』/ 识别：还没准备好 → 电视上的『🎤 声音准备』" ;;
esac
case "$LLM_STATE" in
  ready) echo "🧠 AI（Ollama・$LLM_MODEL）：OK / AI：OK" ;;
  nomodel|pulling|loading) echo "🧠 AI（Ollama・$LLM_MODEL）：AI の データを じゅんびします（まっている あいだも あそべます）/ AI：正在准备 AI 数据（等待时也可以玩）" ;;
  starting) echo "🧠 AI（Ollama）：はじまるのを まっています / AI：正在等待 Ollama 启动" ;;
  off) echo "🧠 AI：つかわない せってい → きまった へんじで はなします / AI：已关闭 → 用固定回答聊天" ;;
  "") echo "🧠 AI：サーバーが こたえません（server.log）→ きまった へんじで はなします / AI：服务器没有回应 → 用固定回答聊天" ;;
  *) echo "🧠 AI（Ollama）：ありません → きまった へんじで はなします / AI：没有 Ollama → 用固定回答聊天"
     echo "   いれる / 安装：https://ollama.com/download（いれたら 1 回 ひらく / 安装后打开一次）" ;;
esac
case "$TTS_STATE" in
  ready) if [ -n "$TTS_MISSING" ]; then echo "🗣 こえ（VOICEVOX）：OK。たりない キャラ / 缺少的角色：$TTS_MISSING（その ボスは もじと ろくおんだけ / 这个首领只有文字和录音）"
         else echo "🗣 こえ（VOICEVOX）：OK / 首领声音：OK"; fi ;;
  starting) echo "🗣 こえ（VOICEVOX）：はじめています / 首领声音：正在启动" ;;
  off) echo "🗣 こえ：つかわない せってい → ろくおんした こえと もじ / 首领声音：已关闭 → 录音和文字" ;;
  *) if [ "$VOICEVOX_NOTE" = none ]; then
       echo "🗣 こえ（VOICEVOX）：ありません → ろくおんした こえと もじで はなします / 首领声音：没有 VOICEVOX → 用录音和文字"
       echo "   いれる / 安装：https://voicevox.hiroshiba.jp/（Mac・Apple シリコン・CPU 版。いれたら 1 回 ひらく / 安装后打开一次）"
     else
       echo "🗣 こえ（VOICEVOX）：まだ こたえません（テレビの『🎤 こえの じゅんび』で テスト）/ 首领声音：还没有回应（在电视『🎤 声音准备』里测试）"
     fi ;;
esac
echo ""

# AI の データ（約 5 GB）を Ollama で ダウンロード。Ctrl-C で 表示だけ やめる（ダウンロードは サーバーが つづける）
# 用 Ollama 下载 AI 数据（约 5 GB）。按 Ctrl-C 只停止显示（下载由服务器继续）
if [ "$LLM_STATE" = nomodel ] || [ "$LLM_STATE" = pulling ]; then
  if [ "$LLM_STATE" = nomodel ]; then
    curl -s -m 10 -X POST -H 'Content-Type: application/json' -d '{"pull":true}' "$BASE/brain/config" >/dev/null 2>&1
  fi
  echo "AI の データを ダウンロードします（はじめの 1 回だけ。10〜30 分）。ゲームは もう あそべます。"
  echo "正在下载 AI 数据（只有第一次，10〜30 分钟）。游戏已经可以玩了。"
  echo "（Ctrl-C で この 表示を とじても、ダウンロードは つづきます / 按 Ctrl-C 关闭显示，下载也会继续）"
  trap 'echo ""; echo "ダウンロードは ゲームの 中で つづきます / 下载在游戏中继续"; exit 0' INT
  while :; do
    sleep 2
    ST="$(curl -s -m 5 "$BASE/brain/status" 2>/dev/null)"
    [ -n "$ST" ] || { echo ""; echo "[!] サーバーが とまりました / 服务器已停止"; break; }
    S="$(jget "$ST" llm state)"
    D="$(jget "$ST" llm done)"; T="$(jget "$ST" llm total)"
    case "$S" in
      pulling)
        if [ -n "$T" ] && [ "$T" -gt 0 ] 2>/dev/null; then
          P=$(( D * 100 / T ))
          G="$(awk -v d="$D" -v t="$T" 'BEGIN { printf "%.1f / %.1f GB", d / 1e9, t / 1e9 }')"
          printf '\rAI の データを ダウンロード中 %d%%（%s）/ 正在下载 AI 数据   ' "$P" "$G"
        else
          printf '\rAI の データを ダウンロード中… / 正在下载 AI 数据…   '
        fi ;;
      loading) printf '\rAI を よみこみ中… / 正在载入 AI…                              ' ;;
      ready) echo ""; echo "🧠 AI の じゅんび OK / AI 准备好了"; break ;;
      *) echo ""
         echo "[!] AI の データを ダウンロード できませんでした（インターネット？）。きまった へんじで あそべます。"
         echo "[!] 没能下载 AI 数据（网络？）。可以用固定回答玩。テレビの『🎤 こえの じゅんび』→『ダウンロード』で やりなおせます。"
         E="$(jget "$ST" llm err)"; [ -n "$E" ] && echo "    $E"
         break ;;
    esac
  done
  trap - INT
  echo ""
fi
echo "（このウィンドウは閉じても大丈夫です / 这个窗口可以关闭）"

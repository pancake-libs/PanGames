#!/bin/bash
# おうちを守れ！戦車隊 Mac 版の起動。
# ダブルクリックで、ゲームのサーバーを起動し、ブラウザでテレビ用の画面を開く。
# Mac 启动脚本：启动游戏服务器，并用浏览器打开电视画面。
cd "$(dirname "$0")" || exit 1
HERE="$(pwd)"
PORT=8090
# こえで こたえる（v0.28）の https・wss のポート / 语音回答（v0.28）用的 https・wss 端口
TLS_PORT=8443
URL="http://127.0.0.1:$PORT/tank-tv.html"

echo "== おうちを守れ！戦車隊（Mac）=="

# 1) Java 21 以上があるか / 检查 Java 21+
if [ -x /usr/libexec/java_home ] && JH="$(/usr/libexec/java_home -v 21+ 2>/dev/null)"; then
  export JAVA_HOME="$JH"
else
  echo ""
  echo "[!] Java 21 が見つかりません。Temurin 21 を入れてから、もう一度ダブルクリックしてください。"
  echo "[!] 没有找到 Java 21。请先安装 Temurin 21，然后再双击一次。"
  echo "    https://adoptium.net/temurin/releases/?os=mac&version=21&package=jdk"
  open "https://adoptium.net/temurin/releases/?os=mac&version=21&package=jdk"
  read -r -p "Enter で閉じる / 按 Enter 关闭 " _
  exit 1
fi
echo "Java: $JAVA_HOME"

# 2) 前のサーバーを止める（ポート 8090 の java だけ）/ 停止旧的服务器
for pid in $(lsof -ti "tcp:$PORT" -sTCP:LISTEN 2>/dev/null); do
  if ps -p "$pid" -o comm= | grep -qi java; then kill "$pid" 2>/dev/null && echo "前のサーバーを止めました / 已停止旧服务器 (PID $pid)"; sleep 1
  else echo "[!] ポート $PORT をほかのアプリが使っています / 端口 $PORT 被其他应用占用：$(ps -p "$pid" -o comm=)"; read -r -p "Enter" _; exit 1; fi
done
# https のポート（8443）も同じ java のサーバーが使う。ほかのアプリなら、こえ（https）なしで起動する
# https 端口（8443）也是同一个 java 服务器。如果被其他应用占用，就不用语音（https）启动
export TANK_TLS_PORT="$TLS_PORT"
for pid in $(lsof -ti "tcp:$TLS_PORT" -sTCP:LISTEN 2>/dev/null); do
  if ps -p "$pid" -o comm= | grep -qi java; then kill "$pid" 2>/dev/null && echo "前のサーバーを止めました / 已停止旧服务器 (PID $pid)"; sleep 1
  else
    echo "[!] ポート $TLS_PORT をほかのアプリが使っています。こえで こたえる は つかえません（タップで あそべます）"
    echo "[!] 端口 $TLS_PORT 被其他应用占用：$(ps -p "$pid" -o comm=)。不能用声音回答（可以用点的方式玩）"
    export TANK_TLS=0
  fi
done

# 3) サーバーを起動 / 启动服务器
export JAVA_OPTS="-Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8"
# 保存はこのフォルダの save に入れる（消すと最初から）/ 存档放在这个文件夹的 save 里（删除就从头开始）
export TANK_SAVE_DIR="$HERE/save"
chmod +x "$HERE/server/bin/desktop" 2>/dev/null
nohup "$HERE/server/bin/desktop" "$PORT" "$HERE/web" > "$HERE/server.log" 2>&1 &
echo "サーバーを起動中… / 正在启动服务器…"
ok=0
for i in $(seq 1 60); do
  if nc -z 127.0.0.1 "$PORT" 2>/dev/null; then ok=1; break; fi
  sleep 0.5
done
if [ "$ok" != 1 ]; then
  echo "[!] サーバーが起動しません。server.log を見てください / 服务器没有启动，请查看 server.log"
  tail -20 "$HERE/server.log"
  read -r -p "Enter" _
  exit 1
fi

# 4) ブラウザで開く（Chrome があれば Chrome。テレビへのキャストに使う）/ 用浏览器打开（有 Chrome 就用 Chrome）
if [ -d "/Applications/Google Chrome.app" ]; then open -a "Google Chrome" "$URL"; else open "$URL"; fi

echo ""
echo "ゲームを開きました：$URL"
echo "- 全画面：Chrome なら control + command + F"
echo "- テレビへ：HDMI でつなぐ。または Chrome の「⋮」→「キャスト」→ テレビ（タブをキャスト）"
echo "- スマホ：Mac と同じ Wi-Fi で、画面の QR を読む"
echo "- 音がテレビから出ない：システム設定 → サウンド → 出力 でテレビを選ぶ"
echo "- 止める：STOP_GAME.command をダブルクリック"
echo ""
echo "游戏已打开：$URL"
echo "- 全屏：Chrome 按 control + command + F"
echo "- 到电视：用 HDMI 连接。或 Chrome「⋮」→「投放」→ 电视（投放标签页）"
echo "- 手机：连同一个 Wi-Fi，扫画面上的二维码"
echo "- 电视没声音：系统设置 → 声音 → 输出 选电视"
echo "- 停止：双击 STOP_GAME.command"
echo ""
if [ "${TANK_TLS:-1}" != 0 ]; then
  echo "🎤 こえで こたえる：テレビの『🎤 こえの じゅんび』を ひらく（はじめの 1 回だけ、きく ための データ 約 180 MB を ダウンロードします）"
  echo "🎤 用声音回答：打开电视上的『🎤 声音准备』（第一次会下载约 180 MB 的识别数据）"
  echo "   （java の「受信を許可しますか？」が出たら「許可」/ 如果出现 java「是否允许传入连接？」请点「允许」）"
  echo ""
fi
echo "（このウィンドウは閉じても大丈夫です / 这个窗口可以关闭）"

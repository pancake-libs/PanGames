#!/bin/bash
# familyplay（おうちを守れ！戦車隊・どうぶつ大合戦・ひかりの木をまもれ！）Mac 版の起動。
# ダブルクリックで、ゲームのサーバーを起動し、ブラウザでテレビ用の画面（ゲームえらび）を開く。
# 家庭用 Mac 起動脚本：启动游戏服务器，并用浏览器打开电视画面（选游戏）。
cd "$(dirname "$0")" || exit 1
HERE="$(pwd)"
PORT=8090
URL="http://127.0.0.1:$PORT/menu.html"

echo "== familyplay（Mac）=="

# 1) Java 21 以上があるか / 检查 Java 21+
if [ -x /usr/libexec/java_home ] && JH="$(/usr/libexec/java_home -v 21+ 2>/dev/null)"; then
  export JAVA_HOME="$JH"
else
  echo ""
  echo "[!] Java 21 が見つかりません。Temurin 21 を入れてから、もう一度ダブルクリックしてください。"
  echo "[!] 没有找到 Java 21。请先安装 Temurin 21，然后再双击一次。"
  echo "    https://adoptium.net/temurin/releases/?os=mac&version=21&package=jdk"
  open "https://adoptium.net/temurin/releases/?os=mac&version=21&package=jdk"
  read -r -p "Enter で閉じる / 按 Enter 关闭 " _
  exit 1
fi
echo "Java: $JAVA_HOME"

# 2) 前のサーバーを止める（ポート 8090 の java だけ）/ 停止旧的服务器
for pid in $(lsof -ti "tcp:$PORT" -sTCP:LISTEN 2>/dev/null); do
  if ps -p "$pid" -o comm= | grep -qi java; then kill "$pid" 2>/dev/null && echo "前のサーバーを止めました / 已停止旧服务器 (PID $pid)"; sleep 1
  else echo "[!] ポート $PORT をほかのアプリが使っています / 端口 $PORT 被其他应用占用：$(ps -p "$pid" -o comm=)"; read -r -p "Enter" _; exit 1; fi
done

# 3) サーバーを起動 / 启动服务器
export JAVA_OPTS="-Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8"
chmod +x "$HERE/server/bin/desktop" 2>/dev/null
nohup "$HERE/server/bin/desktop" "$PORT" "$HERE/web" > "$HERE/server.log" 2>&1 &
echo "サーバーを起動中… / 正在启动服务器…"
ok=0
for i in $(seq 1 60); do
  if nc -z 127.0.0.1 "$PORT" 2>/dev/null; then ok=1; break; fi
  sleep 0.5
done
if [ "$ok" != 1 ]; then
  echo "[!] サーバーが起動しません。server.log を見てください / 服务器没有启动，请查看 server.log"
  tail -20 "$HERE/server.log"
  read -r -p "Enter" _
  exit 1
fi

# 4) ブラウザで開く（Chrome があれば Chrome。テレビへのキャストに使う）/ 用浏览器打开（有 Chrome 就用 Chrome）
if [ -d "/Applications/Google Chrome.app" ]; then open -a "Google Chrome" "$URL"; else open "$URL"; fi

echo ""
echo "ゲームを開きました：$URL"
echo "- 全画面：Chrome なら control + command + F"
echo "- テレビへ：HDMI でつなぐ。または Chrome の「⋮」→「キャスト」→ テレビ（タブをキャスト）"
echo "- スマホ：Mac と同じ Wi-Fi で、画面の QR を読む"
echo "- 止める：STOP_GAME.command をダブルクリック"
echo ""
echo "游戏已打开：$URL"
echo "- 全屏：Chrome 按 control + command + F"
echo "- 到电视：用 HDMI 连接。或 Chrome「⋮」→「投放」→ 电视（投放标签页）"
echo "- 手机：连同一个 Wi-Fi，扫画面上的二维码"
echo "- 停止：双击 STOP_GAME.command"
echo ""
echo "（このウィンドウは閉じても大丈夫です / 这个窗口可以关闭）"

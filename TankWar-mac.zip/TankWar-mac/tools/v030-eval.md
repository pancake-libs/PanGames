# v030-eval (design 13.4)

Checks the v0.30 LLM judges `tone` (k/b/f/n) and `hit` (0/1) with `tools/chat-eval30.json` (100 tone + 60 hit utterances) on Ollama, and re-runs a slice of the v0.29 set (`tools/chat-eval.json`) with the old and the new prompt to show that `cat` accuracy did not drop.

```
node tools/v030-eval.mjs                       # qwen3:8b
node tools/v030-eval.mjs --compare             # qwen3:8b / 14b / gemma3:12b (asks before pulling)
node tools/v030-eval.mjs --model qwen3:14b --n 20 --reg-n 20   # quick try
node tools/v030-eval.mjs --fake                # no network; tests the script only
```

Options: `--engine FILE` (default `../web/talk-engine.js`; its `buildPrompt/parseTurn/checkTurn` are used), `--topics PATH` (v0.30 topics with `notes`: a `talk30-lines.json` or a folder of `<boss>30.json`; default `tools/talk30-lines.json` (next to the script; the Mac kit's `tools\` holds it too); without them a generic beat is used), `--lines`, `--eval`, `--v029`, `--models`, `--reg-n N` (v0.29 cases, default 60, 0 = skip), `--n N`, `--out DIR`, `--report FILE`, `--host`, `--timeout`, `--yes`. `--dry` = `--fake`.

If the engine's prompt has no judge rules yet (engine < v1.1), the tool appends rules 13-15 and the topic notes itself and says so in the report; with v1.1 the engine's own text is used. The request schema is built here (order `cat, tone, hit, ja, zh, mood`). Invalid judge values count as `none` (J2).

Guides: tone agreement >= 70%, hit right >= 80%, false hits <= 15%, added time <= +0.5 s, v0.29 cat accuracy drop <= 2 points. Below the tone/hit guide the report names the fallback (`frame.judges.<name>.use = "kw"`). Output: `OUT/v030-report-*.md/.json` and a text summary appended to `OUT/eval-report.txt` (`--report`).

CHECK_AI.command step (after the v0.29 step):

```bash
if [ -n "$NODE" ] && [ -f "$HERE/tools/v030-eval.mjs" ] && [ "$OLLAMA_OK" = 1 ]; then
  echo "---- tone / hit テスト（v030-eval.mjs ${ARGS[*]}）----"
  "$NODE" "$HERE/tools/v030-eval.mjs" "${ENGINE_ARG[@]}" --out "$OUT" --report "$HERE/eval-report.txt" "${ARGS[@]}"
fi
```

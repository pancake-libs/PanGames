#!/usr/bin/env node
// v029-voice.mjs -- is VOICEVOX up, and how fast does it speak a few lines per boss? (design 13.4) Node 22, no deps.
//   node v029-voice.mjs [chat-scripts.json | content-folder] [--lines 5] [--boss ID] [--play] [--out DIR] [--url URL] [--dry]
// chat-scripts.json = array of { id, who, boxes:[{ ja, who?, char?, style?, speedScale?, pitchScale?, intonationScale? }] } (boss-scripts shape).
// A folder of per-boss content files (chat-lines format) also works; the voice table below is used then.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2), flag = new Set(), opt = {}, pos = [];
for (let i = 0; i < argv.length; i++) { const a = argv[i]; if (a.startsWith('--')) { const k = a.slice(2); if (['lines', 'boss', 'out', 'url'].includes(k)) opt[k] = argv[++i]; else flag.add(k); } else pos.push(a); }
const DRY = flag.has('dry');
const URL_ = (opt.url || process.env.VV_URL || 'http://127.0.0.1:50021').replace(/\/$/, '');
const PER = Number(opt.lines) || 5;
const OUT = path.resolve(opt.out || 'voice-out');
const norm = s => String(s || '').normalize('NFKC').replace(/\s+/g, '').toLowerCase();

// who -> VOICEVOX character / style / speed / pitch / intonation (design 8.5)
const VOICES = {
  bigtank:  ['青山龍星', 'しっとり', 0.92, -0.03, 0.95],
  sandship: ['麒ヶ島宗麟', 'ノーマル', 1.00, -0.02, 1.20],
  snowman:  ['ずんだもん', 'ノーマル', 1.05, 0, 1.20],
  snowkid:  ['櫻歌ミコ', 'ロリ', 1.00, 0.05, 1.20],
  dragon:   ['ちび式じい', 'ノーマル', 0.92, -0.02, 1.15],
  core:     ['ナースロボ＿タイプＴ', 'ノーマル', 0.92, 0, 0.80],
  king:     ['剣崎雌雄', 'ノーマル', 0.92, -0.03, 1.00] };
const BOSSES = ['bigtank', 'sandship', 'snowman', 'dragon', 'core', 'king'];

function loadScripts(p) {
  const cands = p ? [p] : [path.join(HERE, '../tools/chat-scripts.json'), path.join(HERE, 'chat-scripts.json'), path.join(HERE, '../content')];
  const f = cands.find(c => fs.existsSync(c));
  if (!f) throw new Error('chat-scripts.json not found (tried ' + cands.join(', ') + ')');
  if (fs.statSync(f).isDirectory()) {                                  // build scripts from the per-boss content files
    const out = [];
    for (const b of BOSSES) {
      const fp = path.join(f, b + '.json'); if (!fs.existsSync(fp)) continue;
      const d = JSON.parse(fs.readFileSync(fp, 'utf8')), boxes = [];
      for (const k of ['hi', 'think', 'huh', 'dunno', 'bad']) for (const l of d.fixed[k] || []) boxes.push({ ja: l.ja });
      for (const k of ['stop', 'check', 'bye', 'byeWarm']) if (d.fixed[k]) boxes.push({ ja: d.fixed[k].ja });
      for (const t of d.topics.slice(0, 1)) for (const be of t.beats.slice(0, 3)) { boxes.push({ ja: be.q.ja }); if (be.cats[0]) boxes.push({ ja: be.cats[0].re.ja }); }
      out.push({ id: b + '_fixed', who: b, boxes });
    }
    return { scripts: out, src: f };
  }
  const j = JSON.parse(fs.readFileSync(f, 'utf8'));
  return { scripts: Array.isArray(j) ? j : j.scripts || [], src: f };
}
const baseWho = s => String(s || '').split('+')[0];

const get = async (p, ms = 8000) => (await fetch(URL_ + p, { signal: AbortSignal.timeout(ms) }));
const post = async (p, body, ms = 60000) => fetch(URL_ + p, { method: 'POST', headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(ms) });

// ---- fake engine for --dry (deterministic; wav = silence of 0.07 s per character)
function fakeSpeakers() {
  return Object.values(VOICES).map(([name, style], i) => ({ name, styles: [{ name: style, id: 100 + i }, { name: 'ノーマル', id: 200 + i }] })).concat([{ name: 'ずんだもん', styles: [{ name: 'ノーマル', id: 3 }] }]);
}
async function fakeSynth(text) {
  await new Promise(r => setTimeout(r, 5));
  const n = Math.round(24000 * 0.07 * text.length), b = Buffer.alloc(44 + n * 2);
  b.write('RIFF', 0); b.writeUInt32LE(36 + n * 2, 4); b.write('WAVEfmt ', 8); b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22);
  b.writeUInt32LE(24000, 24); b.writeUInt32LE(48000, 28); b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34); b.write('data', 36); b.writeUInt32LE(n * 2, 40);
  return b;
}
const wavSec = b => (b.length - 44) / (b.length > 31 ? b.readUInt32LE(28) : 48000);

function findSpeaker(speakers, ch, st) {
  const c = speakers.find(s => norm(s.name) === norm(ch)) || speakers.find(s => norm(s.name).includes(norm(ch)) || norm(ch).includes(norm(s.name)));
  if (!c) return null;
  const s = c.styles.find(x => norm(x.name) === norm(st)) || c.styles.find(x => norm(x.name) === 'ノーマル') || c.styles[0];
  return { id: s.id, name: c.name, style: s.name, exact: norm(s.name) === norm(st) };
}
const median = a => { const s = [...a].sort((x, y) => x - y); return s.length ? s[Math.floor((s.length - 1) / 2)] : null; };

(async () => {
  console.log(`v029-voice: engine ${DRY ? '(DRY: fake engine)' : URL_}`);
  let speakers, version = 'dry';
  if (DRY) speakers = fakeSpeakers();
  else {
    try { version = await (await get('/version')).json(); speakers = await (await get('/speakers')).json(); }
    catch (e) { console.error(`\nVOICEVOX is not reachable at ${URL_} (${e.message}).\nStart the VOICEVOX app (or its engine) and run again.`); process.exit(3); }
  }
  console.log(`  engine version ${version}, ${speakers.length} speakers`);
  const { scripts, src } = loadScripts(pos[0]);
  console.log(`  scripts: ${src}`);
  fs.mkdirSync(OUT, { recursive: true });

  const lines = [], missing = new Set(), rows = [];
  const bosses = opt.boss ? [opt.boss] : BOSSES;
  let firstDone = false;
  for (const boss of bosses) {
    // collect this boss's boxes (own script ids / who), spread evenly, PER lines
    const boxes = [];
    for (const sc of scripts) {
      const w = baseWho(sc.who || String(sc.id).split('_')[0]);
      if (w !== boss && !String(sc.id).startsWith(boss + '_')) continue;
      for (const b of sc.boxes || []) if (b.ja && (!b.who || baseWho(b.who) === boss || b.who === boss)) boxes.push({ ...b, sc });
    }
    if (!boxes.length) { console.log(`  ${boss}: no lines in the scripts`); rows.push({ boss, n: 0 }); continue; }
    const step = boxes.length / Math.min(PER, boxes.length);
    const pick = Array.from({ length: Math.min(PER, boxes.length) }, (_, i) => boxes[Math.floor(i * step)]);
    const v = VOICES[boss] || [];
    const ch = pick[0].char && !/box/.test(pick[0].char) ? pick[0].char : v[0], st = pick[0].style && !/box/.test(pick[0].style) ? pick[0].style : v[1];
    const sp = findSpeaker(speakers, ch, st);
    if (!sp) { missing.add(`${boss}: ${ch} / ${st}`); console.log(`  ${boss}: MISSING voice ${ch} / ${st}`); rows.push({ boss, missing: true }); continue; }
    if (!sp.exact) lines.push(`${boss}: style "${st}" missing, using "${sp.style}"`);
    if (!DRY) { try { await post(`/initialize_speaker?speaker=${sp.id}&skip_reinit=true`, null, 120000); } catch {} }
    const times = [], secs = [], perChar = [];
    console.log(`\n  ${boss}  (${sp.name} / ${sp.style})`);
    for (let i = 0; i < pick.length; i++) {
      const b = pick[i], text = String(b.ja).replace(/[ 　]+/g, '');
      const t0 = performance.now(); let wav, err = null;
      try {
        if (DRY) wav = await fakeSynth(text);
        else {
          const q = await (await post(`/audio_query?speaker=${sp.id}&text=${encodeURIComponent(text)}`)).json();
          q.speedScale = b.speedScale ?? b.sc.speedScale ?? v[2] ?? 1; q.pitchScale = b.pitchScale ?? b.sc.pitchScale ?? v[3] ?? 0; q.intonationScale = b.intonationScale ?? b.sc.intonationScale ?? v[4] ?? 1;
          q.outputSamplingRate = 24000; q.outputStereo = false; q.prePhonemeLength = 0.05; q.postPhonemeLength = 0.1;
          const r = await post(`/synthesis?speaker=${sp.id}`, q);
          if (!r.ok) throw new Error('synthesis HTTP ' + r.status);
          wav = Buffer.from(await r.arrayBuffer());
        }
      } catch (e) { err = e.message; }
      const ms = performance.now() - t0;
      if (err) { console.log(`    ${i + 1}. FAILED ${err}  「${text}」`); lines.push(`${boss} line ${i + 1}: ${err}`); continue; }
      const sec = wavSec(wav), file = path.join(OUT, `${boss}_${i + 1}.wav`);
      fs.writeFileSync(file, wav);
      // the first synthesis of a session is slower (model load); it is flagged, not hidden
      const tag = (!firstDone && i === 0) ? ' (first call of the run)' : '';
      firstDone = true;
      times.push(ms); secs.push(sec); perChar.push(ms / 1000 / Math.max(1, text.length));
      console.log(`    ${i + 1}. ${(ms / 1000).toFixed(2)} s for ${sec.toFixed(1)} s of speech  「${text.slice(0, 24)}${text.length > 24 ? '…' : ''}」${tag}`);
      if (flag.has('play') && !DRY) { const player = os.platform() === 'darwin' ? 'afplay' : 'aplay'; spawnSync(player, [file], { stdio: 'ignore' }); }
    }
    rows.push({ boss, voice: `${sp.name}/${sp.style}`, n: times.length, medMs: Math.round(median(times)), maxMs: Math.round(Math.max(...times, 0)), speechSec: Math.round(10 * secs.reduce((a, b) => a + b, 0)) / 10, rtf: secs.length ? Math.round(100 * times.reduce((a, b) => a + b, 0) / 1000 / secs.reduce((a, b) => a + b, 0)) / 100 : null });
  }
  console.log('\n  boss       voice                          n  median s  max s  speech s  time/speech');
  for (const r of rows) console.log('  ' + String(r.boss).padEnd(10) + ' ' + String(r.voice || (r.missing ? 'MISSING' : '-')).padEnd(30) + ' ' + String(r.n ?? 0).padStart(2) + '  ' + (r.medMs != null ? (r.medMs / 1000).toFixed(2) : '-').padStart(8) + '  ' + (r.maxMs != null ? (r.maxMs / 1000).toFixed(2) : '-').padStart(5) + '  ' + String(r.speechSec ?? '-').padStart(8) + '  ' + String(r.rtf ?? '-').padStart(10));
  if (missing.size) console.log('\n  missing characters:\n' + [...missing].map(x => '    - ' + x).join('\n'));
  if (lines.length) console.log('\n  notes:\n' + lines.map(x => '    - ' + x).join('\n'));
  const ok = rows.filter(r => r.n).length, med = median(rows.filter(r => r.medMs != null).map(r => r.medMs));
  console.log(`\n  ${ok}/${bosses.length} bosses voiced${med != null ? `, median ${(med / 1000).toFixed(2)} s per line` : ''}. wav files: ${OUT}`);
  fs.writeFileSync(path.join(OUT, 'voice-report.json'), JSON.stringify({ date: new Date().toISOString(), dry: DRY, url: URL_, version, rows, missing: [...missing], notes: lines }, null, 1));
  process.exit(missing.size || ok < bosses.length ? 5 : 0);
})().catch(e => { console.error('ERROR: ' + e.message); process.exit(1); });

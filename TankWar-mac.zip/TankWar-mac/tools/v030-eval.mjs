#!/usr/bin/env node
// v030-eval.mjs -- LLM check for the v0.30 judges "tone" and "hit" (design 13.4). Node 22, no dependencies.
//
//   node tools/v030-eval.mjs [options]
//     --eval FILE      chat-eval30.json (default: next to this script)
//     --models FILE    chat-models.json (default: next to this script)
//     --model TAG      one model (default: the default of chat-models.json)
//     --compare        every model in compare_default (--all: incl. reserve); missing ones are pulled after y/N
//     --engine FILE    talk-engine.js whose buildPrompt/parseTurn/checkTurn are used (default: ../web/talk-engine.js)
//     --lines FILE     v0.29 chat-lines.json (personas + v0.29 topics; default ../tools/chat-lines.json)
//     --topics PATH    v0.30 topics (a talk30-lines.json, or a folder of <boss>30.json); default: talk30-lines.json next to
//                      this script (= tools/talk30-lines.json in the repo and in the Mac kit), else a built-in generic beat
//     --v029 FILE      chat-eval.json of v0.29 for the "did cat accuracy drop?" re-run (default: next to this script)
//     --n N            at most N tone and N hit cases (evenly spread)         --reg-n N   v0.29 cases for the re-run (default 60, 0 = skip)
//     --host URL       Ollama (default http://127.0.0.1:11434)    --timeout SEC (default 30)
//     --out DIR        report folder (default ./eval-out)         --report FILE  text report appended to (default OUT/eval-report.txt)
//     --yes            pull missing models without asking
//     --fake           no network: deterministic fake responder (tests the script only; numbers mean nothing). --dry is the same
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);

// ---------------------------------------------------------------- args
const argv = process.argv.slice(2);
const flag = new Set(), opt = {};
const VALUE = new Set(['eval', 'models', 'model', 'engine', 'lines', 'topics', 'v029', 'n', 'reg-n', 'host', 'timeout', 'out', 'report']);
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a.startsWith('--')) { const k = a.slice(2); if (VALUE.has(k)) opt[k] = argv[++i]; else flag.add(k); }
}
const FAKE = flag.has('fake') || flag.has('dry');
const HOST = (opt.host || process.env.OLLAMA_HOST_URL || 'http://127.0.0.1:11434').replace(/\/$/, '');
const TIMEOUT = (Number(opt.timeout) || 30) * 1000;
const OUT = path.resolve(opt.out || 'eval-out');
const REPORT = path.resolve(opt.report || path.join(OUT, 'eval-report.txt'));
const rj = f => JSON.parse(fs.readFileSync(f, 'utf8'));
const first = list => list.find(p => fs.existsSync(p));
const nsp = s => String(s || '').replace(/[ 　]/g, '');
const BOSSES = ['snowman', 'bigtank', 'sandship', 'dragon', 'core', 'king'];

// ---------------------------------------------------------------- engine (the game's own prompt builder)
const enginePath = path.resolve(opt.engine || path.join(HERE, '../web/talk-engine.js'));
let ENG;
try {
  const m = require(enginePath); const e = m.TalkEngine || m;
  for (const k of ['buildPrompt', 'parseTurn', 'checkTurn']) if (typeof e[k] !== 'function') throw new Error(k + ' missing');
  ENG = e;
} catch (e) { console.error(`engine not usable (${enginePath}): ${e.message}\nPass --engine path/to/talk-engine.js`); process.exit(2); }

// ---------------------------------------------------------------- data
const linesPath = first([opt.lines, path.join(HERE, 'chat-lines.json'), path.join(HERE, '../tools/chat-lines.json')].filter(Boolean));
if (!linesPath) { console.error('chat-lines.json (v0.29 personas) not found; pass --lines'); process.exit(2); }
const LINES = rj(linesPath);
const evalPath = opt.eval || path.join(HERE, 'chat-eval30.json');
const EV = rj(evalPath);

function loadTopics() {      // -> { boss: { topicId: topic } }
  const out = {};
  const add = (boss, d) => { if (!boss || !Array.isArray(d.topics)) return; out[boss] = out[boss] || {}; for (const t of d.topics) if (t && t.id) out[boss][t.id] = t; };
  const cands = opt.topics ? [opt.topics] : [path.join(HERE, 'talk30-lines.json')];   // v0.30 統合：tools/talk30-lines.json（キットの tools\ にも 入れる）
  const found = first(cands); if (!found) return { src: null, out };
  const files = fs.statSync(found).isDirectory() ? fs.readdirSync(found).filter(f => /30\.json$/.test(f) && !/shared|eval|post/.test(f)).map(f => path.join(found, f)) : [found];
  for (const f of files) { const d = rj(f); if (d.bosses) for (const [b, v] of Object.entries(d.bosses)) add(b, v); else add(d.boss, d); }
  return { src: found, out };
}
const T30 = loadTopics();

// judge rules (design 7.3); a data.frame.judges.<name>.rule from the game data wins over these
const JUDGES = (LINES.frame && LINES.frame.judges) || {};
const RULE = {
  tone: '"tone"：こどもの ことばの かんじ。やさしい・おもいやり・だれかの ため → "k"／ゆうき・がんばる・まもる・ちょうせん → "b"／おもしろい・たのしく ふざける・わらえる → "f"／どれでも ない → "n"。まよったら "n"。',
  hit: '"hit"：こどもの ことばが、したの「こころの なか」の ねがい か しんぱいに ふれて いたら 1。ちがえば 0。まよったら 0。',
  hitAid: '"hit"：こどもの アイデアが、こまりごとを ほんとうに たすけそう なら 1。ちがえば 0。まよったら 0。',
  secret: '「こころの なか」は {name} の ひみつ。その まま おしえない。きかれたら「それは…ひみつ」と かるく ながす。こどもが ふれて くれたら、うれしそうに うけとめる。'
};
const TONES = ['k', 'b', 'f', 'n'];

// build the (sheet, topic, beat) for a boss + topic id; falls back to a generic open beat
function sheetFor(boss, topicId, c) {
  const bd = LINES.bosses[boss]; if (!bd) throw new Error('no persona for boss ' + boss);
  let topic = T30.out[boss]?.[topicId];
  let real = !!topic;
  if (!topic) topic = { id: topicId, title: [topicId === 'aid' ? 'おねがい' : 'はなす'], notes: c?.notes || [], beats: [] };
  let beat = (topic.beats || []).find(b => b.type === 'open' && (b.judge || []).includes('hit')) || (topic.beats || []).find(b => b.type === 'open');
  if (!beat) beat = { id: 'bx', type: 'open', q: { ja: (c?.ctx || 'どう おもう？').replace(/\s*\(.*$/, '') }, cats: [{ id: 'a', ja: 'うん', zh: '嗯' }, { id: 'b', ja: 'ううん', zh: '不' }] };
  return { sheet: { persona: bd.persona, topics: [topic] }, topic, beat, real };
}

// ---------------------------------------------------------------- prompt for one case
// arm 'base' = v0.29 prompt (no judge), arm 'new' = v0.30: judge rules + notes + the longer schema
function buildCase(arm, spec) {
  const { sheet, topic, beat0 } = spec;
  const beat = { ...beat0, judge: arm === 'new' ? (spec.judge || ['hit', 'tone']) : [] };
  const ctx = { sheet, topic, beat, next: null, last: false, memory: [], history: [], lang: spec.lang, heard: { text: spec.text, lang: spec.lang, speaker: 1 } };
  const data = { ...LINES, frame: { ...(LINES.frame || {}), judges: Object.keys(JUDGES).length ? JUDGES : undefined } };
  const bp = ENG.buildPrompt(data, ctx);
  let note = null;
  if (arm === 'new') {
    if (!/"tone"/.test(bp.sys)) {      // engine without the v1.1 additions: append the same text the engine will add
      const name = sheet.persona.name[0], isAid = spec.kind === 'aid';
      const rules = [`13. ${JUDGES.tone?.rule || RULE.tone}`, `14. ${(isAid ? (JUDGES.hit?.ruleAid || RULE.hitAid) : (JUDGES.hit?.rule || RULE.hit))}`, `15. ${RULE.secret.replace('{name}', name)}`];
      const notes = (topic.notes || []).slice(0, 5).map(n => '・' + n);
      bp.sys += '\n\n# つけたす きまり\n' + rules.join('\n') + (notes.length ? `\n\n# ${name} の こころの なか\n` + notes.join('\n') : '');
      note = 'appended-by-eval';
    }
  }
  return { bp, note };
}
const schema = (cats, arm) => {
  const props = { cat: { type: 'string', enum: [...cats, 'other', 'unclear', 'stop', 'bad'] } };
  if (arm === 'new') { props.tone = { type: 'string', enum: TONES }; props.hit = { type: 'integer', enum: [0, 1] }; }
  Object.assign(props, { ja: { type: 'string', maxLength: 60 }, zh: { type: 'string', maxLength: 40 }, mood: { type: 'integer', enum: [-1, 0, 1] } });
  return { type: 'object', additionalProperties: false, required: Object.keys(props), properties: props };
};

// ---------------------------------------------------------------- model calls
async function ollama(pathname, body, timeout = TIMEOUT, method = 'POST') {
  const r = await fetch(HOST + pathname, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(timeout) });
  if (!r.ok) throw new Error(`HTTP ${r.status} ${(await r.text()).slice(0, 200)}`);
  return r;
}
async function callOllama(model, bp, info, arm) {
  const body = { model, stream: false, keep_alive: '30m', format: schema(bp.cats, arm),
    messages: [{ role: 'system', content: bp.sys }, ...bp.msgs],
    options: { temperature: 0.6, top_p: 0.9, repeat_penalty: 1.1, num_predict: arm === 'new' ? 140 : 120, num_ctx: 4096 } };
  if (info?.think !== null && info?.think !== undefined) body.think = info.think; else if (/^qwen3/.test(model)) body.think = false;
  const t0 = performance.now();
  const r = await (await ollama('/api/chat', body)).json();
  return { raw: r.message?.content ?? '', ms: performance.now() - t0 };
}

// fake responder: deterministic, mostly right, with injected faults so every scoring path runs
function hashN(s) { let h = 2166136261; for (const ch of s) { h ^= ch.codePointAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
const FK = { k: /ないて|だいじょうぶ|ありがとう|ごめん|いっしょ|はんぶん|たすけ|そば|あげる|やさし|安慰|谢谢|对不起|别哭|陪|分你/, b: /がんばる|まもる|ゆうき|たたかう|まけない|ちょうせん|こわくない|勇敢|保护|加油|挑战|不怕/, f: /あはは|わらう|おもしろ|へん|ぶー|おなら|うんち|ダンス|ぎゃー|哈哈|好玩|搞笑|笑|跳舞/ };
function fakeCall(model, id, arm, spec, bp) {
  const h = hashN(model + id + arm), q = h % 100, t = spec.text;
  let tone = 'n'; for (const k of TONES.slice(0, 3)) if (FK[k].test(t)) { tone = k; break; }
  const kw = (spec.beat0.cats || []).find(c => (c.kw?.[spec.lang] || c.kw?.ja || []).some(k => k && nsp(t).includes(nsp(k))));
  let cat = spec.kind === 'v029' ? (kw ? kw.id : /やめる|かえりたい|回家|ないちゃ/.test(t) ? 'stop' : /ばか|しね|笨蛋|去死/.test(t) ? 'bad' : 'other') : 'other';
  let hit = spec.expectHit ?? (/いっしょ|そば|まもる|とけても|つくって|ひやす|すずし|一起|陪/.test(t) ? 1 : 0);
  if (q < 20) tone = TONES[h % 4];                       // some wrong tones
  if (q % 7 === 0) hit = 1 - hit;                        // some wrong hits
  if (q < 7 && spec.kind === 'v029' && !['stop', 'bad'].includes(cat)) cat = 'other';
  const o = { cat }; if (arm === 'new') { o.tone = q === 50 ? 'x' : tone; o.hit = q === 51 ? 'yes' : hit; }
  Object.assign(o, { ja: 'いいね！ たのしそう！', zh: '嗯，真有意思', mood: 1 });
  let raw = JSON.stringify(o);
  if (q === 97) raw = raw.slice(0, 40);
  if (q === 98) raw = 'はい。' + raw;
  const ms = (/14b|12b/.test(model) ? 4200 : 2600) + (h % 1500) + (arm === 'new' ? 300 : 0);
  return { raw, ms };
}

// ---------------------------------------------------------------- scoring
function parseJudges(raw) {      // -> { tone, hit, toneValid, hitValid }  (J2: anything outside the list = none)
  let t = String(raw || '').replace(/<think>[\s\S]*?(<\/think>|$)/gi, '').replace(/```(?:json)?/gi, '');
  let o = null;
  const i = t.indexOf('{'), j = t.lastIndexOf('}');
  if (i >= 0) { try { o = JSON.parse(t.slice(i, j > i ? j + 1 : undefined)); } catch { /* regex below */ } }
  let tone = o ? o.tone : (t.match(/["']?tone["']?\s*:\s*["']([^"']*)["']/) || [])[1];
  let hit = o ? o.hit : (() => { const m = t.match(/["']?hit["']?\s*:\s*(-?\d+)/); return m ? +m[1] : undefined; })();
  const toneValid = typeof tone === 'string' && TONES.includes(tone);
  const hitValid = (hit === 0 || hit === 1);
  return { tone: toneValid ? tone : 'n', hit: hitValid ? hit : 0, toneValid, hitValid };
}
function evalCat(spec, bp, raw) {
  let strict = false; try { const o = JSON.parse(raw); strict = !!o && 'cat' in o && 'ja' in o; } catch { /* not json */ }
  const turn = ENG.parseTurn(raw);
  const cards = (spec.beat0.cats || []).map(c => c.id);
  const chk = turn.ok ? ENG.checkTurn(turn, { cats: bp.cats, cards, jaKana: '', ng: LINES.ng, allow: LINES.allow, names: [], last2: [], pick: null, m: null, sc: 0, writtenZh: '' }) : { ok: false, rule: 'G1' };
  // G8: bad/stop lines are replaced by a fixed line, so they count as passing
  const guardOk = chk.ok || (chk.rule === 'G8');
  return { strict, parsed: !!turn.ok, got: turn.ok ? turn.cat : null, guardOk, rule: chk.ok ? null : chk.rule };
}

const pct = (a, b) => b ? Math.round(1000 * a / b) / 10 : null;
const avg = a => a.length ? a.reduce((x, y) => x + y, 0) / a.length : null;
const quant = (arr, p) => { if (!arr.length) return null; const s = [...arr].sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.ceil(p * s.length) - 1)]; };

// ---------------------------------------------------------------- cases
function spread(list, n) { if (!n || +n >= list.length) return list; const step = list.length / +n; return Array.from({ length: +n }, (_, i) => list[Math.floor(i * step)]); }
function toneSpecs() {
  const cases = spread(EV.tone || [], opt.n);
  return cases.map((c, i) => {
    const boss = BOSSES[i % BOSSES.length], s = sheetFor(boss, 'pv', c);
    return { id: 'tone' + String(i + 1).padStart(3, '0'), kind: 'tone', boss, lang: c.lang || 'ja', text: c.text, expectTone: c.tone, ...s, beat0: s.beat, judge: ['tone'] };
  });
}
function hitSpecs() {
  const cases = spread(EV.hit || [], opt.n);
  return cases.map((c, i) => {
    const s = sheetFor(c.boss, c.topic, c);
    return { id: 'hit' + String(i + 1).padStart(3, '0'), kind: c.topic === 'aid' ? 'aid' : 'pv', boss: c.boss, ...s, topicId: c.topic, lang: c.lang || 'ja', text: c.text, expectHit: c.hit, beat0: s.beat, judge: ['hit', 'tone'] };
  });
}
function regSpecs() {
  const n = opt['reg-n'] === undefined ? 60 : +opt['reg-n'];
  const p = first([opt.v029, path.join(HERE, 'chat-eval.json')].filter(Boolean));
  if (!n || !p) return [];
  const cases = spread(rj(p).cases.filter(c => LINES.bosses[c.boss]), n);
  return cases.map(c => {
    const topic = LINES.bosses[c.boss].topics[c.topic || 0], beat0 = topic.beats.find(b => b.id === c.beat);
    return { id: c.id, kind: 'v029', boss: c.boss, lang: c.lang, text: c.child, expect: c.expect, group: c.group,
      sheet: { persona: LINES.bosses[c.boss].persona, topics: [topic] }, topic, beat0, judge: ['hit', 'tone'] };
  });
}

// ---------------------------------------------------------------- run one model
async function run(model, info, tone, hit, reg) {
  const rows = { tone: [], hit: [], reg: [] }, tot = tone.length + hit.length + reg.length * 2;
  let done = 0, appended = false;
  const call = async (spec, arm) => {
    const { bp, note } = buildCase(arm, spec); if (note) appended = true;
    let res, err = null;
    try { res = FAKE ? fakeCall(model, spec.id, arm, spec, bp) : await callOllama(model, bp, info, arm); } catch (e) { err = e.message; res = { raw: '', ms: TIMEOUT }; }
    if (!FAKE && ++done % 10 === 0) process.stdout.write(`\r  ${model}: ${done}/${tot}`);
    return { bp, res, err };
  };
  for (const s of tone) {
    const { bp, res, err } = await call(s, 'new'), j = parseJudges(res.raw), c = evalCat(s, bp, res.raw);
    rows.tone.push({ id: s.id, boss: s.boss, lang: s.lang, text: s.text, expect: s.expectTone, got: j.tone, valid: j.toneValid, ok: j.tone === s.expectTone, cat: c.got, ms: Math.round(res.ms), err });
  }
  for (const s of hit) {
    const { bp, res, err } = await call(s, 'new'), j = parseJudges(res.raw), c = evalCat(s, bp, res.raw);
    rows.hit.push({ id: s.id, boss: s.boss, topic: s.topicId, text: s.text, expect: s.expectHit, got: j.hit, valid: j.hitValid, ok: j.hit === s.expectHit, cat: c.got, ms: Math.round(res.ms), err });
  }
  for (let i = 0; i < reg.length; i++) {      // alternate the two arms so a warming/throttling Mac does not bias the time
    const s = reg[i], order = i % 2 ? ['new', 'base'] : ['base', 'new'], r = {};
    for (const arm of order) {
      const { bp, res, err } = await call(s, arm), c = evalCat(s, bp, res.raw);
      r[arm] = { catOk: c.parsed && s.expect.includes(c.got), strict: c.strict, parsed: c.parsed, guardOk: c.guardOk, ms: Math.round(res.ms), err };
    }
    rows.reg.push({ id: s.id, boss: s.boss, group: s.group, child: s.text, expect: s.expect, ...r });
  }
  if (!FAKE) process.stdout.write('\r' + ' '.repeat(50) + '\r');
  return summarize(model, rows, appended);
}

function summarize(model, rows, appended) {
  const T = rows.tone, H = rows.hit;
  const tone = { n: T.length, agree: pct(T.filter(r => r.ok).length, T.length), valid: pct(T.filter(r => r.valid).length, T.length),
    perClass: Object.fromEntries(TONES.map(k => { const x = T.filter(r => r.expect === k); return [k, { n: x.length, recall: pct(x.filter(r => r.ok).length, x.length) }]; })),
    byLang: Object.fromEntries([...new Set(T.map(r => r.lang))].map(l => { const x = T.filter(r => r.lang === l); return [l, pct(x.filter(r => r.ok).length, x.length)]; })),
    confusion: Object.fromEntries(TONES.map(a => [a, Object.fromEntries(TONES.map(b => [b, T.filter(r => r.expect === a && r.got === b).length]))])),
    catOther: pct(T.filter(r => r.cat === 'other').length, T.length), avgMs: Math.round(avg(T.map(r => r.ms)) || 0) };
  const pos = H.filter(r => r.expect === 1), neg = H.filter(r => r.expect === 0);
  const hit = { n: H.length, right: pct(H.filter(r => r.ok).length, H.length), recall: pct(pos.filter(r => r.ok).length, pos.length),
    falseHit: pct(neg.filter(r => r.got === 1).length, neg.length), valid: pct(H.filter(r => r.valid).length, H.length),
    byTopic: Object.fromEntries([...new Set(H.map(r => r.topic))].map(t => { const x = H.filter(r => r.topic === t); return [t, { n: x.length, right: pct(x.filter(r => r.ok).length, x.length), falseHit: pct(x.filter(r => r.expect === 0 && r.got === 1).length, x.filter(r => r.expect === 0).length) }]; })),
    catOther: pct(H.filter(r => r.cat === 'other').length, H.length), avgMs: Math.round(avg(H.map(r => r.ms)) || 0) };
  const R = rows.reg, arm = a => ({ catAcc: pct(R.filter(r => r[a].catOk).length, R.length), json: pct(R.filter(r => r[a].strict).length, R.length), guard: pct(R.filter(r => r[a].guardOk).length, R.length),
    avgMs: Math.round(avg(R.map(r => r[a].ms)) || 0), medMs: quant(R.map(r => r[a].ms), 0.5), p90Ms: quant(R.map(r => r[a].ms), 0.9) });
  const reg = R.length ? { n: R.length, base: arm('base'), new: arm('new') } : null;
  if (reg) { reg.catDrop = Math.round(10 * (reg.base.catAcc - reg.new.catAcc)) / 10; reg.addedMs = reg.new.avgMs - reg.base.avgMs; }
  const lines = [];
  if (T.length) lines.push(['tone agreement >= 70%', tone.agree, tone.agree >= 70]);
  if (H.length) { lines.push(['hit right >= 80%', hit.right, hit.right >= 80], ['false hits <= 15%', hit.falseHit, hit.falseHit <= 15]); }
  if (reg) { lines.push(['added time per call <= 0.5 s', reg.addedMs / 1000, reg.addedMs <= 500], ['v0.29 cat accuracy drop <= 2 points', reg.catDrop, reg.catDrop <= 2]); }
  return { model, tone, hit, reg, lines, appended, rows };
}

// ---------------------------------------------------------------- printing / reports
const f1 = v => v === null || v === undefined ? '-' : String(v);
const sec = v => v === null || v === undefined ? '-' : (v / 1000).toFixed(2);
const r1 = v => Math.round(v * 10) / 10;
function text(res) {
  const L = [`== ${res.model} ==`];
  const t = res.tone, h = res.hit, g = res.reg;
  if (t.n) {
    L.push(`tone: agreement ${f1(t.agree)}%  (n=${t.n}, valid values ${f1(t.valid)}%, cat=other ${f1(t.catOther)}%)  by class: ` + TONES.map(k => `${k} ${f1(t.perClass[k].recall)}%`).join('  ') + '  by lang: ' + Object.entries(t.byLang).map(([l, v]) => `${l} ${v}%`).join(' '));
    L.push('  confusion (rows = expected, cols = got k/b/f/n): ' + TONES.map(a => `${a}:[${TONES.map(b => t.confusion[a][b]).join(',')}]`).join(' '));
  }
  if (h.n) {
    L.push(`hit: right ${f1(h.right)}%  recall ${f1(h.recall)}%  false hits ${f1(h.falseHit)}%  (n=${h.n}, valid values ${f1(h.valid)}%, cat=other ${f1(h.catOther)}%)  ` + Object.entries(h.byTopic).map(([k, v]) => `${k}: right ${v.right}% false ${v.falseHit}%`).join('  '));
  }
  if (g) L.push(`v0.29 re-run (n=${g.n}): cat ${f1(g.base.catAcc)}% -> ${f1(g.new.catAcc)}% (drop ${g.catDrop}), json ${f1(g.base.json)}% -> ${f1(g.new.json)}%, guard ${f1(g.base.guard)}% -> ${f1(g.new.guard)}%, avg ${sec(g.base.avgMs)} s -> ${sec(g.new.avgMs)} s (added ${sec(g.addedMs)} s), p90 ${sec(g.base.p90Ms)} -> ${sec(g.new.p90Ms)} s`);
  for (const [n, v, ok] of res.lines) L.push(`  ${ok ? 'OK  ' : 'LOW '} ${n}  (${typeof v === 'number' ? r1(v) : v})`);
  return L.join('\n');
}
const esc = s => String(s ?? '').replace(/\|/g, '/').replace(/\n/g, ' ');
function fallbackAdvice(results) {
  const out = [];
  for (const r of results) {
    if (r.tone.n && r.tone.agree < 70) out.push(`${r.model}: tone is low -> set frame.judges.tone.use = "kw" (meter grows from cards and fixed rewards only; the keyword lists judge free speech).`);
    if (r.hit.n && (r.hit.right < 80 || r.hit.falseHit > 15)) out.push(`${r.model}: hit is low -> set frame.judges.hit.use = "kw" (judgeKw only).`);
  }
  return out;
}
function md(results, meta) {
  const L = ['# v0.30 eval report (tone / hit)', '', `- date: ${meta.date}`, `- engine: ${meta.engine}${results.some(r => r.appended) ? ' (no v1.1 judge rules found: the eval appended the same text itself)' : ''}`, `- cases: ${meta.cases}`, `- topics: ${meta.topics}`, ''];
  if (meta.fake) L.push('> FAKE RUN: fake responder, numbers mean nothing.', '');
  if (results.length > 1) {
    L.push('## Comparison', '', '| model | tone% | hit% | false hit% | cat drop | added s | median s | verdict |', '|---|---|---|---|---|---|---|---|');
    for (const r of results) L.push(`| ${r.model} | ${f1(r.tone.agree)} | ${f1(r.hit.right)} | ${f1(r.hit.falseHit)} | ${r.reg ? r.reg.catDrop : '-'} | ${r.reg ? sec(r.reg.addedMs) : '-'} | ${r.reg ? sec(r.reg.new.medMs) : '-'} | ${r.lines.every(l => l[2]) ? 'meets all lines' : r.lines.filter(l => !l[2]).length + ' low'} |`);
    L.push('');
  }
  for (const r of results) {
    L.push(`## ${r.model}`, '', '```', text(r), '```', '');
    const mt = r.rows.tone.filter(x => !x.ok), mh = r.rows.hit.filter(x => !x.ok);
    L.push(`### tone misses (${mt.length})`, '', '| id | lang | child | expected | got |', '|---|---|---|---|---|');
    for (const x of mt) L.push(`| ${x.id} | ${x.lang} | ${esc(x.text)} | ${x.expect} | ${x.got}${x.valid ? '' : ' (invalid)'} |`);
    L.push('', `### hit misses (${mh.length})`, '', '| id | boss | topic | child | expected | got |', '|---|---|---|---|---|---|');
    for (const x of mh) L.push(`| ${x.id} | ${x.boss} | ${x.topic} | ${esc(x.text)} | ${x.expect} | ${x.got}${x.valid ? '' : ' (invalid)'} |`);
    L.push('');
  }
  const adv = fallbackAdvice(results);
  if (adv.length) L.push('## Fallbacks (design 13.4)', '', ...adv.map(a => '- ' + a), '');
  return L.join('\n');
}

// ---------------------------------------------------------------- model management (as v029-eval)
async function ask(q) {
  if (!process.stdin.isTTY || flag.has('yes')) return flag.has('yes');
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const a = await new Promise(r => rl.question(q + ' [y/N] ', r)); rl.close();
  return /^y/i.test(a.trim());
}
async function installed() { if (FAKE) return null; const r = await (await ollama('/api/tags', null, 8000, 'GET')).json(); return (r.models || []).map(m => m.name); }
const has = (list, tag) => !list || list.some(n => n === tag || n === tag + ':latest' || (!tag.includes(':') && n.startsWith(tag + ':')));
async function pull(tag) {
  const r = await ollama('/api/pull', { model: tag, stream: true }, 3 * 3600 * 1000);
  const dec = new TextDecoder(); let buf = '', last = '';
  for await (const chunk of r.body) {
    buf += dec.decode(chunk, { stream: true });
    let k; while ((k = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, k); buf = buf.slice(k + 1); if (!line.trim()) continue;
      const j = JSON.parse(line); if (j.error) throw new Error(j.error);
      const s = j.total ? `${j.status} ${Math.round(100 * (j.completed || 0) / j.total)}%` : j.status;
      if (s !== last) { process.stdout.write('\r  ' + s.padEnd(60)); last = s; }
    }
  }
  process.stdout.write('\n');
}
async function unload(tag) { if (!FAKE) try { await ollama('/api/generate', { model: tag, keep_alive: 0 }, 10000); } catch { /* ignore */ } }

// ---------------------------------------------------------------- main
(async () => {
  const modelsPath = first([opt.models, path.join(HERE, 'chat-models.json')].filter(Boolean));
  if (!modelsPath) { console.error('chat-models.json not found; pass --models'); process.exit(2); }
  const models = rj(modelsPath);
  const tone = toneSpecs(), hit = hitSpecs(), reg = regSpecs();
  if (!tone.length && !hit.length) { console.error('no cases in ' + evalPath); process.exit(2); }
  let list;
  if (flag.has('compare') || flag.has('all')) {
    const tags = flag.has('all') ? models.models.map(m => m.tag) : models.compare_default || models.models.filter(m => !m.reserve).map(m => m.tag);
    list = tags.map(t => models.models.find(m => m.tag === t) || { tag: t });
  } else {
    const t = opt.model || models.models.find(m => m.default)?.tag || models.models[0].tag;
    list = [models.models.find(m => m.tag === t) || { tag: t }];
  }
  const nreal = [...tone, ...hit].filter(s => s.real).length;
  console.log(`v030-eval: ${tone.length} tone + ${hit.length} hit cases, ${reg.length} v0.29 cases re-run (both prompts)`);
  console.log(`engine: ${enginePath}${FAKE ? '   (FAKE: no network)' : '   host: ' + HOST}`);
  console.log(`topics: ${T30.src || 'none found: generic beat'} (${nreal}/${tone.length + hit.length} cases on a real v0.30 beat)`);
  let have = null;
  if (!FAKE) {
    try { have = await installed(); }
    catch (e) { console.error(`\nOllama is not reachable at ${HOST} (${e.message}).\nStart the Ollama app and run again.`); process.exit(3); }
  }
  const results = [];
  for (const m of list) {
    if (!has(have, m.tag)) {
      if (!(await ask(`Model ${m.tag} is not installed (about ${m.size_gb ?? '?'} GB). Download it now?`))) { console.log(`  skipped ${m.tag}`); continue; }
      try { await pull(m.tag); have.push(m.tag); } catch (e) { console.error(`  pull failed: ${e.message}`); continue; }
    }
    if (!FAKE) { try { await callOllama(m.tag, { sys: 'こんにちは', msgs: [{ role: 'user', content: 'はい' }], cats: ['a'] }, m, 'base'); } catch (e) { console.error(`  warm-up failed for ${m.tag}: ${e.message}`); } }
    const res = await run(m.tag, m, tone, hit, reg);
    results.push(res); console.log('\n' + text(res));
    await unload(m.tag);
  }
  if (!results.length) { console.error('nothing was run'); process.exit(4); }
  const adv = fallbackAdvice(results); if (adv.length) console.log('\n' + adv.join('\n'));
  fs.mkdirSync(OUT, { recursive: true });
  const stamp = new Date().toISOString().replace(/[-:]/g, '').slice(0, 13);
  const meta = { date: new Date().toISOString(), engine: enginePath, cases: `${tone.length} tone, ${hit.length} hit, ${reg.length} v0.29`, topics: T30.src || 'generic', fake: FAKE, host: HOST };
  const base = path.join(OUT, `v030-report-${FAKE ? 'fake-' : ''}${stamp}`);
  fs.writeFileSync(base + '.json', JSON.stringify({ meta, results }, null, 1));
  fs.writeFileSync(base + '.md', md(results, meta));
  fs.mkdirSync(path.dirname(REPORT), { recursive: true });
  fs.appendFileSync(REPORT, `\n==== v030-eval ${meta.date}${FAKE ? ' (FAKE)' : ''} ====\n` + results.map(text).join('\n\n') + (adv.length ? '\n' + adv.join('\n') : '') + '\n');
  console.log(`\nreport: ${base}.md\n        ${base}.json\n        ${REPORT} (appended)`);
})().catch(e => { console.error('ERROR: ' + e.message); process.exit(1); });

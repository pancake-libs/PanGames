# v0.29 AI チェック道具（Mac 用）

## 日本語

`tools/` に入っています。ふだんは **`CHECK_AI.command` をダブルクリック**するだけです。中身は下の 2 つです。

**じゅんび**：Ollama アプリを起動しておく。VOICEVOX アプリを起動しておく。Node 22 が入っていること。

### 1. ことばの テスト（v029-eval.mjs）
```
node tools/v029-eval.mjs                      # 標準モデル（qwen3:8b）だけ
node tools/v029-eval.mjs --compare            # qwen3:8b / qwen3:14b / gemma3:12b を くらべる
node tools/v029-eval.mjs --model qwen2.5:7b   # 1 つだけ
node tools/v029-eval.mjs --boss snowman --n 30   # 少しだけ（ためし）
node tools/v029-eval.mjs --dry                # ネットなし。道具の動作確認だけ（数字に意味なし）
```
- 入っていないモデルは「ダウンロードしますか？ [y/N]」と聞いてきます（8b は約 5 GB、3 つ合計で約 23 GB）。`n` ならとばします。
- 終わると `eval-out/` に `eval-report-….md` と `.json` ができます。**この `.md` を開発者に送ってください。**
- 見るところ：正答率（cat%）、きまり合格（guard%）、中央値の秒数（8b は 4 秒以下、90% が 7 秒以下がめやす）。
- `--engine web/talk-engine.js` をつけると、ゲーム本体と同じ組み立てを使います（なければ内蔵コピー）。

### 2. こえの テスト（v029-voice.mjs）
```
node tools/v029-voice.mjs tools/chat-scripts.json            # 各ボス 5 本 を つくって 秒数をはかる
node tools/v029-voice.mjs tools/chat-scripts.json --play     # きいてみる
node tools/v029-voice.mjs --dry                              # ネットなし
```
VOICEVOX が起動していない時、足りない声がある時は、はっきり表示します。

## 中文

这些工具在 `tools/` 里。平时只要**双击 `CHECK_AI.command`**。准备：先打开 Ollama 应用和 VOICEVOX 应用，电脑装有 Node 22。

### 1. 台词测试（v029-eval.mjs）
```
node tools/v029-eval.mjs                      # 只测默认模型 qwen3:8b
node tools/v029-eval.mjs --compare            # 比较 qwen3:8b / qwen3:14b / gemma3:12b
node tools/v029-eval.mjs --model qwen2.5:7b   # 只测一个
node tools/v029-eval.mjs --boss snowman --n 30   # 先小测一下
node tools/v029-eval.mjs --dry                # 不联网，只检查工具能否运行（数字无意义）
```
- 没有的模型会问“要下载吗？[y/N]”（8b 约 5 GB，三个共约 23 GB），选 n 就跳过。
- 完成后 `eval-out/` 里会有 `eval-report-….md` 和 `.json`。**请把 `.md` 发给开发者。**
- 看什么：分类正确率（cat%）、规则通过率（guard%）、耗时中位数（8b 目标 4 秒内，90% 在 7 秒内）。
- 加 `--engine web/talk-engine.js` 就用游戏本体同样的提示词组装方式（不加则用内置副本）。

### 2. 语音测试（v029-voice.mjs）
```
node tools/v029-voice.mjs tools/chat-scripts.json            # 每个 Boss 合成 5 句并计时
node tools/v029-voice.mjs tools/chat-scripts.json --play     # 试听
node tools/v029-voice.mjs --dry                              # 不联网
```
VOICEVOX 没开或缺少声音角色时，会明确提示。

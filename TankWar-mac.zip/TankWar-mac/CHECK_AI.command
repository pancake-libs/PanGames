#!/bin/bash
# おうちを守れ！戦車隊：AI（Ollama）と ボスの こえ（VOICEVOX）の チェック（v0.29）。ダブルクリックで うごく。
# 检查 AI（Ollama）和首领声音（VOICEVOX）（v0.29）。双击运行。
#   ./CHECK_AI.command             ふつうの チェック / 普通检查（qwen3:8b）
#   ./CHECK_AI.command --compare   モデルを くらべる / 比较模型（足りない モデルは きいてから ダウンロード）
#   ./CHECK_AI.command --model qwen3:14b
# けっかは check-ai-report.txt と eval-out/ に のこる。eval-out/eval-report-….md を 開発者に おくってください。
# 结果保存在 check-ai-report.txt 和 eval-out/。请把 eval-out/eval-report-….md 发给开发者。
cd "$(dirname "$0")" || exit 1
HERE="$(pwd)"
OLLAMA="http://127.0.0.1:11434"
VV="http://127.0.0.1:50021"
OUT="$HERE/eval-out"
REPORT="$HERE/check-ai-report.txt"
IFS=: read -r -a APP_DIRS <<< "${TANK_APP_DIRS:-/Applications:$HOME/Applications}"
mkdir -p "$OUT"
: > "$REPORT"
exec > >(tee -a "$REPORT") 2>&1

has_app() { local d; for d in "${APP_DIRS[@]}"; do [ -d "$d/$1.app" ] && { echo "$d/$1.app"; return 0; }; done; return 1; }
up() { curl -s -m 3 -o /dev/null "$1" 2>/dev/null; }
wait_up() { local i; for i in $(seq 1 "$2"); do up "$1" && return 0; sleep 2; done; return 1; }

echo "== AI と こえの チェック / AI 和声音检查（$(date '+%Y-%m-%d %H:%M')）=="
echo "Mac: $(sw_vers -productVersion 2>/dev/null) $(uname -m) / $(sysctl -n machdep.cpu.brand_string 2>/dev/null) / RAM $(( $(sysctl -n hw.memsize 2>/dev/null || echo 0) / 1073741824 )) GB"

# 1) Ollama
if ! up "$OLLAMA/api/version"; then
  if has_app Ollama >/dev/null; then open -ga Ollama; echo "Ollama を はじめます… / 正在启动 Ollama…"; wait_up "$OLLAMA/api/version" 20
  elif command -v ollama >/dev/null 2>&1; then nohup ollama serve >/dev/null 2>&1 & wait_up "$OLLAMA/api/version" 20; fi
fi
if up "$OLLAMA/api/version"; then
  echo "🧠 Ollama：$(curl -s -m 3 "$OLLAMA/api/version")"
  echo "   モデル / 模型：$(curl -s -m 3 "$OLLAMA/api/tags" | grep -o '"name":"[^"]*"' | sed 's/"name":"//; s/"$//' | tr '\n' ' ')"
  OLLAMA_OK=1
else
  echo "🧠 Ollama：ありません / 没有 → https://ollama.com/download（いれたら 1 回 ひらく / 安装后打开一次）"
  OLLAMA_OK=0
fi

# 2) VOICEVOX（エンジンを 窓なしで。だめなら アプリを 隠して）/ 引擎后台启动，不行就隐藏启动应用
ENGINE_PID=""
if ! up "$VV/version"; then
  for d in "${APP_DIRS[@]}"; do
    for f in "$TANK_VOICEVOX_RUN" "$d/VOICEVOX.app/Contents/Resources/vv-engine/run" "$d/VOICEVOX.app/Contents/MacOS/vv-engine/run" "$d/VOICEVOX.app/Contents/MacOS/run"; do
      if [ -n "$f" ] && [ -x "$f" ] && [ -f "$f" ]; then
        "$f" --host 127.0.0.1 --port 50021 >/dev/null 2>&1 &
        ENGINE_PID=$!
        echo "VOICEVOX の エンジンを はじめます：$f"
        break 2
      fi
    done
  done
  if [ -z "$ENGINE_PID" ] && has_app VOICEVOX >/dev/null; then open -gja VOICEVOX; echo "VOICEVOX を はじめます… / 正在启动 VOICEVOX…"; fi
  wait_up "$VV/version" 30
fi
if up "$VV/version"; then
  echo "🗣 VOICEVOX：$(curl -s -m 3 "$VV/version")"
  VV_OK=1
else
  echo "🗣 VOICEVOX：ありません / 没有 → https://voicevox.hiroshiba.jp/（Mac・Apple シリコン・CPU 版）"
  VV_OK=0
fi

# 3) node が あれば Part D の どうぐ（tools/v029-eval.mjs・v029-voice.mjs）/ 有 node 就用 tools 里的工具
NODE="$(command -v node 2>/dev/null)"
for n in /opt/homebrew/bin/node /usr/local/bin/node; do [ -z "$NODE" ] && [ -x "$n" ] && NODE="$n"; done
ARGS=("$@")
if [ ${#ARGS[@]} -eq 0 ] && [ "$OLLAMA_OK" = 1 ] && [ -t 0 ]; then
  echo ""
  echo "1) ふつうの チェック（qwen3:8b）/ 普通检查"
  echo "2) モデルを くらべる（qwen3:8b・qwen3:14b・gemma3:12b。足りない モデルは 1 つずつ きいてから ダウンロード。最大 約 23 GB）/ 比较模型"
  read -r -p "えらぶ / 选择 [1]: " pick
  [ "$pick" = 2 ] && ARGS=(--compare)
fi
echo ""
if [ -n "$NODE" ] && [ -f "$HERE/tools/v029-eval.mjs" ]; then
  echo "node: $("$NODE" --version)"
  ENGINE_ARG=()
  [ -f "$HERE/web/talk-engine.js" ] && ENGINE_ARG=(--engine "$HERE/web/talk-engine.js")
  if [ "$OLLAMA_OK" = 1 ]; then
    echo "---- ことばの テスト / 台词测试（v029-eval.mjs ${ARGS[*]}）----"
    "$NODE" "$HERE/tools/v029-eval.mjs" "${ENGINE_ARG[@]}" --out "$OUT" "${ARGS[@]}"
  fi
  if [ "$VV_OK" = 1 ] && [ -f "$HERE/tools/v029-voice.mjs" ]; then
    echo "---- こえの テスト / 语音测试（v029-voice.mjs）----"
    "$NODE" "$HERE/tools/v029-voice.mjs" "$HERE/tools/chat-scripts.json" --play --out "$OUT"
  fi
else
  echo "[i] Node 22 が ないので かんたんな チェックだけ します（くわしい チェックには https://nodejs.org/ja/download の LTS を いれる）"
  echo "[i] 没有 Node 22，只做简单检查（详细检查请安装 https://nodejs.org/zh-cn/download 的 LTS）"
  if [ "$OLLAMA_OK" = 1 ]; then
    BODY='{"model":"qwen3:8b","stream":false,"think":false,"keep_alive":"30m","messages":[{"role":"system","content":"JSON だけで こたえる。"},{"role":"user","content":"ゆきと こおり、どっちが すき？ こどもの ことば：「こおり」"}],"format":{"type":"object","properties":{"cat":{"type":"string","enum":["a","b","other","unclear","stop","bad"]},"ja":{"type":"string"}},"required":["cat","ja"]},"options":{"num_predict":60}}'
    for i in 1 2 3; do
      T0=$(date +%s)
      R="$(curl -s -m 120 -H 'Content-Type: application/json' -d "$BODY" "$OLLAMA/api/chat")"
      T1=$(date +%s)
      echo "🧠 $i 回目 / 第 $i 次：$((T1 - T0)) 秒  $(printf '%s' "$R" | grep -o '"content":"[^}]*' | head -c 160)"
    done
    echo "   （1 回目は よみこみで おそい。2・3 回目が 4〜7 秒なら OK / 第一次因为载入较慢，第二三次 4〜7 秒就 OK）"
  fi
  if [ "$VV_OK" = 1 ]; then
    SPK="$(curl -s -m 5 "$VV/speakers")"
    for c in 青山龍星 麒ヶ島宗麟 ずんだもん 櫻歌ミコ ちび式じい ナースロボ＿タイプＴ 剣崎雌雄; do
      if printf '%s' "$SPK" | grep -q "\"name\":\"$c\""; then echo "🗣 $c：OK"; else echo "🗣 $c：ありません / 没有"; fi
    done
    ID="$(printf '%s' "$SPK" | grep -o '"name":"ずんだもん"[^]]*' | grep -o '"name":"ノーマル","id":[0-9]*' | head -1 | sed 's/.*://')"
    if [ -n "$ID" ]; then
      T0=$(date +%s)
      Q="$(curl -s -m 30 -X POST "$VV/audio_query?speaker=$ID&text=%E3%81%93%E3%82%93%E3%81%AB%E3%81%A1%E3%81%AF")"
      curl -s -m 30 -X POST -H 'Content-Type: application/json' -d "$Q" -o "$OUT/check-voice.wav" "$VV/synthesis?speaker=$ID"
      echo "🗣 ずんだもん「こんにちは」：$(( $(date +%s) - T0 )) 秒"
      afplay "$OUT/check-voice.wav" 2>/dev/null
    fi
  fi
fi

# じぶんで はじめた エンジンだけ とめる（ゲーム中なら ゲームの サーバーの エンジンは そのまま）
[ -n "$ENGINE_PID" ] && kill "$ENGINE_PID" 2>/dev/null
echo ""
echo "おわり。check-ai-report.txt と eval-out/ を 開発者に おくってください。/ 完成。请把 check-ai-report.txt 和 eval-out/ 发给开发者。"
read -r -p "Enter で閉じる / 按 Enter 关闭 " _

/* P13 pure: begin */
/* ==================== P13（v0.30）：説得・おぼえている ボス・おねがい・こころメーター — 物語の 純粋な 部分（P13-B3） ====================
   - 設計：tank-v030/v030-design.md §3.2〜3.3・4・5.3・7.1〜7.2・9。約束：tank-v030/p13b3-contract.md
   - DOM・タイマー・通信・いまの 時こく は つかわない（日にちは 呼ぶ 側が わたす）。node でも 読める：require('./tank-talk30.js').pure
   - 記録は テレビの 'tank-tv30-talk' だけ（ふるい キーには 書かない）。store を かえす 関数は わたされた store を その場で かえて 同じ ものを かえす
   - AI は 結果を きめない（J4）：説得＝整数の ♥ ≥ 整数の 必要、おねがい＝えらんだ 札、記憶＝決まった 文、メーター＝上限つきの タグ
   ==================== */
(function (root) {
  'use strict';
  const req = n => { try { return typeof require !== 'undefined' ? require(n) : null; } catch (e) { return null; } };
  const TE = () => root.TalkEngine || req('./talk-engine.js');
  const TD = () => root.TankTalk30Data || req('./tank-talk30data.js');
  const TD29 = () => root.TankChatData || req('./tank-chatdata.js');
  const KEY = 'tank-tv30-talk';
  const ORDER = ['bigtank', 'sandship', 'snowman', 'dragon', 'core', 'king'];
  const TRAITS = ['k', 'b', 'f'], TAG2T = { kind: 'k', brave: 'b', fun: 'f' }, T2TAG = { k: 'kind', b: 'brave', f: 'fun' };
  const NEED = [4, 3, 2, 1], START_MAX = 2, GAUGE_MAX = 5, MEM_MAX = 10, MEM_LINES = 3, NAME_MAX = 12, VOICE_NAME_MAX = 8, LONG_DAYS = 7, LETTER_AFTER = 2;
  const MEM_K = ['met', 'pvx', 'pv', 'aid', 'soft', 'pr', 'prk', 'say'];
  const GREET_K = { aid: 'hiAid', pv: 'hiPv', prk: 'hiPrk', soft: 'hiSoft', pvx: 'hiPvx' };
  const CAP = { trait: 3, total: 5 }, PTS_MAX = 999, COINS = { prKept: 30, aid: 100 };
  const HELP = { futon: [1, 2], shield: [4, 6], freeze: [8, 10] }, HELP_AT = [12, 30], HELPERS_MAX = 2, AID_PAGES_MAX = 2;
  const PV_GLOW = ['b2', 'b3', 'b4'];
  const GREET_ASK = 'ひさしぶりに あった。『まえに はなした こと』から ひとつ だけ えらんで、なつかしそうに ひとこと。しつもんは しない。なまえは かかない。';
  // 記憶の 文（§4.1）。{by}＝名前（空 → みんな）、{c}＝札の ことば、{w}＝こどもの ことば
  const MEM_T = {
    met: ['はじめて はなしたのは {by}', '第一次聊天的是{by}'],
    pvx: ['{by} たちと はなした あと、しょうぶ した', '和{by}他们聊过之后，比赛了'],
    pv: ['{by} たちの ことばで なかまに なった', '因为{by}他们的话成了伙伴'],
    aid: ['こまった とき、{by} の アイデア「{c}」で たすかった', '有困难时，{by}的主意「{c}」帮了我'],
    soft: ['こまりごとを {by} たちが きいて くれた', '{by}他们听了我的烦恼'],
    pr: ['{by} と「{c}」の やくそくを した', '和{by}约定了「{c}」'],
    prk: ['{by} と「{c}」の やくそくを まもった', '和{by}遵守了「{c}」的约定'],
    say: ['{by} は「{w}」と いった', '{by}说了「{w}」'] };
  const ALL = ['みんな', '大家'];

  /* ---------- 小さな 道具 ---------- */
  const clampI = (x, a, b) => Math.max(a, Math.min(b, Number.isFinite(+x) ? Math.floor(+x) : a));
  const bit = x => (x ? 1 : 0);
  const obj = x => (x && typeof x === 'object' && !Array.isArray(x) ? x : {});
  const len = s => [...String(s || '')].length;
  const lists = () => { const D = TD29(); return D ? { ng: D.ng, allow: D.allow } : null; };
  const dataOf = d => d || TD();
  const fixedOf = (boss, data) => { const D = dataOf(data); return (D && D.bosses && D.bosses[boss] && D.bosses[boss].fixed) || {}; };
  const LL = o => (o && typeof o === 'object' ? { ja: String(o.ja || ''), zh: String(o.zh || '') } : null);
  const fillT = (s, by, c, w) => String(s).replace(/\{by\}/g, by).replace(/\{c\}/g, c).replace(/\{w\}/g, w);
  // 日にち YYYYMMDD（その 土地の 時間、朝 4 時に かわる：ポストの 記録と 同じ）
  function dayOf(now) { const d = new Date((Number.isFinite(+now) ? +now : 0) - 4 * 3600e3); return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate(); }
  const dayMs = d => { d = d | 0; return Date.UTC(Math.floor(d / 10000), (Math.floor(d / 100) % 100) - 1, d % 100); };
  function daysBetween(a, b) { if (!(a > 0) || !(b > 0)) return 0; return Math.round((dayMs(b) - dayMs(a)) / 864e5); }
  const cleanDay = d => { d = clampI(d, 0, 99991231); return d >= 19000101 ? d : 0; };
  // 名前：12 文字まで・制御文字なし・NG は ★。名前 ぜんぶが NG → ''（ボスは「みんな」と いう）
  function cleanName(s) {
    let t = [...String(s == null ? '' : s).replace(/[\u0000-\u001F\u007F-\u009F\u2028\u2029]/g, '').replace(/\s+/g, ' ').trim()].slice(0, NAME_MAX).join('');
    const E = TE(), L = lists(); if (!t || !E || !L) return t;
    if (E.hasNG(t, 'ja', L) || E.hasNG(t, 'zh', L)) { t = E.maskNG(E.maskNG(t, '', 'ja', L), '', 'zh', L); if (!t.replace(/[★\s]/g, '')) return ''; }
    return [...t].slice(0, NAME_MAX).join('');
  }
  const keepW = w => { const E = TE(); return E ? E.cleanKeep(w, lists()) : ''; };
  const KANA_NAME = /^[ぁ-ゖァ-ヺー]+$/u;
  function voiceable(name) { const E = TE(), L = lists(); return !!name && KANA_NAME.test(name) && len(name) <= VOICE_NAME_MAX && !(E && L && (E.hasNG(name, 'ja', L) || E.hasNG(name, 'zh', L))); }

  /* ---------- 記録（§9） ---------- */
  const emptyBoss = () => ({ pv: { n: 0, ok: [0, 0], best: 0 }, aid: { st: 0, v: 0, by: '', d: 0, soft: 0, gift: 0, since: 0 }, pr: { v: 0, by: '', d: 0, kept: 0, at: 0 }, mem: [] });
  function cleanMem(m) {
    m = obj(m); if (!MEM_K.includes(m.k)) return null;
    const e = { d: cleanDay(m.d), k: m.k, by: cleanName(m.by), v: clampI(m.v, 0, 9) };
    if (m.w != null) { const w = keepW(m.w); if (w) e.w = w; }
    return e;
  }
  function cleanStore(v) {
    v = obj(v); const c = obj(v.cfg), m = obj(v.m), en = obj(v.ends), src = obj(v.b);
    const out = { v: 1, cfg: { pv: c.pv === 0 || c.pv === false ? 0 : 1, hud: ['key', 'all', 'off'].includes(c.hud) ? c.hud : 'key', meter: c.meter === 0 || c.meter === false ? 0 : 1 },
      m: { k: clampI(m.k, 0, PTS_MAX), b: clampI(m.b, 0, PTS_MAX), f: clampI(m.f, 0, PTS_MAX), last: TRAITS.includes(m.last) ? m.last : '' },
      ends: { k: bit(en.k), b: bit(en.b), f: bit(en.f) }, day: cleanDay(v.day), letterDay: cleanDay(v.letterDay), cl: clampI(v.cl, 0, 99999), b: {} };
    for (const k of ORDER) {
      const s = obj(src[k]), o = emptyBoss(); out.b[k] = o;
      const pv = obj(s.pv), aid = obj(s.aid), pr = obj(s.pr);
      o.pv.n = clampI(pv.n, 0, 3); o.pv.ok = [0, 1].map(i => bit(Array.isArray(pv.ok) && pv.ok[i])); o.pv.best = clampI(pv.best, 0, GAUGE_MAX);
      o.aid = { st: clampI(aid.st, 0, 2), v: clampI(aid.v, 0, 4), by: cleanName(aid.by), d: cleanDay(aid.d), soft: clampI(aid.soft, 0, 99), gift: bit(aid.gift), since: clampI(aid.since, 0, 99) };
      if (o.aid.st === 2 && !o.aid.v) o.aid.st = 1; if (o.aid.st < 2) o.aid.gift = 0;
      o.pr = { v: clampI(pr.v, 0, 3), by: cleanName(pr.by), d: cleanDay(pr.d), kept: clampI(pr.kept, 0, 99), at: clampI(pr.at, 0, 99999) };
      if (Array.isArray(s.mem)) for (const x of s.mem) { const e = cleanMem(x); if (e) o.mem.push(e); }
      o.mem = o.mem.slice(-MEM_MAX);
    }
    return out;
  }
  const B = (store, boss) => { if (!store.b) store.b = {}; if (!store.b[boss]) store.b[boss] = emptyBoss(); return store.b[boss]; };
  const known = boss => ORDER.includes(boss);
  // 面を クリア した（ぼうけん）：cl と、ともだちの ボスの since を ふやす
  function onClear(store, friends) {
    store.cl = Math.min(99999, (store.cl | 0) + 1);
    for (const k of ORDER) if (Array.isArray(friends) && friends.includes(k)) { const a = B(store, k).aid; a.since = Math.min(99, (a.since | 0) + 1); }
    return store;
  }

  /* ---------- こころメーター（§7.1） ---------- */
  const meterLevel = p => Math.min(10, Math.floor(clampI(p, 0, PTS_MAX) / 4));
  function meterAdd(store, tags, run) {
    run = run && typeof run === 'object' ? run : {}; const gained = { k: 0, b: 0, f: 0 }, up = []; if (!store.cfg || !store.cfg.meter) return { store, gained, run, up };
    tags = obj(tags);
    for (const tag of ['kind', 'brave', 'fun']) {
      const t = TAG2T[tag], n = Number.isInteger(tags[tag]) ? tags[tag] : 0; if (n <= 0) continue;
      const tot = TRAITS.reduce((a, x) => a + (run[x] | 0), 0), room = Math.min(CAP.trait - (run[t] | 0), CAP.total - tot), add = Math.max(0, Math.min(n, room));
      if (!add) continue; const lv0 = meterLevel(store.m[t]); store.m[t] = Math.min(PTS_MAX, store.m[t] + add); run[t] = (run[t] | 0) + add; gained[t] += add; store.m.last = t;
      if (meterLevel(store.m[t]) > lv0) up.push(t);
    }
    return { store, gained, run, up };
  }
  function meterFixed(store, trait, n) {
    const gained = { k: 0, b: 0, f: 0 }, up = []; n = clampI(n, 0, PTS_MAX); if (!store.cfg || !store.cfg.meter || !TRAITS.includes(trait) || !n) return { store, gained, up };
    const lv0 = meterLevel(store.m[trait]); store.m[trait] = Math.min(PTS_MAX, store.m[trait] + n); gained[trait] = n; store.m.last = trait; if (meterLevel(store.m[trait]) > lv0) up.push(trait);
    return { store, gained, up };
  }
  function meterTop(store) {
    const m = obj(store && store.m), mx = Math.max(...TRAITS.map(t => m[t] | 0)); if (mx <= 0) return '';
    const tied = TRAITS.filter(t => (m[t] | 0) === mx); return tied.includes(m.last) ? m.last : tied[0];
  }
  function meterView(store, data) {
    const D = dataOf(data), M = D && D.meter, top = meterTop(store);
    return TRAITS.map(t => { const pts = store.m[t] | 0, lv = meterLevel(pts); let title = null;
      if (M && M.titles && Array.isArray(M.levelTitleAt)) { let i = -1; M.levelTitleAt.forEach((at, j) => { if (lv >= at) i = j; }); if (i >= 0 && M.titles[t] && M.titles[t][i]) title = LL(M.titles[t][i]); }
      return { t, pts, lv, title, top: t === top }; });
  }
  const endSeen = (store, t) => { if (TRAITS.includes(t)) store.ends[t] = 1; return store; };
  const endsCount = store => TRAITS.reduce((a, t) => a + bit(store.ends && store.ends[t]), 0);
  // v0.29 の シートに trait の タグ（tones の 表）。もとの シートは かえない
  function toneSheet(sheet29, boss, data) {
    const D = dataOf(data), tones = (D && D.tones) || {}, sh = JSON.parse(JSON.stringify(sheet29 || {}));
    for (const tp of sh.topics || []) for (const be of tp.beats || []) for (const c of be.cats || []) { const t = tones[`${boss}.${tp.id}.${be.id}.${c.id}`];
      if (T2TAG[t]) c.tags = Object.assign({}, c.tags, { [T2TAG[t]]: 1 }); }
    return sh;
  }

  /* ---------- 記憶（§4.1） ---------- */
  function memAdd(store, boss, entry, day) {
    if (!known(boss)) return store; const e = cleanMem(Object.assign({}, entry, { d: day })); if (!e) return store;
    const s = B(store, boss); s.mem.push(e); if (s.mem.length > MEM_MAX) s.mem = s.mem.slice(-MEM_MAX); return store;
  }
  function cardText(boss, e, data, li) {
    const D = dataOf(data), BB = D && D.bosses && D.bosses[boss]; if (!BB) return '';
    if (e.k === 'pr' || e.k === 'prk') { const w = BB.words && BB.words.pr && BB.words.pr[e.v - 1]; return w ? (li ? w.zh : w.ja) : ''; }
    if (e.k === 'aid') { if (e.v === 4 && e.w) return e.w; const tp = (BB.topics || []).find(t => t.id === 'aid'), be = tp && tp.beats.find(b => b.key === 'aid'), c = be && be.cats.find(x => x.val === e.v); return c ? (li ? c.zh : c.ja) : ''; }
    return '';
  }
  function memLine(boss, e, data, lang) {
    const li = lang === 'zh' ? 1 : 0, T = MEM_T[e.k]; if (!T) return '';
    const c = cardText(boss, e, data, li); if (T[li].includes('{c}') && !c) return ''; if (T[li].includes('{w}') && !e.w) return '';
    return '・' + fillT(T[li], e.by || ALL[li], c, e.w || '');
  }
  function memLines(store, boss, data, lang) {
    if (!known(boss)) return []; const mem = B(store, boss).mem, out = [];
    for (let i = mem.length - 1; i >= 0 && out.length < MEM_LINES; i--) { const l = memLine(boss, mem[i], data, lang); if (l && !out.includes(l)) out.push(l); }
    return out;
  }

  /* ---------- あいさつ（§4.2） ---------- */
  function lastDay(store, store29, boss) {
    let d = 0; for (const m of B(store, boss).mem) if (m.d > d) d = m.d;
    const s29 = store29 && store29.b && store29.b[boss], ms = s29 && +s29.last; if (ms > 0) { const d2 = dayOf(ms); if (d2 > d) d = d2; }
    return d;
  }
  function greetFor(store, store29, boss, names, day, cleared, data) {
    if (!known(boss)) return null; const s = B(store, boss), F = fixedOf(boss, data); if (cleared == null) cleared = store.cl | 0;
    let key = '', entry = null;
    if (s.pr.v) { key = 'hiPr.' + s.pr.v; entry = { k: 'pr', by: s.pr.by, v: s.pr.v, d: s.pr.d }; }
    else for (let i = s.mem.length - 1; i >= 0; i--) if (GREET_K[s.mem[i].k]) { entry = s.mem[i]; key = GREET_K[entry.k]; break; }
    let body = null, nm = '', nmZh = '';
    if (entry) {
      body = key.startsWith('hiPr.') ? LL(F.hiPr && F.hiPr[s.pr.v]) : LL(F[key]);
      const room = (Array.isArray(names) ? names : []).map(cleanName).filter(Boolean);
      nm = entry.by && room.includes(entry.by) ? entry.by : room[0] || '';
      nmZh = nm || ALL[1]; nm = nm || ALL[0];
    } else { const t = meterTop(store); if (t && F.att && F.att[t]) { key = 'att.' + t; body = LL(F.att[t]); } }
    if (!body || !body.ja) return null;
    const ld = lastDay(store, store29, boss), long = ld && day && daysBetween(ld, day) >= LONG_DAYS && F.hiLong ? LL(F.hiLong) : null;
    const vn = !!entry && voiceable(nm), pre = (o, li) => (o ? (li ? o.zh : o.ja) + (li ? '' : ' ') : '');
    const say = { ja: pre(long, 0) + (entry ? nm + '、' : '') + body.ja, zh: pre(long, 1) + (entry ? nmZh + '，' : '') + body.zh };
    const voice = { ja: pre(long, 0) + (entry && vn ? nm + '、' : '') + body.ja };
    const keep = !!s.pr.v && ((day | 0) > s.pr.d || (cleared | 0) > s.pr.at);
    return { key, entry: entry ? Object.assign({}, entry) : null, name: entry ? nm : '', nameZh: entry ? nmZh : '', body, long, say, voice, voiceName: vn, keep, llm: !!entry && memLines(store, boss, data, 'ja').length >= 2 };
  }

  /* ---------- 小さな やくそく（§4.3） ---------- */
  function prMake(store, boss, v, by, day, data) {
    v = clampI(v, 0, 3); if (!known(boss) || !v) return { store, word: null, line: null };
    const s = B(store, boss), BB = dataOf(data).bosses[boss], w = BB && BB.words.pr[v - 1];
    s.pr = { v, by: cleanName(by), d: cleanDay(day), kept: s.pr.kept | 0, at: store.cl | 0 }; memAdd(store, boss, { k: 'pr', by, v }, day);
    return { store, word: w ? { ja: w.ja, zh: w.zh, tone: w.tone } : null, line: w ? { ja: '🤝 やくそく：' + w.ja, zh: '🤝 约定：' + w.zh } : null };
  }
  function prKeep(store, boss, day, players, data) {
    if (!known(boss)) return null; const s = B(store, boss), v = s.pr.v; if (!v) return null;
    const BB = dataOf(data).bosses[boss], w = BB && BB.words.pr[v - 1], F = fixedOf(boss, data), photo = !s.pr.kept, trait = w && TRAITS.includes(w.tone) ? w.tone : '';
    s.pr.kept = Math.min(99, s.pr.kept + 1); s.pr.v = 0; if (trait) meterFixed(store, trait, 1); memAdd(store, boss, { k: 'prk', by: s.pr.by, v }, day);
    return { store, coins: COINS.prKept * clampI(players, 0, 8), perPlayer: COINS.prKept, trait, photo, v, word: w ? { ja: w.ja, zh: w.zh } : null, lines: ((F.prKept && F.prKept[v]) || []).map(LL) };
  }
  const prKeptTotal = store => ORDER.reduce((a, k) => a + (B(store, k).pr.kept | 0), 0);

  /* ---------- 説得（§3.2〜3.3） ---------- */
  function finalStageBoss(stage, perWorld) {
    if (!stage || stage.no !== perWorld || stage.p3dDuel || stage.p3dBonus != null || stage.p4b || stage.p3dGold || stage.climb) return '';
    const bs = Array.isArray(stage.bosses) ? stage.bosses : []; return bs.length === 1 && known(bs[0]) ? bs[0] : '';
  }
  function pvOffer(store, stage, lap, o) {
    o = obj(o); if (!store.cfg || !store.cfg.pv || o.mode !== 'adv' || (o.players | 0) < 1) return '';
    const boss = finalStageBoss(stage, o.perWorld == null ? 24 : o.perWorld); if (!boss) return '';
    const li = clampI(lap, 1, 2) - 1; return B(store, boss).pv.ok[li] ? '' : boss;
  }
  const pvNeed = (store, boss) => NEED[Math.min(3, known(boss) ? B(store, boss).pv.n | 0 : 0)];
  function pvStart(store, store29, boss, data) {
    void store29; if (!known(boss)) return { n: 0, why: [] }; const s = B(store, boss), D = dataOf(data), why = [];
    const fond = D && D.bosses && D.bosses[boss] && D.bosses[boss].fond; if (fond && meterTop(store) === fond) why.push('fond');
    if (s.pr.kept >= 1) why.push('pr'); if (s.aid.st === 2) why.push('aid');
    return { n: Math.min(START_MAX, why.length), why };
  }
  const pvTopic = (boss, data) => { const D = dataOf(data), BB = D && D.bosses && D.bosses[boss]; return BB ? BB.topics.find(t => t.id === 'pv') : null; };
  function pvOpen(store, store29, boss, lap, data) {
    const s = B(store, boss), st = pvStart(store, store29, boss, data), F = fixedOf(boss, data), tp = pvTopic(boss, data), glow = {};
    const again = s.pv.n > 0 || s.pv.ok.some(Boolean) || s.mem.some(m => m.k === 'pv' || m.k === 'pvx') || (lap | 0) >= 2;
    const key = again && F.pvAgain ? 'pvAgain' : st.why.includes('fond') ? 'pvHi.trait' : 'pvHi.first';
    const line = key === 'pvAgain' ? F.pvAgain : F.pvHi && F.pvHi[key === 'pvHi.trait' ? 'trait' : 'first'];
    if (tp) for (const bid of PV_GLOW.slice(0, Math.min(3, s.pv.n))) { const be = tp.beats.find(b => b.id === bid); if (!be) continue; let best = null;
      for (const c of be.cats) if (!best || ((c.tags && c.tags.pv) | 0) > ((best.tags && best.tags.pv) | 0)) best = c; if (best) glow[bid] = best.id; }
    return { start: st.n, why: st.why, need: pvNeed(store, boss), greet: Object.assign({ key }, LL(line) || { ja: '', zh: '' }), glow };
  }
  // 1 つの Step で ふえた ♥（J3：札は tags.pv、はんてい は hit の ある ビートで hit → 2・trait → 1。1 ビート 2 まで）
  function pvStepHearts(step, topic) {
    let n = 0; const by = step && Array.isArray(step.tagBy) ? step.tagBy : [];
    for (const e of by) { const t = obj(e && e.tags);
      if (e.src === 'card') { n += Math.max(0, Math.min(GAUGE_MAX, Number.isInteger(t.pv) ? t.pv : 0)); continue; }
      const be = topic && Array.isArray(topic.beats) ? topic.beats.find(b => b.id === e.b) : null; if (!be || !Array.isArray(be.judge) || !be.judge.includes('hit')) continue;
      n += (t.hit | 0) > 0 ? 2 : ((t.kind | 0) > 0 || (t.brave | 0) > 0 || (t.fun | 0) > 0) ? 1 : 0; }
    return n;
  }
  const pvGauge = (start, gained) => Math.max(0, Math.min(GAUGE_MAX, clampI(start, 0, START_MAX) + Math.max(0, clampI(gained, 0, 99))));
  function pvNextLine(need, data) { const U = dataOf(data).ui.pv.next; return { ja: U.ja.replace('{n}', need), zh: U.zh.replace('{n}', need) }; }
  function pvResult(store, boss, gained, lap, o) {
    o = obj(o); const s = B(store, boss), F = fixedOf(boss, o.data), g = typeof gained === 'number' ? gained : obj(gained).pv | 0;
    const hearts = pvGauge(o.start | 0, g), need = pvNeed(store, boss), day = o.day | 0;
    if (o.why !== 'gone' && !s.mem.some(m => m.k === 'met')) memAdd(store, boss, { k: 'met', by: o.by }, day);
    if (!o.complete) return { ok: false, hearts, need, next: need, counted: false, fight: true, line: null, store };
    s.pv.best = Math.max(s.pv.best, hearts); const ok = Number.isInteger(hearts) && Number.isInteger(need) && hearts >= need;
    if (ok) { s.pv.ok[clampI(lap, 1, 2) - 1] = 1; memAdd(store, boss, { k: 'pv', by: o.by }, day); meterFixed(store, 'k', 1); }
    else { s.pv.n = Math.min(3, s.pv.n + 1); memAdd(store, boss, { k: 'pvx', by: o.by }, day); }
    const next = pvNeed(store, boss);
    return { ok, hearts, need, next, counted: true, fight: !ok, line: Object.assign({ key: ok ? 'pvOk' : 'pvNg' }, LL(ok ? F.pvOk : F.pvNg) || {}), store };
  }

  /* ---------- おねがい（§5） ---------- */
  function letterDue(store, friends, day, cleared) {
    void cleared; if (!Array.isArray(friends) || (day && store.letterDay === day)) return '';
    if (ORDER.some(k => B(store, k).aid.st === 1 && !B(store, k).aid.soft)) return '';   // まだ よんで いない てがみ が ある
    return ORDER.find(k => friends.includes(k) && B(store, k).aid.st === 0 && B(store, k).aid.since >= LETTER_AFTER) || '';
  }
  function letterSend(store, boss, day) { if (!known(boss)) return store; const a = B(store, boss).aid; if (a.st === 0) a.st = 1; store.letterDay = cleanDay(day); return store; }
  const aidOpenList = store => ORDER.filter(k => B(store, k).aid.st >= 1).map(k => ({ boss: k, st: B(store, k).aid.st }));
  function aidResult(store, boss, o) {
    o = obj(o); if (!known(boss) || o.why === 'gone') return { kind: 'none', store };
    const s = B(store, boss), F = fixedOf(boss, o.data), v = clampI(o.v, 0, 4), day = o.day | 0, players = clampI(o.players, 0, 8);
    if (o.complete && v) {
      const first = !s.aid.gift; Object.assign(s.aid, { st: 2, v, by: cleanName(o.by), d: cleanDay(day) }); if (first) { s.aid.gift = 1; meterFixed(store, 'k', 2); }
      memAdd(store, boss, { k: 'aid', by: o.by, v, w: v === 4 ? o.w : undefined }, day);
      return { kind: 'done', v, gift: first, coins: first ? COINS.aid * players : 0, perPlayer: first ? COINS.aid : 0, sticker: first, photo: first, line: LL(F.aidOk && F.aidOk[v]), end: LL(F.aidEnd && F.aidEnd[v]), store };
    }
    const first = !s.aid.soft && s.aid.st !== 2; s.aid.soft = Math.min(99, s.aid.soft + 1); if (s.aid.st === 0) s.aid.st = 1; if (first) meterFixed(store, 'k', 1);
    memAdd(store, boss, { k: 'soft', by: o.by }, day);
    return { kind: 'soft', photo: first, line: LL(F.aidSoft), store };
  }

  /* ---------- さいごの たたかいの おてつだい（§5.3）・エンディング（§5.3・7.2） ---------- */
  function finalKind(stage) { if (!stage || stage.p3dDuel || stage.p4b) return ''; if (stage.p3dGold) return 'gold'; if (Array.isArray(stage.bosses) && stage.bosses.includes('king') && stage.p3dBonus == null) return 'king'; return ''; }
  function helpers30(list29, store, stage, lap, data) {
    void lap; const D = dataOf(data), kind = finalKind(stage), base = Array.isArray(list29) ? list29.filter(h => h && known(h.boss)) : [];
    if (!kind) return base.map(h => Object.assign({}, h));
    const fought = Array.isArray(stage.bosses) ? stage.bosses : [], out = [];
    const aids = ORDER.filter(k => B(store, k).aid.st === 2 && !fought.includes(k) && (k !== 'king' || kind === 'gold'));
    for (const k of aids) { const ah = D && D.bosses && D.bosses[k] && D.bosses[k].aidHelp, hk = (ah && HELP[ah[String(B(store, k).aid.v)]]) ? ah[String(B(store, k).aid.v)] : 'futon'; out.push({ boss: k, k: hk, aid: 1 }); }
    for (const h of base) if (!out.some(x => x.boss === h.boss) && HELP[h.k] && !fought.includes(h.boss)) out.push({ boss: h.boss, k: h.k, aid: 0 });
    return out.slice(0, HELPERS_MAX).map((h, i) => Object.assign(h, { at: HELP_AT[i], n: HELP[h.k][h.aid], pr: B(store, h.boss).pr.kept >= 1 ? 1 : 0 }));
  }
  const bossName = k => { const D = TD29(), c = D && D.chars && D.chars[k]; return c ? c.persona.name : [k, k]; };
  const joinL = (ls, li) => (ls || []).map(l => (li ? l.zh : l.ja)).join('　');
  function pages30(pages29, store, store29, data) {
    void store29; const D = dataOf(data), out = Array.isArray(pages29) ? pages29.slice() : [];
    const aids = ORDER.filter(k => B(store, k).aid.st === 2).sort((a, b) => B(store, b).aid.d - B(store, a).aid.d || ORDER.indexOf(a) - ORDER.indexOf(b)).slice(0, AID_PAGES_MAX);
    const lastFriend = () => { let i = -1; out.forEach((p, j) => { if (p && (p.kind === 'friend' || p.kind === 'aid')) i = j; }); return i; };
    for (const k of aids) { const v = B(store, k).aid.v, F = fixedOf(k, D), e = F.aidEnd && F.aidEnd[v]; if (!e) continue; const nm = bossName(k);
      const pg = { kind: 'aid', who: k, v, title: ['🤝 ' + nm[0] + ' の その あと', '🤝 ' + nm[1] + '的后来'], ja: e.ja, zh: e.zh, tts: true };
      const fi = out.findIndex(p => p && p.kind === 'friend' && p.who === k); out.splice(fi >= 0 ? fi + 1 : lastFriend() + 1, 0, pg); }
    const t = meterTop(store), M = D && D.meter;
    if (t && M && M.ending && M.ending[t]) { const E = M.ending[t]; out.push({ kind: 'heart', who: 'narr', trait: t, art: E.art, frame: E.frame, title: [E.title.ja, E.title.zh], ja: joinL(E.lines, 0), zh: joinL(E.lines, 1), tts: true }); }
    if (prKeptTotal(store) >= 3 && M && M.promiseKept) { const P = M.promiseKept; out.push({ kind: 'kept', who: 'narr', art: P.art, title: [P.title.ja, P.title.zh], ja: joinL(P.lines, 0), zh: joinL(P.lines, 1), tts: true }); }
    return out;
  }

  // 録った 声（§12・v0.30 統合）：ボスごと 7 本。/voice/t30_<boss>_<key>_<n>.ogg（tools/v030-gen.mjs の 台本 talk30-scripts.json と 同じ 名前）。無い 時は ライブの VOICEVOX か 字だけ
  const REC30 = { pvAsk: [''], pvHi: ['first', 'trait'], pvOk: [''], pvNg: [''], aidSoft: [''], helpPr: [''] };
  function vo30(boss, key, sub) { const r = REC30[key]; if (!r || !ORDER.includes(boss)) return ''; const i = r.indexOf(sub == null ? '' : String(sub)); return i < 0 ? '' : 't30_' + boss + '_' + key.toLowerCase() + '_' + (i + 1); }
  // かざりだなの 🤝（§5.3）：おねがいを たすけた ボス
  const shelf30 = (store, boss) => { const b = store && store.b && store.b[boss]; return b && b.aid && b.aid.st === 2 ? '🤝' : ''; };

  const pure = { KEY, ORDER, REC30, vo30, shelf30, TRAITS, TAG2T, NEED, MEM_K, MEM_MAX, CAP, COINS, HELP, HELP_AT, GREET_ASK,
    cleanStore, dayOf, daysBetween, cleanName, onClear,
    pvOffer, pvNeed, pvStart, pvOpen, pvStepHearts, pvGauge, pvResult, pvNextLine,
    memAdd, memLines, greetFor, prMake, prKeep, prKeptTotal,
    letterDue, letterSend, aidResult, aidOpenList, helpers30, pages30, endSeen, endsCount,
    meterAdd, meterFixed, meterTop, meterLevel, meterView, toneSheet, finalKind };
  const api = root.TankTalk30 && typeof root.TankTalk30 === 'object' ? root.TankTalk30 : {}; api.pure = pure; root.TankTalk30 = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
/* P13 pure: end */
/* P13 scene: begin */
/* ==================== P13（v0.30）：説得・おぼえている ボス・おねがい・こころメーター・そうだんタイム — 場面（P13-B2） ====================
   - 設計：tank-v030/v030-design.md §3・4・5・6・7.1。物語の 計算は 上の 純粋な 部分（TankTalk30.pure、B3）。会話は TankChat.run（tank-chat.js の P13 hooks）
   - テレビ：せっとくの さそい（p3dDuelMaybe の 前）・せっとく／おねがい／やくそくの おしゃべり・ゲージ・アイデア ボード・てがみ・こころメーター・#tv30Rows
   - スマホ → テレビ：cmd {a:'tv30', op:'go'（tank-chat.js）|'aid'|'meter', boss}。テレビ → スマホ：presence の g.tv30（{ hud, ans, pv, board, m, aid }）
   - 会話は 勝手に すすまない。時間の 決まりは ない。マイクは おした 時だけ。タップは いつでも 同じ 結果。記録は 'tank-tv30-talk' だけ
   ==================== */
(function (root) {
  'use strict';
  if (typeof window === 'undefined' || typeof document === 'undefined') return;   // node では 純粋な 部分だけ
  const T = root.TankTalk30 = root.TankTalk30 || {}, P = T.pure;
  const TD = () => root.TankTalk30Data, TD29 = () => root.TankChatData, TC = () => root.TankChat, TE = () => root.TalkEngine;
  let C = null;
  const S = { store: null, pv: null, aid: null, pr: null, keep: null, pass: null, fight: null, backAt: 0, mrun: {}, talkRef: null, rowsArm: 0, meterSig: '', lastPack: '' };
  const Lx = (ja, zh) => C.L(ja, zh), LANGx = () => (C.lang() === 'zh' ? 'zh' : 'ja');
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const bossNm = k => { const c = TD29() && TD29().chars[k]; return c ? c.persona.name : [k, k]; };
  const fixed = k => TD().bosses[k].fixed, ui = () => TD().ui;
  const LP = (o, vars) => { const f = s => String(s || '').replace(/\{(\w+)\}/g, (m, k) => (vars && vars[k] != null ? vars[k] : m)); return o ? [f(o.ja), f(o.zh)] : ['', '']; };
  const today = () => P.dayOf(Date.now());
  const friends = () => { const P3 = C.P3(); return P.ORDER.filter(k => P3.cap[k] && P3.cap[k].got); };
  const tvS = () => TC()._tv;
  const PCOLx = slot => (C.PCOL && C.PCOL[slot]) || '#ffd23a';
  function save() { C.writeJSON(P.KEY, S.store); }
  function attach(ctx) { C = T.ctx = ctx; if (!P || !TC() || !TD() || !TD29()) return false; css(); if (ctx.ROLE === 'tv') tvInit(); else padInit(); T.ready = true; return true; }
  function css() { if (document.getElementById('tv30sCss')) return; const s = document.createElement('style'); s.id = 'tv30sCss'; s.textContent = `
#tv30Meter{position:fixed;left:1.4vw;bottom:2vh;z-index:14;display:flex;align-items:center;gap:1vw;padding:.6vh 1.2vw;border-radius:99px;border:.3vh solid #1b2a22;background:rgba(255,246,220,.94);color:#1b2a22;font-weight:900;font-size:2.2vh;cursor:pointer;font-family:"Hiragino Sans","PingFang SC","Noto Sans SC",sans-serif}
#tv30Meter.hide{display:none}#tv30Meter .t{display:flex;flex-direction:column;align-items:flex-start;gap:.2vh}#tv30Meter .bar{width:5vw;height:.7vh;border-radius:99px;background:#d8d0b8;overflow:hidden}#tv30Meter .bar i{display:block;height:100%}
#tv30Rows{margin-top:1.4vh;border-top:2px dashed rgba(0,0,0,.25);padding-top:1vh}#tv30Rows p{margin:.4vh 0}#tv30Rows button{margin:.3vh .4vw;padding:.4vh 1vw;border-radius:99px;border:2px solid #1b2a22;background:#fff;font-weight:900}#tv30Rows button.on{background:#ffd23a}#tv30Rows button.arm{background:#e4483f;color:#fff}
#navBox button.tv30{background:#ffd0c8}
#tv29Pad .m30{display:flex;gap:10px;justify-content:center;font-weight:900;font-size:14px;color:#fff6dc}
#tv30GarM{margin:.4em 0 0;padding:2px 8px;border-radius:10px;border:2px solid #ff8aa8;background:rgba(255,138,168,.15);color:#fff6dc;font-weight:900;cursor:pointer}#tv30GarM b{color:#ff8aa8}#tv30GarM span{white-space:nowrap;display:inline-block}`;
    document.head.appendChild(s); }

  /* ==================== テレビ ==================== */
  function tvInit() {
    S.store = P.cleanStore(C.readJSON(P.KEY));
    Object.assign(TC().ext, EXT);
    C.room.on('cmd', m => { if (m.data && m.data.a === 'tv30') try { tvCmd(m.peer, m.data); } catch (e) { console.warn('P13：v0.30 の 操作を 処理できませんでした', e); } });
    const w = document.createElement('div'); w.id = 'tv30Meter'; w.className = 'hide'; w.onclick = () => { if (C.audioOn) C.audioOn(); openMeter(); }; document.body.appendChild(w);
    C.hookAfter(tick);
  }
  function tvCmd(peer, d) { const G = C.G(); if (!G.pl[peer]) return;
    if (d.op === 'aid' && P.ORDER.includes(d.boss)) { if (tvS().on && tvS().ui === 'list') TC().close(); startAid(String(d.boss)); }
    else if (d.op === 'meter') openMeter(); }
  const canTalk = () => { const G = C.G(); return (G.ph === 'lobby' || G.ph === 'over') && !C.SC().on && !tvS().on && !(C.busy && C.busy()) && !document.getElementById('tv28Set'); };

  /* ---------- フック（TankChat.ext） ---------- */
  const EXT = {
    sheet: boss => (S.store.cfg.meter ? P.toneSheet(TD29().chars[boss], boss) : undefined),   // v0.29 の 札にも こころの タグ（§7.1）
    greet: (boss, store29) => greetLine(boss, store29),
    memory: boss => P.memLines(S.store, boss, TD(), 'ja'),
    onTurn: (step, ctx) => onTurn(step, ctx),
    huddle: ask => (S.store.cfg.hud === 'all' ? true : S.store.cfg.hud === 'key' ? !!ask.key : false),
    badges: boss => badgesOf(boss),
    badgeTap: (boss, op) => { if (op === 'aid') { if (tvS().on && tvS().ui === 'list') TC().close(); startAid(boss); } },
    helpers: (list, stage, lap) => P.helpers30(list, S.store, stage, lap).map(h => Object.assign({}, h, { n: h.k === 'futon' ? h.n : undefined, sec: h.k === 'shield' ? h.n : undefined, fz: h.k === 'freeze' ? h.n : undefined, line: h.pr ? fixed(h.boss).helpPr : undefined })),
    pages: pages => { const out = P.pages30(pages, S.store, tvS().store); const h = out.find(p => p.kind === 'heart'); if (h) { P.endSeen(S.store, h.trait); save(); } return out; },
    drawPage: (x, st, r, now) => drawPage(x, st, r, now),
    wait: boss => (TD().bosses[boss] ? fixed(boss).wait : null),
    pack: () => pack(),
    keep: (boss, store29, ti) => keepVisit(boss, store29, ti),   // v0.29 の おしゃべりでも やくそくを まもる（§4.3。統合で 追加）
    shelf: boss => (S.store ? P.shelf30(S.store, boss) : ''),     // かざりだなの 🤝（§5.3）
    vo: (boss, l) => voOf(boss, l)                                 // 録った 声 t30_*（§12）。無ければ tank-chat が ライブの 声に する
  };
  function voOf(boss, l) { const fx = l && l.fx; if (!fx || !P.REC30[fx[0]]) return ''; const r = P.REC30[fx[0]], i = Math.max(0, fx[1] | 0); return i < r.length ? P.vo30(boss, fx[0], r[i]) : ''; }
  // v0.29 の おしゃべりの 前：あいさつ（ext.greet）の あとで「やくそく、いま ちょっと だけ やる？」→ v0.29 の 話へ（tank-chat の visit）
  function keepVisit(boss, store29, ti) { if (!TD().bosses[boss]) return null; const g = greetData(boss, store29); if (!g || !g.keep) return null;
    console.info('P13：v0.29 の おしゃべりで やくそく ' + boss); return keepCfg(boss, g, null, ti); }
  function badgesOf(boss) { if (!friends().includes(boss)) return []; const a = S.store.b[boss].aid, U = ui().aid;
    if (a.st === 1) return [{ ic: '🆘', ja: U.badge.ja, zh: U.badge.zh, op: 'aid' }]; if (a.st === 2) return [{ ic: '🤝', ja: U.replay.ja, zh: U.replay.zh, op: 'aid' }]; return []; }
  function meterArr() { const v = P.meterView(S.store, TD()); return v.map(m => m.lv).concat([v.findIndex(m => m.top)]); }
  function pack() { const o = { m: S.store.cfg.meter ? meterArr() : 0 }, pv = S.pv;
    if (pv && tvS().on && tvS().run && tvS().run.kind === 'pv') o.pv = [P.pvGauge(pv.start, pv.gained), pv.need];
    if (S.aid && tvS().on && tvS().run && tvS().run.kind === 'aid') o.board = S.aid.board.slice(0, 6);
    const al = P.aidOpenList(S.store).filter(a => a.st === 1 && friends().includes(a.boss)); if (al.length) o.aid = al.map(a => [a.boss, bossNm(a.boss)[0], bossNm(a.boss)[1]]);
    return o; }
  // こころメーター：札の タグ・はんてい（v0.29 の おしゃべりでも）。1 回の おしゃべりで 1 つ +3・ぜんぶで +5 まで
  function onTurn(step, ctx) {
    if (tvS().talk !== S.talkRef) { S.talkRef = tvS().talk; S.mrun = {}; }
    const tg = step.tags || {}; if (tg.kind || tg.brave || tg.fun) { const r = P.meterAdd(S.store, tg, S.mrun); S.mrun = r.run; if (r.gained.k || r.gained.b || r.gained.f) { save(); meterPops(r.gained, r.up, ctx.speaker.slot); } }
    if (ctx.kind === 'pv' || ctx.kind === 'aid') for (const m of step.memo || []) if (m && m.w && m.c === 'other' && ctx.speaker.name) { P.memAdd(S.store, ctx.boss, { k: 'say', by: ctx.speaker.name, w: m.w }, today()); save(); }
  }
  function meterPops(g, up, slot) { const M = TD().meter; for (const t of P.TRAITS) if (g[t]) TC().pop(`${M.icon[t]} +${g[t]} ${Lx(M.pop[t].ja, M.pop[t].zh)}`, slot >= 0 ? PCOLx(slot) : '#ffd23a');
    if (up && up.length) TC().pop(`✨ ${Lx(M.pop.up.ja, M.pop.up.zh)}`, '#ffd23a'); }
  function fixedPops(g, up) { meterPops(g, up, -1); }

  /* ---------- あいさつ（§4.2）：おぼえている ボス。AI が ことばを えらぶ ことも ある（その 時だけ、名前は ゲームが つける） ---------- */
  function greetData(boss, store29) { const names = C.players().map(p => p.name); return P.greetFor(S.store, store29 || tvS().store, boss, names, today(), S.store.cl, TD()); }
  const greetObj = g => ({ ja: g.say.ja, zh: g.say.zh, spk: g.voice.ja, src: 'fixed' });
  async function greetLLM(boss, g) {
    if (!g || !g.llm) return g ? greetObj(g) : null;
    let r = null; try { r = await tvS().eng.line({ who: boss, memory: P.memLines(S.store, boss, TD(), 'ja'), ask: P.GREET_ASK, lang: LANGx(), names: C.players().map(p => p.name), last2: [] }); } catch (e) { r = null; }
    if (!r || !r.ja) return greetObj(g);
    const pre = o => (o ? o.ja + ' ' : ''), nm = g.name ? g.name + '、' : '', nz = g.nameZh ? g.nameZh + '，' : '';
    return { ja: pre(g.long) + nm + r.ja, zh: (g.long ? g.long.zh : '') + nz + r.zh, spk: pre(g.long) + (g.voiceName ? nm : '') + r.ja, src: 'llm' };
  }
  function greetLine(boss, store29) { const g = greetData(boss, store29); if (!g) return null; return g.llm ? greetLLM(boss, g) : greetObj(g); }

  /* ---------- 説得（§3）：さそい → おしゃべり → ♥ → なかよく／しょうぶ ---------- */
  // p3dDuelMaybe の かわり（tank.html の P13 から）。true＝場面を はじめた（いまは 出発しない）
  function duelMaybe(gi, from, orig) {
    const G = C.G();
    if (tvS().on || S.starting) return true;   // おしゃべりの 間は 出発しない
    if (S.pass && S.pass.gi === gi) { if (!S.pass.peace) S.pass = null; return false; }   // はなした あと：けっとうの くじは ひかない
    if (S.fight && S.fight.gi === gi) { S.fight = null; return orig(gi, from); }
    if ((C.duOn && C.duOn()) || C.SC().on || G.p3dList || G.climb) return orig(gi, from);
    if (offer(gi, from)) return true;
    return orig(gi, from);
  }
  function go(from) { if (from === 'next') C.nextAdv(); else C.startMapSel(); }
  function fightNow(gi, from) { S.pass = { gi, peace: 0 }; go(from); }
  function peaceNow(gi, from) { S.pass = { gi, peace: 1 }; go(from); }
  function offer(gi, from) {
    const st = C.ST.ADV[gi], P3 = C.P3(); if (!st) return false;
    const boss = P.pvOffer(S.store, st, P3.lap, { mode: 'adv', players: C.players().length, perWorld: C.ST.PER_WORLD }); if (!boss) return false;
    const F = fixed(boss), U = ui().pv; let pick = -1;
    const vo = P.vo30(boss, 'pvAsk');
    C.scene([{ t: 'choice', who: boss, theme: st.theme, title: ['💬 ' + U.offerNote.ja, '💬 ' + U.offerNote.zh], ja: F.pvAsk.ja, zh: F.pvAsk.zh, p13: 'offer', vo, enter: () => voFallback(boss, F.pvAsk.ja, vo),
      opts: [{ ic: '💬', ja: U.offerTalk.ja, zh: U.offerTalk.zh }, { ic: '⚔', ja: U.offerFight.ja, zh: U.offerFight.zh }], pick: v => { pick = v; return null; } }],
    () => { if (pick === 0) { if (!startPv(boss, gi, from)) { S.fight = { gi }; go(from); } } else { S.fight = { gi }; go(from); } });
    console.info('P13：せっとくの さそい：' + boss);
    return true;
  }
  const sheetFor = (boss, ti) => { const c = TD29().chars[boss]; return { persona: c.persona, fixed: c.fixed, topics: [TD().bosses[boss].topics[ti]] }; };
  function gaugeHtml() { const pv = S.pv; if (!pv) return ''; const h = P.pvGauge(pv.start, pv.gained), left = Math.max(0, pv.need - h), U = ui().pv;
    return `${esc(Lx(U.meter.ja, U.meter.zh))} ${'♥'.repeat(h)}${'♡'.repeat(5 - h)}<small>${left ? esc(Lx(`あと ♥ ${left} つ`, `还差 ${left} 颗心`)) : '♥ OK！'}</small>`; }
  const hl = n => '♥'.repeat(Math.max(0, Math.min(5, n))) + '♡'.repeat(5 - Math.max(0, Math.min(5, n)));
  function startPv(boss, gi, from) {
    if (!canTalk()) return false; const lap = C.P3().lap, o = P.pvOpen(S.store, tvS().store, boss, lap, TD()), F = fixed(boss);
    S.pv = { boss, gi, from, lap, start: o.start, need: o.need, gained: 0, by: '', glow: o.glow };
    const g = greetData(boss); console.info('P13：せっとく ' + boss + ' あいさつ ' + (g ? g.key + (g.keep ? '・やくそく' : '') : 'なし'));
    const main = { boss, sheet: sheetFor(boss, 0), frame: TD().frame, title: ['', ''], memory: P.memLines(S.store, boss, TD(), 'ja'), kind: 'pv',
      greet: Object.assign({ src: 'fixed' }, o.greet, o.greet.key === 'pvHi.first' ? { fx: ['pvHi', 0] } : o.greet.key === 'pvHi.trait' ? { fx: ['pvHi', 1] } : {}), huddle: S.store.cfg.hud !== 'off', wait: F.wait, hud: gaugeHtml,
      glow: ask => { const id = S.pv && S.pv.glow[ask.b]; return id ? ask.cards.map((c, i) => (c.id === id ? i : -1)).filter(i => i >= 0) : []; },
      onStep: (st, ctx) => { const n = P.pvStepHearts(st, TD().bosses[boss].topics[0]); if (n > 0 && S.pv) { S.pv.gained += n; TC().pop('♥ +' + n, '#ff6a8a'); C.play && C.play('powerup'); }
        if (S.pv && !S.pv.by && ctx.speaker.name && (st.tagBy || st.ans)) S.pv.by = ctx.speaker.name; },
      onEnd: st => pvEnd(st) };
    return startWith(boss, g, main);
  }
  // あいさつ（おぼえている）→（やくそくを まもる？）→ 本の おしゃべり。AI の あいさつを まつ 間は S.starting（出発しない）
  function startWith(boss, g, main) {
    const run = cfg => TC().run(cfg);
    if (g && g.keep) return run(keepCfg(boss, g, main));
    if (g && g.entry) { const base = greetObj(g); main.greet = base;
      if (g.llm) { if (!canTalk()) return false; S.starting = 1;
        greetLLM(boss, g).then(x => x, () => null).then(x => { S.starting = 0; main.greet = x || base; if (!run(main)) fightFallback(main); }); return true; } }
    return run(main);
  }
  function fightFallback(main) { if (main.kind === 'pv' && S.pv) fightNow(S.pv.gi, S.pv.from); }
  function pvEnd(st) {
    const pv = S.pv, boss = pv.boss, complete = st.why === 'done' && !!st.complete, U = ui().pv;
    const r = P.pvResult(S.store, boss, pv.gained, pv.lap, { why: st.why, complete, start: pv.start, by: pv.by || (C.players()[0] || {}).name || '', day: today(), data: TD() }); save();
    console.info('P13：せっとく ' + boss + ' ♥' + r.hearts + '/' + r.need + (r.counted ? r.ok ? ' なかよく' : ' あと すこし' : ' たたかう'));
    if (!r.counted) return { skip: 1, next: () => fightNow(pv.gi, pv.from) };
    const th = (TD29().chars[boss].fixed.think || [])[0], think = th ? { ja: th.ja, zh: th.zh, fx: ['think', 0] } : null, say = think ? [think] : [];
    if (r.ok) { fixedPops({ k: 1, b: 0, f: 0 }, []);
      return { say: say.concat([{ ja: r.line.ja, zh: r.line.zh, fx: ['pvOk', -1] }]), mood: 'happy', day: 1, happy: 1,
        then: prCfg(boss, lines => ({ big: [U.rewardTitle.ja, U.rewardTitle.zh], lines: [[hl(r.hearts), hl(r.hearts)]].concat(lines), happy: 1, next: () => peaceNow(pv.gi, pv.from) })) }; }
    const nx = P.pvNextLine(r.next, TD());
    return { say: say.concat([{ ja: r.line.ja, zh: r.line.zh, fx: ['pvNg', -1] }]), big: [U.almost.ja, U.almost.zh], lines: [[hl(r.hearts), hl(r.hearts)], [nx.ja, nx.zh]], next: () => fightNow(pv.gi, pv.from) };
  }
  // 小さな やくそく（§4.3）：2 つの ビート。done(lines) → onEnd の 答え
  function prCfg(boss, done) {
    const tp = TD().bosses[boss].topics[2]; S.pr = { boss, v: 0, by: '' };
    return { boss, sheet: sheetFor(boss, 2), frame: TD().frame, title: tp.title, greet: { ja: '', zh: '' }, kind: 'pr', huddle: false, wait: fixed(boss).wait, memory: P.memLines(S.store, boss, TD(), 'ja'),
      onStep: (st, ctx) => { if (st.flags && st.flags.pr) { S.pr.v = st.flags.pr | 0; S.pr.by = ctx.speaker.name; } },
      onEnd: () => { const lines = []; if (S.pr.v) { const m = P.prMake(S.store, boss, S.pr.v, S.pr.by, today(), TD()); save(); if (m.line) lines.push([m.line.ja, m.line.zh]); } return done(lines); } };
  }
  // やくそくを まもる？（§4.3）：うん → あそぶ（30 コイン・こころ +1）→ 本の おしゃべり。ううん → じゃあ こんど ね
  // main が null（v0.29 の おしゃべり）の 時は おわったら { visit } で v0.29 の 話（ti）へ もどる
  function keepCfg(boss, g, main, ti) {
    const w = TD().bosses[boss].words.pr[(S.store.b[boss].pr.v || 1) - 1] || { ja: '', zh: '' };
    const topic = { id: 'keep', title: ['🤝 やくそく', '🤝 约定'], limits: { beats: 1, exchanges: 3, reasks: 1, min: 1 }, beats: [{ id: 'b1', type: 'pick', key: 'keep', keep: false, huddle: 0, judge: [],
      q: { ja: 'やくそく、いま ちょっと だけ やる？', zh: `约定（${w.zh}），现在玩一下吗？` }, reask: { ja: 'やくそく、いま やる？', zh: '约定，现在玩吗？' }, memo: '',
      cats: [{ id: 'a', ic: '⭕', ja: 'うん', zh: '嗯', val: 1, next: null, kw: { ja: ['うん', 'やる', 'いいよ', 'はい', 'やろう'], zh: ['嗯', '好', '玩', '可以', '来吧'] }, re: { ja: 'やった！ いくよ！', zh: '太好了！来吧！' } },
        { id: 'b', ic: '⏰', ja: 'ううん', zh: '下次', val: 2, next: null, kw: { ja: ['ううん', 'こんど', 'あとで', 'また', 'いや'], zh: ['不', '下次', '以后', '改天', '不要'] }, re: { ja: 'じゃあ こんど ね', zh: '那下次吧' } }],
      reOther: { ja: 'じゃあ こんど ね', zh: '那下次吧' } }] };
    const c = TD29().chars[boss]; S.keep = { greet: greetObj(g), v: 0 };
    const cfg = { boss, sheet: { persona: c.persona, fixed: c.fixed, topics: [topic] }, frame: {}, title: topic.title, greet: greetObj(g), kind: 'keep', huddle: false, wait: fixed(boss).wait, memory: P.memLines(S.store, boss, TD(), 'ja'),
      onStep: st => { if (st.flags && st.flags.keep) S.keep.v = st.flags.keep | 0; },
      onEnd: st => { const nx = main ? Object.assign({}, main) : null, cont = nx ? { then: nx } : { visit: 1, ti: ti | 0 }; if (S.keep.v === 1) { const r = P.prKeep(S.store, boss, today(), C.players().length, TD()); save();
          if (r) { giveCoins(r.perPlayer); if (r.trait) fixedPops({ k: 0, b: 0, f: 0, [r.trait]: 1 }, []); if (r.photo) album(boss, ['🤝 ' + bossNm(boss)[0] + ' と やくそくを まもった！', '🤝 和' + bossNm(boss)[1] + '守约了！']);
            TC().pop('🪙 +' + r.perPlayer, '#ffd23a'); return Object.assign({ say: r.lines.map(l => ({ ja: l.ja, zh: l.zh, fx: ['prKept', -1] })), mood: 'happy' }, cont); } }
        void st; return cont; } };
    return cfg;
  }

  /* ---------- おねがい（§5）：てがみ → アイデア → えらぶ → やって みる ---------- */
  function boardHtml() { const a = S.aid; if (!a || !a.board.length) return ''; const G = C.G(); void G;
    return `<div class="board30"><span style="background:#fff6dc">💡 ${esc(Lx(ui().aid.ideasSoFar.ja, ui().aid.ideasSoFar.zh))}</span>` + a.board.map(([sl, tx]) => `<span style="background:${PCOLx(sl)}">${esc(tx)}</span>`).join('') + '</div>'; }
  function startAid(boss) {
    if (!canTalk() || !friends().includes(boss) || S.store.b[boss].aid.st < 1) return false; const F = fixed(boss), U = ui().aid, tp = TD().bosses[boss].topics[1];
    S.aid = { boss, board: [], hits: [], by: '', v: 0, w: '', tp };
    const g = greetData(boss);
    const main = { boss, sheet: sheetFor(boss, 1), frame: TD().frame, title: LP(U.letterTitle, { boss: '' }).map((s, i) => '🆘 ' + bossNm(boss)[i] + ' ' + s.replace(/^\s*/, '')), memory: P.memLines(S.store, boss, TD(), 'ja'), kind: 'aid',
      greet: Object.assign({ src: 'fixed', fx: ['aidAsk', 0] }, F.aidAsk[0]), huddle: S.store.cfg.hud !== 'off', wait: F.wait, board: boardHtml,
      extra: ask => (ask.key === 'aid' && S.aid && S.aid.board.length ? ['# これまでの アイデア：' + S.aid.board.map((b, i) => `${i + 1}「${b[1]}」`).join(' ')] : []),
      onStep: (st, ctx) => aidStep(st, ctx), onEnd: st => aidEnd(st) };
    main.title = [`🆘 ${bossNm(boss)[0]} の おねがい`, `🆘 ${bossNm(boss)[1]}的请求`];
    return startWith(boss, g, main);
  }
  function aidStep(st, ctx) {
    const a = S.aid; if (!a) return; const sl = ctx.speaker.slot;
    for (const m of st.memo || []) { if (!m || !/^b[345]/.test(m.b)) continue; const be = a.tp.beats.find(b => b.id === m.b), c = be && be.cats.find(x => x.id === m.c);
      const tx = c ? c.ja : m.w ? String(m.w).slice(0, 16) : ''; if (tx) a.board.push([sl, tx]); }
    for (const e of st.tagBy || []) if (e.src !== 'card' && e.tags && e.tags.hit > 0) { if (ctx.speaker.name && !a.hits.includes(ctx.speaker.name)) a.hits.push(ctx.speaker.name); const mm = (st.memo || []).find(m => m.w); if (mm && !a.w) a.w = mm.w; }
    if (st.flags && st.flags.aid) { a.v = st.flags.aid | 0; a.by = ctx.speaker.name; }
    if (!a.by && ctx.speaker.name && st.ans) a.by = ctx.speaker.name;
  }
  function aidEnd(st) {
    const a = S.aid, boss = a.boss, U = ui().aid, complete = st.why === 'done' && !!st.complete && a.v > 0;
    const r = P.aidResult(S.store, boss, { why: st.why, complete, v: a.v, by: a.by || (C.players()[0] || {}).name || '', day: today(), players: C.players().length, w: a.w, data: TD() }); save();
    if (r.kind === 'none') return { skip: 1, next: null };
    if (r.kind === 'done') { const lines = [[`🤝 ${U.done.ja}`, `🤝 ${U.done.zh}`]];
      if (r.gift) { giveCoins(r.perPlayer); lines.push([`🎁 ${U.gift.ja}：🪙 ${r.perPlayer}`, `🎁 ${U.gift.zh}：🪙 ${r.perPlayer}`]); fixedPops({ k: 2, b: 0, f: 0 }, []); }
      if (a.v === 4 && a.hits.length) lines.push([`✨ ${a.hits.join('・')} の アイデア！`, `✨ ${a.hits.join('・')} 的主意！`]);
      if (r.photo) album(boss, [`🤝 ${bossNm(boss)[0]} を たすけた！`, `🤝 帮助了${bossNm(boss)[1]}！`]);
      return { say: [{ ja: r.line.ja, zh: r.line.zh, fx: ['aidOk', a.v] }], mood: 'happy', happy: 1, then: prCfg(boss, pl => ({ big: [U.resultOk.ja, U.resultOk.zh], lines: lines.concat(pl), happy: 1, next: null })) };
    }
    if (r.photo) { album(boss, [`💌 ${bossNm(boss)[0]} の はなしを きいた`, `💌 听了${bossNm(boss)[1]}的话`]); fixedPops({ k: 1, b: 0, f: 0 }, []); }
    return { say: [{ ja: r.line.ja, zh: r.line.zh, fx: ['aidSoft', -1] }], big: [U.resultSoft.ja, U.resultSoft.zh], lines: [[`💌 ${U.replay.ja}：🆘`, `💌 ${U.replay.zh}：🆘`]],
      then: st.why === 'done' ? prCfg(boss, pl => ({ big: [U.resultSoft.ja, U.resultSoft.zh], lines: pl, next: null })) : null };
  }
  // てがみ（ロビー・ワールドマップに もどった 時。1 日 1 通。場面の 間は 出さない）
  function letterTick() {
    const G = C.G(); if (!S.backAt || performance.now() - S.backAt < 700) return; if (G.ph !== 'lobby' || S.starting || C.SC().on || tvS().on || (C.busy && C.busy()) || document.getElementById('tv28Set')) return;
    S.backAt = 0; const boss = P.letterDue(S.store, friends(), today(), S.store.cl); if (!boss || !C.players().length) return;
    P.letterSend(S.store, boss, today()); save(); const F = fixed(boss), U = ui().aid, nm = bossNm(boss); let pick = -1;
    C.scene([{ t: 'choice', who: boss, theme: 'grass', title: [`✉ ${LP(U.letterTitle, { boss: nm[0] })[0]}`, `✉ ${LP(U.letterTitle, { boss: nm[1] })[1]}`], p13: 'letter',
      ja: `✉ ${nm[0]} から てがみ：『${F.aidAsk[0].ja}…』`, zh: `✉ ${nm[1]}的来信：『${F.aidAsk[0].zh}……』`,
      opts: [{ ic: '💬', ja: 'いま きく', zh: '现在听' }, { ic: '⏰', ja: U.later ? U.later.ja : 'あとで', zh: U.later ? U.later.zh : '以后' }], pick: v => { pick = v; return null; } }],
    () => { if (pick === 0) startAid(boss); });
    console.info('P13：てがみ：' + boss);
  }
  function onLobby() { S.backAt = performance.now(); }
  // sim の 知らせ：stage（はなしあいで クリア）・clear（cl・since）
  function onEvent(e) {
    const G = C.G();
    if (e.k === 'stage') { const pass = S.pass; S.pass = null; G.p13Peace = 0;
      if (pass && pass.peace && G.mode === 'adv' && !G.p3dList && G.stageIdx === pass.gi) { const ok = C.S.peaceClear(G); console.info('P13：はなしあいで クリア ' + (ok ? 'OK' : 'NG')); } }
    else if (e.k === 'clear' && G.mode === 'adv' && !G.p3dList) { P.onClear(S.store, friends()); save(); }
  }
  // ボスの 面の あと（G.p13Peace の 時）：pvPeace の まんが・なかま（まだ なら すぐ）→ わかれ道・エンディング
  function afterBoss(st, orig) {
    const G = C.G(); if (!G.p13Peace) return orig(st); G.p13Peace = 0;
    const P3 = C.P3(), lap = P3.lap, STY = C.STY, boss = (st.bosses || []).find(k => STY.CAPTURE.by[k]); if (!boss || !TD().bosses[boss]) return orig(st);
    const U = ui().pv, T2 = [U.peaceTitle.ja, U.peaceTitle.zh], isKing = st.gi === C.ST.ADV.length - 1, F = fixed(boss);
    const steps = C.manga(F.pvPeace.map((l, i) => ({ who: 'narr', art: 'boss', kinds: [boss], ja: l.ja, zh: l.zh, sfx: i === 2 ? ['♥ なかま！', '♥ 伙伴！'] : null })), st.theme, T2);
    P3.seen['d' + lap + '-' + st.gi] = 1; const cap = P3.cap[boss];
    if (cap && !cap.got) { cap.got = 1; const CB = STY.CAPTURE.by[boss], got = C.ui('cap.ui.got');
      steps.push({ t: 'slide', art: 'unlock', car: CB.car, kind: boss, who: 'narr', ja: got[0], zh: got[1], title: ['👑 ボス戦車', '👑 首领坦克'], enter: () => { C.fanfare && C.fanfare(true); const nm = bossNm(boss); C.albumShot && C.albumShot('boss', ['♥ ' + nm[0] + ' と なかよし！', '♥ 和' + nm[1] + '成为朋友！'], 400); } }); }
    C.p3dSave();
    if (st.no === C.ST.PER_WORLD && st.world < STY.BRANCH.length && !P3.ch[lap][st.world]) steps.push(...C.branch(st.world));
    if (isKing) steps.push(...C.ending());
    return steps;
  }
  /* ---------- 録った 声が ない 時の ライブの 声（せっとくの さそい。p3d の 場面は 録った 声だけ なので ここで おぎなう） ---------- */
  async function voFallback(who, text, id) {
    try { if (!C.voOn || !C.voOn() || !C.AC || !C.AC() || C.AC().state !== 'running' || !text) return;
      const h = await fetch('/voice/' + id + '.ogg', { cache: 'force-cache' }).then(r => r.ok, () => false); if (h) return;
      let st = tvS().status; if (!st) st = await fetch('/brain/status', { cache: 'no-store' }).then(r => (r.ok ? r.json() : null), () => null);
      if (!(st && st.on && st.tts && st.tts.state === 'ready')) return;
      const r = await fetch('/tts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ boss: who, who, text, keep: true }), cache: 'no-store' });
      if (!r.ok || !/audio/.test(r.headers.get('content-type') || '')) return; const ac = C.AC(), ab = await r.arrayBuffer();
      const buf = await new Promise((res, rej) => { const p = ac.decodeAudioData(ab, res, rej); if (p && p.then) p.then(res, rej); });
      if (!C.SC().on) return; const src = ac.createBufferSource(); src.buffer = buf; src.connect(C.voiceOut ? C.voiceOut() : ac.destination); src.start(); S.voFb = (S.voFb | 0) + 1;
    } catch (e) { /* 声は なくても よい（字は 出ている） */ } }
  /* ---------- しゃしん・コイン ---------- */
  function giveCoins(n) { n = Math.max(0, n | 0); if (!n || !C.coins) return; C.coins(n); }
  function album(boss, cap) { if (!window.TankAlbum) return;
    try { const c = document.createElement('canvas'); c.width = 960; c.height = 540; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 540); g.addColorStop(0, '#fff2d0'); g.addColorStop(1, '#ffe0ea'); x.fillStyle = g; x.fillRect(0, 0, 960, 540);
      if (C.bossPic) C.bossPic(x, boss, 3, 300, 330, 300); x.fillStyle = '#1b2a22'; x.font = '900 44px sans-serif'; x.fillText(cap[0], 470, 250, 470); x.font = '900 34px sans-serif'; x.fillText(cap[1], 470, 320, 470);
      const nm = C.players().map(p => p.name);
      c.toBlob(b => { if (!b) return; window.TankAlbum.add({ at: Date.now(), kind: 'reunion', caps: [cap], stage: ['ボスと おしゃべり', '和首领聊天'], mode: 'chat', names: nm, w: 960, h: 540, blob: b }).catch(e => console.warn('P13：写真を 残せませんでした', e)); }, 'image/jpeg', .88);
    } catch (e) { console.warn('P13：写真を 作れませんでした', e); } }

  /* ---------- こころメーター（§7.1）：ロビーの 小さな 窓・スライド ---------- */
  function meterTick() {
    const w = document.getElementById('tv30Meter'); if (!w) return; const G = C.G(), v = C.view ? C.view() : 'lobby';
    const show = !!S.store.cfg.meter && G.ph === 'lobby' && (v === 'lobby' || v === 'map') && !C.SC().on && !tvS().on && !document.getElementById('tv28Set');
    w.classList.toggle('hide', !show); if (!show) return;
    const M = TD().meter, mv = P.meterView(S.store, TD()), sig = JSON.stringify(mv) + C.lang(); if (sig === S.meterSig) return; S.meterSig = sig;
    const col = { k: '#ff6a8a', b: '#ff8a3a', f: '#ffc93a' };
    w.innerHTML = `<span>${esc(Lx(M.widget.ja, M.widget.zh))}</span>` + mv.map(m => `<span class="t"><span>${m.top ? '✨' : ''}${M.icon[m.t]} Lv${m.lv}</span><span class="bar"><i style="width:${Math.min(100, (m.pts % 4) * 25 + (m.lv >= 10 ? 100 : 0))}%;background:${col[m.t]}"></i></span></span>`).join('');
  }
  function openMeter() { const G = C.G(); if (G.ph !== 'lobby' || C.SC().on || tvS().on) return; const M = TD().meter;
    C.scene([{ t: 'slide', art: 'tv29', tv29: { kind: 'meter' }, who: 'narr', ja: M.recordNote ? M.recordNote.ja : '', zh: M.recordNote ? M.recordNote.zh : '', title: [M.slide.ja, M.slide.zh] }], null); C.play && C.play('powerup'); }
  function drawPage(x, st, r, now) {
    const p = st.tv29; if (!p || !['aid', 'heart', 'kept', 'meter'].includes(p.kind)) return false;
    const [px, py, pw, ph] = r, cx = px + pw / 2; x.save(); x.beginPath(); x.rect(px, py, pw, ph); x.clip(); x.textAlign = 'center'; x.textBaseline = 'middle'; x.lineJoin = 'round';
    const head = (t, col) => { x.font = `${ph * .085}px "Dela Gothic One",sans-serif`; x.lineWidth = ph * .02; x.strokeStyle = '#1b2a22'; x.fillStyle = col; x.strokeText(t, cx, py + ph * .13, pw * .9); x.fillText(t, cx, py + ph * .13, pw * .9); };
    if (p.kind === 'aid') { if (C.bossPic) C.bossPic(x, p.who, 3, cx, py + ph * .62 + Math.sin(now / 300) * ph * .01, ph * .4); x.font = `${ph * .12}px sans-serif`; x.fillText('🤝', px + pw * .78, py + ph * .4); head(Lx(p.title[0], p.title[1]), '#ffd23a'); }
    else if (p.kind === 'heart' || p.kind === 'kept') {
      const fr = p.frame || 'heart', R = i => (Math.sin(i * 12.9898) * 43758.5453) % 1, n = 26; x.font = `${ph * .07}px sans-serif`;
      for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2, ex = cx + Math.cos(a) * pw * .44, ey = py + ph * .55 + Math.sin(a) * ph * .4, ic = fr === 'flame' ? '🔥' : fr === 'confetti' ? ['🎉', '✨', '🎊'][i % 3] : p.kind === 'kept' ? '🤝' : '💗';
        x.globalAlpha = .55 + .45 * Math.abs(Math.sin(now / 500 + i)); x.fillText(ic, ex, ey + (fr === 'confetti' ? ((now / 20 + R(i + 1) * 300) % (ph * .1)) : 0)); }
      x.globalAlpha = 1; const ks = p.kind === 'kept' ? P.ORDER.filter(k => S.store.b[k].pr.kept > 0) : friends();
      ks.slice(0, 6).forEach((k, i, a) => { const bx = a.length === 1 ? cx : px + pw * (.2 + .6 * i / Math.max(1, a.length - 1)); if (C.bossPic) C.bossPic(x, k, 3 + (i % 3), bx, py + ph * .66 + Math.sin(now / 300 + i) * ph * .012, ph * .18); });
      head(Lx(p.title[0], p.title[1]), p.kind === 'kept' ? '#ffd23a' : { k: '#ff6a8a', b: '#ff8a3a', f: '#ffc93a' }[p.trait] || '#ff6a8a'); }
    else if (p.kind === 'meter') { const M = TD().meter, mv = P.meterView(S.store, TD()), col = { k: '#ff6a8a', b: '#ff8a3a', f: '#ffc93a' };
      head(Lx(M.slide.ja, M.slide.zh), '#ff8aa8');
      mv.forEach((m, i) => { const y = py + ph * (.3 + i * .16), bw = pw * .5, bx = px + pw * .32; x.textAlign = 'left'; x.font = `900 ${ph * .05}px sans-serif`; x.fillStyle = '#1b2a22';
        x.fillText(`${m.top ? '✨' : ''}${M.icon[m.t]} ${Lx(M.name[m.t].ja, M.name[m.t].zh)}`, px + pw * .06, y, pw * .25); x.fillStyle = '#d8d0b8'; x.fillRect(bx, y - ph * .02, bw, ph * .04); x.fillStyle = col[m.t]; x.fillRect(bx, y - ph * .02, bw * Math.min(1, m.lv / 10), ph * .04);
        x.fillStyle = '#1b2a22'; x.font = `900 ${ph * .04}px sans-serif`; x.fillText(`Lv ${m.lv}${m.title ? '　' + Lx(m.title.ja, m.title.zh) : ''}`, bx, y + ph * .055, bw); });
      x.textAlign = 'center'; x.font = `900 ${ph * .045}px sans-serif`; x.fillStyle = '#6a4a00'; const rt = M.recordTitle || { ja: 'かぞくの こころの え', zh: '全家的心之画' };
      x.fillText(`🖼 ${Lx(rt.ja, rt.zh)} ${P.endsCount(S.store)} / 3　` + P.TRAITS.map(t => (S.store.ends[t] ? M.icon[t] : '・')).join(' '), cx, py + ph * .86, pw * .9); }
    x.restore(); return true;
  }
  /* ---------- テレビの「🎤 こえの じゅんび」に v0.30 の 行（§15）---------- */
  function rowsTick() {
    const set = document.getElementById('tv28Set'); if (!set) return; const cols = set.querySelector('.st') || set; let box = document.getElementById('tv30Rows'); const cf = S.store.cfg, H = ui().huddle;
    const on = (b, t) => `<button id="${b}" class="${t ? 'on' : ''}">${t ? 'ON' : 'OFF'}</button>`;
    const html = `<p><b>💬 ${Lx('せっとく', '说服')}：</b>${on('tv30Pv', cf.pv)}　<b>💗 ${Lx('こころメーター', '心之计')}：</b>${on('tv30Me', cf.meter)}</p>`
      + `<p><b>🗣 ${esc(Lx(H.settingName.ja, H.settingName.zh))}：</b>` + [['key', H.optKey], ['all', H.optAll], ['off', H.optOff]].map(([k, l]) => `<button data-hud="${k}" class="${cf.hud === k ? 'on' : ''}">${esc(Lx(l.ja, l.zh))}</button>`).join('') + '</p>'
      + `<p><button id="tv30Forget" class="${S.rowsArm ? 'arm' : ''}">🧹 ${S.rowsArm ? Lx('もういちど おすと けす', '再按一次清除') : Lx('ボスの おもいでを けす', '清除首领的记忆')}</button></p>`;
    if (box && box.parentNode === cols && box.dataset.h === html) return;
    if (!box || box.parentNode !== cols) { box = document.createElement('div'); box.id = 'tv30Rows'; cols.appendChild(box); }
    box.dataset.h = html; box.innerHTML = html;
    const set2 = f => () => { f(); S.store = P.cleanStore(S.store); save(); box.dataset.h = ''; rowsTick(); };
    box.querySelector('#tv30Pv').onclick = set2(() => { cf.pv = cf.pv ? 0 : 1; }); box.querySelector('#tv30Me').onclick = set2(() => { cf.meter = cf.meter ? 0 : 1; });
    box.querySelectorAll('button[data-hud]').forEach(b => { b.onclick = set2(() => { cf.hud = b.dataset.hud; }); });
    box.querySelector('#tv30Forget').onclick = () => { if (S.rowsArm && performance.now() - S.rowsArm < 4000) { for (const k of P.ORDER) { const b = S.store.b[k]; b.mem = []; b.pr = { v: 0, by: '', d: 0, kept: 0, at: 0 }; } S.rowsArm = 0; save(); C.toast && C.toast(Lx('🧹 ボスの おもいでを けしたよ', '🧹 清除了首领的记忆'), '#ffd0e0'); }
      else S.rowsArm = performance.now(); box.dataset.h = ''; rowsTick(); };
  }
  function tick() { try { letterTick(); } catch (e) { console.warn('P13：てがみで 失敗しました', e); } meterTick(); rowsTick(); if (S.rowsArm && performance.now() - S.rowsArm > 4000) { S.rowsArm = 0; const b = document.getElementById('tv30Rows'); if (b) b.dataset.h = ''; } }

  /* ==================== スマホ：🆘 おねがい（ロビーの ボタン）・こころの 行 ==================== */
  function padInit() { if (C.hookNav) C.hookNav(padNav); const gm = () => { try { padGarage(); } catch (e) { console.warn('P13：ガレージの こころの 行で 失敗しました', e); } };
    if (C.hookPad) C.hookPad(gm); else if (C.hookNav) C.hookNav(gm); }
  // スマホの ガレージ：「今の強さ」の 箱の 下に「かぞくの こころ 💗3 🔥2 ✨😆5」（§7.1）。おすと テレビに こころメーターの スライド。点が まだ ない 時は 出さない
  function padGarage() { const g = padG(), t = g && g.tv30, m = t && Array.isArray(t.m) && t.m.length >= 4 ? t.m : null, box = document.querySelector('#garage:not(.hide) #garInfo .genh');
    let el = document.getElementById('tv30GarM'); const show = !!(m && m[3] >= 0 && box), sig = show ? JSON.stringify(m) + C.lang() : '';
    if (!show) { if (el) el.remove(); return; } if (el && el.parentNode === box && el.dataset.sig === sig) return;
    if (!el || el.parentNode !== box) { if (el) el.remove(); el = document.createElement('p'); el.id = 'tv30GarM'; el.setAttribute('role', 'button');
      el.onclick = () => { C.room.emit('cmd', { a: 'tv30', op: 'meter' }).catch(e => console.warn('P13：こころメーターを 送れませんでした', e)); C.vibrate && C.vibrate(15); }; box.appendChild(el); }
    const ic = ['💗', '🔥', '😆']; el.dataset.sig = sig;
    el.innerHTML = `<b>${esc(Lx('かぞくの こころ', '全家的心'))}</b>　` + ic.map((c, i) => `<span>${m[3] === i ? '✨' : ''}${c} Lv${m[i] | 0}</span>`).join('　'); }
  function padG() { const ps = C.room.peers ? C.room.peers() : [], host = ps.find(p => p.presence && p.presence.role === 'tv'); return host && host.presence.g ? host.presence.g : null; }
  function padNav(S2, mine) { const box = document.getElementById('navBox'); if (!box) return; const t = S2 && S2.tv30, al = t && Array.isArray(t.aid) ? t.aid : [];
    const show = !!(al.length && mine && S2.ph === 'lobby' && C.me && C.me.joined && !(S2.tv29 && S2.tv29.on)), sig = show + C.lang() + JSON.stringify(al);
    if (box.dataset.tv30 === sig && (!show || box.querySelector('button.tv30'))) return; box.dataset.tv30 = sig; box.querySelectorAll('button.tv30').forEach(b => b.remove());
    if (show) for (const [k, nj, nz] of al.slice(0, 2)) { const b = document.createElement('button'); b.className = 'tv30'; b.textContent = '🆘 ' + Lx(`${nj} の おねがい`, `${nz}的请求`);
      b.onclick = () => { C.room.emit('cmd', { a: 'tv30', op: 'aid', boss: k }).catch(e => console.warn('P13：🆘 を 送れませんでした', e)); C.vibrate && C.vibrate(20); }; box.appendChild(b); box.classList.remove('hide'); } }

  Object.assign(T, { attach, duelMaybe, onEvent, afterBoss, onLobby, startPv, startAid, openMeter, _s: S, ext: EXT });
})(typeof window !== 'undefined' ? window : globalThis);
/* P13 scene: end */

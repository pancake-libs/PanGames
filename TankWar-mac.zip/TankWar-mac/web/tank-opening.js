/* ==================== P16B（v0.31）：オープニング「かぞくの せんしゃたい、おうちを まもる」 ====================
   設計：tank-plan-1117/plan.md の F 章（F-0 かぞくの 4 台・F-0b ふきだし・F-1〜F-5）。約束：tank-v031/partB-contract.md
   - 8 コマ。字は 自分では 進まない（スマホの「📖 よんだ」を 参加している 全員が 押すと 次へ）。字の 無い 動き（各コマの 始まり・④→⑤・⑧）は 自分で 進む
   - 絵は 今 ある 絵だけ（tk/v10-*.png の 戦車・ボス・おうち）＋ 絵文字 ＋ コードで かく 形。戦車に 顔は かかない。気持ちは 大きな ふきだし
   - 見た目は UI キット（tank-ui.css の .k-card / .k-pill / .k-dot / .k-mat / .k-spr）。字は M PLUS Rounded 1c（.k）
   - 声：語りは No.7（読み聞かせ）。コマ 1・6 は 今 ある 声（narr_w1_1・narr_w1_2）、ほかの 6 本は tools/v031-clips.json で 録る（op31_*）。無い 時は 字だけ（待たない）
   - 起動の たびに 1 回：最初の 画面で 1 人めの スマホが 参加した 時に 始まる。⏭ とばす で すぐ 最初の 画面へ。だれも いない まま 3 分 → 字の 無い 動きだけを くり返す
   - あとで 動画（opening-01..08.mp4、16:9）を コマごとの 背景に できる：setVideo()。字・声・ふきだしは その 上に のこる
   - テレビ → スマホ：presence の g.op31。スマホ → テレビ：cmd {a:'op31', op:'read'|'skip'|'story', i}
   - node でも 読める（データと 純粋な 関数だけ。module.exports）。ブラウザでは window.TankOpening
   ==================== */
(function (root) {
  'use strict';
  // ---------- F-0 かぞくの 4 台（名前と 形は きまり）。slot＝プレイヤーの 色（0 黄・1 緑・2 青・3 ピンク）、car＝今 ある 車の 形（a ふつう・b はやい・c どっしり・d おたすけ） ----------
  const FAMILY = [
    { id: 'papa', name: 'パパ', slot: 2, car: 'c', mark: '🧢', scale: 1.18, word: '大きくて つよい' },
    { id: 'mama', name: 'ママ', slot: 3, car: 'd', mark: '🎀', scale: 1.0, word: 'みんなを たすける' },
    { id: 'kaito', name: 'カイトくん', slot: 1, car: 'b', mark: '⚡', scale: 0.95, word: 'はやくて げんき' },
    { id: 'umi', name: 'ウミちゃん', slot: 0, car: 'a', mark: '🌼', scale: 0.76, word: 'ちいさくて ゆうかん' }
  ];
  const famRow = f => 'abcd'.indexOf(f.car) * 4 + f.slot;   // tk/v10-players.png の 行（p<slot>_<car>）
  // 絵の 表（tank.html の ART と 同じ 数）。frame：1 コマの 大きさ（px）。向き 3＝右下、7＝左上
  const ATLAS = {
    players: { src: 'v10-players.png', px: 232 }, enemies: { src: 'v10-enemies.png', px: 232 },
    bosses2: { src: 'v10-bosses2.png', px: 611 }, bosses3: { src: 'v10-bosses3.png', px: 611 }, bosses4: { src: 'v10-bosses4.png', px: 481 }, house: { src: 'v10-house.png', px: 400 }
  };
  const BOSS = { king: ['bosses4', 6], core: ['bosses4', 3], bigtank: ['bosses2', 2], sandship: ['bosses2', 5], twin: ['bosses2', 0], snowman: ['bosses3', 2], dragon: ['bosses3', 5] };
  const ENEMY_ROW = { normal: 0, fast: 1, heavy: 2, armor: 3, bouncer: 5 };

  // ---------- F-2 コマ割り（座標は 1920×1080）。tanks：f＝FAMILY の 番号、fr＝向き、k＝大きさ（FAMILY.scale に かける）、plate＝名前の 札の y（戦車の 上はしから）、
  //   bubbles：t＝tanks の 番号、em＝絵文字、tx＝かな（1〜5 字。無ければ 絵文字だけ）、d＝大きさ、at＝出る 秒。lead＝字が 出るまでの 動きだけの 秒、dur＝動きの 長さ（くり返しの 時も） ----------
  const ENEMIES = [['normal', 60, 450], ['heavy', 280, 600], ['fast', -50, 640], ['bouncer', 400, 420], ['armor', 190, 310]];
  const SHOTS = [
    { no: 1, id: 'house', sky: 'day', hill: 600, cam: 'down', lead: 1.6, dur: 8, music: 'lobby', vo: 'narr_w1_1', who: 'narr', icon: '🔊', cap: '#fff',
      ja: 'むかし むかし、はらっぱに<br>ちいさな おうちが ありました',
      house: { x: 770, y: 330, k: 0.95 }, smoke: [1000, 320], flowers: true, sfx: [[0.3, 'pon'], [1.2, 'pon']], tanks: [], bubbles: [] },
    { no: 2, id: 'family', sky: 'day', hill: 600, lead: 1.9, dur: 8, music: 'lobby', vo: 'op31_narr_1', who: 'narr', icon: '🔊', cap: '#fff',
      ja: 'この おうちには、なかよしの<br>かぞくが すんで います',
      house: { x: 90, y: 400, k: 0.75 }, heart: [300, 330, 2.0],
      tanks: [{ f: 0, x: 440, y: 420, fr: 3, plate: 262, anim: 'hop', at: 0.15 }, { f: 1, x: 800, y: 470, fr: 3, plate: 222, anim: 'hop', at: 0.5 },
        { f: 2, x: 1140, y: 460, fr: 3, plate: 212, anim: 'hop', at: 0.85 }, { f: 3, x: 1480, y: 520, fr: 3, plate: 172, anim: 'hop', at: 1.2 }],
      sfx: [[0.3, 'join'], [0.65, 'join'], [1.0, 'join'], [1.35, 'join'], [2.0, 'heart']],
      bubbles: [{ t: 0, em: '😊', tx: 'よし！', at: 0.6 }, { t: 1, em: '🥰', tx: 'うふふ', at: 0.95 }, { t: 2, em: '😆', tx: 'イェイ！', at: 1.3 }, { t: 3, em: '😊', tx: 'わーい', at: 1.65 }] },
    { no: 3, id: 'night', sky: 'night', hill: 600, fromDay: true, lead: 2.0, dur: 8, music: '', vo: 'op31_narr_2', who: 'narr', icon: '🌙', cap: '#fff',
      ja: 'よるは みんな ぐっすり。<br>あったかい おうち です',
      house: { x: 770, y: 300, k: 0.95, glow: true },
      tanks: [{ f: 0, x: 330, y: 500, fr: 3, dim: true }, { f: 1, x: 560, y: 600, fr: 3, dim: true }, { f: 2, x: 1240, y: 520, fr: 3, dim: true }, { f: 3, x: 1500, y: 590, fr: 3, dim: true }],
      sfx: [],
      bubbles: [{ t: 0, em: '😴', tx: 'ぐー', at: 1.0 }, { t: 1, em: '😴', d: 130, at: 1.3 }, { t: 2, em: '😴', d: 130, at: 1.6 }, { t: 3, em: '😴', tx: 'すやすや', d: 180, at: 1.9 }] },
    { no: 4, id: 'watchers', sky: 'dusk', hill: 700, lead: 2.8, dur: 9, music: 'boss', vo: 'op31_narr_3', who: 'narr', icon: '👀', cap: 'var(--grape-l)',
      ja: 'とおくから、それを じっと<br>見ている ものたちが いました',
      house: { x: 885, y: 690, k: 0.26, glow: true },
      sil: [['bigtank', 60, 330, 0.62, 3, '#7dff8c', 0.3], ['sandship', 340, 250, 0.62, 3, '#ffd66b', 0.7], ['snowman', 1230, 250, 0.62, 5, '#9fe4ff', 1.1],
        ['dragon', 1500, 330, 0.62, 5, '#ff8a5c', 1.5], ['core', 1010, 420, 0.6, 4, '#c8d6e6', 1.9], ['king', 640, 40, 1.3, 4, '#c06bff', 2.3]],
      eyes: [[868, 400], [1000, 400], 2.6], sfx: [[0.2, 'rumble'], [2.3, 'rumble']], tanks: [], bubbles: [] },
    { no: 5, id: 'twin', sky: 'dusk', hill: 700, lead: 2.6, dur: 7, music: 'boss', vo: 'op31_twin_1', who: 'twin', name: 'ふたご砲', icon: '💬', cap: 'var(--orange-l)',
      ja: 'あの おうち、いいなあ…。<br>よし、もらっちゃおう！',
      house: { x: 210, y: 590, k: 0.38, glow: true, spark: true }, sil: [['king', 1150, 30, 1.1, 4, '#c06bff', 0, 0.45]],
      boss: { kind: 'twin', x: 690, y: 150, k: 0.95, fr: 5, anim: 'twin' }, pill: [560, 150, 'ジロッ', 'berry', 1.8, -6],
      sfx: [[1.8, 'jiro']], tanks: [], bubbles: [] },
    { no: 6, id: 'enemies', sky: 'day', hill: 600, lead: 2.5, dur: 8, music: 'boss', vo: 'narr_w1_2', who: 'narr', icon: '⚠️', cap: 'var(--berry-l)',
      ja: 'ある ひ、ふしぎな せんしゃが<br>やって きました',
      house: { x: 1560, y: 330, k: 0.8 }, enemies: 'in', dust: [[640, 520], [720, 640], [600, 700]], shake: 2.0, pill: [120, 150, 'ゴゴゴ…', 'grape', 0.3, -6],
      tanks: [{ f: 0, x: 860, y: 380, fr: 7 }, { f: 1, x: 1230, y: 410, fr: 7 }, { f: 2, x: 1010, y: 570, fr: 7 }, { f: 3, x: 1350, y: 590, fr: 7 }],
      sfx: [[0.2, 'danger'], [1.6, 'rumble']],
      bubbles: [{ t: 0, em: '😲', tx: 'えっ！？', d: 200, at: 2.2 }, { t: 1, em: '❗', d: 140, at: 2.35 }, { t: 2, em: '💦', d: 130, at: 2.5 }, { t: 3, em: '😨', d: 130, at: 2.65 }] },
    { no: 7, id: 'sortie', sky: 'day', hill: 600, lead: 1.8, dur: 8, music: 'battle4', vo: 'op31_narr_4', who: 'narr', icon: '🚩', cap: 'var(--sun-l)',
      ja: 'パパ、ママ、カイトくん、ウミちゃん、<br>しゅつどう！ おうちを まもるぞ！',
      house: { x: 1560, y: 330, k: 0.8 }, shield: [1575, 330, 300], enemies: 'stay', dust: [[1090, 520], [1190, 680], [1450, 700]], pill: [110, 130, 'ブロロロ！', 'berry', 0.4, -6],
      tanks: [{ f: 0, x: 800, y: 380, fr: 7, anim: 'go', at: 0 }, { f: 1, x: 1190, y: 410, fr: 7, anim: 'go', at: 0.1 }, { f: 2, x: 950, y: 570, fr: 7, anim: 'go', at: 0.2 }, { f: 3, x: 1310, y: 590, fr: 7, anim: 'go', at: 0.3 }],
      sfx: [[0.1, 'engine'], [0.5, 'engine']],
      bubbles: [{ t: 0, em: '😤', tx: 'まもるぞ！', d: 210, at: 1.1 }, { t: 1, em: '💪', d: 140, at: 1.25 }, { t: 2, em: '🔥', d: 130, at: 1.4 }, { t: 3, em: '😤', d: 130, at: 1.55 }] },
    { no: 8, id: 'logo', sky: 'day', hill: 560, lead: 0.6, dur: 6.5, music: 'lobby', vo: 'op31_narr_5', who: 'narr', icon: '', cap: '', ja: '', logo: true, confetti: true,
      house: { x: 170, y: 640, k: 0.62 },
      tanks: [{ f: 0, x: 470, y: 690, fr: 3, k: 0.9, plate: -70 }, { f: 1, x: 800, y: 720, fr: 3, k: 0.9, plate: -70 }, { f: 2, x: 1110, y: 710, fr: 3, k: 0.9, plate: -70 }, { f: 3, x: 1420, y: 750, fr: 3, k: 0.9, plate: -70 }],
      sfx: [[0.5, 'fanfare']], bubbles: [] }
  ];
  // 声：今 ある 2 本（世界 1 の 始まりの 語り）と 録る 6 本（tools/v031-clips.json。名前＝<台本>_<箱>）
  const CLIPS = { reuse: ['narr_w1_1', 'narr_w1_2'], rec: ['op31_narr_1', 'op31_narr_2', 'op31_narr_3', 'op31_narr_4', 'op31_narr_5', 'op31_twin_1'] };
  const LINES = { op31_narr_5: 'おうちを まもれ！ せんしゃたい！' };   // 字の 出ない 声（コマ 8）
  const IDLE_SEC = 180;          // 最初の 画面で だれも いない まま この 秒 → 動きだけの くり返し
  const READ_MIN = 1.0;          // 字が 出てから 「よんだ」を 受けつけるまでの 秒
  const VOICE_WAIT_MAX = 8;      // 声の 間は 「よんだ」を 待たせる（いちばん 長くて この 秒）
  const FADE_MS = 450;
  const IDLE_VOL = 0.35;
  // 全員が 読んだ か（ids＝参加している 人。0 人の 時は false）
  const allRead = (ids, rd) => ids.length > 0 && ids.every(id => !!(rd && rd[id]));
  const plainText = s => String(s || '').replace(/([、。！？…])<br>/g, '$1').replace(/<br>/g, ' ');
  // コマの 字（声の 台本の 文と 同じ。<br> と 空白を 声の 文に そろえる）
  const lineOf = sh => sh.ja ? plainText(sh.ja) : (LINES[sh.vo] || '');

  const api = { FAMILY, SHOTS, CLIPS, LINES, ATLAS, BOSS, IDLE_SEC, READ_MIN, VOICE_WAIT_MAX, famRow, allRead, plainText, lineOf };
  if (typeof document === 'undefined') { if (typeof module !== 'undefined') module.exports = api; return; }

  /* ==================== ブラウザ ==================== */
  let H = { art: '/tk/' };       // テレビの host（attach）
  let P = null;                  // スマホの host（attachPad）
  const S = { on: false, mode: '', i: 0, t: 0, rd: {}, played: false, seq: 0, capOn: false, voOn: false, sfxI: 0, idleT: 0, last: 0, root: null, stage: null, shot: null, hud: null, vol: 1, video: null, vopt: {}, fromView: '' };
  const q = new URLSearchParams(location.search), FORCE = q.get('opening');
  const autoOk = () => FORCE === '1' ? true : FORCE === '0' ? false : !navigator.webdriver;   // 自動の 確かめ（Playwright）では 自分から 始めない（?opening=1 で 始める）
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  const famCol = f => `var(--p${f.slot})`;

  // ---------- 部品（HTML の 文字列）----------
  // 戦車・ボスの 絵（UI キットの .k-spr）。set＝ATLAS の 名前、row・fr＝行・向き、k＝大きさ、st＝外側の style、cls＝外側の class
  function spr(set, row, fr, k, st, cls, inner) {
    const A = ATLAS[set], w = A.px * k;
    return `<div class="op31-a ${cls || ''}" style="width:${w}px;height:${w}px;${st || ''}"><i class="k-spr op31-spr" style="position:absolute;left:0;top:0;transform-origin:0 0;background-repeat:no-repeat;width:${A.px}px;height:${A.px}px;background-image:url(${H.art}${A.src});background-position:-${fr * A.px}px -${row * A.px}px;transform:scale(${k})${inner ? ';' + inner : ''}"></i></div>`;
  }
  const sprite = (f, fr, k) => spr('players', famRow(f), fr === undefined ? 3 : fr, (k || 1) * f.scale, 'position:relative;display:inline-block');
  function plate(f, px) {
    px = px || 34;
    return `<span class="k-pill op31-plate" style="--c:${famCol(f)};font-size:${px}px;padding:4px 20px 4px 6px${f.slot === 2 ? ';color:#fff;text-shadow:0 2px 0 rgba(0,0,0,.3)' : ''}"><span class="op31-mark" style="width:${px * 1.5}px;height:${px * 1.5}px;font-size:${px * .9}px">${f.mark}</span>${esc(f.name)}</span>`;
  }
  const houseImg = (h, extra) => `<img class="op31-house${h.glow ? ' glow' : ''}" src="${H.art}${ATLAS.house.src}" alt="" style="left:${h.x}px;top:${h.y}px;width:${400 * h.k}px;${extra || ''}">`;
  function skyHtml(sh, idle) {
    let o = `<div class="op31-sky ${sh.sky}"></div>`;
    if (sh.sky === 'day') o += `<div class="op31-rays"></div>` + [[1250, 90, 1], [300, 210, .7], [1650, 300, .8]].map((c, i) => `<div class="op31-cloud" style="left:${c[0]}px;top:${c[1]}px;transform:scale(${c[2]});animation-delay:-${i * 7}s"></div>`).join('');
    if (sh.sky === 'night') { for (let i = 0; i < 40; i++) o += `<div class="op31-star" style="left:${(i * 397) % 1900}px;top:${(i * 211) % 470}px;width:${6 + i % 3 * 3}px;height:${6 + i % 3 * 3}px;animation-delay:-${(i % 7) * .4}s"></div>`;
      o += `<div class="op31-moon"></div><div class="op31-moon2"></div>`; }
    o += `<div class="op31-hill k-mat" style="top:${sh.hill}px"></div>`;
    if (sh.sky !== 'day') o += `<div class="op31-hill ${sh.sky}" style="top:${sh.hill}px"></div>`;
    if (sh.fromDay && !idle) o += `<div class="op31-dayfade"><div class="op31-sky day"></div><div class="op31-hill k-mat" style="top:${sh.hill}px"></div></div>`;
    return o;
  }
  // ふきだし（F-0b）：白い 丸い ふきだし。ふちは その人の 色。しっぽが 戦車を 指す。主役 190〜210px（字つき）、わき役 130px（絵文字だけ）
  function bubbleHtml(b, tk, f, idle) {
    const k = (tk.k || 1) * f.scale, cx = tk.x + 232 * k / 2, tipY = tk.y + 14, tx = idle ? '' : (b.tx || ''), d = b.d || (tx ? 190 : 130), h = tx ? d + 56 : d, rot = (b.t % 2 ? -2 : 2);
    const a = S.vopt.anchors && S.vopt.anchors[S.shotNo] && S.video ? S.vopt.anchors[S.shotNo][b.t] : null;
    const x = a ? a[0] : cx, y = a ? a[1] : tipY;
    return `<div class="op31-bw" data-t="${b.t}" style="left:${x}px;top:${y}px;--c:${famCol(f)};--d:${d}px;animation-delay:${(b.at || 0) + .3}s"><div class="op31-bb${tx ? ' tx' : ''}" style="min-width:${d}px;height:${h}px;border-radius:${d * .42}px;--r:${rot}deg;padding:0 ${tx ? 26 : 0}px;animation-delay:${b.at || 0}s">` +
      `<span class="op31-em" style="font-size:${d * .6}px">${b.em}</span>${tx ? `<b style="font-size:${Math.round(d * .27)}px">${esc(tx)}</b>` : ''}</div></div>`;
  }
  function shotHtml(sh, idle) {
    let g = skyHtml(sh, idle), fx = '';
    if (sh.smoke) g += `<div class="op31-smoke" style="left:${sh.smoke[0]}px;top:${sh.smoke[1]}px"><i></i><i></i><i></i></div>`;
    if (sh.house) g += houseImg(sh.house);
    if (sh.house && sh.house.spark) g += `<div class="op31-emo op31-twinkle" style="left:${sh.house.x + 120}px;top:${sh.house.y - 50}px;font-size:70px">✨</div>`;
    if (sh.flowers) g += ['🌼', '🌷', '🌼', '🌸', '🌼', '🌷'].map((f, i) => `<div class="op31-emo" style="left:${260 + i * 270 + (i % 2) * 60}px;top:${700 + (i % 3) * 40}px;font-size:54px">${f}</div>`).join('');
    if (sh.shield) g += `<div class="op31-shield" style="left:${sh.shield[0]}px;top:${sh.shield[1]}px;width:${sh.shield[2]}px;height:${sh.shield[2]}px"></div>`;
    for (const s of sh.sil || []) { const [kind, x, y, k, fr, col, at, op] = s, B = BOSS[kind];
      g += spr(B[0], B[1], fr, k, `left:${x}px;top:${y}px;--g:${col};animation-delay:${at}s;${op ? 'opacity:' + op : ''}`, 'op31-sil' + (op ? ' faint' : '')); }
    if (sh.eyes) g += sh.eyes.slice(0, 2).map(e => `<div class="op31-eye" style="left:${e[0]}px;top:${e[1]}px;animation-delay:${sh.eyes[2]}s"></div>`).join('');
    if (sh.boss) { const b = sh.boss, B = BOSS[b.kind]; g += spr(B[0], B[1], b.fr, b.k, `left:${b.x}px;top:${b.y}px`, 'op31-boss ' + b.anim); }
    if (sh.enemies) g += ENEMIES.map((e, i) => spr('enemies', ENEMY_ROW[e[0]], 3, .85, `left:${e[1]}px;top:${e[2]}px;animation-delay:${i * .12}s`, 'op31-en ' + sh.enemies)).join('');
    if (sh.dust) g += sh.dust.map((d, i) => `<div class="op31-dust" style="left:${d[0]}px;top:${d[1]}px;animation-delay:${.3 + i * .25}s"></div>`).join('');
    sh.tanks.forEach((tk, n) => { const f = FAMILY[tk.f], k = (tk.k || 1) * f.scale;
      g += spr('players', famRow(f), tk.fr, k, `left:${tk.x}px;top:${tk.y}px;animation-delay:${tk.at || 0}s`, 'op31-tank ' + (tk.anim || '') + (tk.dim ? ' dim' : ''));
      if (tk.plate !== undefined) g += `<div class="op31-pl ${tk.anim || ''}" style="left:${tk.x + 232 * k / 2}px;top:${tk.y + tk.plate}px;animation-delay:${(tk.at || 0) + .2}s">${plate(f, tk.k && tk.k < 1 ? 32 : 34)}</div>`;
      void n; });
    if (sh.heart) g += `<div class="op31-emo op31-heart" style="left:${sh.heart[0]}px;top:${sh.heart[1]}px;animation-delay:${sh.heart[2]}s">💕</div>`;
    if (sh.logo) fx += `<div class="op31-logo"><div class="op31-logo-in"><span data-t="おうちを守れ！">おうちを守れ！</span><span class="r" data-t="戦車隊">戦車隊</span></div></div>`;
    if (sh.confetti) fx += ['🎉', '✨', '🎊', '✨', '🎉'].map((f, i) => `<div class="op31-emo op31-conf" style="left:${180 + i * 390}px;top:${60 + (i % 2) * 90}px;animation-delay:${.4 + i * .15}s">${f}</div>`).join('');
    if (sh.pill) { const [x, y, t, c, at, r] = sh.pill; fx += `<div class="op31-sfx" style="left:${x}px;top:${y}px;--r:${r}deg;animation-delay:${at}s"><span class="k-pill w" style="--c:var(--${c})">${esc(t)}</span></div>`; }
    for (const b of sh.bubbles) fx += bubbleHtml(b, sh.tanks[b.t], FAMILY[sh.tanks[b.t].f], idle);
    return `<div class="op31-bgv"></div><div class="op31-drawn"><div class="op31-cam ${sh.cam || ''}${sh.shake ? ' shake' : ''}" style="--shake:${sh.shake || 0}s">${g}</div></div><div class="op31-fx">${fx}</div>`;
  }
  function capHtml(sh) {
    if (!sh.ja) return '';
    return `<div class="op31-cap k-card" style="background:${sh.cap}">${sh.name ? `<span class="k-pill w op31-who" style="--c:var(--orange)">${esc(sh.name)}</span>` : ''}` +
      `<span class="op31-ic">${sh.icon}</span><div class="op31-tx">${sh.ja}</div><div class="op31-rd"><span class="k-pill op31-yb">📖 よんだ</span><span class="op31-dots"></span></div></div>`;
  }

  // ---------- テレビ：画面 ----------
  function css() {
    if (document.getElementById('op31Css')) return;
    const c = document.createElement('style'); c.id = 'op31Css'; c.textContent = `
#op31{position:fixed;inset:0;z-index:60;overflow:hidden;background:#49b6ff;opacity:1;transition:opacity ${FADE_MS}ms}
#op31.out{opacity:0;pointer-events:none}
#op31 .op31-stage{position:absolute;left:50%;top:50%;width:1920px;height:1080px;transform-origin:50% 50%;overflow:hidden}
#op31 .op31-shot{position:absolute;inset:0;animation:op31-fadein .45s ease-out both}
#op31 .op31-bgv,#op31 .op31-drawn,#op31 .op31-fx,#op31 .op31-cam{position:absolute;inset:0}
#op31 .op31-bgv video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
#op31 .op31-shot.vid .op31-drawn{visibility:hidden}
#op31 .op31-fx{pointer-events:none}
#op31 .op31-a{position:absolute}
#op31 .op31-sky{position:absolute;inset:0}
#op31 .op31-sky.day{background:linear-gradient(#49b6ff,#a8e4ff 60%,#e9fbff)}
#op31 .op31-sky.night{background:linear-gradient(#0b1440,#27306e 55%,#5a4a8a)}
#op31 .op31-sky.dusk{background:linear-gradient(#3b2a6b,#b0528a 45%,#ffb37a 75%,#ffe2a8)}
#op31 .op31-rays{position:absolute;left:-300px;top:-520px;width:1700px;height:1700px;border-radius:50%;background:repeating-conic-gradient(from 0deg,rgba(255,255,255,.28) 0 9deg,transparent 9deg 18deg);-webkit-mask:radial-gradient(circle,#000 20%,transparent 68%);mask:radial-gradient(circle,#000 20%,transparent 68%);animation:op31-spin 90s linear infinite}
#op31 .op31-cloud{position:absolute;width:260px;height:80px;border-radius:99px;background:#fff;box-shadow:70px -36px 0 10px #fff,150px -10px 0 0 #fff;opacity:.9;transform-origin:0 0;animation:op31-drift 24s ease-in-out infinite alternate}
#op31 .op31-star{position:absolute;border-radius:50%;background:#fff8c0;animation:op31-tw 2.8s ease-in-out infinite alternate}
#op31 .op31-moon{position:absolute;left:1480px;top:70px;width:170px;height:170px;border-radius:50%;background:#fff3b0;box-shadow:0 0 80px #fff3b0}
#op31 .op31-moon2{position:absolute;left:1440px;top:50px;width:170px;height:170px;border-radius:50%;background:#131b4c}
#op31 .op31-hill{position:absolute;left:-200px;right:-200px;height:900px;border-radius:50% 50% 0 0/22% 22% 0 0;border-top:8px solid var(--ink)}
#op31 .op31-hill.night{background:rgba(12,20,70,.55);border-top-color:transparent}
#op31 .op31-hill.dusk{background:rgba(90,40,90,.35);border-top-color:transparent}
#op31 .op31-dayfade{position:absolute;inset:0;animation:op31-fadeout 2.2s ease-in .2s both}
#op31 .op31-house{position:absolute;filter:drop-shadow(0 12px 0 rgba(27,42,34,.3))}
#op31 .op31-house.glow{filter:drop-shadow(0 0 50px rgba(255,220,120,.95));animation:op31-glow 2.4s ease-in-out infinite alternate}
#op31 .op31-emo{position:absolute;line-height:1}
#op31 .op31-smoke{position:absolute}
#op31 .op31-smoke i{position:absolute;left:0;top:0;width:44px;height:44px;border-radius:50%;background:rgba(255,255,255,.9);animation:op31-smoke 3.6s ease-out infinite}
#op31 .op31-smoke i:nth-child(2){animation-delay:1.2s}#op31 .op31-smoke i:nth-child(3){animation-delay:2.4s}
#op31 .op31-tank{filter:drop-shadow(0 12px 6px rgba(0,0,0,.3))}
#op31 .op31-tank.dim{filter:brightness(.7) drop-shadow(0 12px 6px rgba(0,0,0,.3))}
#op31 .op31-tank.hop,#op31 .op31-pl.hop{animation:op31-hop .7s cubic-bezier(.3,.7,.4,1) both}
#op31 .op31-tank.go{animation:op31-go 1.1s ease-out both}
#op31 .op31-pl{position:absolute;transform:translateX(-50%)}
#op31 .op31-pl.hop{animation-name:op31-hopx}
#op31 .op31-mark{border-radius:50%;background:#fff;border:3px solid var(--ink);display:inline-flex;align-items:center;justify-content:center;text-shadow:none}
#op31 .op31-heart{font-size:80px;animation:op31-heart 2.6s ease-out both}
#op31 .op31-sil{filter:brightness(0) drop-shadow(0 0 18px var(--g)) drop-shadow(0 0 40px var(--g));animation:op31-sil 1.1s ease-out both}
#op31 .op31-sil.faint{animation:none}
#op31 .op31-eye{position:absolute;width:46px;height:26px;border-radius:50%;background:#ffe45c;box-shadow:0 0 30px #ffe45c;animation:op31-eye 3s ease-in-out both infinite}
#op31 .op31-boss{filter:drop-shadow(0 14px 8px rgba(0,0,0,.35))}
#op31 .op31-boss.twin{animation:op31-inR 1.6s cubic-bezier(.2,.8,.3,1) both,op31-sway 1.8s ease-in-out 1.6s infinite alternate}
#op31 .op31-en{filter:drop-shadow(0 10px 5px rgba(0,0,0,.35))}
#op31 .op31-en.in{animation:op31-inL 2.2s cubic-bezier(.25,.7,.35,1) both}
#op31 .op31-en.stay{animation:op31-jit .5s steps(2) infinite}
#op31 .op31-dust{position:absolute;width:70px;height:70px;border-radius:50%;background:rgba(255,255,255,.7);box-shadow:-60px 14px 0 -10px rgba(255,255,255,.5),-110px 4px 0 -22px rgba(255,255,255,.4);animation:op31-dust 1.6s ease-out both infinite}
#op31 .op31-shield{position:absolute;border-radius:50%;border:8px solid rgba(120,220,255,.9);box-shadow:0 0 30px rgba(120,220,255,.9),inset 0 0 40px rgba(120,220,255,.5);animation:op31-shield 1.6s ease-in-out infinite alternate}
#op31 .op31-cam.down{transform-origin:50% 42%;animation:op31-camdown 8s cubic-bezier(.3,.6,.4,1) both}
#op31 .op31-cam.shake{animation:op31-shake .6s linear var(--shake) 2}
#op31 .op31-sfx{position:absolute;transform:rotate(var(--r));animation:op31-popin .3s ease-out both}
#op31 .op31-sfx .k-pill{font-size:66px;padding:10px 44px;border-width:6px}
#op31 .op31-twinkle{animation:op31-tw 1.2s ease-in-out infinite alternate}
#op31 .op31-conf{font-size:80px;animation:op31-conf 1.4s ease-out both}
#op31 .op31-bw{position:absolute;width:0;height:0;animation:op31-bob 1.8s ease-in-out infinite alternate}
#op31 .op31-bb{position:absolute;left:0;bottom:34px;box-sizing:border-box;background:#fff;border:9px solid var(--c);box-shadow:0 10px 0 rgba(27,42,34,.28),inset 0 -12px 0 color-mix(in srgb,var(--c) 22%,#fff);display:flex;flex-direction:column;align-items:center;justify-content:center;transform-origin:50% 100%;animation:op31-pop .28s ease-out both}
#op31 .op31-bb::before{content:"";position:absolute;left:50%;bottom:-34px;margin-left:-22px;border:22px solid transparent;border-top:30px solid var(--c);border-bottom:0}
#op31 .op31-bb::after{content:"";position:absolute;left:50%;bottom:-18px;margin-left:-13px;border:13px solid transparent;border-top:19px solid #fff;border-bottom:0}
#op31 .op31-em{line-height:1}
#op31 .op31-bb b{line-height:1.05;color:var(--ink);white-space:nowrap;font-weight:900}
#op31 .op31-logo{position:absolute;left:0;right:0;top:120px;display:flex;justify-content:center;animation:op31-drop 1.3s cubic-bezier(.3,.7,.4,1) .2s both}
#op31 .op31-logo-in{font-weight:900;white-space:nowrap;isolation:isolate;transform:rotate(-2deg);display:flex;flex-direction:column;align-items:center;font-size:150px;line-height:1.15}
#op31 .op31-logo-in span{position:relative;display:inline-block;color:transparent;background:linear-gradient(#fffbe0 10%,#ffe45c 45%,#ffab00 90%);-webkit-background-clip:text;background-clip:text}
#op31 .op31-logo-in span::before{content:attr(data-t);position:absolute;left:0;top:0;z-index:-1;color:var(--ink);-webkit-text-stroke:24px var(--ink);text-shadow:0 14px 0 var(--ink),0 26px 24px rgba(0,0,0,.35);background:none;-webkit-background-clip:border-box}
#op31 .op31-logo-in span::after{content:attr(data-t);position:absolute;left:0;top:0;z-index:-2;color:#fff;-webkit-text-stroke:40px #fff;text-shadow:0 14px 0 #fff}
#op31 .op31-logo-in .r{font-size:240px;margin-top:-20px;background:linear-gradient(#fff 10%,#ffd6d0 40%,#ff5d5d 90%);-webkit-background-clip:text;background-clip:text}
#op31 .op31-hud{position:absolute;inset:0;pointer-events:none}
#op31 .op31-prog{position:absolute;left:40px;top:34px;display:inline-flex;gap:8px;padding:8px 18px;background:rgba(255,255,255,.85);border:4px solid var(--ink);border-radius:99px;box-shadow:0 5px 0 var(--ink)}
#op31 .op31-prog .k-dot{width:24px;height:24px;border-width:3px}
#op31 .op31-qr{position:absolute;right:30px;top:26px;width:196px;border-radius:24px}
#op31 .op31-qr .k-band{font-size:28px;padding:6px 14px;justify-content:center;--c:var(--sky)}
#op31 .op31-qr img{display:block;width:140px;height:140px;margin:10px auto 12px;border:4px solid var(--ink);border-radius:14px;background:#fff;padding:6px}
#op31.idle .op31-qr{width:290px}#op31.idle .op31-qr .k-band{font-size:34px}#op31.idle .op31-qr img{width:230px;height:230px}
#op31 .op31-cap{position:absolute;left:140px;right:140px;bottom:44px;border-radius:44px;overflow:visible;display:flex;align-items:center;gap:26px;padding:26px 40px;opacity:0;transform:translateY(60px);transition:opacity .35s,transform .35s cubic-bezier(.3,.7,.4,1.2)}
#op31 .op31-cap.on{opacity:1;transform:none}
#op31 .op31-who{position:absolute;left:150px;top:-34px;font-size:34px}
#op31 .op31-ic{flex:none;width:92px;height:92px;border-radius:50%;background:var(--sky);border:5px solid var(--ink);display:flex;align-items:center;justify-content:center;font-size:50px}
#op31 .op31-tx{font-size:60px;font-weight:900;line-height:1.3;flex:1;min-width:0}
#op31 .op31-rd{flex:none;display:flex;flex-direction:column;align-items:center;gap:10px}
#op31 .op31-yb{font-size:32px}
#op31 .op31-cap:not(.ready) .op31-yb{opacity:.45}
#op31 .op31-dots{display:flex;gap:8px}
#op31 .op31-dots .k-dot{background:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:22px;color:#fff}
#op31 .op31-dots .k-dot.ok{background:var(--c)}
@keyframes op31-fadein{from{opacity:0}to{opacity:1}}
@keyframes op31-fadeout{from{opacity:1}to{opacity:0}}
@keyframes op31-spin{to{transform:rotate(360deg)}}
@keyframes op31-drift{from{margin-left:-30px}to{margin-left:40px}}
@keyframes op31-tw{from{opacity:.45}to{opacity:1}}
@keyframes op31-glow{from{filter:drop-shadow(0 0 30px rgba(255,220,120,.7))}to{filter:drop-shadow(0 0 70px rgba(255,230,140,1))}}
@keyframes op31-smoke{0%{transform:translate(0,0) scale(.5);opacity:0}15%{opacity:.95}100%{transform:translate(70px,-150px) scale(1.7);opacity:0}}
@keyframes op31-hop{0%{transform:translateY(-280px);opacity:0}55%{transform:translateY(0);opacity:1}72%{transform:translateY(-34px)}86%{transform:translateY(0)}93%{transform:translateY(-8px)}100%{transform:none;opacity:1}}
@keyframes op31-hopx{0%{transform:translate(-50%,-280px);opacity:0}55%{transform:translate(-50%,0);opacity:1}72%{transform:translate(-50%,-34px)}86%,100%{transform:translate(-50%,0);opacity:1}}
@keyframes op31-go{from{transform:translateX(320px)}to{transform:none}}
@keyframes op31-heart{0%{transform:scale(0);opacity:0}25%{transform:scale(1.2);opacity:1}100%{transform:translateY(-70px) scale(1);opacity:.9}}
@keyframes op31-sil{0%{opacity:0;transform:translateY(30px) scale(.92)}100%{opacity:1;transform:none}}
@keyframes op31-eye{0%,8%{opacity:0;transform:scaleY(.1)}14%,70%{opacity:1;transform:none}74%{transform:scaleY(.1)}78%,100%{opacity:1;transform:none}}
@keyframes op31-inR{from{transform:translateX(760px)}to{transform:none}}
@keyframes op31-inL{from{transform:translateX(-900px)}to{transform:none}}
@keyframes op31-sway{from{transform:translateX(-18px) rotate(-3deg)}to{transform:translateX(18px) rotate(3deg)}}
@keyframes op31-jit{from{transform:translateX(-3px)}to{transform:translateX(3px)}}
@keyframes op31-dust{0%{transform:scale(.4);opacity:0}30%{opacity:.9}100%{transform:translateX(-80px) scale(1.3);opacity:0}}
@keyframes op31-shield{from{transform:scale(.97);opacity:.75}to{transform:scale(1.04);opacity:1}}
@keyframes op31-camdown{0%{transform:translateY(440px) scale(1)}42%{transform:translateY(0) scale(1)}100%{transform:translateY(0) scale(1.07)}}
@keyframes op31-shake{0%,100%{transform:none}20%{transform:translate(-10px,6px)}40%{transform:translate(9px,-7px)}60%{transform:translate(-7px,-5px)}80%{transform:translate(6px,7px)}}
@keyframes op31-popin{0%{transform:rotate(var(--r)) scale(0)}70%{transform:rotate(var(--r)) scale(1.15)}100%{transform:rotate(var(--r)) scale(1)}}
@keyframes op31-conf{0%{transform:translateY(-120px) scale(0);opacity:0}60%{transform:translateY(10px) scale(1.15);opacity:1}100%{transform:none;opacity:1}}
@keyframes op31-pop{0%{transform:translateX(-50%) rotate(var(--r)) scale(0)}70%{transform:translateX(-50%) rotate(var(--r)) scale(1.1)}100%{transform:translateX(-50%) rotate(var(--r)) scale(1)}}
@keyframes op31-bob{from{transform:translateY(0)}to{transform:translateY(-12px)}}
@keyframes op31-drop{0%{transform:translateY(-760px)}55%{transform:translateY(0)}70%{transform:translateY(-46px)}84%{transform:translateY(0)}92%{transform:translateY(-12px)}100%{transform:none}}
/* スマホ */
#op31Pad{position:absolute;inset:0;z-index:36;background:linear-gradient(#49b6ff,#a8e4ff 70%,#e9fbff);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:min(3.5vh,14px);padding:8px var(--padw-sr,20px) 8px var(--padw-sl,20px);text-align:center}
#op31Pad .k-pill{font-size:clamp(16px,5vh,24px);padding:4px 18px;box-shadow:0 4px 0 var(--ink);border-width:3px}
#op31Pad .op31-row{display:flex;gap:min(3vw,18px);width:100%;justify-content:center;align-items:stretch}
#op31Pad .k-btn{font-family:inherit;border-width:4px;box-shadow:0 7px 0 var(--ink);border-radius:24px;padding:6px 18px;white-space:normal}
#op31Pad .k-btn:active{transform:translateY(5px);box-shadow:0 2px 0 var(--ink)}
#op31Read{flex:0 1 62%;min-height:min(40vh,150px);font-size:clamp(28px,12vh,48px)}
#op31Read:disabled{opacity:.4}
#op31Skip{flex:0 1 30%;font-size:clamp(18px,6vh,26px)}
#p3dBox:has(button.op31) button{flex:1 1 28%;min-width:0}
#op31Pad .op31-st{font-size:clamp(14px,4.2vh,19px);background:#fff;border-radius:99px;border:3px solid var(--ink);padding:3px 14px}
`;
    document.head.appendChild(c);
  }
  function fit() { if (!S.stage) return; const s = Math.min(innerWidth / 1920, innerHeight / 1080); S.stage.style.transform = `translate(-50%,-50%) scale(${s})`; }
  function build() {
    css();
    const r = document.createElement('div'); r.id = 'op31'; r.className = 'k';
    r.innerHTML = `<div class="op31-stage"><div class="op31-hud"><div class="op31-prog">${SHOTS.map(() => '<span class="k-dot"></span>').join('')}</div>` +
      `<div class="op31-qr k-card"><div class="k-band">📱 さんか</div><img alt=""></div><div class="op31-capw"></div></div></div>`;
    (H.root || document.body).appendChild(r);
    S.root = r; S.stage = r.querySelector('.op31-stage'); S.hud = r.querySelector('.op31-hud'); fit();
  }
  function showShot(i) {
    const sh = SHOTS[i], idle = S.mode === 'idle';
    S.i = i; S.t = 0; S.rd = {}; S.capOn = false; S.voOn = false; S.sfxI = 0; S.shotNo = sh.no; S.seq++;
    if (H.voice && H.voice.stop) H.voice.stop();
    const old = S.stage.querySelectorAll('.op31-shot'), el = document.createElement('div');
    old.forEach(o => o.classList.remove('cur')); el.className = 'op31-shot cur'; el.dataset.no = sh.no; el.innerHTML = shotHtml(sh, idle);
    S.stage.insertBefore(el, S.hud); S.shot = el;
    old.forEach(o => setTimeout(() => o.remove(), FADE_MS));
    S.root.style.background = sh.sky === 'night' ? '#0b1440' : sh.sky === 'dusk' ? '#3b2a6b' : '#49b6ff';
    S.root.querySelectorAll('.op31-prog .k-dot').forEach((d, n) => d.style.setProperty('--c', n <= i ? 'var(--sun)' : '#fff'));
    S.hud.querySelector('.op31-capw').innerHTML = idle ? '' : capHtml(sh);
    const qr = H.qr ? H.qr() : '', im = S.root.querySelector('.op31-qr img');
    if (qr && im.getAttribute('src') !== qr) im.src = qr;
    S.root.querySelector('.op31-qr').style.display = qr ? '' : 'none';
    videoFor(sh, el);
    if (H.log) H.log('shot ' + sh.no + ' (' + sh.id + ')' + (idle ? ' idle' : ''));
  }
  // ---------- 動画（あとで：Gemini の opening-01..08.mp4）。無い・読めない 時は かいた 絵の まま ----------
  function videoUrl(no) { const v = S.video; if (!v) return null; if (typeof v === 'function') { try { return v(no) || null; } catch (e) { return null; } } return v[no] || null; }
  function videoFor(sh, el) {
    const url = videoUrl(sh.no); if (!url) return;
    const v = document.createElement('video'); v.muted = true; v.playsInline = true; v.setAttribute('playsinline', ''); v.preload = 'auto'; v.loop = !!sh.ja; v.src = url;
    let done = false; const seq = S.seq;
    const ok = () => { if (done || seq !== S.seq) return; done = true; el.classList.add('vid'); v.play().catch(() => el.classList.remove('vid')); };
    const ng = () => { if (done) return; done = true; el.classList.remove('vid'); v.remove(); };
    v.addEventListener('canplay', ok, { once: true }); v.addEventListener('error', ng, { once: true }); setTimeout(() => { if (!done) ng(); }, 2500);
    el.querySelector('.op31-bgv').appendChild(v);
  }
  function setVideo(src, opt) { S.video = src || null; S.vopt = opt || {}; }

  // ---------- テレビ：進み ----------
  const players = () => { try { return (H.players ? H.players() : []) || []; } catch (e) { return []; } };
  const cur = () => SHOTS[S.i];
  function ready() {
    if (!S.on || S.mode === 'idle') return false; const sh = cur(); if (!sh.ja) return false;
    if (S.t < sh.lead + READ_MIN) return false;
    const busy = sh.vo && H.voice && H.voice.busy ? H.voice.busy(sh.vo) : false;
    return !busy || S.t >= sh.lead + VOICE_WAIT_MAX;
  }
  function start(mode) {
    mode = mode === 'idle' || mode === 'replay' ? mode : 'story';
    if (S.on) stop('restart', true);
    if (!S.root) build();
    S.on = true; S.mode = mode; S.idleT = 0; S.vol = mode === 'idle' ? IDLE_VOL : 1;
    S.root.classList.remove('out'); S.root.style.display = ''; S.root.classList.toggle('idle', mode === 'idle');
    if (mode !== 'idle' && H.voice && H.voice.preload) H.voice.preload(SHOTS.map(s => s.vo).filter(Boolean));
    showShot(0);
    if (H.onStart) try { H.onStart(mode); } catch (e) { console.warn('オープニング：始まりで 失敗しました', e); }
    console.info('オープニングを 始めました（' + mode + '）');
    return true;
  }
  function stop(reason, quiet) {
    if (!S.on) return;
    const mode = S.mode; S.on = false; S.mode = ''; S.seq++;
    if (mode !== 'idle' && (reason === 'end' || reason === 'skip')) S.played = true;
    if (H.voice && H.voice.stop) H.voice.stop();
    if (S.root) { S.root.classList.add('out'); const r = S.root; setTimeout(() => { if (!S.on) { r.style.display = 'none'; r.querySelectorAll('.op31-shot').forEach(o => o.remove()); } }, FADE_MS); }
    if (!quiet && H.onEnd) try { H.onEnd(reason, mode); } catch (e) { console.warn('オープニング：おわりで 失敗しました', e); }
    console.info('オープニングを 止めました（' + reason + '）');
  }
  function next() { if (S.i + 1 < SHOTS.length) showShot(S.i + 1); else if (S.mode === 'idle') showShot(0); else stop('end'); }
  function read(peer, i) {
    if (!S.on || S.mode === 'idle' || i !== S.i || !ready()) return false;
    if (!players().some(p => p.id === peer)) return false;
    if (!S.rd[peer]) { S.rd[peer] = 1; if (H.sound) H.sound('read'); }
    return true;
  }
  function cmd(peer, d) {
    if (!d || d.a !== 'op31') return false;
    const joined = players().some(p => p.id === peer);
    if (!joined) return false;
    if (d.op === 'read' && Number.isInteger(d.i)) read(peer, d.i);
    else if (d.op === 'skip') { if (S.on && S.mode !== 'idle') stop('skip'); }
    else if (d.op === 'story') { if (!S.on && (!H.canReplay || H.canReplay())) start('replay'); }
    return true;
  }
  function sfxTick(sh) {
    const list = sh.sfx || [];
    while (S.sfxI < list.length && S.t >= list[S.sfxI][0]) { const n = list[S.sfxI][1]; S.sfxI++; if (S.mode !== 'idle' && H.sound) try { H.sound(n); } catch (e) { } }
  }
  function capTick(sh) {
    const box = S.hud.querySelector('.op31-cap'); if (!box) return;
    box.classList.toggle('ready', ready());
    const ps = players().slice().sort((a, b) => a.slot - b.slot), dots = box.querySelector('.op31-dots');
    const sig = ps.map(p => p.id + ':' + p.slot + ':' + (S.rd[p.id] ? 1 : 0)).join('|');
    if (dots.dataset.sig !== sig) { dots.dataset.sig = sig; dots.innerHTML = ps.map(p => `<span class="k-dot${S.rd[p.id] ? ' ok' : ''}" style="--c:var(--p${p.slot})">${S.rd[p.id] ? '✓' : ''}</span>`).join(''); }
  }
  // 毎コマ（テレビの frame から）：決まり（1 人めの 参加・3 分の くり返し・だれも いない）と 進み
  function frame(now) {
    const dt = S.last ? Math.min(.25, Math.max(0, (now - S.last) / 1000)) : 0; S.last = now;
    const ps = players(), n = ps.length, title = H.title ? !!H.title() : false, busy = H.busy ? !!H.busy() : false;
    if (!S.on) {
      if (n > 0 && !S.played && title && !busy && autoOk()) { start('story'); return; }
      if (n === 0 && title && !busy && autoOk()) { S.idleT += dt; if (S.idleT >= IDLE_SEC) start('idle'); } else S.idleT = 0;
      return;
    }
    if (S.mode === 'idle') { if (n > 0 || !title || busy) { stop('join'); return; } }
    else if (n === 0) { stop('nobody'); return; }
    S.t += dt; const sh = cur();
    sfxTick(sh);
    if (S.mode !== 'idle' && !S.voOn && sh.vo && S.t >= sh.lead) { S.voOn = true; if (H.voice && H.voice.play) H.voice.play(sh.vo); }
    if (!S.capOn && S.t >= sh.lead) { S.capOn = true; const box = S.hud.querySelector('.op31-cap'); if (box) box.classList.add('on'); }
    if (S.mode === 'idle' || !sh.ja) { if (S.t >= sh.dur) next(); return; }
    capTick(sh);
    if (ready() && allRead(ps.map(p => p.id), S.rd)) next();
  }
  function pack() {
    if (!S.on) return undefined;
    if (S.mode === 'idle') return { m: 'idle' };
    const sh = cur();
    return { m: S.mode, i: S.i, n: SHOTS.length, c: sh.ja && S.capOn ? 1 : 0, r: ready() ? 1 : 0, rd: Object.keys(S.rd) };
  }
  function onKey(ev) {
    if (!S.on) return; const k = ev.key;
    if (k === '0' || k === 'F2' || k === 'Info') return;
    if (S.mode === 'idle') { stop('key'); ev.preventDefault(); ev.stopImmediatePropagation(); return; }
    if ((k === 'Enter' || k === ' ') && ready()) next();
    else if (['Escape', 'GoBack', 'BrowserBack', 'Backspace'].includes(k)) stop('skip');
    ev.preventDefault(); ev.stopImmediatePropagation();
  }
  function attach(host) {
    H = Object.assign({ art: '/tk/' }, host || {});
    addEventListener('keydown', onKey, true); addEventListener('resize', fit);
    return api;
  }

  // ---------- スマホ ----------
  const PS = { sig: '', step: -1, sent: -1 };
  function attachPad(host) { P = host || {}; css(); return api; }
  function padEnsure() {
    let o = document.getElementById('op31Pad'); if (o) return o;
    o = document.createElement('div'); o.id = 'op31Pad'; o.className = 'k hide';
    o.innerHTML = `<span class="k-pill op31-pt"></span><div class="op31-row"><button id="op31Read" class="k-btn">📖 よんだ</button><button id="op31Skip" class="k-btn w">⏭ とばす</button></div><span class="op31-st"></span>`;
    (P && P.root || document.getElementById('pad') || document.body).appendChild(o);
    o.querySelector('#op31Read').onclick = () => { if (PS.step < 0) return; PS.sent = PS.step; send({ op: 'read', i: PS.step }); PS.sig = ''; };
    o.querySelector('#op31Skip').onclick = () => send({ op: 'skip' });
    return o;
  }
  function send(d) { const m = Object.assign({ a: 'op31' }, d); if (P && P.emit) { try { const r = P.emit(m); if (r && r.catch) r.catch(e => console.warn('おはなしの 操作を 送れませんでした', e)); } catch (e) { console.warn(e); } } if (P && P.vibrate) P.vibrate(20); }
  // g＝テレビの 様子、self＝自分、mine＝自分の 行（参加して いない 時は null）
  function padRender(g, self, mine) {
    const o = g && g.op31, on = !!(o && mine && o.m !== 'idle' && Number.isInteger(o.i));
    const el = document.getElementById('op31Pad') || (on ? padEnsure() : null); if (!el) return;
    el.classList.toggle('hide', !on);
    if (!on) { PS.step = -1; PS.sent = -1; PS.sig = ''; return; }
    if (PS.step !== o.i) { PS.step = o.i; PS.sent = -1; if (P && P.vibrate) P.vibrate(40); }
    const id = self ? self.peer : '', read = (Array.isArray(o.rd) && o.rd.includes(id)) || PS.sent === o.i;
    const sig = [o.i, o.n, o.c, o.r, read ? 1 : 0].join('/'); if (sig === PS.sig) return; PS.sig = sig;
    el.querySelector('.op31-pt').textContent = `📖 おはなし ${o.i + 1} / ${o.n}`;
    const rb = el.querySelector('#op31Read');
    rb.classList.toggle('hide', !!read || !o.c); rb.disabled = !o.r;
    el.querySelector('.op31-st').textContent = !o.c ? '📺 テレビを 見てね' : read ? '✓ みんなを まっています…' : o.r ? 'よんだら おしてね' : '📺 テレビを 見てね';
  }
  // 待合室の ボタン（tank.html の p3dBox に 足す）：[key, html, class]
  const padItems = () => [['op31', '<i>📖</i>おはなし', 'op31']];
  const padStory = () => send({ op: 'story' });

  Object.assign(api, {
    attach, frame, start, stop, cmd, read, pack, ready, setVideo, attachPad, padRender, padItems, padStory, sprite, plate,
    isOn: () => S.on, mode: () => S.mode, step: () => S.i, played: () => S.played, seq: () => S.seq,
    music: () => S.on ? (S.mode === 'idle' ? 'lobby' : cur().music) : null, musicVol: () => S.on ? S.vol : 1,
    _s: S, _next: next, _show: i => { if (S.on) showShot(i); }   // 確かめ用
  });
  root.TankOpening = api;
})(typeof window !== 'undefined' ? window : globalThis);

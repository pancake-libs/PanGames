/* 共通部品：外の 3D 模型（glb）を読む・覚えておく・複製する・動かす（2026-11-15 新規）。
   Three.js（three-td.js の window.THREE。GLTFLoader・MeshoptDecoder・SkeletonUtils が入っていること）を使う。
   模型は部屋のサーバーの /models/<名前>.glb から読む（APK の assets/web/models）。圧縮は meshopt（glTF-Transform で作る）。

   使い方：
     const A = FPAssets3d.create({ shadows: true });
     await A.load(['tank_green', 'tree_a']);         // 先に読んでおく（同じ名前は 1 回だけ読む）
     const t = A.spawn('tank_green');                 // 複製（骨のある模型も 1 体ずつ動かせる）。{ obj, mixer, actions, play(name, fade, once), clips }
     const k = A.spawn('kk_knight', { clipsFrom: ['kk_anim_move'] });  // 動きだけの glb（KayKit の動きなど、骨の名前が同じ物）の動きも使う。先に load しておく
     scene.add(t.obj); t.play('Idle');
     const im = A.instanced('tree_a', 200);           // 同じ形をまとめて描く（骨の無い模型だけ）。im.setMatrixAt(i, m) で置く
     毎フレーム：A.update(dt)                          // 全部の動きを進める
     A.info('tank_green')                             // { tris, meshes, bones, clips:[名前], bytes }
     A.release(t)                                     // 使い終わった複製を外す（形・絵は共有なので残る） */
(function () {
  'use strict';
  const T3 = window.THREE;
  if (!T3 || !T3.GLTFLoader) { console.error('Three.js の GLTFLoader が読めていません（three-td.js を新しくする）'); return; }

  function create(opts) {
    opts = opts || {};
    const base = opts.base || '/models/';
    const loader = new T3.GLTFLoader();
    if (T3.MeshoptDecoder) loader.setMeshoptDecoder(T3.MeshoptDecoder);
    const cache = new Map();      // 名前 → Promise<{ scene, clips, info }>
    const mixers = new Set();

    function measure(root, clips, bytes) {
      let tris = 0, meshes = 0, bones = 0;
      root.traverse(o => {
        if (o.isMesh) { meshes++; const g = o.geometry; tris += (g.index ? g.index.count : g.attributes.position.count) / 3; }
        if (o.isBone) bones++;
      });
      return { tris: Math.round(tris), meshes, bones, clips: clips.map(c => c.name), bytes };
    }
    function prepare(root) {
      root.traverse(o => {
        if (o.isMesh) {
          o.castShadow = opts.shadows !== false; o.receiveShadow = opts.shadows !== false;
          (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => { if (m) m.userData.shared = true; });
          if (o.geometry) o.geometry.userData.shared = true;
        }
      });
    }
    function loadOne(name) {
      if (cache.has(name)) return cache.get(name);
      const p = (async () => {
        const r = await fetch(base + name + '.glb');
        if (!r.ok) throw new Error('模型を読めませんでした：' + name + '（HTTP ' + r.status + '）');
        const buf = await r.arrayBuffer();
        const gltf = await new Promise((ok, ng) => loader.parse(buf, '', ok, ng));
        prepare(gltf.scene);
        return { scene: gltf.scene, clips: gltf.animations || [], info: measure(gltf.scene, gltf.animations || [], buf.byteLength) };
      })();
      cache.set(name, p);
      p.catch(e => { console.warn(e); cache.delete(name); });
      return p;
    }
    // 読めた物は Promise に印（done・value）をつけて、すぐ取り出せるようにする
    function track(name) { const p = loadOne(name); if (!p.tracked) { p.tracked = true; p.then(v => { p.done = true; p.value = v; }, () => {}); } return p; }
    function got(name) { const p = cache.get(name); return p && p.done ? p.value : null; }

    function spawn(name, o) {
      o = o || {};
      const a = got(name); if (!a) { track(name); console.warn('まだ読めていない模型：' + name); return null; }
      let clips = a.clips.slice();
      (o.clipsFrom || []).forEach(n => { const b = got(n); if (b) clips = clips.concat(b.clips); else console.warn('動きの glb がまだ読めていません：' + n); });
      const obj = clips.length || hasBones(a.scene) ? T3.SkeletonUtils.clone(a.scene) : a.scene.clone(true);
      const mixer = clips.length ? new T3.AnimationMixer(obj) : null;
      const actions = {}; let current = null;
      if (mixer) { clips.forEach(c => { if (!actions[c.name]) actions[c.name] = mixer.clipAction(c); }); mixers.add(mixer); }
      function play(clip, fade, once) {
        const next = actions[clip] || findClip(actions, clip);
        if (!next || next === current) return !!next;
        next.reset(); next.setLoop(once ? T3.LoopOnce : T3.LoopRepeat); next.clampWhenFinished = !!once; next.play();
        if (current) current.crossFadeTo(next, fade === undefined ? .2 : fade, false);
        current = next; return true;
      }
      return { name, obj, mixer, actions, play, clips: Object.keys(actions) };
    }
    function hasBones(root) { let b = false; root.traverse(o => { if (o.isSkinnedMesh) b = true; }); return b; }
    // 名前の大文字小文字・前につく文字（CharacterArmature|Run など）の違いを許して探す
    function findClip(actions, want) {
      const w = String(want).toLowerCase();
      for (const k in actions) { const s = k.toLowerCase(); if (s === w || s.endsWith('|' + w) || s.endsWith('_' + w)) return actions[k]; }
      return null;
    }
    // 同じ形をまとめて描く。模型の中の部品ごとに 1 つの InstancedMesh を作り、Group にまとめて返す
    function instanced(name, count) {
      const a = got(name); if (!a) { track(name); return null; }
      if (hasBones(a.scene)) { console.warn('骨のある模型はまとめて描けません：' + name); return null; }
      const g = new T3.Group(); const parts = [];
      a.scene.updateMatrixWorld(true);
      a.scene.traverse(o => {
        if (!o.isMesh) return;
        const im = new T3.InstancedMesh(o.geometry, o.material, count);
        im.castShadow = o.castShadow; im.receiveShadow = o.receiveShadow; im.userData.local = o.matrixWorld.clone();
        g.add(im); parts.push(im);
      });
      const tmp = new T3.Matrix4();
      g.userData.setMatrixAt = (i, m) => { parts.forEach(im => { tmp.multiplyMatrices(m, im.userData.local); im.setMatrixAt(i, tmp); im.instanceMatrix.needsUpdate = true; }); };
      g.userData.setColorAt = (i, c) => { parts.forEach(im => { im.setColorAt(i, c); if (im.instanceColor) im.instanceColor.needsUpdate = true; }); };
      g.userData.count = n => parts.forEach(im => { im.count = n; });
      return g;
    }
    function update(dt) { mixers.forEach(m => m.update(dt)); }
    function release(s) { if (!s) return; if (s.mixer) { s.mixer.stopAllAction(); mixers.delete(s.mixer); } if (s.obj.parent) s.obj.parent.remove(s.obj); }
    function info(name) { const a = got(name); return a ? a.info : null; }
    // 先に読んでおく。読めなかった名前の一覧を返す
    function load(names) {
      const list = Array.isArray(names) ? names : [names];
      return Promise.allSettled(list.map(track)).then(r => { const bad = list.filter((n, i) => r[i].status !== 'fulfilled'); if (bad.length) console.warn('読めなかった模型：' + bad.join(', ')); return bad; });
    }
    return { load, spawn, instanced, update, release, info, loaded: n => !!got(n) };
  }
  window.FPAssets3d = { create };
})();

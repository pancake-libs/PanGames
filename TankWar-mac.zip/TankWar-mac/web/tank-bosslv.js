/* おうちを守れ！戦車隊：ボスちょうせん（v0.21、P4B）。計算と 表だけ（画面なし。node でも動く）。window.TankBossLv
   JUN さん「ボスを たおすたびに むずかしく。いまは 20 レベルまで。うしろの レベルは すごく むずかしく。クリアしたら ボス限定の ごほうび」
   - レベルは「👑 ボスちょうせん」だけ（ぼうけんの 144 面・2 周目・なかよし・けっとうは 今のまま）。家族で 1 つの記録（テレビ：tank-p4b-bosslv）
   - 開いた レベルは 自由に えらべる。ごほうびは 1 人 1 回（打ちかった時に いた人 ぜんいん）。くり返しは コイン 3 わり＋木の宝箱
   - 面は そのボスの ぼうけんの面から 作る（1 面だけの並び g.p3dList。id 'x-bl'、stage.p4b に レベルの 数）。戦いの中の 変化は tank-sim.js の P4B の所
   - ボス装備（19 こ）の 表と 効果は tank-gear.js（P4B_GEAR・P4B_SIG）。ここは ごほうびの 順番・かざり（ステッカー・旗・尾・スキン・称号）・面・記録 */
(function (root) {
  'use strict';
  const req = n => (typeof require !== 'undefined' ? require(n) : null);
  const Stages = root.TankStages || req('./tank-stages.js');
  const ADV = Stages.ADV, PER = Stages.PER_WORLD;
  const MAX = 20;
  const NAME = { sis: ['双子戦車', '双子坦克'], gold: ['きんぴか戦車', '黄金坦克'] };
  // ボス 19 体：id・計算の 種類（kinds）・ぼうけんの面（gi）・絵の 種類（art）・あいさつ（1 行）
  const BOSSES = [
    ['twin', ['twin'], ['また あそぼうぜ！ ふたりで いくぞ！', '再来玩吧！我们俩一起上！']],
    ['engineer', ['engineer'], ['あたらしい かべ、つんで まってたぞ！', '我砌了新墙等你们呢！']],
    ['bigtank', ['bigtank'], ['よし、もう いっかい ちからくらべだ', '好，再比一次力气吧']],
    ['burrower', ['burrower'], ['こ、こんどは まけないもん！（ズボッ）', '这、这次不会输的！（噗）']],
    ['scorpion', ['scorpion'], ['しっぽ、みがいて きたぞ！', '我把尾巴擦亮了！']],
    ['sandship', ['sandship'], ['ぜんほうもん、あいさつの いっせいほうげき！', '全炮门，打个招呼齐射！']],
    ['plow', ['plow'], ['きょうも ぜーんぶ かたづけまーす！', '今天也统统清理干净！']],
    ['icegun', ['icegun'], ['…また きたの。…ちょっと うれしい', '…又来了。…有点高兴']],
    ['snowman', ['snowman'], ['わーい！ ゆきがっせんの つづきだね！', '耶！继续打雪仗吧！']],
    ['flamer', ['flamer'], ['もえる さいせんだァ！', '燃烧的再战！']],
    ['golem', ['golem'], ['ボク… すこし つよく なったよ', '我…变强了一点哦']],
    ['dragon', ['dragon'], ['よくきた。わが ほのお、さらに あつく なったぞ', '来得好。我的火焰更热了']],
    ['sis', ['sisA', 'sisB'], ['ねえさん、あのこたち また きたよ！', '姐，那些孩子又来了！']],
    ['airship', ['airship'], ['ごきげんよう。きょうは おりて あげても よくてよ', '日安。今天可以下来陪你们哦']],
    ['core', ['core'], ['さいせんを しょうにん。…たのしみに していました', '批准再战。…我很期待']],
    ['shadow', ['shadow'], ['また きてくれた… ぼくたち、うれしい', '又来了… 我们好开心']],
    ['superstar', ['superstar'], ['アンコール、ありがとォ！', '谢谢安可！']],
    ['king', ['king'], ['よくぞ もどった。さあ、もう いちど ためそう', '欢迎回来。来，再试一次吧']],
    ['gold', ['boss'], ['みつかっちゃった！ また かくれんぼ しよ！', '被发现了！再玩捉迷藏吧！']]
  ].map(([id, kinds, hi]) => {
    const gi = id === 'gold' ? 5 * PER + 7 : ADV.findIndex(s => s.bosses && s.bosses.length === kinds.length && kinds.every(k => s.bosses.includes(k)));
    const st = ADV[gi], tk = Stages.BOSS_TALK[kinds[0]];
    return { id, kinds, gi, world: st ? st.world : 5, art: kinds[0], hi, name: NAME[id] || (tk && tk.name) || [id, id], secret: id === 'gold' };
  });
  const BY = {}; BOSSES.forEach((b, i) => { b.i = i; BY[b.id] = b; });
  const IDS = BOSSES.map(b => b.id);
  const KIND_BOSS = {}; for (const b of BOSSES) for (const k of b.kinds) KIND_BOSS[k] = b.id;   // 計算の 種類 → ボス

  /* ---------- レベルの 数（ここを 変えると むずかしさが 変わる。tools/p4b-check.mjs で 自動の 味方の 勝ちを 見て きめた）----------
     hp＝ボスの体力・mv＝ボスの速さ・bul＝ボスの弾の速さ・int＝ボスの こうげきの 間（小さいほど よく撃つ。わざの 待ちも ぜんぶ）。
     1〜10 は ゆっくり、11〜15 は 強く、16〜20 は とても 強く（3 つの 区切りごとの 1 レベルの 上がり方） */
  const TUNE = {
    hp: [0.04, 0.70, 1.20], mv: 0.015, bul: [0.01, 0.03, 0.04], int: [0.01, 0.07, 0.04],
    field: [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 3, 3, 3, 4, 5, 5, 6, 6, 7],   // 手下が 面に 出られる数 +
    mhp: [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6],    // 手下の 体力 +
    cap: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 2, 2, 3, 3, 4, 4, 5],    // 隊長
    share: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2, .3, .3, .4, .4, .5, .5, .6, .6, .7],   // 自作の敵の 割合（0＝面の まま）
    // 1 人の 時（Lv11〜20）：ボスの 体力 ×・こうげきの 間 ×（1 人だと 強い 装備の 差が 大きいので）
    solo: [[1.6, 2.0, 2.4, 2.8, 3.0, 3.2, 3.4, 3.6, 3.8, 4.0], [0.9, 0.85, 0.8, 0.75, 0.75, 0.7, 0.7, 0.7, 0.7, 0.7]],
    aSecL: { 10: 18, 11: 11, 12: 9, 13: 8, 14: 7 }, ph: { 11: 0.62, 12: 0.55, 13: 0.55, 14: 0.49 },   // ph＝この 体力の 割合から 本気（Lv11〜14 は 少しずつ 早く）
    sumSec: [24, 24, 16, 12, 12],   // Lv10〜14 の わざ A の 間（15 から aSec と B を こうたい）・なかまを よぶ 間（むずかしさの 印ごと）
    ap: 15, item: 16, m5: 5, m10: 10, m15: 15, m20: 20,
    rage: 0.8, rageAt: 0.2, aSec: 9, bSec: 11, summonSec: 14, altSec: 5, ring: 12
  };
  function seg(L, a) { const l = clamp(L, 1, MAX); return l <= 10 ? a[0] * (l - 1) : l <= 15 ? a[0] * 9 + a[1] * (l - 10) : a[0] * 9 + a[1] * 5 + a[2] * (l - 15); }
  function clamp(v, a, b) { v = Math.floor(Number(v)); return Number.isFinite(v) ? Math.max(a, Math.min(b, v)) : a; }
  const r3 = v => Math.round(v * 1000) / 1000;
  function params(L) {
    const l = clamp(L, 1, MAX), T = TUNE;
    return { lv: l, hp: r3(1 + seg(l, T.hp)), mv: r3(1 + T.mv * (l - 1)), bul: r3(1 + seg(l, T.bul)), int: r3(1 - seg(l, T.int)),
      field: T.field[l - 1], mhp: T.mhp[l - 1], ph: T.ph[l] || 0, sh: l > 10 ? T.solo[0][l - 11] : 0, si: l > 10 ? T.solo[1][l - 11] : 0, cap: T.cap[l - 1], share: T.share[l - 1], ap: l >= T.ap ? 2 : 0, item: l >= T.item ? 1 : 0,
      m5: l >= T.m5, m10: l >= T.m10, m15: l >= T.m15, m20: l >= T.m20 };
  }
  // むずかしさの 印：0 ★（1〜5）・1 ★★（6〜10）・2 ☠（11〜15）・3 ☠☠（16〜19）・4 ☠☠☠（20）
  function band(L) { const l = clamp(L, 1, MAX); return l <= 5 ? 0 : l <= 10 ? 1 : l <= 15 ? 2 : l < 20 ? 3 : 4; }
  const RATING = ['★', '★★', '☠', '☠☠', '☠☠☠'];
  const BAND_COL = ['#ffffff', '#ffe36a', '#ff6a5f', '#d6a8ff', '#ffd23a'];
  const rating = L => RATING[band(L)];
  // かりた わざ：A（Lv10）・B（Lv15）。ボスの 自分の わざと ちがう物
  const MOVES = { twin: ['ring', 'missile'], engineer: ['lob', 'ring'], bigtank: ['ring', 'laser'], burrower: ['ring', 'lob'], scorpion: ['ring', 'missile'], sandship: ['lob', 'laser'],
    plow: ['ring', 'lob'], icegun: ['lob', 'missile'], snowman: ['ring', 'lob'], flamer: ['lob', 'missile'], golem: ['ring', 'missile'], dragon: ['ring', 'missile'], sis: ['ring', 'lob'],
    airship: ['lob', 'laser'], core: ['ring', 'lob'], shadow: ['missile', 'laser'], superstar: ['ring', 'rain'], king: ['ring', 'rain'], gold: ['missile', 'laser'] };
  const NO_SUMMON = ['burrower', 'scorpion', 'icegun', 'sis', 'shadow'];   // なかまを よばない ボス（M5 で 14 秒ごとに 2 台）
  const MOVE_NAME = { ring: ['まわりに たま', '环形弹'], missile: ['ミサイル', '导弹'], lob: ['ばくだん', '炸弹'], laser: ['ビーム', '光束'], rain: ['ばくだんの あめ', '炸弹雨'] };
  const MILESTONE = {
    5: ['💢', 'いかり', '发怒', 'はやく 本気に なる', '更早认真'], 10: ['✨', 'わざ +1', '新招 +1', 'あたらしい わざ', '新招式'],
    15: ['🔥', 'さいしょから ほんき', '一开始就认真', 'はじめから 本気', '一开始就认真'], 20: ['👑', 'でんせつ', '传说', 'さいごに おおあばれ', '最后大暴走']
  };
  // その レベルで 変わる事（前の レベルと くらべて）。[絵, ja, zh]
  function changes(L) {
    const l = clamp(L, 1, MAX), a = params(l), b = l > 1 ? params(l - 1) : null, out = [];
    if (l === 1) { out.push(['🙂', 'いつもの ボス', '平常的首领']); return out; }
    out.push(['❤', `体力 ×${a.hp.toFixed(2)}`, `体力 ×${a.hp.toFixed(2)}`]);
    if (a.int < 1) out.push(['⚡', `こうげき ×${(1 / a.int).toFixed(2)}`, `攻击 ×${(1 / a.int).toFixed(2)}`]);
    if (a.field > b.field) out.push(['👥', `てした +${a.field}`, `手下 +${a.field}`]);
    if (a.mhp > b.mhp) out.push(['🛡', `てしたの 体力 +${a.mhp}`, `手下体力 +${a.mhp}`]);
    if (a.cap > b.cap) out.push(['👑', `たいちょう ${a.cap}`, `队长 ${a.cap}`]);
    if (a.ap && !b.ap) out.push(['💥', 'よろいを 2 まい こわす弾', '打掉 2 层护甲的炮弹']);
    if (a.item && !b.item) out.push(['🎁', 'アイテムが 少し へる', '道具稍微变少']);
    if (MILESTONE[l]) out.push([MILESTONE[l][0], MILESTONE[l][1] + '：' + MILESTONE[l][3], MILESTONE[l][2] + '：' + MILESTONE[l][4]]);
    return out;
  }

  /* ---------- 面 ----------
     ボスの ぼうけんの面（地図・景色・仕掛け・曲）＋ stage.p4b。ひみつのボスは ひみつの面（tank-story.js の bonusStage(5)）から */
  function baseStage(B) {
    if (B.id === 'gold') { const STY = root.TankStory || req('./tank-story.js'); if (STY && STY.bonusStage) return STY.bonusStage(5);
      const b = ADV[B.gi]; return Object.assign({}, b, { id: 'x-boss', p3dGold: true, bosses: ['boss'], seed: b.seed + 777 }); }
    return ADV[B.gi];
  }
  function stage(boss, L) {
    const B = BY[boss]; if (!B) return null; const base = baseStage(B), P = params(L), l = P.lv;
    const p4b = Object.assign({}, P, { boss, prim: B.kinds[0], a: l >= TUNE.m10 ? MOVES[boss][0] : '', b: l >= TUNE.m15 ? MOVES[boss][1] : '', sum: P.m5 && NO_SUMMON.includes(boss) ? 1 : 0, T: Object.assign({}, TUNE, { aSec: l < TUNE.m15 ? TUNE.aSecL[l] || 18 : TUNE.aSec, summonSec: TUNE.sumSec[band(l)] }) });
    return Object.assign({}, base, { id: 'x-bl', p4bLv: l, p4b, p3dBonus: 'bl', reunion: null, p3dSec: null, p3dChests: null, night: false,
      captains: P.cap, share: P.share ? Math.max(base.share || 0, P.share) : base.share, specials: base.specials && base.specials.length ? base.specials : ['bouncer'],
      p4bHi: { ja: B.hi[0], zh: B.hi[1] }, ja: `👑 ${B.name[0]}　Lv ${l}`, zh: `👑 ${B.name[1]}　Lv ${l}` });
  }

  /* ---------- 記録（テレビ：家族で 1 つ）---------- lv＝クリアした レベル（0〜20）、best＝{ レベル: 秒 }、streak＝[レベル, つづけて まけた数] */
  function cleanStore(v) {
    v = v && typeof v === 'object' ? v : {}; const o = { v: 1, lv: {}, best: {}, streak: {} };
    for (const id of IDS) {
      o.lv[id] = clamp(v.lv && v.lv[id], 0, MAX);
      const b = v.best && v.best[id], ob = {}; if (b && typeof b === 'object') for (const k of Object.keys(b).slice(0, MAX)) { const l = clamp(k, 1, MAX), s = Number(b[k]); if (Number.isFinite(s) && s > 0) ob[l] = Math.round(Math.min(9999, s) * 10) / 10; }
      o.best[id] = ob;
      const s = v.streak && v.streak[id]; o.streak[id] = Array.isArray(s) ? [clamp(s[0], 1, MAX), clamp(s[1], 0, 99)] : [1, 0];
    }
    return o;
  }
  const maxPick = (store, boss) => Math.min(MAX, ((store.lv[boss] | 0) + 1));
  // ぼうけんで たおした ボス（beaten(id)＝true）は Lv1 クリアに する（前の 記録の 引っ越しも これ）。変えた時 true
  function syncAdventure(store, beaten) { let ch = false; for (const id of IDS) if ((store.lv[id] | 0) < 1 && beaten(id)) { store.lv[id] = 1; ch = true; } return ch; }
  // 勝ち：レベルの 記録・いちばん 早い 時間。返すのは { up：新しく 開いたか, from, to }
  function winStore(store, boss, L, sec) {
    const l = clamp(L, 1, MAX), was = store.lv[boss] | 0; if (l > was) store.lv[boss] = l;
    const b = store.best[boss] = store.best[boss] || {}; if (sec > 0 && (!b[l] || sec < b[l])) b[l] = Math.round(sec * 10) / 10;
    store.streak[boss] = [l, 0];
    return { up: l > was, from: was, to: store.lv[boss] };
  }
  function loseStore(store, boss, L) { const l = clamp(L, 1, MAX), s = store.streak[boss] || [l, 0]; store.streak[boss] = s[0] === l ? [l, Math.min(99, s[1] + 1)] : [l, 1]; return store.streak[boss][1]; }
  // おたすけ：Lv1〜10 で 同じ レベルを 3 回 つづけて まけたら、つぎは 1 人 ♥ +1（ごほうびは 同じ）
  const HELP_LOSSES = 3, HELP_MAX_LV = 10;
  function helpOn(store, boss, L) { const s = store.streak[boss]; return clamp(L, 1, MAX) <= HELP_MAX_LV && !!s && s[0] === clamp(L, 1, MAX) && s[1] >= HELP_LOSSES; }

  /* ---------- ごほうび（ボスごとに 同じ 順番）---------- */
  const LADDER = { 1: ['sticker'], 3: ['bonus'], 5: ['flag'], 8: ['trail'], 10: ['gear5'], 12: ['title1'], 15: ['skin'], 18: ['gear6', 'charm'], 20: ['gear7', 'title2'] };
  const REWARD_IC = { 1: '🏷', 3: '🪙', 5: '🚩', 8: '✨', 10: '⚔', 12: '📛', 15: '🎨', 18: '🥈', 20: '👑' };
  const levelCoins = L => 40 + 20 * clamp(L, 1, MAX);
  const chestOf = L => (L <= 4 ? 'wood' : L <= 10 ? 'silver' : 'gold');
  const REPLAY = 0.3, LOSE_COIN = 20, BONUS3 = { coins: 100, parts: 30 };
  // かざりの 名前（B5）。flag・trail・title1・skin は [ja, zh]
  const DECO = {
    twin: [['ふたごの はた', '双子旗'], ['ふたつぼし', '双星'], ['ふたごの ライバル', '双子的对手'], ['ツートン', '双色']],
    engineer: [['レンガの はた', '砖块旗'], ['レンガの かけら', '碎砖'], ['かべづくり名人', '砌墙达人'], ['レンガ', '砖纹']],
    bigtank: [['草原の はた', '草原旗'], ['はっぱ', '草叶'], ['草原の まもりて', '草原守护者'], ['びょううち', '铆钉']],
    burrower: [['もぐらの はた', '钻地旗'], ['すなけむり', '沙烟'], ['かくれんぼ名人', '捉迷藏达人'], ['すなもよう', '沙纹']],
    scorpion: [['さそりの はた', '蝎子旗'], ['むらさきの きらきら', '紫色闪光'], ['かっこいい ポーズ', '最帅造型'], ['さそりの こうら', '蝎甲']],
    sandship: [['いかりの はた', '船锚旗'], ['なみ', '波浪'], ['すなの かんちょう', '沙海舰长'], ['せんかんグレー', '战舰灰']],
    plow: [['ゆきかきの はた', '铲雪旗'], ['わだち', '雪辙'], ['ゆきかき名人', '铲雪达人'], ['きいろと くろ', '黄黑条']],
    icegun: [['つららの はた', '冰柱旗'], ['こおりの つぶ', '冰粒'], ['こおりの ともだち', '冰之朋友'], ['クリスタル', '水晶']],
    snowman: [['ゆきだるまの はた', '雪人旗'], ['ゆきの けっしょう', '雪花'], ['ゆきがっせん王', '雪仗之王'], ['ゆきだるま', '雪人']],
    flamer: [['ほのおの はた', '火焰旗'], ['ひのこ', '火星'], ['あつい ハート', '火热的心'], ['もえる しましま', '燃烧条纹']],
    golem: [['いわの はた', '岩石旗'], ['ようがんの しずく', '熔岩滴'], ['おふろの ともだち', '泡澡伙伴'], ['ひびわれ ようがん', '熔岩裂纹']],
    dragon: [['りゅうの はた', '龙旗'], ['りゅうの ほのお', '龙焰'], ['りゅうつかい', '驭龙者'], ['りゅうの うろこ', '龙鳞']],
    sis: [['リボンの はた', '缎带旗'], ['ハートふたつ', '双心'], ['なかよし しまい', '好姐妹'], ['リボン', '缎带']],
    airship: [['ふうせんの はた', '气球旗'], ['くも', '云朵'], ['おちゃかいの おきゃくさま', '茶会贵宾'], ['そらいろ', '天空蓝']],
    core: [['はぐるまの はた', '齿轮旗'], ['ひばな', '电火花'], ['ようさいの あるじ', '要塞之主'], ['きかい', '机械纹']],
    shadow: [['かげの はた', '影子旗'], ['かげぼうし', '残影'], ['かげの ともだち', '影子朋友'], ['シャドウ', '暗影']],
    superstar: [['スターの はた', '明星旗'], ['おんぷ', '音符'], ['こんやの スター', '今晚的明星'], ['ステージ', '舞台']],
    king: [['おうかんの はた', '王冠旗'], ['きんの こな', '金粉'], ['おうの ともだち', '王的朋友'], ['ロイヤル', '皇家']],
    gold: [['きんの はた', '金旗'], ['コインの きらきら', '金币闪光'], ['たからの ばんにん', '宝藏守护者'], ['ダイヤ', '钻石']]
  };
  // 旗・尾の 色（絵は tank.html がコードで描く）
  const COL = { twin: ['#4fa8ff', '#ff7a5c'], engineer: ['#c8643a', '#ffd27a'], bigtank: ['#5fb04a', '#e9f5c0'], burrower: ['#d9b26a', '#7a5a2a'], scorpion: ['#b07aff', '#ffe36a'],
    sandship: ['#6a7a8a', '#e8c27a'], plow: ['#ffd23a', '#1b2a22'], icegun: ['#9fe8ff', '#ffffff'], snowman: ['#ffffff', '#ff6a5f'], flamer: ['#ff6a1a', '#ffd23a'], golem: ['#7a3a24', '#ff8a2a'],
    dragon: ['#c0392b', '#ffd23a'], sis: ['#ff8ac8', '#ffffff'], airship: ['#7fd4ff', '#ffffff'], core: ['#9aa6b8', '#7ff0ff'], shadow: ['#3a2a5a', '#b07aff'], superstar: ['#ff4fa8', '#ffe36a'],
    king: ['#ffd23a', '#a8231a'], gold: ['#ffc21a', '#fff7c0'] };
  const titleId = (boss, n) => (n === 2 ? 'bt2_' : 'bt1_') + boss;
  const skinId = boss => 'bl_' + boss;
  const ALL_TITLE = 'bt_all';
  function titleText(id) {
    if (id === ALL_TITLE) return ['ボスの王', '首领之王'];
    const m = /^bt([12])_([a-z]+)$/.exec(id || ''); if (!m || !BY[m[2]]) return null; const B = BY[m[2]];
    return m[1] === '1' ? DECO[B.id][2] : [B.name[0] + 'マスター', B.name[1] + '大师'];
  }
  // tank-book.js の 称号・スキンに 足す（一覧 ACH・SKINS には 入れない。名前を 引く表と、もっているかの 表だけ）
  function registerBook(AL) {
    if (!AL || !AL.ACH_BY || AL.ACH_BY[ALL_TITLE]) return;
    for (const B of BOSSES) { for (const n of [1, 2]) { const id = titleId(B.id, n); AL.ACH_BY[id] = { id, ic: n === 2 ? '👑' : '📛', t: titleText(id), p4b: B.id }; }
      const sid = skinId(B.id); AL.SKIN_BY[sid] = { id: sid, ja: DECO[B.id][3][0], zh: DECO[B.id][3][1], p4b: B.id }; }
    AL.ACH_BY[ALL_TITLE] = { id: ALL_TITLE, ic: '🏆', t: titleText(ALL_TITLE), p4b: 'all' };
  }
  registerBook(root.TankBook || req('./tank-book.js'));

  function prof(pr) { if (!pr.p4b || typeof pr.p4b !== 'object') pr.p4b = { got: {}, sticker: '', flag: '', trail: '' }; if (!pr.p4b.got) pr.p4b.got = {}; return pr.p4b; }
  const got = (pr, boss) => (pr && pr.p4b && pr.p4b.got ? pr.p4b.got[boss] | 0 : 0);
  // つぎの ごほうび（その人）。[レベル, 絵] か null
  function nextReward(pr, boss) { const g = got(pr, boss); for (const k of Object.keys(LADDER).map(Number).sort((a, b) => a - b)) if (k > g) return [k, REWARD_IC[k]]; return null; }
  // もっている かざり
  function owned(pr, kind) { const q = prof(pr), out = []; for (const id of IDS) { const g = q.got[id] | 0; if ((kind === 'sticker' && g >= 1) || (kind === 'flag' && g >= 5) || (kind === 'trail' && g >= 8)) out.push(id); } return out; }
  function setDeco(pr, kind, id) { if (!['sticker', 'flag', 'trail'].includes(kind)) return false; const q = prof(pr); if (id && !owned(pr, kind).includes(id)) return false; q[kind] = id || ''; return true; }
  function titleIds(pr) { const out = []; if (!pr.ach) return out; for (const B of BOSSES) for (const n of [1, 2]) if (pr.ach[titleId(B.id, n)]) out.push(titleId(B.id, n)); if (pr.ach[ALL_TITLE]) out.push(ALL_TITLE); return out; }

  /* 勝った時の ごほうび（1 人分）。pr を 書きかえる。GR＝TankGear。返すのは ならべて 見せる 物の 一覧
     [{ k:'coins', n } { k:'chest', kind, res } { k:'parts', n } { k:'charm' } { k:'sticker'|'flag'|'trail'|'skin', b } { k:'gear', b, r, id } { k:'title', id }]
     - まだ もらっていない レベル（got+1 〜 L）：コインは ぜんぶ、宝箱は いちばん上の レベルの 1 つ、とちゅうの ごほうびも ぜんぶ
     - もう もらった レベル：コイン 3 わり＋木の宝箱（金の おまもり でんせつ：5% で 金） */
  function claim(pr, boss, L, GR, now) {
    const B = BY[boss]; if (!B || !pr) return []; const l = clamp(L, 1, MAX), q = prof(pr), g0 = q.got[boss] | 0, out = [], cm = GR ? GR.mods(pr).coin || 1 : 1, world = B.world;
    const chest = kind => { if (!GR) return; const res = GR.openChest(pr, kind, { world }); out.push({ k: 'chest', kind, res }); };
    if (g0 >= l) { const n = Math.round(levelCoins(l) * REPLAY * cm); pr.coins = (pr.coins | 0) + n; out.push({ k: 'coins', n });
      const m = GR ? GR.mods(pr) : null, gold = m && m.p4b && m.p4b.gold ? m.p4b.gold : 0; chest(gold && GR && Math.random() < gold ? 'gold' : 'wood'); return out; }
    let coins = 0; for (let k = g0 + 1; k <= l; k++) coins += levelCoins(k); coins = Math.round(coins * cm); pr.coins = (pr.coins | 0) + coins; out.push({ k: 'coins', n: coins });
    chest(chestOf(l));
    for (let k = g0 + 1; k <= l; k++) for (const r of LADDER[k] || []) {
      if (r === 'bonus') { pr.coins += BONUS3.coins; pr.parts = (pr.parts | 0) + BONUS3.parts; out.push({ k: 'coins', n: BONUS3.coins }, { k: 'parts', n: BONUS3.parts }); }
      else if (r === 'sticker' || r === 'flag' || r === 'trail') { out.push({ k: r, b: boss }); if (!q[r]) q[r] = boss; }
      else if (r === 'charm') { pr.charms = Math.min(999, (pr.charms | 0) + 1); out.push({ k: 'charm' }); }
      else if (r === 'gear5' || r === 'gear6' || r === 'gear7') { const it = GR && GR.p4bGive ? GR.p4bGive(pr, boss, +r.slice(4)) : null; if (it) out.push({ k: 'gear', b: boss, r: it.r, id: it.id }); }
      else if (r === 'title1' || r === 'title2') { const id = titleId(boss, r === 'title2' ? 2 : 1); if (!pr.ach || typeof pr.ach !== 'object') pr.ach = {}; pr.ach[id] = Math.floor((now || Date.now()) / 1000) || 1; out.push({ k: 'title', id }); }
      else if (r === 'skin') { const id = skinId(boss); if (!Array.isArray(pr.skins)) pr.skins = []; if (!pr.skins.includes(id)) pr.skins.push(id); out.push({ k: 'skin', b: boss, id }); }
    }
    q.got[boss] = l;
    if (l >= MAX && IDS.every(id => (q.got[id] | 0) >= MAX) && !(pr.ach && pr.ach[ALL_TITLE])) { pr.ach = pr.ach || {}; pr.ach[ALL_TITLE] = Math.floor((now || Date.now()) / 1000) || 1; out.push({ k: 'title', id: ALL_TITLE }); }
    return out;
  }
  // 負け：コイン 20 だけ（なにも へらない）
  function lose(pr) { pr.coins = (pr.coins | 0) + LOSE_COIN; return LOSE_COIN; }
  // フィギュア（家族の かざりだな）：0 なし・1 銅（Lv1）・2 銀（Lv10）・3 金（Lv20）
  const figure = lv => (lv >= 20 ? 3 : lv >= 10 ? 2 : lv >= 1 ? 1 : 0);
  // チームの 強さ（装備の 強さの 平均）と その レベルの めやす → 0 😀・1 😐・2 😱
  function teamPower(prs, GR) { if (!prs.length || !GR) return 0; let s = 0; for (const pr of prs) { let v = 0; for (const it of Object.values(GR.equipped(pr))) if (it) v += GR.power(it); s += v / 6 + (GR.carLv(pr, pr.car) - 1) * 0.05; } return s / prs.length; }
  const needPower = L => 0.6 + 0.3 * clamp(L, 1, MAX);
  function teamHint(prs, L, GR) { const p = teamPower(prs, GR), n = needPower(L); return p >= n ? 0 : p >= n * 0.6 ? 1 : 2; }

  // はじまりの 持ち物（ぼうけんでは 前の 面から 持ちこむ 分の かわり）：パワー 1・よろい 1。おたすけは 台数 +1
  const KIT = { power: 1, armor: 1, lives: 3 };
  function carry(L, n, help, base) { const c = Object.assign({}, base || {}), pl = {}; for (let i = 0; i < Math.max(4, n | 0); i++) pl[i] = Object.assign({ power: KIT.power, armor: KIT.armor, lives: KIT.lives + (help ? 1 : 0), twin: 0, sp: 0 }, (base && base.pl && base.pl[i]) || {});
    c.pl = pl; return c; }
  const api = { MAX, KIT, carry, BOSSES, BY, IDS, KIND_BOSS, TUNE, params, band, rating, RATING, BAND_COL, MOVES, MOVE_NAME, NO_SUMMON, MILESTONE, changes, stage, baseStage,
    cleanStore, maxPick, syncAdventure, winStore, loseStore, helpOn, HELP_LOSSES, HELP_MAX_LV, LADDER, REWARD_IC, levelCoins, chestOf, REPLAY, LOSE_COIN, BONUS3,
    DECO, COL, titleId, skinId, ALL_TITLE, titleText, registerBook, prof, got, nextReward, owned, setDeco, titleIds, claim, lose, figure, teamPower, needPower, teamHint };
  root.TankBossLv = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);

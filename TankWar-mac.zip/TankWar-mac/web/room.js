/* 部屋のサーバー（/ws）につなぐ部品。どうぶつ大合戦（game.html）と戦車（tank.html）で共通に使う。
   試作は Claude の room を使っていた。同じ使い方（presence・peers・on・emit）ができるようにしてある。
   テレビ（同じ端末の中からだけ）とスマホを、部屋のサーバーの WebSocket が中継する。

   使い方：const room = FamilyRoom.create('tv' または 'pad', { onConn, onStop });
     onConn()        つながった・切れた時に呼ぶ（画面の「通信OK」などを直すため）
     onStop(reason)  この画面が止まった時に呼ぶ。reason は 'replaced'（ほかの画面がテレビになった）か 'not tv'（この端末はテレビになれない） */
(function () {
  'use strict';
  const ROOM_PING_MS = 2000;      // つながりを保つ ping と、スマホの名乗り直しの間隔
  const ROOM_RETRY_MS = 1500;     // 切れた時につなぎ直すまでの時間
  const HOST_STALE_MS = 3000;     // テレビからの知らせがこの時間来なければ、テレビが見つからない扱いにする
  const PONG_LIMIT_MS = 6000;     // pong がこの時間来なければ、通信が死んでいるとみなしてつなぎ直す（iPhone のスリープ明けなど）

  function create(role, opts) {
    const onConn = (opts && opts.onConn) || function () {};
    const onStop = (opts && opts.onStop) || function () {};
    const handlers = {}, pads = new Map();   // pads：テレビ側だけ。スマホの id → 名乗り（presence）
    let ws = null, myId = null, myPresence = null, host = null, hostAt = 0, retry = null, stopped = false, lastPong = 0;
    const api = {
      connected: false,
      presence(p) { myPresence = p; send(role === 'tv' ? { t: 'presence', to: 'all', p } : { t: 'presence', p }); return Promise.resolve(); },
      emit(topic, data) { return send({ t: 'emit', topic, data }) ? Promise.resolve() : Promise.reject(new Error('未接続')); },
      on(topic, fn) { (handlers[topic] = handlers[topic] || []).push(fn); },
      peers() {
        if (role === 'tv') return [...pads].map(([peer, presence]) => ({ peer, presence }));
        const list = [];
        if (host && performance.now() - hostAt < HOST_STALE_MS) list.push({ peer: 'tv', presence: host });
        if (myId) list.push({ peer: myId, isMe: true, sameTab: true, presence: myPresence });
        return list;
      }
    };
    function send(o) { if (stopped || !ws || ws.readyState !== WebSocket.OPEN) return false; ws.send(JSON.stringify(o)); return true; }
    function stop(reason) {
      if (stopped) return;
      stopped = true; api.connected = false; onConn(); onStop(reason);
      try { if (ws) ws.close(); } catch (e) { console.warn('接続を閉じられませんでした', e); }
    }
    function onMsg(m) {
      if (!m || typeof m !== 'object') return;
      // サーバー自身の知らせには from が無い（スマホからの中継には必ず付く）
      const fromServer = m.from === undefined;
      if (m.t === 'pong') { lastPong = performance.now(); return; }
      if (m.t === 'replaced' && fromServer) { stop('replaced'); return; }
      if (role === 'tv') {
        const id = m.from;
        if (m.t === 'peers' && fromServer) { pads.clear(); (m.list || []).forEach(p => { if (p && typeof p.id === 'string') pads.set(p.id, null); }); }
        else if (m.t === 'leave') pads.delete(id);
        else if (m.t === 'presence' && typeof id === 'string') pads.set(id, m.p && typeof m.p === 'object' ? m.p : null);
        else if (m.t === 'emit' && typeof id === 'string' && typeof m.topic === 'string')
          (handlers[m.topic] || []).forEach(fn => { try { fn({ peer: id, data: m.data }); } catch (e) { console.error('操作を処理できませんでした', e); } });
      } else {
        if (m.t === 'welcome' && fromServer) { myId = typeof m.id === 'string' ? m.id : null; if (myPresence) send({ t: 'presence', p: myPresence }); }
        else if (m.t === 'presence' && m.p && typeof m.p === 'object') { host = m.p; hostAt = performance.now(); }
      }
    }
    function connect() {
      retry = null; if (stopped) return; let mine;
      try { mine = new WebSocket('ws://' + location.host + '/ws'); }
      catch (e) { console.error('部屋のサーバーにつなげませんでした', e); retry = setTimeout(connect, ROOM_RETRY_MS); return; }
      ws = mine;
      mine.onopen = () => {
        if (ws !== mine) return;
        api.connected = true; lastPong = performance.now(); console.info('部屋のサーバーにつながりました');
        send({ t: 'hello', role, name: '' }); if (role === 'tv' && myPresence) send({ t: 'presence', to: 'all', p: myPresence }); onConn();
      };
      mine.onmessage = e => { if (ws !== mine) return; let m; try { m = JSON.parse(e.data); } catch (err) { console.error('通信を読めませんでした', err); return; } onMsg(m); };
      mine.onerror = () => console.warn('通信でエラーが起きました');
      mine.onclose = e => {
        if (ws !== mine || retry || stopped) return;
        if (e.reason === 'not tv') { stop('not tv'); return; }
        api.connected = false; myId = null; host = null; if (role === 'tv') pads.clear();
        console.warn('部屋のサーバーとの接続が切れました。code=' + e.code); onConn(); retry = setTimeout(connect, ROOM_RETRY_MS);
      };
    }
    connect();
    // 通信が死んでいないか確かめる。pong が来なければ閉じて、つなぎ直す
    function checkAlive() { if (ws && ws.readyState === WebSocket.OPEN && performance.now() - lastPong > PONG_LIMIT_MS) { console.warn('応答が無いため、つなぎ直します'); ws.close(); } }
    setInterval(() => { checkAlive(); send({ t: 'ping', ts: performance.now() }); if (role === 'pad' && myPresence) send({ t: 'presence', p: myPresence }); }, ROOM_PING_MS);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) { lastPong = Math.min(lastPong, performance.now() - PONG_LIMIT_MS + 1000); send({ t: 'ping', ts: performance.now() }); } });
    return api;
  }

  window.FamilyRoom = { create };
})();

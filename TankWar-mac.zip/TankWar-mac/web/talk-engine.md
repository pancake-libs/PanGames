# 会話エンジン（Talk Engine）v1.1 — API

`web/talk-engine.js` → `window.TalkEngine`（node では `require('./talk-engine.js')`）。
ゲームに よらない「こえ＋AI の キャラクターと おしゃべり」の 部品です。DOM・音・ゲームの 名前は 入っていません。
ゲーム（ホスト）は キャラクター表と 画面を 用意し、エンジンの `Step` を 見て 文を 出し、声を ならし、`flags` の いみを きめます。
v1.1 の たし算（§8）は どれも かかなければ 使われず、v1 の 表では 答えが 1 バイトも かわりません（`tools/v030-check.mjs` §2 が v1 の 指紋と くらべる）。

```
child words / tapped card ──► talk.answer() ──► Step { say[], ask, flags, memo, done }
                                   │  brain 'llm':  POST /brain/chat → parseTurn → checkTurn（しっぱい → written）
                                   │  brain 'written': キーワードの 札あわせ → 書いた 答え（サーバー なし）
                                   └─ nextState（じゅんばん・たしかめ・おわり・フラグは いつも エンジンが きめる）
```

## 1. つくる・ひらく

```js
const eng = TalkEngine.create({
  data,                         // { frame:{title, role}, ng:{ja,zh}, allow:{ja,zh}, yes:{ja,zh}, no:{ja,zh}, chars:{ id: キャラクター表 } }
  brains: { llm: TalkEngine.brains.http('/brain/chat') },   // written は いつも ある
  brain: 'auto',                // 'auto' | 'llm' | 'written'、または () => そのどれか
  ready: () => llmReady,        // 'auto' の 時：true なら llm
  limits: { beats: 10, exchanges: 15, reasks: 5 }
});
const talk = eng.open({ who: 'id', topic: 0, memory: ['・…'], lang: 'ja', names: ['プレイヤーの 名前'], greet: {ja, zh}? });
await talk.start();                                   // → Step（あいさつ＋さいしょの しつもん）
await talk.answer({ text, kana, pick, m, sc, speaker, lang });   // 聞きとった 文（kana＝読み）か、タップ（pick＝札の 番号）
await talk.confirm(true | false);                     // だいじな しつもんの「これで きめる？」
talk.stop();  talk.gone();                            // 「おわる」・だれも いなくなった
talk.thinking();                                      // 考えている 間の ひとこと（fixed.think を じゅんばんに）
```

- `pick >= 0` は タップ（いつも その 札）。`m`／`sc` は スマホの 札あわせの 結果（無ければ エンジンが `match` する）。
- たしかめ中の `answer` は はい／いいえ の ことばで `confirm` に なる（いいえ を 先に しらべる：「ううん」の 中の「うん」）。札の タップは その 札に きめる。

### Step

```js
{ say: [{ who, ja, zh, src: 'llm'|'written'|'fixed', fx?: [fixedKey, index], q?: 1 }],
  ask: { b, q:{ja,zh}, cards:[{id, ic, ja, zh}], big: 0|1|2, check: card|null, type, key, reask, again, n, of } | null,
  cat, mood, flags: { slot: value }, memo: [{ b, c, w? }], done, complete, why, brain, ex, ans, fails, reasks }
```

- `say` の さいごが つぎの しつもん（`q: 1`）。`fx` は 決まった セリフ（録った 声の ある もの）の 印。
- `big`：0 ふつう、1 札を 大きく（🎤 小さく）、2 タップだけ。`check` が ある 時は「これで きめる？」（✅ うん／↩ ちがう）。
- `flags` は たしかめの すんだ だいじな 札の `val` だけ。いみは ゲームが きめる。
- `why`：`done`（さいごまで）・`stop`・`bad`（わるい ことば 3 回）・`gone`。`complete` = `done` で 8 つ以上 こたえた。

## 2. キャラクター表（`data.chars[id]`）

```json
{ "persona": { "name": ["ja","zh"], "tone": "…", "likes": "…", "dislikes": "…", "notes": ["8〜15 の じじつ"], "sample": ["×5"],
               "ex": [ { "q": "…", "child": "…", "out": { "cat": "other", "ja": "…", "zh": "…", "mood": 0 } } ] },
  "fixed": { "hi": [{ja,zh}…], "think": […3], "huh": […], "dunno": […], "bad": […], "stop": {ja,zh}, "check": {ja,zh}, "byeWarm": {…}, "bye": {…} },
  "topics": [ { "id": "…", "title": ["ja","zh"], "close": {ja,zh}, "beats": [ ビート… ] } ] }
```

ビート：

```json
{ "id": "b1", "type": "ab|yn|pick|open", "key": null, "keep": false,
  "q": {ja,zh}, "reask": {ja,zh}, "memo": "すきなのは「{c}」",
  "cats": [ { "id": "a", "ic": "❄", "ja": "ゆき", "zh": "雪", "val": null, "next": null,
              "kw": { "ja": [], "zh": [] }, "say": { "ja": [], "zh": [] }, "re": { "ja", "zh", "who"? } } ],
  "reOther": {ja,zh} }
```

- 本の ビートは `b1`…`b10`。`next` で とぶ 先（`b2x` など）は その あと つぎの 本の ビートへ もどる。
- `key`（フラグの 名前）が ある ビートが だいじな しつもん：札の `val`（1〜3）が `flags[key]` に なる。こたえは いつも その 札の 書いた `re`（きまった ことが はっきり わかる）。
- `memo`：`{c}`＝札の 文、`{w}`＝こどもの ことば（`keep: true` の `open` だけ。16 文字まで・かな／漢字だけ・NG なし）。
- そのほか の 欄（`words`・`fixed.help` など）は エンジンは つかわない（ゲームの もの）。

## 3. じゅんばん（`nextState`）の きまり

| こたえ | エンジン |
|---|---|
| 札（ふつう） | ひとこと → つぎ |
| 札（だいじ）タップ／札あわせ ≥ 0.75 | フラグ → ひとこと → つぎ |
| 札（だいじ）話した だけ | 「これで きめる？」→ うん：フラグ／ちがう：タップだけ |
| other（open） | ひとこと（`keep` なら おぼえる）→ つぎ |
| other（ab/yn/pick）1 回め | ひとこと → `reask`（札 大きく） |
| other 2 回め | ふつう：つぎへ。だいじ：タップだけ |
| unclear 1 回め | `huh` → 札を 読む しつもん |
| unclear 2 回め | 札 大きく（だいじ：タップだけ） |
| bad | `bad` → 同じ しつもん。3 回め：おわり |
| stop | `stop` → おわり |

- やりなおし（`reask`・`huh`・`bad`）は 5 回まで。やりとりは 15 回まで（こえたら おわりの セリフ）。
- `mood` の 合計 ≥ 4 で `byeWarm`、ほかは `bye`。ごほうびは へらさない。

## 4. あたま（brains）

```js
TalkEngine.brains.http(url, { wait: 12000, fetch, headers })  // { kind:'llm', ask(req), warm() }
TalkEngine.brains.written()                                    // { kind:'written' }
TalkEngine.brains.script([raw, {err:'timeout'}, …])            // 試し用
```

- 自分の あたまも つくれる：`{ kind:'llm', ask: async ({sys, msgs, cats}) => ({ ok:true, raw:'{"cat":…}', jaKana:'' }) }`。
- `ask` が `{ok:false}`・12 秒こえ・見張りで だめ → その 回は 書いた 答え。1 回の おしゃべりで 3 回 → のこりは 書いた 答え。

## 5. 純粋な 関数

```js
buildPrompt(data, ctx)  -> { sys, msgs, cats }   // ctx = { who|sheet, topic, beat, next, last, memory, history:[{heard, say:{cat,ja,zh,mood}}], heard:{text,kana,pick,m,speaker,lang} }
parseTurn(raw)          -> { ok, cat, ja, zh, mood } | { ok:false, why }
checkTurn(turn, env)    -> { ok, ja, zh, cat, mood, swapZh } | { ok:false, rule:'G1'…'G9', cat? }   // env = { cats, cards, jaKana, ng, allow, names, last2, pick, m, sc }
nextState(state, ev, data) -> { state, out:[…] }  // data = { topic, limits, lists }
memoryLines(store, who, data, lang) -> [string] (≤ 6)   // store = { b:{ who:{ f:{slot:val}, memo:[{t,b,c,w}] } } } または { f, memo }
match(text, kana, cards, lang) -> { m, score, amb, none, sc }
yesNo(text, kana, lang, lists) -> 'yes'|'no'|null
maskNG(text, kana, lang, lists) / hasNG(text, lang, lists)   // lists = { ng:{ja,zh}, allow:{ja,zh} }
```

- 見張り（§3.5）：G1 形・G2 かなだけ（漢字は `jaKana` で）・G3 長さ／2 文まで／しつもん しない・G4 中国語（だめなら 書いた zh）・G5 NG・G6 名前／数字／URL・G7 くりかえし・G8 bad/stop は きまった セリフ・G9 タップ／つよい 札あわせが かつ。
- NG は 部分一致。空白と 句読点は 区切り。`allow` の ことばの 中から はじまる 当たりは 数えない（「ころころして」の「ころして」）。

## 6. サーバー（会話エンジンの パッケージ `app.familyplay.talk`）

| Route | |
|---|---|
| `POST /brain/chat` | `{sys, msgs, cats, warm}` → `{ok, raw, jaKana, ms, tok, model}` / `{ok:false, err}`。この 端末の 中から だけ |
| `GET /brain/status` | `{on, fake, llm:{state, model, done, total, tps}, tts:{state, missing}}` |
| `POST /tts` | `{boss, who, text, keep}` → `audio/wav`。声の 表は `talk-voices.json`（who → char・style・speedScale・pitchScale・intonationScale） |
| `POST /brain/config` | `{pull}`・`{model}`・`{retry}`・`{startTts}`・`{open}` |

## 7. べつの ゲームで つかう

キャラクター表と トピックを 同じ 形で 書き、画面を つくり、「フラグ → 効果」の 表を もつ だけ。エンジンと サーバーの パッケージは そのまま。
`tools/talk-sample.json` が ゲームと 関係ない 見本（v029-check §8 が 1 回 おしゃべり します）。

## 8. v1.1 の たし算（どれも 書かなくて よい）

| | データ | 結果 |
|---|---|---|
| E1 タグ | 札に `tags: { name: 整数 }`（name `^[a-z]{1,8}$`、値 −9〜9） | `Step.tags`＝この ターンで ふえた タグ（無い 時は 欄も ない）、`Step.tagBy`＝`[{ b, src:'card'|'llm'|'kw', tags }]`、`talk.state.tally`（`talk.tally`）＝おしゃべり 全体の 合計。いみは ゲームが きめる |
| E2 はんてい | `frame.judges = { name: { vals:[2〜5], none, rule, tags:{ 値: タグ }, use:'llm'|'kw'|'off', kw:{ 値:{ja,zh} } } }`、ビートに `judge: [name…]` | `buildPrompt` が きまり 13〜 と `enums` を たす。AI の 値（ない・まちがい → `none`）を `tags` で タグに。**さいごの cat が `other`・AI の セリフが 見張りを ぜんぶ とおった 時 だけ** |
| E3 書いた はんてい | `judges.<name>.kw`、topic の `judgeKw.<name>`（同じ 形、たし算） | written の 時・AI が しっぱいした 時・`use:'kw'`：こどもの ことばの キーワード（いちばん 多く 当たった 値。同点・なし → `none`）。これも `other` の 時 だけ |
| E4 huddle | ビートに `huddle: 1` | `ask.huddle = 1`（無い 時は 欄も ない）。いみは ゲームが きめる |
| E5 need | 札に `need: { tag, min }` | `tally[tag] ≥ min`（min なし＝1）の 時 だけ `ask.cards` と AI の `cats` に 出る。`answer({pick})` は `ask.cards` の 番号 |
| E6 notes | topic に `notes: [..5]`、`notesTitle`（なし＝`{name} の こころの なか`） | judge の ある ビート だけ、system に ひみつの きまり（`frame.secretRule` で かえられる）と「# notesTitle」の 行。Step には 出ない |
| E7 limits | topic に `limits: { beats, exchanges, reasks, min }` | この topic だけ エンジンの 上限を うわがき。`complete`＝`done` で `ans ≥ min` |
| E8 line | — | `eng.line({ who|character, memory, ask, lang, names, last2, notes? }) → Promise<{ja, zh, src:'llm'} | null>` |
| E9 tagCap | `frame.tagCap = { tag: 上限 }` | はんてい で ふえる タグの 1 回の おしゃべりの 上限（札の タグは 上限 なし） |

```js
const talk = eng.open({ character: sheet, topic: 0, frame: { judges, tagCap }, … });   // frame は data.frame に かさねる（この おしゃべり だけ）
await talk.answer({ text, …, extra: ['# これまでの アイデア：1「…」'] });                // AI の user に 3 行まで たす（120 文字まで）
const l = await eng.line({ who: 'id', memory: ['・…'], ask: 'ひさしぶりに あった。ひとこと。' });   // null → ゲームの 書いた 文
```

- `brains.http` の 体：v1 と 同じ `{sys, msgs, cats, warm}`。`enums`（はんてい の ある ビート）・`free: true`（line、`cats: []`）は ある 時 だけ。サーバーの スキーマの じゅん：`cat, <enums…>, ja, zh, mood`。
- line の 見張り：G2 かな（`jaKana` も）・「？」なし・2〜30 文字・2 文まで・zh（かえ なし）・G5 NG・G6 名前／数字・G7 くりかえし・J7 notes。だめなら `null`。AI が つかえない（written・`auto` で まだ）時も `null`。
- J7：`checkTurn(turn, { notes })`・`checkLine` は notes の 1 文 まるごと（空白なし・4 文字以上）を ふくむ セリフを `J7` で はねる。

純粋な 関数の たし算：

```js
buildPrompt(data, ctx)        // ctx ＋ frame・tally（need）・extra。judge の ある ビート → { sys, msgs, cats, enums }
parseTurn(raw, { judges })    // ＋ j:{ name: 値 }。parseTurn(raw, { free:true }) → cat なしで よい
checkTurn(turn, env)          // env ＋ notes（J7）・judges → ＋ j、tags（cat が other の 時 だけ）
checkLine(turn, env) / buildLine(data, { who|sheet, memory, ask })
nextState(state, ev, data)    // data ＋ tagCap。ev ＋ jt（はんてい の タグ）・jsrc。out ＋ {k:'tags', b, src, tags}。state ＋ tally・jt
judgesFor(frame, topic, beat) / judgeVal(def, raw) / judgeByWords(def, text, kana, lang) / judgeTags(js, j, cat) / cleanTags(t) / cardsFor(beat, tally) / topicLimits(topic)
```

見本：`tools/talk-sample.json` の b2 が tags・judge（`feel`）・huddle・need を つかう。

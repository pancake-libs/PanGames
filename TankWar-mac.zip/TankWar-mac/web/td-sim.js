/* タワーディフェンス「ひかりの木をまもれ！」の計算（v1.0）。テレビの画面（td.html）・スマホの画面・確かめ用の node から読む。
   - 升（タイル）を 1 とした座標。升 (x, y) の真ん中は (x + 0.5, y + 0.5)
   - 地図は面の番号（1〜）から自動で作る（genLevel）。同じ番号なら同じ地図・同じ敵の並びになる
   - 乱数は種を決めた関数だけを使う。step(g) は決まった刻み（CFG.fixedDt）で呼ぶ。描画は別（td.html）
   - 音・光などの知らせは g.ev に積む。画面がそれを読んで鳴らす・光らせる
   - お金は参加者ごとの財布（枠ごと）。敵を倒すと、参加している全員に同じだけ入る（取り合いにならない） */
(function (root) {
  'use strict';

  /* ============ ここを変えると難しさ・長さを変えられます ============ */
  const CFG = {
    fixedDt: 1 / 30,          // 計算の刻み（秒）
    maxPlayers: 4,            // 同時に遊べる人数
    cols: 22, rows: 13,       // 盤面の升の数（横・縦）
    waves: 30,                // 1 回の遊び（1 面）の波の数。1 波 約 50 秒で、1 面 約 25 分
    bossEvery: 10,            // この波ごとにボスが来る
    levels: 120,              // 選べる面の数（地図は自動で作るので、もっと増やせる）
    lives: { easy: 30, normal: 20, hard: 12 },        // ひかりの木の命
    hpDiff: { easy: 0.72, normal: 1, hard: 1.3 },      // 敵の体力の倍率
    goldDiff: { easy: 1.2, normal: 1, hard: 0.92 },    // もらえるお金の倍率
    startGold: 240,           // 1 人の最初のお金（1 面）
    startGoldPerLevel: 5,     // 面が 1 つ進むごとに増やす最初のお金
    startGoldMax: 700,        // 最初のお金の上限
    firstBreakSec: 35,        // 最初の波までの準備の時間（秒）
    breakSec: 12,             // 波と波の間の時間（秒）
    nextBonusPerSec: 2,       // 「すぐ次の波」を呼んだ時、残りの秒 × この額を全員にあげる
    sellRate: 0.7,            // 売った時に戻るお金の割合
    undoSec: 6,               // 建ててからこの秒の間に売ると、全額が戻る（押しまちがいの取り消し）
    highRange: 1.2,           // 光る石の升（h）に建てた塔の射程の倍率
    skillCd: 70,              // 流れ星（ひっさつ）を次に使えるまで（秒）
    skillDelay: 0.9,          // 流れ星が落ちるまで（秒）
    skillR: 1.7,              // 流れ星の広さ（升）
    skillDmg: 170,            // 流れ星の強さ（波が進むと強くなる）
    giftGold: 50,             // 「おすそわけ」で 1 回に渡すお金
    maxEnemies: 260,          // 同時に出る敵の上限（重くしない）
    waveBonus: w => 20 + 3 * w,                       // 波を越えた時に全員がもらうお金
  };

  /* 敵の種類。hp＝体力、spd＝速さ（升/秒）、arm＝物理の守り（0〜1）、res＝魔法の守り、bounty＝倒した時のお金、leak＝木に着いた時に減る命 */
  const ENEMY = {
    slime:  { hp: 32,  spd: 1.5,  arm: 0,    res: 0,    bounty: 3,   leak: 1,  r: 0.32 },
    runner: { hp: 22,  spd: 2.7,  arm: 0,    res: 0,    bounty: 3,   leak: 1,  r: 0.28 },
    bat:    { hp: 28,  spd: 1.9,  arm: 0,    res: 0.1,  bounty: 4,   leak: 1,  r: 0.30, fly: 1 },
    turtle: { hp: 100, spd: 0.95, arm: 0.5,  res: 0,    bounty: 6,   leak: 2,  r: 0.40 },
    shroom: { hp: 64,  spd: 1.3,  arm: 0.1,  res: 0,    bounty: 4,   leak: 1,  r: 0.36, split: 'sprout', splitN: 3 },
    sprout: { hp: 16,  spd: 2.1,  arm: 0,    res: 0,    bounty: 1,   leak: 1,  r: 0.20 },
    ghost:  { hp: 54,  spd: 1.7,  arm: 0,    res: 0.65, bounty: 5,   leak: 1,  r: 0.32 },
    healer: { hp: 62,  spd: 1.3,  arm: 0.1,  res: 0.2,  bounty: 6,   leak: 1,  r: 0.34, heal: 0.05 },
    knight: { hp: 155, spd: 1.05, arm: 0.4,  res: 0.35, bounty: 9,   leak: 2,  r: 0.42 },
    boss1:  { hp: 800,  spd: 0.7, arm: 0.2,  res: 0.2,  bounty: 120, leak: 5,  r: 0.80, boss: 1, abil: 'summon' },
    boss2:  { hp: 1450, spd: 0.6, arm: 0.45, res: 0.3,  bounty: 220, leak: 7, r: 0.90, boss: 1, abil: 'stomp' },
    boss3:  { hp: 2500, spd: 0.65, arm: 0.3, res: 0.45, bounty: 400, leak: 10, r: 1.00, boss: 1, abil: 'shield' },
  };
  /* 敵が出始める強さ（tierOf：波の番号 + 面の分。この値以上で出る） */
  const UNLOCK = { slime: 0, runner: 2, bat: 5, turtle: 7, shroom: 10, ghost: 13, healer: 16, knight: 20 };
  const ENEMY_NAME = {
    slime: ['スライム', '史莱姆'], runner: ['はやうさぎ', '快跑兔'], bat: ['コウモリ（空）', '蝙蝠（空中）'], turtle: ['よろいガメ', '铠甲龟'],
    shroom: ['わかれキノコ', '分裂蘑菇'], sprout: ['こキノコ', '小蘑菇'], ghost: ['まほうよけおばけ', '抗魔幽灵'], healer: ['いやしガエル', '治愈青蛙'],
    knight: ['くろ騎士', '黑骑士'], boss1: ['キングスライム', '史莱姆国王'], boss2: ['いわのゴーレム', '岩石魔像'], boss3: ['やみのドラゴン', '暗黑巨龙'],
  };

  /* 塔の種類。cost＝建てる、up＝2・3 段目に上げる、br＝4 段目（A か B を選ぶ）。lv＝1〜3 段目、A・B＝4 段目
     dmg＝1 発の強さ、rate＝1 秒に撃つ数、rng＝射程（升）、type＝phys（物理）か magic（魔法）、air＝空の敵を撃てるか */
  const TOWER = {
    arrow: { cost: 70, up: [65, 120], br: 230, type: 'phys', air: 1, shot: 'arrow',
      lv: [{ dmg: 11, rate: 1.5, rng: 3.0 }, { dmg: 19, rate: 1.7, rng: 3.2 }, { dmg: 31, rate: 1.9, rng: 3.5 }],
      A: { dmg: 30, rate: 4.4, rng: 3.6 },
      B: { dmg: 125, rate: 0.75, rng: 6.0, crit: 0.25 } },
    cannon: { cost: 110, up: [90, 160], br: 300, type: 'phys', air: 0, shot: 'ball',
      lv: [{ dmg: 26, rate: 0.7, rng: 3.0, splash: 1.0 }, { dmg: 45, rate: 0.72, rng: 3.1, splash: 1.1 }, { dmg: 72, rate: 0.75, rng: 3.3, splash: 1.2 }],
      A: { dmg: 155, rate: 0.6, rng: 3.5, splash: 1.9 },
      B: { dmg: 85, rate: 0.8, rng: 3.3, splash: 1.3, stun: 0.9 } },
    ice: { cost: 90, up: [70, 120], br: 240, type: 'magic', air: 1, shot: 'shard',
      lv: [{ dmg: 5, rate: 1.2, rng: 2.8, slow: 0.35, slowT: 1.6 }, { dmg: 9, rate: 1.25, rng: 3.0, slow: 0.45, slowT: 1.8 }, { dmg: 14, rate: 1.3, rng: 3.2, slow: 0.55, slowT: 2.0 }],
      A: { dps: 18, rng: 3.0, slow: 0.6, slowT: 0.6, aura: 1 },
      B: { dmg: 42, rate: 1.1, rng: 3.4, slow: 0.55, slowT: 2.0, freeze: 0.22, freezeT: 1.4 } },
    thunder: { cost: 140, up: [110, 180], br: 320, type: 'magic', air: 1, airMul: 1.5, shot: 'zap',
      lv: [{ dmg: 20, rate: 0.85, rng: 3.2, chain: 3 }, { dmg: 33, rate: 0.9, rng: 3.3, chain: 4 }, { dmg: 50, rate: 0.95, rng: 3.5, chain: 5 }],
      A: { dmg: 58, rate: 1.0, rng: 3.7, chain: 9 },
      B: { dmg: 270, rate: 0.55, rng: 4.3, chain: 1, stun: 0.5 } },
    poison: { cost: 100, up: [80, 130], br: 260, type: 'magic', air: 1, shot: 'orb',
      lv: [{ dmg: 4, rate: 1.0, rng: 2.9, dot: 7, dotT: 3, shred: 0.2 }, { dmg: 6, rate: 1.0, rng: 3.0, dot: 13, dotT: 3, shred: 0.25 }, { dmg: 9, rate: 1.0, rng: 3.2, dot: 21, dotT: 3, shred: 0.3 }],
      A: { dmg: 12, rate: 1.1, rng: 3.3, dot: 58, dotT: 3.5, shred: 0.3 },
      B: { dmg: 12, rate: 1.0, rng: 3.3, dot: 24, dotT: 3, shred: 0.55, splash: 1.3 } },
    gold: { cost: 120, up: [100, 160], br: 280, type: null, air: 0, shot: null,
      lv: [{ inc: 30 }, { inc: 50 }, { inc: 75 }],
      A: { inc: 140 },
      B: { inc: 60, buff: 0.25, buffR: 1.6 } },
  };
  const TOWER_KINDS = ['arrow', 'cannon', 'ice', 'thunder', 'poison', 'gold'];
  const TOWER_NAME = {
    arrow: ['ゆみの塔', '弓箭塔'], cannon: ['たいほう', '大炮'], ice: ['こおりの塔', '冰霜塔'], thunder: ['かみなりの塔', '雷电塔'],
    poison: ['どくの塔', '毒雾塔'], gold: ['おかねの木', '摇钱树'],
  };
  const BRANCH_NAME = {
    arrow: { A: ['れんしゃ', '连射'], B: ['そげき', '狙击'] }, cannon: { A: ['ばくれつ', '爆裂'], B: ['じしん', '地震'] },
    ice: { A: ['ふぶき', '暴风雪'], B: ['こおりづけ', '冰冻'] }, thunder: { A: ['らいう', '雷雨'], B: ['いかずち', '霹雳'] },
    poison: { A: ['もうどく', '剧毒'], B: ['さびのきり', '锈蚀雾'] }, gold: { A: ['たからの木', '宝藏树'], B: ['はげましの木', '鼓舞之树'] },
  };
  const TARGET_MODES = ['first', 'strong', 'close'];

  /* 景色（10 面ごとに変わる）。色・飾りは td.html が使う */
  const BIOMES = [
    { id: 'meadow', ja: 'はなの草原', zh: '花之草原' },
    { id: 'desert', ja: 'すなの谷', zh: '沙之谷' },
    { id: 'snow', ja: 'ゆきの山', zh: '雪之山' },
    { id: 'autumn', ja: 'もみじの森', zh: '红叶森林' },
    { id: 'volcano', ja: 'ほのおの島', zh: '火焰岛' },
    { id: 'crystal', ja: 'よるの水晶', zh: '夜之水晶' },
  ];

  /* ---------- 乱数（種を決める） ---------- */
  function rng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  /* ---------- 地図を作る ---------- */
  const D4 = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  /* 道を A* で探す。used＝もう道になった升（触れてはいけない）。goals＝着いてよい升の集まり（key の Set） */
  function findPath(C, R, from, goals, used, r, opt) {
    const key = (x, y) => y * C + x;
    const cost = new Float32Array(C * R);
    for (let i = 0; i < cost.length; i++) cost[i] = 1 + r() * 2.2;   // 道をくねらせるための、升ごとのでこぼこ
    const g = new Float32Array(C * R).fill(Infinity), prev = new Int32Array(C * R).fill(-1);
    const s = key(from.x, from.y); g[s] = 0;
    const open = [s];
    const yMin = opt.yMin, yMax = opt.yMax;
    // 升 v に入ってよいか。u＝来た升。道（used）には触れない（着く升の集まりだけは別）
    const ok = (u, vx, vy) => {
      if (vx < 0 || vy < yMin || vx >= C || vy > yMax) return false;
      const v = key(vx, vy);
      if (goals.has(v)) return true;
      if (used.has(v)) return false;
      for (const [dx, dy] of D4) {
        const nx = vx + dx, ny = vy + dy; if (nx < 0 || ny < 0 || nx >= C || ny >= R) continue;
        const n = key(nx, ny);
        if (n !== u && used.has(n) && !(opt.touchGoals && goals.has(n))) return false;
      }
      return true;
    };
    while (open.length) {
      let bi = 0; for (let i = 1; i < open.length; i++) if (g[open[i]] < g[open[bi]]) bi = i;
      const u = open[bi]; open[bi] = open[open.length - 1]; open.pop();
      if (goals.has(u) && u !== s) { const out = []; for (let c = u; c !== -1; c = prev[c]) out.push(c); return out.reverse(); }
      const ux = u % C, uy = (u / C) | 0;
      for (const [dx, dy] of D4) {
        const vx = ux + dx, vy = uy + dy;
        if (!ok(u, vx, vy)) continue;
        const v = key(vx, vy), ng = g[u] + cost[v];
        if (ng < g[v]) { g[v] = ng; prev[v] = u; open.push(v); }
      }
    }
    return null;
  }
  /* 道が自分自身に触れていないか（くっついた道は見分けにくい） */
  function pathClean(C, cells, allowFirst) {
    const idx = new Map(); cells.forEach((c, i) => idx.set(c, i));
    for (let i = 0; i < cells.length; i++) {
      const x = cells[i] % C, y = (cells[i] / C) | 0;
      for (const [dx, dy] of D4) {
        const j = idx.get((y + dy) * C + (x + dx));
        if (j !== undefined && Math.abs(j - i) > 1 && !(allowFirst && (i === 0 || j === 0))) return false;
      }
    }
    return true;
  }
  /* 升の並びから、真ん中を結んだ折れ線と長さを作る */
  function polyline(C, cells) {
    const pts = cells.map(c => ({ x: (c % C) + 0.5, y: ((c / C) | 0) + 0.5 }));
    const cum = [0];
    for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y));
    return { pts, cum, len: cum[cum.length - 1] };
  }
  /* 面の番号から地図を作る。cells：'.'＝建てられる、'h'＝光る石（射程が伸びる）、'p'＝道、'x'＝岩や木（建てられない）、'S'＝敵の出口、'T'＝ひかりの木 */
  function genLevel(L) {
    L = Math.max(1, L | 0);
    const C = CFG.cols, R = CFG.rows, r = rng(L * 7919 + 13);
    const biome = BIOMES[Math.floor((L - 1) / 10) % BIOMES.length];
    const nSpawn = L < 12 ? 1 : L < 40 ? (r() < 0.5 ? 1 : 2) : L < 80 ? 2 : (r() < 0.45 ? 3 : 2);
    const minLen = Math.max(34, 50 - Math.floor(L / 6));
    for (let attempt = 0; attempt < 400; attempt++) {
      const key = (x, y) => y * C + x;
      const goal = { x: C - 2, y: 3 + Math.floor(r() * (R - 6)) };
      const start = { x: 0, y: 2 + Math.floor(r() * (R - 4)) };
      // 通る点：上と下へ交互に振ると、長くくねった道になる
      const k = 3 + Math.floor(r() * 3), zig = r() < 0.7, up0 = r() < 0.5;
      const wps = [start];
      for (let i = 0; i < k; i++) {
        const y = zig ? ((i % 2 === 0) === up0 ? 1 + Math.floor(r() * 3) : R - 2 - Math.floor(r() * 3)) : 1 + Math.floor(r() * (R - 2));
        wps.push({ x: clamp(Math.round(2 + (C - 6) * (i + 0.5 + (r() - 0.5) * 0.5) / k), 2, C - 4), y });
      }
      wps.push(goal);
      const used = new Set([key(start.x, start.y)]);
      let main = [key(start.x, start.y)], ok = true;
      for (let i = 1; i < wps.length && ok; i++) {
        const tail = main[main.length - 1], w = wps[i];
        const seg = findPath(C, R, { x: tail % C, y: (tail / C) | 0 }, new Set([key(w.x, w.y)]), used, r, { yMin: 1, yMax: R - 2 });
        if (!seg) { if (i < wps.length - 1) continue; ok = false; break; }   // 届かない通る点は飛ばす（木には必ず着く）
        for (let j = 1; j < seg.length; j++) { main.push(seg[j]); used.add(seg[j]); }
      }
      if (!ok || main.length < minLen || !pathClean(C, main, false)) continue;
      // ほかの出口（上か下の端から、本道の前半へ合流する）
      const branches = [];
      for (let b = 1; b < nSpawn && ok; b++) {
        let made = false;
        for (let tries = 0; tries < 30 && !made; tries++) {
          const top = r() < 0.5, sx = 2 + Math.floor(r() * Math.floor(C * 0.5)), sy = top ? 0 : R - 1;
          if (used.has(key(sx, sy))) continue;
          const lo = 4, hi = Math.floor(main.length * 0.62), goals = new Set(main.slice(lo, hi));
          const seg = findPath(C, R, { x: sx, y: sy }, goals, used, r, { yMin: 0, yMax: R - 1, touchGoals: true });
          if (!seg || seg.length < 6) continue;
          const merge = seg[seg.length - 1], mi = main.indexOf(merge), own = seg.slice(0, -1);
          // 合流の手前以外で、本道に触れていないか
          let touch = false;
          for (let i = 0; i < own.length - 1 && !touch; i++) {
            const x = own[i] % C, y = (own[i] / C) | 0;
            for (const [dx, dy] of D4) { const n = key(x + dx, y + dy); if (x + dx >= 0 && x + dx < C && used.has(n)) { touch = true; break; } }
          }
          if (touch || !pathClean(C, own, false)) continue;
          own.forEach(c => used.add(c));
          branches.push({ cells: own.concat(main.slice(mi)), sx, sy });
          made = true;
        }
        if (!made) ok = false;
      }
      if (!ok) continue;
      // 升の種類
      const cells = new Array(C * R).fill('.');
      used.forEach(c => { cells[c] = 'p'; });
      cells[key(start.x, start.y)] = 'S';
      branches.forEach(b => { cells[key(b.sx, b.sy)] = 'S'; });
      cells[key(goal.x, goal.y)] = 'T';
      // ひかりの木のまわりは木の場所（建てられない）。道の升はそのまま
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        const x = goal.x + dx, y = goal.y + dy; if (x < 0 || y < 0 || x >= C || y >= R) continue;
        if (cells[key(x, y)] === '.') cells[key(x, y)] = 'x';
      }
      // 岩や木（道から離れた所に多く置く）
      const pdist = distField(C, R, cells);
      const propP = 0.07 + (biome.id === 'autumn' || biome.id === 'crystal' ? 0.03 : 0);
      for (let i = 0; i < cells.length; i++) if (cells[i] === '.' && r() < propP * (pdist[i] <= 1 ? 0.5 : pdist[i] >= 4 ? 2.2 : 1)) cells[i] = 'x';
      // 光る石（道のそば 1〜2 升に 3〜5 個）
      const nearCells = []; for (let i = 0; i < cells.length; i++) if (cells[i] === '.' && pdist[i] >= 1 && pdist[i] <= 2) nearCells.push(i);
      const nh = 3 + Math.floor(r() * 3);
      for (let i = 0; i < nh && nearCells.length; i++) { const j = Math.floor(r() * nearCells.length); cells[nearCells[j]] = 'h'; nearCells.splice(j, 1); }
      // 折れ線（敵が歩く道）。空の敵は、出口から木へまっすぐ（少しうねる）
      const paths = [polyline(C, main)].concat(branches.map(b => polyline(C, b.cells)));
      const spawns = [start].concat(branches.map(b => ({ x: b.sx, y: b.sy })));
      const flyPaths = spawns.map(s => {
        const a = { x: s.x + 0.5, y: s.y + 0.5 }, z = { x: goal.x + 0.5, y: goal.y + 0.5 };
        const mx = (a.x + z.x) / 2 + (r() - 0.5) * 3, my = clamp((a.y + z.y) / 2 + (r() - 0.5) * 5, 1, R - 1);
        const pts = []; for (let i = 0; i <= 12; i++) { const t = i / 12, u = 1 - t; pts.push({ x: u * u * a.x + 2 * u * t * mx + t * t * z.x, y: u * u * a.y + 2 * u * t * my + t * t * z.y }); }
        const cum = [0]; for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y));
        return { pts, cum, len: cum[cum.length - 1] };
      });
      return { L, cols: C, rows: R, cells, biome, spawns, goal, paths, flyPaths, seed: L * 7919 + 13, attempt };
    }
    throw new Error('地図を作れませんでした。面=' + L);
  }
  /* 道までの升の数（建てる所の目安・飾りの置き方に使う） */
  function distField(C, R, cells) {
    const d = new Int32Array(C * R).fill(99), q = [];
    for (let i = 0; i < cells.length; i++) if (cells[i] === 'p' || cells[i] === 'S') { d[i] = 0; q.push(i); }
    for (let h = 0; h < q.length; h++) {
      const u = q[h], x = u % C, y = (u / C) | 0;
      for (const [dx, dy] of D4) { const nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= C || ny >= R) continue; const v = ny * C + nx; if (d[v] > d[u] + 1) { d[v] = d[u] + 1; q.push(v); } }
    }
    return d;
  }
  function posOn(path, dist, out) {
    const { pts, cum } = path; let i = out.seg || 0;
    if (i >= pts.length - 1 || cum[i] > dist) i = 0;
    while (i < pts.length - 2 && cum[i + 1] < dist) i++;
    const a = pts[i], b = pts[i + 1], segLen = (cum[i + 1] - cum[i]) || 1, t = clamp((dist - cum[i]) / segLen, 0, 1);
    out.seg = i; out.x = a.x + (b.x - a.x) * t; out.y = a.y + (b.y - a.y) * t; out.dir = Math.atan2(b.y - a.y, b.x - a.x);
    return out;
  }

  /* ---------- 波の中身 ---------- */
  /* 敵の体力の伸び方（ここを変えると難しさが変わる）。波 w の体力 ＝ 1 + A×(w-1) + B×(w-1)²、面 L ごとに LEVEL ずつ増える */
  const HP_WAVE_A = 0.13, HP_WAVE_B = 0.0065, HP_LEVEL = 0.008;
  /* 人数による体力の倍率。お金は人数分入るが、建てる場所は限られるので、人数ほどは増やさない */
  function playerHp(n) { return (0.25 + 0.75 * Math.max(1, n)) * 0.85; }
  function tierOf(L, w) { return w + Math.min(L - 1, 50) * 0.25; }
  /* 1 人の最初のお金（強い面ほど多い） */
  function startGoldOf(L) { return Math.min(CFG.startGoldMax, CFG.startGold + CFG.startGoldPerLevel * (L - 1)); }
  function hpScale(L, w, n, diff) {
    const wv = w - 1;
    // 面の強さは、波が進むほど効く（強い面でも、最初の波は少ない塔で守れる）
    const ramp = Math.min(1, 0.3 + w / 15);
    return (1 + HP_WAVE_A * wv + HP_WAVE_B * wv * wv) * (1 + HP_LEVEL * (L - 1) * ramp) * playerHp(n) * (CFG.hpDiff[diff] || 1);
  }
  function bossKindOf(L, w) {
    if (L < 30) return w >= 30 ? 'boss3' : w >= 20 ? 'boss2' : 'boss1';
    return ['boss1', 'boss2', 'boss3'][(Math.floor(w / CFG.bossEvery) + L) % 3];
  }
  /* 波 w（1〜）の敵の並び。list の at＝出る時刻（波の始めからの秒） */
  function waveSpec(L, w, n, diff) {
    const r = rng(L * 100003 + w * 917 + 7);
    const tier = tierOf(L, w);
    const avail = Object.keys(UNLOCK).filter(k => UNLOCK[k] <= tier);
    const hpMul = hpScale(L, w, n, diff), cntMul = 0.8 + 0.2 * Math.max(1, n);
    const base = Math.round((7 + 0.75 * w) * cntMul);
    const boss = w % CFG.bossEvery === 0;
    const list = [], dur = 16 + w * 0.35;
    let theme = 'mix';
    const roll = r();
    if (!boss && w > 2) {
      if (roll < 0.16 && avail.includes('runner')) theme = 'fast';
      else if (roll < 0.30 && avail.includes('bat')) theme = 'air';
      else if (roll < 0.42 && (avail.includes('turtle') || avail.includes('knight'))) theme = 'tank';
      else if (roll < 0.52) theme = 'swarm';
    }
    let pool, count = base, hpk = 1;
    if (theme === 'fast') { pool = ['runner']; count = Math.round(base * 1.3); hpk = 0.9; }
    else if (theme === 'air') { pool = ['bat']; count = Math.round(base * 0.85); }
    else if (theme === 'tank') { pool = avail.filter(k => k === 'turtle' || k === 'knight'); count = Math.max(3, Math.round(base * 0.5)); }
    else if (theme === 'swarm') { pool = ['slime', 'runner'].filter(k => avail.includes(k)); if (avail.includes('shroom')) pool.push('shroom'); count = Math.round(base * 1.6); hpk = 0.55; }
    else {
      // まぜる：新しい種類を多めに 2〜3 種
      const sorted = avail.slice().sort((a, b) => UNLOCK[b] - UNLOCK[a]);
      pool = [];
      const m = Math.min(sorted.length, 2 + (r() < 0.5 ? 1 : 0));
      for (let i = 0; i < m; i++) { const j = Math.min(sorted.length - 1, Math.floor(Math.pow(r(), 1.6) * sorted.length)); if (!pool.includes(sorted[j])) pool.push(sorted[j]); }
      if (!pool.length) pool = ['slime'];
    }
    if (boss) count = Math.round(base * 0.6);
    // 3〜6 匹のまとまりで出す
    let t = 0; const step = dur / Math.max(1, count);
    for (let i = 0; i < count; i++) {
      const type = pool[Math.floor(r() * pool.length)];
      list.push({ type, hp: Math.round(ENEMY[type].hp * hpMul * hpk), at: Math.round(t * 100) / 100, sp: Math.floor(r() * 8) });
      t += step * (i % 5 === 4 ? 2.2 : 0.7);
    }
    if (boss) {
      const bk = bossKindOf(L, w);
      list.push({ type: bk, hp: Math.round(ENEMY[bk].hp * hpMul * (L < 3 ? 0.8 : 1)), at: Math.round(dur * 0.45 * 100) / 100, sp: 0 });
      list.sort((a, b) => a.at - b.at);
    }
    const types = [...new Set(list.map(e => e.type))];
    return { list, boss, theme, types, total: list.length, hpMul };
  }

  /* ---------- 遊びの状態 ---------- */
  function newGame(seed) {
    return { ph: 'lobby', seed: seed | 0, t: 0, lv: 1, diff: 'normal', level: null, pl: {}, slots: [0, 1, 2, 3].map(() => newSlot(false)),
      towers: [], enemies: [], shots: [], meteors: [], ev: [], uid: 1, wave: 0, wst: 'break', breakT: 0, wt: 0, queue: [], spec: null,
      lives: 20, maxLives: 20, speed: 1, paused: false, win: -1, stars: 0, save: null, leaks: 0, msgSeq: 1, kills: 0 };
  }
  function newSlot(active) { return { active, gold: CFG.startGold, kills: 0, dmg: 0, built: 0, earned: 0, spent: 0, skillCd: 0, msg: '', msgSeq: 0, used: false }; }
  function playerCount(g) { return Object.keys(g.pl).length; }
  function activeSlots(g) { return g.slots.filter(s => s.active); }
  function addPlayer(g, id, name) {
    if (g.pl[id]) return g.pl[id];
    const taken = new Set(Object.values(g.pl).map(p => p.slot));
    let slot = -1; for (let i = 0; i < CFG.maxPlayers; i++) if (!taken.has(i)) { slot = i; break; }
    if (slot < 0) return null;
    const s = g.slots[slot];
    if (!s.used) {
      // 途中から入った人は、ほかの人の平均くらいのお金から始める
      const others = activeSlots(g);
      if (g.ph === 'play' && others.length) s.gold = Math.max(startGoldOf(g.lv), Math.round(others.reduce((a, o) => a + o.gold, 0) / others.length));
      else s.gold = startGoldOf(g.lv);
    }
    s.active = true; s.used = true;
    const p = { id, slot, name: name || '?', cx: Math.floor(CFG.cols / 2), cy: Math.floor(CFG.rows / 2), seen: 0 };
    g.pl[id] = p;
    return p;
  }
  function removePlayer(g, id) { const p = g.pl[id]; if (!p) return; g.slots[p.slot].active = false; delete g.pl[id]; }

  /* 面を始める。save があれば続きから */
  function startRun(g, L, diff, save) {
    g.lv = Math.max(1, L | 0); g.diff = CFG.lives[diff] ? diff : 'normal';
    g.level = genLevel(g.lv);
    g.towers = []; g.enemies = []; g.shots = []; g.meteors = []; g.queue = []; g.spec = null; g.save = null;
    g.maxLives = CFG.lives[g.diff]; g.lives = g.maxLives; g.wave = 0; g.wst = 'break'; g.breakT = CFG.firstBreakSec; g.wt = 0;
    g.t = 0; g.win = -1; g.stars = 0; g.leaks = 0; g.paused = false; g.kills = 0; g.speed = 1;
    g.slots.forEach(s => { s.gold = startGoldOf(g.lv); s.kills = 0; s.dmg = 0; s.built = 0; s.earned = 0; s.spent = 0; s.skillCd = 0; s.used = s.active; });
    if (save) {
      g.wave = clamp(save.wave | 0, 0, CFG.waves - 1); g.lives = clamp(save.lives | 0, 1, g.maxLives); g.breakT = CFG.firstBreakSec;
      (save.gold || []).forEach((v, i) => { if (g.slots[i]) { g.slots[i].gold = Math.max(0, v | 0); g.slots[i].used = true; } });
      (save.towers || []).forEach(t => {
        if (!g.slots[t.o]) return;
        const tw = placeTower(g, t.x, t.y, t.k, t.o, true); if (!tw) return;
        tw.lvl = clamp(t.l | 0, 1, 4); tw.br = t.l >= 4 ? (t.b === 'B' ? 'B' : 'A') : ''; tw.inv = t.inv | 0; tw.tm = t.tm | 0; tw.undo = 0; refreshTower(g, tw);
      });
      refreshBuffs(g);
    }
    g.ph = 'play';
    g.ev.push({ k: 'start', lv: g.lv, wave: g.wave });
  }
  /* 続きから遊ぶための記録（波の始めに作る） */
  function makeSave(g) {
    return { lv: g.lv, diff: g.diff, wave: g.wave, lives: g.lives, gold: g.slots.map(s => s.gold),
      towers: g.towers.map(t => ({ x: t.x, y: t.y, k: t.k, l: t.lvl, b: t.br, o: t.owner, inv: t.inv, tm: t.tm })) };
  }

  /* ---------- 塔 ---------- */
  /* 塔の種類か（スマホから届く値は、オブジェクトのキーで引く前に確かめる） */
  function isKind(k) { return typeof k === 'string' && TOWER_KINDS.includes(k); }
  function cellAt(g, x, y) { const L = g.level; if (!L || x < 0 || y < 0 || x >= L.cols || y >= L.rows) return 'x'; return L.cells[y * L.cols + x]; }
  function towerAt(g, x, y) { return g.towers.find(t => t.x === x && t.y === y) || null; }
  function canBuild(g, x, y) { const c = cellAt(g, x, y); return (c === '.' || c === 'h') && !towerAt(g, x, y); }
  function towerStats(t) { const T = TOWER[t.k]; return t.lvl <= 3 ? T.lv[t.lvl - 1] : T[t.br || 'A']; }
  function refreshTower(g, t) {
    const s = towerStats(t);
    t.st = Object.assign({}, s);
    if (t.st.rng) t.st.rng *= cellAt(g, t.x, t.y) === 'h' ? CFG.highRange : 1;
  }
  function refreshBuffs(g) {
    const trees = g.towers.filter(t => t.k === 'gold' && t.st.buff);
    for (const t of g.towers) {
      t.buff = 1;
      if (t.k === 'gold') continue;
      for (const b of trees) if (Math.hypot(b.x - t.x, b.y - t.y) <= b.st.buffR + 0.01) { t.buff = 1 + b.st.buff; break; }
    }
  }
  function placeTower(g, x, y, k, slot, free) {
    if (!isKind(k) || !canBuild(g, x, y)) return null;
    const t = { id: g.uid++, x, y, k, lvl: 1, br: '', owner: slot, inv: free ? 0 : TOWER[k].cost, cd: 0, yaw: Math.PI, tm: 0, stun: 0, undo: free ? 0 : CFG.undoSec, kills: 0, dmg: 0, buff: 1, fireN: 0, st: null };
    refreshTower(g, t);
    g.towers.push(t);
    return t;
  }
  function upgradeCost(t) { const T = TOWER[t.k]; if (t.lvl < 3) return T.up[t.lvl - 1]; if (t.lvl === 3) return T.br; return 0; }
  function sellValue(t) { return t.undo > 0 ? t.inv : Math.floor(t.inv * CFG.sellRate); }

  function say(g, slot, code) { const s = g.slots[slot]; if (!s) return; s.msg = code; s.msgSeq = g.msgSeq++; }

  /* スマホからの操作。結果をその人の財布の欄（msg）に残す */
  function command(g, id, a) {
    const p = g.pl[id]; if (!p || !a || typeof a !== 'object') return false;
    const s = g.slots[p.slot];
    if (g.ph !== 'play') return false;
    // 升の座標は、盤の中の整数だけを受ける
    const inBoard = Number.isInteger(a.x) && Number.isInteger(a.y) && a.x >= 0 && a.y >= 0 && a.x < CFG.cols && a.y < CFG.rows;
    const x = inBoard ? a.x : -1, y = inBoard ? a.y : -1;
    if (inBoard) { p.cx = x; p.cy = y; }
    switch (a.a) {
      case 'sel': return true;
      case 'build': {
        if (!isKind(a.k)) return false;
        const T = TOWER[a.k];
        if (!canBuild(g, x, y)) { say(g, p.slot, 'cant'); return false; }
        if (s.gold < T.cost) { say(g, p.slot, 'gold'); return false; }
        const t = placeTower(g, x, y, a.k, p.slot, false); if (!t) return false;
        s.gold -= T.cost; s.built++; s.spent += T.cost; refreshBuffs(g);
        g.ev.push({ k: 'build', x, y, tk: a.k, slot: p.slot, id: t.id });
        return true;
      }
      case 'up': {
        const t = towerAt(g, x, y); if (!t) return false;
        if (t.lvl >= 4) { say(g, p.slot, 'max'); return false; }
        const c = upgradeCost(t); if (s.gold < c) { say(g, p.slot, 'gold'); return false; }
        if (t.lvl === 3) { if (a.b !== 'A' && a.b !== 'B') return false; t.br = a.b; }
        s.gold -= c; s.spent += c; t.inv += c; t.lvl++; t.undo = 0; refreshTower(g, t); refreshBuffs(g);
        g.ev.push({ k: 'up', x, y, tk: t.k, lvl: t.lvl, br: t.br, slot: p.slot, id: t.id });
        return true;
      }
      case 'sell': {
        const t = towerAt(g, x, y); if (!t) return false;
        const owner = g.slots[t.owner];
        if (t.owner !== p.slot && owner && owner.active) { say(g, p.slot, 'notmine'); return false; }
        const v = sellValue(t); s.gold += v; if (t.undo > 0) s.spent -= v;
        g.towers.splice(g.towers.indexOf(t), 1); refreshBuffs(g);
        g.ev.push({ k: 'sell', x, y, tk: t.k, v, slot: p.slot, id: t.id });
        return true;
      }
      case 'tgt': { const t = towerAt(g, x, y); if (!t || t.k === 'gold') return false; t.tm = (t.tm + 1) % TARGET_MODES.length; g.ev.push({ k: 'tgt', id: t.id }); return true; }
      case 'skill': {
        if (s.skillCd > 0 || !inBoard) return false;
        s.skillCd = CFG.skillCd;
        g.meteors.push({ x: x + 0.5, y: y + 0.5, t: CFG.skillDelay, slot: p.slot, dmg: CFG.skillDmg * (1 + 0.09 * Math.max(0, g.wave - 1)) * (1 + 0.02 * (g.lv - 1)) });
        g.ev.push({ k: 'meteor', x: x + 0.5, y: y + 0.5, slot: p.slot, delay: CFG.skillDelay });
        return true;
      }
      case 'next': {
        if (g.wst !== 'break') return false;
        const bonus = Math.round(Math.max(0, g.breakT) * CFG.nextBonusPerSec);
        if (bonus > 0) for (const o of activeSlots(g)) { o.gold += bonus; o.earned += bonus; }
        g.breakT = 0; g.ev.push({ k: 'callnext', bonus, slot: p.slot });
        return true;
      }
      case 'gift': {
        const others = Object.values(g.pl).filter(q => q.slot !== p.slot).map(q => g.slots[q.slot]);
        if (!others.length || s.gold <= 0) return false;
        const to = others.reduce((a, b) => (b.gold < a.gold ? b : a));
        const v = Math.min(CFG.giftGold, s.gold); s.gold -= v; to.gold += v;
        const toSlot = g.slots.indexOf(to); say(g, toSlot, 'gifted');
        g.ev.push({ k: 'gift', from: p.slot, to: toSlot, v });
        return true;
      }
      case 'speed': g.speed = g.speed === 1 ? 2 : 1; g.ev.push({ k: 'speed', v: g.speed }); return true;
    }
    return false;
  }

  /* ---------- 波の進め方 ---------- */
  function startWave(g) {
    g.wave++;
    g.save = makeSave(g); g.save.wave = g.wave - 1;   // 続きからは、この波の前の準備から
    g.spec = waveSpec(g.lv, g.wave, playerCount(g), g.diff);
    g.queue = g.spec.list.map(e => Object.assign({}, e));
    g.wst = 'fight'; g.wt = 0;
    g.ev.push({ k: 'wave', n: g.wave, boss: g.spec.boss, theme: g.spec.theme });
  }
  function waveCleared(g) {
    const bonus = Math.round(CFG.waveBonus(g.wave) * (CFG.goldDiff[g.diff] || 1));
    for (const s of activeSlots(g)) { s.gold += bonus; s.earned += bonus; }
    for (const t of g.towers) if (t.k === 'gold') { const s = g.slots[t.owner]; if (s) { s.gold += t.st.inc; s.earned += t.st.inc; g.ev.push({ k: 'income', x: t.x, y: t.y, v: t.st.inc, slot: t.owner }); } }
    g.ev.push({ k: 'waveclear', n: g.wave, bonus });
    if (g.wave >= CFG.waves) { finish(g, 1); return; }
    g.wst = 'break'; g.breakT = CFG.breakSec;
  }
  function finish(g, win) {
    g.ph = 'over'; g.win = win;
    g.stars = win ? (g.lives >= g.maxLives * 0.9 ? 3 : g.lives >= g.maxLives * 0.5 ? 2 : 1) : 0;
    g.ev.push({ k: win ? 'win' : 'lose', stars: g.stars });
  }

  /* ---------- 敵 ---------- */
  function spawnEnemy(g, type, hp, spIdx, dist, from) {
    if (g.enemies.length >= CFG.maxEnemies) return null;
    const def = ENEMY[type], L = g.level;
    const si = spIdx % L.spawns.length;
    const path = def.fly ? L.flyPaths[si] : L.paths[si];
    const e = { id: g.uid++, type, hp, maxHp: hp, arm: def.arm, res: def.res, spd: def.spd, fly: !!def.fly, boss: !!def.boss, r: def.r,
      path: si, dist: dist || 0, seg: 0, x: 0, y: 0, dir: 0, slowT: 0, slow: 0, freezeT: 0, stunT: 0, dotT: 0, dot: 0, dotSlot: -1, shredT: 0, shred: 0,
      hitT: 0, shield: 0, abilT: 4, healT: 1, dead: false, leaked: false, born: g.t, wave: g.wave };
    posOn(path, e.dist, e);
    if (from) { e.x = from.x; e.y = from.y; }
    g.enemies.push(e);
    return e;
  }
  function pathOf(g, e) { return e.fly ? g.level.flyPaths[e.path] : g.level.paths[e.path]; }
  function remaining(g, e) { return pathOf(g, e).len - e.dist; }
  function hurt(g, e, amt, type, slot, tw) {
    if (e.dead || amt <= 0) return 0;
    if (e.shield > 0) { g.ev.push({ k: 'deflect', x: e.x, y: e.y }); return 0; }
    let m = 1;
    if (type === 'phys') m = 1 - Math.max(0, e.arm - e.shred);
    else if (type === 'magic') m = 1 - Math.max(0, e.res - e.shred);
    const d = Math.min(e.hp, amt * m);
    e.hp -= d; e.hitT = 0.12;
    const s = g.slots[slot]; if (s) s.dmg += d;
    if (tw) tw.dmg += d;
    if (e.hp <= 0.001) kill(g, e, slot, tw);
    return d;
  }
  function kill(g, e, slot, tw) {
    if (e.dead) return;
    e.dead = true; g.kills++;
    const def = ENEMY[e.type];
    const v = Math.max(1, Math.round(def.bounty * (1 + 0.035 * Math.max(0, e.wave - 1)) * (CFG.goldDiff[g.diff] || 1)));
    for (const s of activeSlots(g)) { s.gold += v; s.earned += v; }
    const s = g.slots[slot]; if (s) s.kills++;
    if (tw) tw.kills++;
    g.ev.push({ k: 'die', type: e.type, x: e.x, y: e.y, fly: e.fly, boss: e.boss, v, id: e.id });
    if (def.split) {
      for (let i = 0; i < def.splitN; i++) {
        const c = spawnEnemy(g, def.split, Math.max(1, Math.round(e.maxHp * 0.25)), e.path, Math.max(0, e.dist - 0.25 * i));
        if (c) c.wave = e.wave;
      }
      g.ev.push({ k: 'split', x: e.x, y: e.y });
    }
  }
  function stepEnemies(g, dt) {
    const L = g.level;
    for (const e of g.enemies) {
      if (e.dead) continue;
      e.hitT = Math.max(0, e.hitT - dt);
      if (e.slowT > 0) { e.slowT -= dt; if (e.slowT <= 0) e.slow = 0; }
      if (e.freezeT > 0) e.freezeT -= dt;
      if (e.stunT > 0) e.stunT -= dt;
      if (e.shredT > 0) { e.shredT -= dt; if (e.shredT <= 0) e.shred = 0; }
      if (e.shield > 0) e.shield -= dt;
      if (e.dotT > 0) { e.dotT -= dt; hurt(g, e, e.dot * dt, 'true', e.dotSlot, null); if (e.dead) continue; }
      const def = ENEMY[e.type];
      // 特技
      if (def.heal) {
        e.healT -= dt;
        if (e.healT <= 0) {
          e.healT = 1;
          let any = false;
          for (const o of g.enemies) if (!o.dead && o !== e && o.hp < o.maxHp && Math.abs(o.x - e.x) < 1.8 && Math.hypot(o.x - e.x, o.y - e.y) < 1.8) { o.hp = Math.min(o.maxHp, o.hp + o.maxHp * (o.boss ? 0.01 : def.heal)); any = true; }
          if (any) g.ev.push({ k: 'heal', x: e.x, y: e.y });
        }
      }
      if (def.abil) {
        e.abilT -= dt;
        if (e.abilT <= 0) {
          if (def.abil === 'summon') {
            e.abilT = 6;
            for (let i = 0; i < 3; i++) { const c = spawnEnemy(g, 'slime', Math.round(e.maxHp * 0.035), e.path, Math.max(0, e.dist - 0.4 - 0.3 * i)); if (c) c.wave = e.wave; }
            g.ev.push({ k: 'summon', x: e.x, y: e.y });
          } else if (def.abil === 'stomp') {
            e.abilT = 7;
            for (const t of g.towers) if (Math.hypot(t.x + 0.5 - e.x, t.y + 0.5 - e.y) < 2.6) t.stun = 3;
            g.ev.push({ k: 'stomp', x: e.x, y: e.y, r: 2.6 });
          } else if (def.abil === 'shield') {
            e.abilT = 8; e.shield = 2.5;
            for (let i = 0; i < 2; i++) { const c = spawnEnemy(g, 'bat', Math.round(e.maxHp * 0.02), e.path, 0); if (c) { c.wave = e.wave; c.x = e.x; c.y = e.y; c.dist = Math.min(L.flyPaths[c.path].len * 0.5, e.dist); } }
            g.ev.push({ k: 'shieldup', x: e.x, y: e.y });
          }
        }
      }
      const stopped = e.freezeT > 0 || e.stunT > 0;
      const sp = stopped ? 0 : e.spd * (1 - e.slow);
      e.dist += sp * dt;
      const path = pathOf(g, e);
      if (e.dist >= path.len) {
        e.dead = true; e.leaked = true;
        g.lives = Math.max(0, g.lives - def.leak); g.leaks += def.leak;
        g.ev.push({ k: 'leak', n: def.leak, type: e.type, boss: e.boss });
        continue;
      }
      posOn(path, e.dist, e);
    }
  }

  /* ---------- 塔が撃つ ---------- */
  function pickTarget(g, t) {
    const st = t.st, T = TOWER[t.k], cx = t.x + 0.5, cy = t.y + 0.5, r2 = st.rng * st.rng;
    let best = null, bv = Infinity;
    for (const e of g.enemies) {
      if (e.dead || (e.fly && !T.air)) continue;
      const dx = e.x - cx, dy = e.y - cy, d2 = dx * dx + dy * dy;
      if (d2 > r2) continue;
      let v;
      if (t.tm === 1) v = -e.hp; else if (t.tm === 2) v = d2; else v = remaining(g, e);
      if (v < bv) { bv = v; best = e; }
    }
    return best;
  }
  function applyHit(g, e, t, st, mult) {
    const T = TOWER[t.k];
    let dmg = (st.dmg || 0) * t.buff * (mult || 1);
    if (e.fly && T.airMul) dmg *= T.airMul;
    if (st.crit && g.rand() < st.crit) { dmg *= 2.5; g.ev.push({ k: 'crit', x: e.x, y: e.y }); }
    hurt(g, e, dmg, T.type, t.owner, t);
    if (e.dead) return;
    if (st.slow && st.slow >= e.slow) { e.slow = st.slow; e.slowT = st.slowT; }
    else if (st.slow) e.slowT = Math.max(e.slowT, st.slowT * 0.5);
    if (st.freeze && !e.boss && g.rand() < st.freeze) { e.freezeT = st.freezeT; g.ev.push({ k: 'freeze', x: e.x, y: e.y }); }
    if (st.stun) e.stunT = Math.max(e.stunT, e.boss ? st.stun * 0.3 : st.stun);
    if (st.dot) { const dps = st.dot * t.buff; if (dps >= e.dot || e.dotT <= 0) { e.dot = dps; e.dotSlot = t.owner; } e.dotT = st.dotT; }
    if (st.shred) { e.shred = Math.max(e.shred, st.shred); e.shredT = 3; }
  }
  function impact(g, s) {
    const t = g.towers.find(q => q.id === s.tw) || s.twRef;
    if (!t) return;
    if (s.splash) {
      const T = TOWER[t.k];
      for (const e of g.enemies) {
        if (e.dead || (e.fly && !T.air)) continue;
        const d = Math.hypot(e.x - s.x, e.y - s.y);
        if (d <= s.splash) applyHit(g, e, t, s.st, d < s.splash * 0.4 ? 1 : 0.65);
      }
      g.ev.push({ k: 'boom', x: s.x, y: s.y, r: s.splash, tk: t.k, br: t.br });
    } else {
      const e = g.enemies.find(q => q.id === s.target);
      if (e && !e.dead) applyHit(g, e, t, s.st, 1);
      g.ev.push({ k: 'hit', x: s.x, y: s.y, tk: t.k });
    }
  }
  function stepTowers(g, dt) {
    for (const t of g.towers) {
      if (t.undo > 0) t.undo -= dt;
      if (t.stun > 0) { t.stun -= dt; continue; }
      if (t.k === 'gold') continue;
      const st = t.st;
      if (st.aura) {
        t.cd -= dt;
        if (t.cd <= 0) {
          t.cd = 0.25;
          const cx = t.x + 0.5, cy = t.y + 0.5;
          let any = false;
          for (const e of g.enemies) {
            if (e.dead || Math.hypot(e.x - cx, e.y - cy) > st.rng) continue;
            any = true; e.slow = Math.max(e.slow, st.slow); e.slowT = Math.max(e.slowT, st.slowT);
            hurt(g, e, st.dps * 0.25 * t.buff, 'magic', t.owner, t);
          }
          t.active = any;
        }
        continue;
      }
      t.cd -= dt;
      if (t.cd > 0) continue;
      const e = pickTarget(g, t);
      if (!e) { t.cd = 0; continue; }
      t.yaw = Math.atan2(e.y - (t.y + 0.5), e.x - (t.x + 0.5));
      t.cd += 1 / st.rate; if (t.cd < 0) t.cd = 0;
      t.fireN++;
      const T = TOWER[t.k];
      if (T.shot === 'zap') {
        // かみなり：すぐ当たり、近くの敵へ飛び移る
        const pts = [[t.x + 0.5, t.y + 0.5]], hit = new Set();
        let cur = e, mult = 1;
        for (let i = 0; i < st.chain && cur; i++) {
          hit.add(cur.id); pts.push([cur.x, cur.y]);
          const cx = cur.x, cy = cur.y;
          applyHit(g, cur, t, st, mult); mult *= 0.85;
          let nx = null, nd = 1.7;
          for (const o of g.enemies) { if (o.dead || hit.has(o.id)) continue; const d = Math.hypot(o.x - cx, o.y - cy); if (d < nd) { nd = d; nx = o; } }
          cur = nx;
        }
        g.ev.push({ k: 'zap', pts, br: t.br, id: t.id });
      } else {
        const spd = T.shot === 'arrow' ? 13 : T.shot === 'ball' ? 7 : T.shot === 'shard' ? 10 : 8;
        g.shots.push({ id: g.uid++, kind: T.shot, tw: t.id, twRef: t, target: e.id, x: t.x + 0.5, y: t.y + 0.5, sx: t.x + 0.5, sy: t.y + 0.5, tx: e.x, ty: e.y, spd, st, splash: st.splash || 0, life: 0, br: t.br });
        g.ev.push({ k: 'shoot', tk: t.k, id: t.id, br: t.br });
      }
    }
  }
  function stepShots(g, dt) {
    for (const s of g.shots) {
      s.life += dt;
      const e = g.enemies.find(q => q.id === s.target);
      if (e && !e.dead) { s.tx = e.x; s.ty = e.y; }
      const dx = s.tx - s.x, dy = s.ty - s.y, d = Math.hypot(dx, dy), mv = s.spd * dt;
      if (d <= mv || s.life > 3) { s.x = s.tx; s.y = s.ty; s.done = true; impact(g, s); continue; }
      s.x += dx / d * mv; s.y += dy / d * mv;
    }
    g.shots = g.shots.filter(s => !s.done);
  }
  function stepMeteors(g, dt) {
    for (const m of g.meteors) {
      m.t -= dt;
      if (m.t > 0) continue;
      m.done = true;
      for (const e of g.enemies) {
        if (e.dead) continue;
        if (Math.hypot(e.x - m.x, e.y - m.y) <= CFG.skillR) { hurt(g, e, m.dmg * (e.boss ? 0.6 : 1), 'true', m.slot, null); if (!e.dead) e.stunT = Math.max(e.stunT, e.boss ? 0.3 : 1); }
      }
      g.ev.push({ k: 'meteorhit', x: m.x, y: m.y, r: CFG.skillR, slot: m.slot });
    }
    g.meteors = g.meteors.filter(m => !m.done);
  }

  /* 1 刻み進める */
  function step(g, dt) {
    if (!g.rand) g.rand = rng(g.seed + 99);
    if (g.ph !== 'play' || g.paused) return;
    g.t += dt;
    for (const s of g.slots) if (s.skillCd > 0) s.skillCd = Math.max(0, s.skillCd - dt);
    if (g.wst === 'break') {
      g.breakT -= dt;
      if (g.breakT <= 0) startWave(g);
    } else {
      g.wt += dt;
      while (g.queue.length && g.queue[0].at <= g.wt) {
        const q = g.queue.shift();
        const e = spawnEnemy(g, q.type, q.hp, q.sp, 0);
        if (e && e.boss) g.ev.push({ k: 'boss', type: e.type });
      }
    }
    stepMeteors(g, dt);
    stepEnemies(g, dt);
    stepTowers(g, dt);
    stepShots(g, dt);
    g.enemies = g.enemies.filter(e => !e.dead);
    if (g.lives <= 0) { finish(g, 0); return; }
    if (g.wst === 'fight' && !g.queue.length && !g.enemies.length) waveCleared(g);
  }
  function setPause(g, on) { if (g.ph !== 'play') return; g.paused = !!on; g.ev.push({ k: on ? 'pause' : 'resume' }); }

  /* スマホへ知らせる地図（1 升 1 文字）と塔（x,y,種類の番号,段,枝,持ち主,ねらい;…） */
  function mapString(g) { return g.level ? g.level.cells.join('') : ''; }
  function towerString(g) {
    return g.towers.map(t => [t.x, t.y, TOWER_KINDS.indexOf(t.k), t.lvl, t.br || '-', t.owner, t.tm, t.stun > 0 ? 1 : 0].join(',')).join(';');
  }
  function summary(g) {
    return { ph: g.ph, lv: g.lv, diff: g.diff, wave: g.wave, wst: g.wst, breakT: Math.round(g.breakT * 10) / 10, lives: g.lives, enemies: g.enemies.length, queue: g.queue.length,
      towers: g.towers.length, t: Math.round(g.t), win: g.win, stars: g.stars, kills: g.kills, players: playerCount(g),
      gold: g.slots.map(s => s.gold), biome: g.level ? g.level.biome.id : '' };
  }

  const api = { CFG, ENEMY, UNLOCK, ENEMY_NAME, TOWER, TOWER_KINDS, TOWER_NAME, BRANCH_NAME, TARGET_MODES, BIOMES,
    isKind, rng, tierOf, startGoldOf, genLevel, distField, posOn, waveSpec, hpScale, newGame, addPlayer, removePlayer, playerCount, activeSlots, startRun, makeSave,
    cellAt, towerAt, canBuild, towerStats, upgradeCost, sellValue, command, step, setPause, mapString, towerString, summary, pathOf, remaining };
  root.TdSim = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);

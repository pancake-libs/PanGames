/* おうちを守れ！戦車隊：育ち（v0.12、開発 3 回目）。計算だけ（画面なし。node でも動く）。
   - 一人ずつの記録（名前ごと）：コイン・部品・まもりの札・車種・装備・袋
   - 車種 4 つ（ふつう・はやい・どっしり・おたすけ）と必殺技
   - 装備（砲・車体・キャタピラ・おまもり）、希少さ 4 段、特別な効果、セット 8 種
   - 強化 +0〜+10（確率。JUN の指示：+7 から失敗で段が下がり、+10 に挑む時は 10% で壊れる。失敗するたび次は +5%。札で守れる）
   - 分解・合体、面のあとのルーレット、戦い中の宝箱の中身
   乱数は種を決めたもの（mulberry32）。tank-sim.js には「強さ（mods）」だけを渡す */
(function (root) {
  'use strict';
  // 装備の部位（v0.15：JUN さん「部位と種類を増やす」→ 砲塔・エンジンを足して 6 か所）
  const SLOTS = ['gun', 'turret', 'body', 'track', 'engine', 'charm'];
  const SLOT_NAME = { gun: ['砲', '炮'], turret: ['砲塔', '炮塔'], body: ['車体', '车身'], track: ['キャタピラ', '履带'], engine: ['エンジン', '引擎'], charm: ['おまもり', '护身符'] };
  // 色（希少さ）8 段（v0.16：JUN さん「無色・緑・青・紫・黄・赤・銀・金。銀と金はピカピカ」）。[名前, 中国語, 色, 光るか]
  const RARITY = [['無色', '无色', '#d5dde2', 0], ['緑', '绿', '#5fd36a', 0], ['青', '蓝', '#4fa8ff', 0], ['紫', '紫', '#c27bff', 0],
    ['黄', '黄', '#ffd23a', 0], ['赤', '红', '#ff4f45', 0], ['銀', '银', '#e8f2ff', 1], ['金', '金', '#ffc21a', 2]];
  const R_TOP = RARITY.length - 1;
  const RBASE = [1, 1.5, 2, 3, 4, 4.8, 5.6, 6.5];   // 色ごとの強さのもと（前の 4 段：ふつう 1・いい 2・すごい 3・でんせつ 4 と同じ所に並ぶ）
  const OLD_R = [0, 2, 3, 4];   // 前の記録（4 段）→ 新しい色：ふつう→無色・いい→青・すごい→紫・でんせつ→黄
  // 戦車のレベル（v0.16：JUN さん「戦車をレベルアップ」）。車ごとに Lv1〜30。戦うと経験値
  const CAR_MAX = 30;
  function xpNeed(lv) { return 30 + 12 * lv; }   // lv → lv+1 に要る経験値（Lv30 まで合計 約 6100）
  const MAX_LV = 10;
  // 車種。sprite＝焼いた絵の形（a〜d）。sp＝必殺技
  const CARS = {
    a: { ja: 'ふつう', zh: '普通', dja: 'なんでもできる（足と弾が少し速い）。必殺技はまわりの敵に爆撃', dzh: '样样都行（移动和炮弹稍快）。必杀技：轰炸周围的敌人', speed: 1.05, bullet: 1.08, armor: 0, inv: 0, sp: 'bomb' },
    b: { ja: 'はやい', zh: '快速', dja: '足と弾が速い。必殺技は 3 秒の急加速（無敵）', dzh: '移动和炮弹快。必杀技：3 秒冲刺（无敌）', speed: 1.18, bullet: 1.1, armor: 0, inv: 0, sp: 'dash' },
    c: { ja: 'どっしり', zh: '重型', dja: '遅いけれどかたい（よろい +1）。必殺技はみんなに盾', dzh: '慢但很硬（护甲 +1）。必杀技：全队护盾', speed: 0.88, bullet: 1, armor: 1, inv: 1, sp: 'wall' },
    d: { ja: 'おたすけ', zh: '支援', dja: '仲間を助ける。必殺技で仲間の台数 +1・おうちにおふとん', dzh: '帮助队友。必杀技：队友坦克 +1、小屋加被子', speed: 1, bullet: 1, armor: 0, inv: 0.5, sp: 'heal' }
  };
  const SP_NAME = { bomb: ['ばくげき！', '轰炸！'], dash: ['きゅうかそく！', '冲刺！'], wall: ['みんなに盾！', '全队护盾！'], heal: ['おたすけ！', '支援！'] };
  const SP_NEED = 8;   // 必殺技がたまるまでに倒す敵の数（ボスに当てると 0.5）
  /* ===== P3D-2 BEGIN：ボス戦車（アイデア No.2、JUN さん「収服最終首領、換乗首領坦克」）。5 つ目の車種。ワールドの さいごの ボス 6 体と 1 体ずつ なかよくなると、その ボスの戦車に のれる（v0.20）。
     boss＝ボスの絵（tank.html が ボスの絵を 味方の大きさに縮めて、その人の色の ふちどりを付ける）。強さは ほかの車と同じくらい（速さ・弾・よろい・無敵の合計を そろえた）。
     のれるかどうかは 家族で 1 つ（テレビの記録 'tank-p3d-story'）。act の bossOk が無ければ のりかえられない ===== */
  const P3D_BOSS_CARS = {
    kk: { boss: 'king', ja: '戦車の王', zh: '坦克之王', dja: 'おうさまの戦車。必殺技は まわり ぜんぶに 王の弾（じぶんに 盾）', dzh: '国王的坦克。必杀技：向四周发射王之弹（自己获得护盾）', speed: 1, bullet: 1.06, armor: 0, inv: 0.5, sp: 'royal' },
    kb: { boss: 'bigtank', ja: '大型戦車', zh: '大型坦克', dja: 'おそいけれど かたい（よろい +1）。必殺技は 鉄も こわす 大きな弾', dzh: '慢但很硬（护甲 +1）。必杀技：能打穿钢板的大炮弹', speed: 0.9, bullet: 1.04, armor: 1, inv: 0.5, sp: 'bigshot' },
    kw: { boss: 'sandship', ja: '砂上戦艦', zh: '沙上战舰', dja: '弾が はやい。必殺技は 前へ 3 本の はやい 砲弾（つらぬく）', dzh: '炮弹很快。必杀技：向前射出 3 发快速炮弹（可穿透）', speed: 0.95, bullet: 1.08, armor: 0, inv: 0.5, sp: 'broadside' },
    kn: { boss: 'snowman', ja: '雪だるま戦車', zh: '雪人坦克', dja: 'のんびり やさしい。必殺技は 敵を 少しの間 こおらせる', dzh: '慢悠悠又温柔。必杀技：把敌人冻住一小会儿', speed: 0.96, bullet: 1, armor: 0, inv: 1, sp: 'snow' },
    kd: { boss: 'dragon', ja: '火竜戦車', zh: '火龙坦克', dja: '弾が はやい。必殺技は 前へ 炎の いき', dzh: '炮弹很快。必杀技：向前喷出火焰', speed: 1.04, bullet: 1.1, armor: 0, inv: 0, sp: 'flame' },
    kc: { boss: 'core', ja: '要塞コア', zh: '要塞核心', dja: 'みんなを まもる。必殺技は 家族みんなに 少しの 盾（じぶんは 長め）', dzh: '守护大家。必杀技：给全家人一点护盾（自己更久）', speed: 0.98, bullet: 1.04, armor: 0, inv: 0.5, sp: 'guard' }
  };
  Object.assign(CARS, P3D_BOSS_CARS);
  Object.assign(SP_NAME, { royal: ['王のごうれい！', '王之号令！'], bigshot: ['どっかん砲！', '轰天大炮！'], broadside: ['いっせいほうげき！', '齐射！'], guard: ['まもりの ひかり！', '守护之光！'], snow: ['ゆきやこんこ！', '漫天飞雪！'], flame: ['ほのおの いき！', '火焰吐息！'] });
  const p3dIsBossCar = k => !!(CARS[k] && CARS[k].boss);
  // ボス戦車のレベルも 記録から読む（newProfile の cars は a〜d だけなので）
  function p3dCleanCars(o, p) { if (p && p.cars && typeof p.cars === 'object') for (const k in P3D_BOSS_CARS) { const c = p.cars[k]; if (c && typeof c === 'object') o.cars[k] = { lv: toInt(c.lv, 1, 30, 1), xp: toInt(c.xp, 0, 1e6, 0) }; } }
  /* ===== P3D-2 END ===== */
  // 特別な効果
  const FX = {
    bounce: { s: 'gun', ja: '弾が 1 回はね返る', zh: '炮弹反弹 1 次' },
    pierce: { s: 'gun', ja: 'レンガを 2 枚ぬく', zh: '连穿 2 块砖' },
    longInv: { s: 'body', ja: '出直した時の無敵が長い', zh: '复活无敌更久' },
    lifeUp: { s: 'body', ja: '面の始めに台数 +1', zh: '每关开始坦克 +1' },
    swift: { s: 'track', ja: 'さらに速い（+8%）', zh: '更快（+8%）' },
    grip: { s: 'track', ja: '氷・砂ですべらない・遅くならない', zh: '冰面沙地不打滑不减速' },
    coin: { s: 'charm', ja: 'コイン +20%', zh: '金币 +20%' },
    house: { s: 'charm', ja: 'おうちの自衛 +1', zh: '小屋自卫 +1' },
    charge: { s: 'charm', ja: '必殺技が早くたまる（+25%）', zh: '必杀技充能更快（+25%）' },
    // v0.15 で足した効果
    longShot: { s: 'gun', ja: '弾がもっと速い（+10%）', zh: '炮弹更快（+10%）' },
    power1: { s: 'turret', ja: '火力 +1', zh: '火力 +1' },
    heavy: { s: 'turret', ja: '弾の威力 +15%', zh: '炮弹威力 +15%' },
    thick: { s: 'body', ja: 'よろい +1', zh: '护甲 +1' },
    turbo: { s: 'engine', ja: '速さ +6%・必殺技 +10%', zh: '速度 +6%・必杀技 +10%' },
    quickSp: { s: 'engine', ja: '必殺技が早くたまる（+30%）', zh: '必杀技充能更快（+30%）' },
    luck: { s: 'charm', ja: 'コイン +10%・おうちにおふとん', zh: '金币 +10%・小屋加被子' }
  };
  const FX_BY_SLOT = {}; for (const k in FX) (FX_BY_SLOT[FX[k].s] = FX_BY_SLOT[FX[k].s] || []).push(k);
  // セット 8 種。from＝出る所（v0.13 で 草原・砂漠・雪山・火山・ボス・ルーレット の 6 つが出る）
  const WORLD_SET = ['wakaba', 'sand', 'silver', 'crimson', 'steel', 'abyss', 'thunder'];   // 7 番目＝ランダムの面（v0.15）   // 世界ごとに出やすいセット（v0.13：雪山＝白銀・火山＝紅蓮）
  const SETS = {
    wakaba: { ja: '若葉', zh: '若叶', col: '#7fe08f', from: 'w1', two: ['速さ +10%', '速度 +10%'], four: ['やられた時、近くの仲間に盾', '被击败时给附近队友护盾'] },
    sand: { ja: '砂嵐', zh: '沙暴', col: '#e8c27a', from: 'w2', two: ['弾の速さ +15%', '炮弹速度 +15%'], four: ['3 発ごとに壁をぬける弾', '每 3 发一颗穿墙弹'] },
    silver: { ja: '白銀', zh: '白银', col: '#cfe8ff', from: 'w3', two: ['よろい +1', '护甲 +1'], four: ['当てた敵が少し遅くなる', '命中的敌人减速'] },
    crimson: { ja: '紅蓮', zh: '红莲', col: '#ff7a5c', from: 'w4', two: ['火力 +1', '火力 +1'], four: ['倒した敵が爆発する', '击败的敌人会爆炸'] },
    steel: { ja: '鋼鉄', zh: '钢铁', col: '#9aa6b8', from: 'w5', two: ['おうちの自衛 +1', '小屋自卫 +1'], four: ['おうちにおふとん +1', '小屋加 1 床被子'] },
    king: { ja: '王者', zh: '王者', col: '#ffd23a', from: 'boss', two: ['必殺技のたまり +20%', '必杀技充能 +20%'], four: ['必殺技を 2 回ためられる', '必杀技可存 2 次'] },
    abyss: { ja: '深淵', zh: '深渊', col: '#b07aff', from: 'hell', two: ['弾の威力 +20%', '炮弹威力 +20%'], four: ['のこり 1 台の時、威力 2 倍', '剩 1 辆时威力翻倍'] },
    bond: { ja: 'きずな', zh: '羁绊', col: '#ff9ad5', from: 'wheel', two: ['コイン +10%', '金币 +10%'], four: ['仲間が近いほど強い', '队友越近越强'] },
    thunder: { ja: '雷光', zh: '雷光', col: '#7ff0ff', from: 'rand', two: ['速さ +5%・弾 +5%', '速度 +5%・弹速 +5%'], four: ['必殺技 +25%', '必杀技 +25%'] }
  };
  const ENH = [   // 強化：今の段 → 次の段の成功の確率と、失敗した時（JUN の指示 2026-11-15）
    null, [1, 'none'], [1, 'none'], [1, 'none'], [.9, 'lose'], [.8, 'lose'], [.7, 'lose'], [.6, 'down'], [.5, 'down'], [.4, 'down'], [.3, 'break']];
  const PITY_STEP = 0.05, BREAK_RATE = 0.10;
  function rng(seed) { let a = seed >>> 0 || 1; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const toInt = (v, lo, hi, d) => { const n = Math.floor(Number(v)); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : d; };

  /* ---------- 一人ずつの記録 ---------- */
  function newProfile(name) { return { name, rv: 2, cars: { a: { lv: 1, xp: 0 }, b: { lv: 1, xp: 0 }, c: { lv: 1, xp: 0 }, d: { lv: 1, xp: 0 } }, coins: 0, parts: 0, charms: 0, car: 'a', gear: { gun: 0, turret: 0, body: 0, track: 0, engine: 0, charm: 0 }, bag: [], nextId: 1, pity: 0, wheelDry: 0, seed: (Date.now() % 1e9) | 0, buff: null, stats: { enh: 0, broke: 0, chests: 0, spins: 0, gave: 0, got: 0, craft: 0 },
    driver: null, rec: { all: {}, wk: {}, wid: 0, boss: {}, x: {} }, ach: {}, title: '', skin: '', skins: [],
    bagMax: BAG_MAX, lab: 0 }; }   // P2-1/5/26/14/11（driver はテレビが参加の時に作る）。P9 v0.26：stats の gave・got・craft、bagMax・lab は保存しない その場の数（v26Apply が きちから入れる）
  function cleanItem(it) {
    if (!it || typeof it !== 'object' || !SLOTS.includes(it.s)) return null;
    return { id: toInt(it.id, 1, 1e9, 1), s: it.s, r: toInt(it.r, 0, R_TOP, 0), set: SETS[it.set] ? it.set : 'wakaba', lv: toInt(it.lv, 0, MAX_LV, 0), pi: toInt(it.pi, 0, 1e6, 0),
      fx: Array.isArray(it.fx) ? it.fx.filter(k => FX[k]).slice(0, 4) : [], lock: !!it.lock, ...(typeof it.from === 'string' && it.from ? { from: it.from.slice(0, 12) } : {}) };   // P9：ロック・もらった相手
  }
  function cleanProfile(p, name) {
    const o = newProfile(name); if (!p || typeof p !== 'object') return o;
    o.coins = toInt(p.coins, 0, 1e8, 0); o.parts = toInt(p.parts, 0, 1e7, 0); o.charms = toInt(p.charms, 0, 999, 0); o.car = CARS[p.car] ? p.car : 'a';
    o.bag = (Array.isArray(p.bag) ? p.bag : []).map(cleanItem).filter(Boolean).slice(0, 100);   // P9：そうこ Lv 5 の 100 こまで読む
    if (p.rv !== 2) for (const it of o.bag) it.r = OLD_R[Math.min(3, it.r)];   // 前の 4 段の記録を 8 色に読み替える（強さは同じ）
    if (p.cars && typeof p.cars === 'object') for (const k in o.cars) { const c = p.cars[k]; if (c) o.cars[k] = { lv: toInt(c.lv, 1, CAR_MAX, 1), xp: toInt(c.xp, 0, 1e6, 0) }; }
    o.nextId = Math.max(toInt(p.nextId, 1, 1e9, 1), ...o.bag.map(i => i.id + 1), 1);
    for (const s of SLOTS) { const id = p.gear && toInt(p.gear[s], 0, 1e9, 0); o.gear[s] = id && o.bag.some(i => i.id === id && i.s === s) ? id : 0; }
    o.pity = Math.max(0, Math.min(1, Number(p.pity) || 0)); o.wheelDry = toInt(p.wheelDry, 0, 99, 0); o.seed = toInt(p.seed, 1, 2e9, o.seed);
    o.buff = p.buff === 'shield' || p.buff === 'power' ? p.buff : null;
    o.seenAt = toInt(p.seenAt, 0, 1e14, 0);
    if (p.stats && typeof p.stats === 'object') for (const k in o.stats) o.stats[k] = toInt(p.stats[k], 0, 1e7, 0);
    cleanP2(o, p);   // P2-1/5/26/14/11：ドライバー・実績・称号・ランキングの数・スキン（前の記録に無ければ空のまま）
    p3dCleanCars(o, p);   // P3D-2：ボス戦車のレベル
    p4bKeepBk(o, p);   // P4B：ボスの装備の印・ボスちょうせんの ごほうびの記録
    return o;
  }
  function itemOf(pr, id) { return pr.bag.find(i => i.id === id) || null; }
  function equipped(pr) { const o = {}; for (const s of SLOTS) o[s] = pr.gear[s] ? itemOf(pr, pr.gear[s]) : null; return o; }
  function roll(pr) { const r = rng(pr.seed); const v = r(); pr.seed = (Math.floor(r() * 2e9) | 0) || 7; return v; }

  /* ---------- 装備を作る ---------- */
  function fxCount(r, lv) { return [0, 0, 0, 1, 2, 2, 3, 3][r] + (lv >= 5 ? 1 : 0) + (lv >= 10 ? 1 : 0); }
  function addFx(pr, it) { const pool = FX_BY_SLOT[it.s].filter(k => !it.fx.includes(k)); while (it.fx.length < fxCount(it.r, it.lv) && pool.length) it.fx.push(pool.splice(Math.floor(roll(pr) * pool.length), 1)[0]); }
  function makeItem(pr, opt) {
    const o = opt || {}; const s = SLOTS.includes(o.s) ? o.s : SLOTS[Math.floor(roll(pr) * SLOTS.length)];
    let r = o.r; if (r === undefined) { const v = roll(pr), w = o.rw || RW.base, sum = w.reduce((a, b) => a + b, 0); let acc = 0; r = 0; for (let i = 0; i < w.length; i++) { acc += w[i] / sum; if (v < acc) { r = i; break; } } }
    const it = { id: pr.nextId++, s, r, set: SETS[o.set] ? o.set : 'wakaba', lv: 0, pi: 0, fx: [] }; addFx(pr, it); pr.bag.push(it);
    // 持ち物は bagMaxOf まで。あふれたら、付けていない一番弱い物を部品にする（新しい物は残す。P9：ロック中は外す）
    if (pr.bag.length > bagMaxOf(pr)) { const used = Object.values(pr.gear), cand = pr.bag.filter(i => i !== it && !used.includes(i.id) && !i.bk && !i.lock).sort((x, y) => power(x) - power(y))[0]; if (cand) { pr.bag = pr.bag.filter(i => i !== cand); pr.parts += dismantleGain(cand); } }
    return it;
  }
  const BAG_MAX = 80;
  function bagMaxOf(pr) { return Math.max(BAG_MAX, Math.min(100, (pr && pr.bagMax) | 0)); }   // P9：そうこで 80 → 100
  // 色の出やすさ（無色・緑・青・紫・黄・赤・銀・金）。赤から上はめったに出ない。銀・金は主に合体とボスの金の宝箱
  const RW = { base: [38, 30, 18, 10, 4, 0, 0, 0], star3: [24, 30, 23, 15, 6, 2, 0, 0], wood: [70, 25, 5, 0, 0, 0, 0, 0],
    silver: [0, 0, 45, 35, 17, 3, 0, 0], gold: [0, 0, 0, 25, 45, 22, 6, 2] };
  // 装備の強さ（v＝1〜8）。希少さと段で上がる
  function power(it) { return RBASE[it.r] + it.lv * 0.4; }
  function itemStats(it) {
    const v = power(it);
    if (it.s === 'gun') return { bullet: 0.04 * v, power: Math.floor(v / 5) };
    if (it.s === 'body') return { armor: Math.floor(v / 4), inv: 0.3 * v };
    if (it.s === 'track') return { speed: 0.02 * v };
    if (it.s === 'turret') return { dmg: 0.025 * v, power: Math.floor(v / 7) };
    if (it.s === 'engine') return { speed: 0.012 * v, charge: 0.025 * v };
    return { coin: 0.05 * v, charge: 0.04 * v };
  }
  function statText(it, L) {
    const s = itemStats(it), t = [];
    if (s.bullet) t.push(L(`弾の速さ +${Math.round(s.bullet * 100)}%`, `弹速 +${Math.round(s.bullet * 100)}%`)); if (s.power) t.push(L(`火力 +${s.power}`, `火力 +${s.power}`));
    if (s.dmg) t.push(L(`弾の威力 +${Math.round(s.dmg * 100)}%`, `炮弹威力 +${Math.round(s.dmg * 100)}%`));
    if (s.armor) t.push(L(`よろい +${s.armor}`, `护甲 +${s.armor}`)); if (s.inv) t.push(L(`無敵 +${s.inv.toFixed(1)} 秒`, `无敌 +${s.inv.toFixed(1)} 秒`));
    if (s.speed) t.push(L(`速さ +${Math.round(s.speed * 100)}%`, `速度 +${Math.round(s.speed * 100)}%`));
    if (s.coin) t.push(L(`コイン +${Math.round(s.coin * 100)}%`, `金币 +${Math.round(s.coin * 100)}%`)); if (s.charge) t.push(L(`必殺技 +${Math.round(s.charge * 100)}%`, `必杀技 +${Math.round(s.charge * 100)}%`));
    for (const k of it.fx) t.push('★' + L(FX[k].ja, FX[k].zh));
    t.push(...p4bSigText(it, L));   // P4B
    return t;
  }
  function setCounts(pr) { const c = {}; for (const it of Object.values(equipped(pr))) if (it) c[it.set] = (c[it.set] || 0) + 1; return c; }

  /* ---------- 戦いに渡す強さ（上限つき。強くなりすぎないように） ---------- */
  const CAP = { speed: 1.34, bullet: 1.55, power: 2, armor: 2, inv: 3, coin: 1.8, charge: 1.7, dmgMul: 1.5 };
  function mods(pr) {
    const car = CARS[pr.car] || CARS.a, m = { car: pr.car, sp: car.sp, speed: car.speed, bullet: car.bullet, power: 0, armor: car.armor, inv: car.inv, coin: 1, charge: 1, dmgMul: 1,
      bounce: 0, pierce: 0, grip: false, lifeUp: 0, tower: 0, futon: 0, spMax: 1, set4: {}, buff: pr.buff };
    for (const it of Object.values(equipped(pr))) {
      if (!it) continue; const s = itemStats(it);
      m.bullet += s.bullet || 0; m.power += s.power || 0; m.dmgMul += s.dmg || 0; m.armor += s.armor || 0; m.inv += s.inv || 0; m.speed += s.speed || 0; m.coin += s.coin || 0; m.charge += s.charge || 0;
      for (const k of it.fx) { if (k === 'bounce') m.bounce = 1; else if (k === 'pierce') m.pierce = 1; else if (k === 'longInv') m.inv += 2; else if (k === 'lifeUp') m.lifeUp = 1;
        else if (k === 'swift') m.speed += 0.08; else if (k === 'grip') m.grip = true; else if (k === 'coin') m.coin += 0.2; else if (k === 'house') m.tower += 1; else if (k === 'charge') m.charge += 0.25;
        else if (k === 'longShot') m.bullet += 0.1; else if (k === 'power1') m.power += 1; else if (k === 'heavy') m.dmgMul += 0.15; else if (k === 'thick') m.armor += 1;
        else if (k === 'turbo') { m.speed += 0.06; m.charge += 0.1; } else if (k === 'quickSp') m.charge += 0.3; else if (k === 'luck') { m.coin += 0.1; m.futon += 1; } }
    }
    p4bAddMods(pr, m);   // P4B：ボスの装備の 決まった効果（上限の前）
    const sc = setCounts(pr);
    for (const k in sc) {
      if (sc[k] >= 2) { if (k === 'wakaba') m.speed += 0.1; else if (k === 'sand') m.bullet += 0.15; else if (k === 'silver') m.armor += 1; else if (k === 'crimson') m.power += 1;
        else if (k === 'steel') m.tower += 1; else if (k === 'king') m.charge += 0.2; else if (k === 'abyss') m.dmgMul += 0.2; else if (k === 'bond') m.coin += 0.1; else if (k === 'thunder') { m.speed += 0.05; m.bullet += 0.05; } }
      if (sc[k] >= 4) { m.set4[k] = 1; if (k === 'king') m.spMax = 2; if (k === 'steel') m.futon += 1; if (k === 'thunder') m.charge += 0.25; }
    }
    m.speed = Math.min(CAP.speed, m.speed); m.bullet = Math.min(CAP.bullet, m.bullet); m.power = Math.min(CAP.power, m.power); m.armor = Math.min(CAP.armor, m.armor);
    m.inv = Math.min(CAP.inv + 2, m.inv); m.coin = Math.min(CAP.coin, m.coin); m.charge = Math.min(CAP.charge, m.charge); m.tower = Math.min(2, m.tower); m.dmgMul = Math.min(CAP.dmgMul, m.dmgMul); m.futon = Math.min(2, m.futon);
    // 戦車のレベル：上限のあとに少しずつ足す（どんな装備でもレベルの分は強くなる）。Lv10・20・30 で必殺技が強くなる
    const lv = carLv(pr, pr.car), k = lv - 1; m.lv = lv; m.spLv = Math.floor(lv / 10);
    m.speed += 0.003 * k; m.bullet += 0.005 * k; m.dmgMul += 0.005 * k; m.inv += 0.03 * k; m.charge += 0.01 * k;
    // P2-1 BEGIN：ドライバーの力も、車のレベルと同じく上限のあとに少しだけ足す（bossDmg・team は tank-sim.js が使う）
    const db = driverBonus(pr); if (db) { m.bullet += db.bullet; m.speed += db.speed; m.inv += db.inv; m.charge += db.charge; m.bossDmg = 1 + db.bossDmg; m.team = db.team; m.luck = db.luck; m.dlv = pr.driver.lv; }
    // P2-1 END
    return m;
  }

  /* ---------- 戦車のレベル ---------- */
  function carLv(pr, car) { const c = pr.cars && pr.cars[car]; return c ? c.lv : 1; }
  function carInfo(pr, car) { const c = (pr.cars && pr.cars[car]) || { lv: 1, xp: 0 }; return { lv: c.lv, xp: c.xp, need: c.lv >= CAR_MAX ? 0 : xpNeed(c.lv), max: c.lv >= CAR_MAX }; }
  // 経験値を足す。上がったレベルの数を返す
  function addXp(pr, n, car) {
    const k = car || pr.car; if (!pr.cars) pr.cars = {}; const c = pr.cars[k] = pr.cars[k] || { lv: 1, xp: 0 }; let up = 0; if (c.lv >= CAR_MAX) return 0;
    c.xp += Math.max(0, Math.round(n)); while (c.lv < CAR_MAX && c.xp >= xpNeed(c.lv)) { c.xp -= xpNeed(c.lv); c.lv++; up++; } if (c.lv >= CAR_MAX) c.xp = 0; return up;
  }
  // 面のあとの経験値：倒した数 ×2、クリア 20＋星 ×5、ボス ×15（クリアしなくても倒した分は入る）
  function stageXp(kills, clear, stars, bossKills) { return kills * 2 + (clear ? 20 + 5 * (stars ? stars.reduce((a, b) => a + (b ? 1 : 0), 0) : 0) + 15 * (bossKills || 0) : 0); }

  /* ---------- ガレージの操作（スマホから。結果を返す） ---------- */
  function enhCost(it) { return { coins: Math.round(15 * (it.lv + 1) * RBASE[it.r]), parts: 2 * (it.lv + 1) }; }
  function enhInfo(pr, it) {
    if (!it || it.lv >= MAX_LV) return null; const [p0, fail] = ENH[it.lv + 1], rate = Math.min(1, p0 + (p0 < 1 ? pr.pity + luckOf(pr) + labOf(pr) : 0));   // P2-1：うん（最大 +3%）。P9：研究所（最大 +5%）
    return { to: it.lv + 1, rate, fail, breakRate: fail === 'break' ? BREAK_RATE : 0, cost: enhCost(it) };
  }
  function dismantleGain(it) { return Math.round(3 * RBASE[it.r]) + it.lv; }
  const labOf = pr => Math.max(0, Math.min(0.05, Number(pr && pr.lab) || 0));   // P9
  function act(pr, a) {
    const it = a.id ? itemOf(pr, toInt(a.id, 0, 1e9, 0)) : null;
    const p4 = p4bAct(pr, a, it); if (p4) return p4;   // P4B：ボスの装備は 分解・合体 できない
    if (a.op === 'car') { if (!CARS[a.car]) return { ok: false }; if (p3dIsBossCar(a.car) && !a.bossOk) return { ok: false, msg: 'lock' };   // P3D-2：ボス戦車は なかよくなってから
      pr.car = a.car; return { ok: true, msg: 'car' }; }
    if (a.op === 'equip') { if (!it) return { ok: false }; pr.gear[it.s] = pr.gear[it.s] === it.id ? 0 : it.id; return { ok: true, msg: pr.gear[it.s] ? 'equip' : 'unequip' }; }
    if (a.op === 'dismantle') { if (!it || Object.values(pr.gear).includes(it.id)) return { ok: false, msg: 'inuse' }; if (it.lock) return { ok: false, msg: 'lock' }; pr.bag = pr.bag.filter(i => i !== it); const g = dismantleGain(it); pr.parts += g; return { ok: true, msg: 'dismantle', parts: g }; }
    if (a.op === 'merge') {   // 同じ所・同じ希少さの装備 3 つ（付けていない物）→ 1 つ上の希少さ
      if (!it || it.r >= R_TOP) return { ok: false }; if (it.lock) return { ok: false, msg: 'lock' }; const same = pr.bag.filter(i => i.s === it.s && i.r === it.r && !Object.values(pr.gear).includes(i.id) && !i.bk && !i.lock);   // P9：ロック中は材料にしない
      if (same.length < 3) return { ok: false, msg: 'need3' }; const use = [it, ...same.filter(i => i !== it)].slice(0, 3); if (!use.includes(it) || Object.values(pr.gear).includes(it.id)) return { ok: false, msg: 'inuse' };
      const sets = {}; for (const u of use) sets[u.set] = (sets[u.set] || 0) + 1; const set = Object.keys(sets).sort((x, y) => sets[y] - sets[x])[0];
      pr.bag = pr.bag.filter(i => !use.includes(i)); const n = makeItem(pr, { s: it.s, r: it.r + 1, set }); return { ok: true, msg: 'merge', item: n.id };
    }
    if (a.op === 'enh') {
      const info = enhInfo(pr, it); if (!info) return { ok: false };
      if (pr.coins < info.cost.coins || pr.parts < info.cost.parts) return { ok: false, msg: 'poor' };
      const guard = !!a.guard && pr.charms > 0 && info.fail !== 'none' && info.fail !== 'lose';
      pr.coins -= info.cost.coins; pr.parts -= info.cost.parts; it.pi += info.cost.parts; if (guard) pr.charms--; pr.stats.enh++;
      if (roll(pr) < info.rate) { it.lv++; addFx(pr, it); pr.pity = 0; return { ok: true, msg: 'up', lv: it.lv }; }
      pr.pity = Math.min(0.5, pr.pity + PITY_STEP);
      if (guard) return { ok: true, msg: 'guarded', lv: it.lv };
      if (it.bk && info.fail === 'break') { if (roll(pr) < BREAK_RATE) { it.lv = 0; pr.stats.broke++; return { ok: true, msg: 'down', lv: 0 }; } it.lv = Math.max(0, it.lv - 1); return { ok: true, msg: 'down', lv: it.lv }; }   // P4B：ボスの装備は こわれない（+0 に なる）
      if (info.fail === 'break' && roll(pr) < BREAK_RATE) { for (const s of SLOTS) if (pr.gear[s] === it.id) pr.gear[s] = 0; pr.bag = pr.bag.filter(i => i !== it); const back = Math.floor(it.pi * 0.75) + dismantleGain(it); pr.parts += back;   /* P9：つぎこんだ分の 75%＋分解の数 */ pr.stats.broke++; return { ok: true, msg: 'broke', parts: back }; }
      if (info.fail === 'down' || info.fail === 'break') { it.lv = Math.max(0, it.lv - 1); return { ok: true, msg: 'down', lv: it.lv }; }
      return { ok: true, msg: 'fail', lv: it.lv };
    }
    const p9 = p9Act(pr, a, it); if (p9) return p9;   // P9 v0.26：ロック・まとめて分解・所ばらばらの合体・つくる
    return { ok: false };
  }

  /* ---------- 面のあとのルーレット ---------- */
  // 当たりの円。w＝割合（円の広さもこの割合）
  const WHEEL = [
    { k: 'coins', n: 30, w: 20, ja: 'コイン 30', zh: '金币 30', col: '#ffd23a' }, { k: 'gear', w: 12, ja: '装備', zh: '装备', col: '#c27bff' },
    { k: 'parts', n: 3, w: 16, ja: '部品 3', zh: '零件 3', col: '#8fd0ff' }, { k: 'coins', n: 60, w: 12, ja: 'コイン 60', zh: '金币 60', col: '#ffb53a' },
    { k: 'buff', b: 'shield', w: 8, ja: '次の面：たてで出発', zh: '下一关：带盾出发', col: '#7fe0ff' }, { k: 'charm', w: 7, ja: 'まもりの札', zh: '守护符', col: '#ff9ad5' },
    { k: 'parts', n: 6, w: 9, ja: '部品 6', zh: '零件 6', col: '#5fb8ff' }, { k: 'gear', w: 6, ja: '装備', zh: '装备', col: '#a46bff' },
    { k: 'buff', b: 'power', w: 6, ja: '次の面：火力 +1', zh: '下一关：火力 +1', col: '#ff8a5c' }, { k: 'coins', n: 200, w: 4, ja: 'コイン 200！', zh: '金币 200！', col: '#fff07a' }];
  const WHEEL_SUM = WHEEL.reduce((a, b) => a + b.w, 0);
  const WHEEL_PITY = 5;   // 5 回回して装備が出なければ、次は必ず装備
  function spin(pr, ctx) {   // ctx：{ world: 0/1, stars: 3 なら世界のセットが出やすい }
    let idx; const lk = luckOf(pr); if (pr.wheelDry >= WHEEL_PITY || (lk > 0 && roll(pr) < lk)) idx = WHEEL.findIndex(w => w.k === 'gear');   // P2-1：うん の分だけ装備が出やすい
    else { const v = roll(pr) * WHEEL_SUM; let acc = 0; idx = WHEEL.length - 1; for (let i = 0; i < WHEEL.length; i++) { acc += WHEEL[i].w; if (v < acc) { idx = i; break; } } }
    const w = WHEEL[idx], res = { idx, k: w.k, ja: w.ja, zh: w.zh }; pr.stats.spins++;
    if (w.k === 'gear') { pr.wheelDry = 0; const ws = WORLD_SET[(ctx && ctx.world) | 0] || 'wakaba', set = roll(pr) < 0.3 ? 'bond' : ws; const it = makeItem(pr, { set, rw: ctx && ctx.stars >= 3 ? RW.star3 : RW.base }); res.item = it.id; }
    else { pr.wheelDry++; if (w.k === 'coins') { const n = Math.round(w.n * mods(pr).coin); pr.coins += n; res.n = n; } else if (w.k === 'parts') { pr.parts += w.n; res.n = w.n; } else if (w.k === 'charm') pr.charms++; else if (w.k === 'buff') pr.buff = w.b; }
    return res;
  }
  function wheelSpins(stars) { return Math.min(4, 1 + (stars ? stars.reduce((a, b) => a + (b ? 1 : 0), 0) : 0)); }

  /* ---------- 宝箱の中身（拾った時） ---------- */
  const CHEST = { wood: { life: 10, col: '#b0763a' }, silver: { life: 12, col: '#cfd8e2' }, gold: { life: 15, col: '#ffd23a' } };
  function openChest(pr, kind, ctx) {
    const res = { kind }, m = mods(pr), ws = WORLD_SET[(ctx && ctx.world) | 0] || 'wakaba', lk = luckOf(pr); pr.stats.chests++;   // P2-1：lk＝うん
    if (kind === 'wood') { const v = roll(pr); if (v < 0.1 + lk) res.item = makeItem(pr, { set: ws, rw: RW.wood }).id; else if (v < 0.55) { res.parts = 1 + Math.floor(roll(pr) * 2); pr.parts += res.parts; } else { res.coins = Math.round((10 + Math.floor(roll(pr) * 16)) * m.coin); pr.coins += res.coins; } }
    else if (kind === 'silver') { res.coins = Math.round((30 + Math.floor(roll(pr) * 31)) * m.coin); pr.coins += res.coins; if (roll(pr) < 0.15) { pr.charms++; res.charm = 1; } if (roll(pr) < 0.45 + lk) res.item = makeItem(pr, { set: roll(pr) < 0.3 ? 'king' : ws, rw: RW.silver }).id; }
    else { res.item = makeItem(pr, { set: roll(pr) < 0.5 ? 'king' : ws, rw: RW.gold }).id; res.share = 50; }
    return res;
  }
  // 面のクリアのコイン（一人ずつ）
  function clearCoins(pr, stars) { const n = Math.round((20 + 10 * (stars ? stars.reduce((a, b) => a + b, 0) : 0)) * mods(pr).coin); pr.coins += n; return n; }

  /* ================= P2-1 BEGIN：ドライバー（JUN さん「戦車＋ドライバー 共同成長。いろいろな係数、はじめはランダム」） =================
     - 一人（名前）に一人。係数は 6 つ：ねらい・うんてん・がんじょう・うん・ゆうき・なかま
     - はじめはランダム。でも合計はみんな同じ 12（1 つは 1〜4）なので、だれも損をしない。ふりなおしは 1 回ただ、あとはコイン
     - 戦うと経験値（車と同じ stageXp）。Lv 1〜30。1 つ上がるたびに 1 点もらえて、好きな係数に足せる（足さなければ、次の面の始めに一番低い所へ）
     - なかよし度：ドライバーと車の組ごと。その車で遊んだ面の数。MAX で必殺技が少し早くたまる
     - 力はどれも小さい（車のレベルの半分くらい）。mods() で上限のあとに足す */
  const DRV = { STATS: ['aim', 'drive', 'armor', 'luck', 'courage', 'team'], FACES: 8, MAX_LV: 30, STAT_MAX: 15, BASE_SUM: 12, BASE_MIN: 1, BASE_MAX: 4, BOND_MAX: 30, BOND_STEP: 6, REROLL_COST: 150, LUCK_CAP: 0.03,
    // 1 点あたりの力
    PER: { aim: 0.005, drive: 0.003, armor: 0.04, luck: 0.002, courage: 0.01, team: 0.005 }, BOND_CHARGE: 0.05,
    INFO: {
      aim: { ic: '🎯', ja: 'ねらい', zh: '瞄准', dja: '弾が速くなる', dzh: '炮弹更快' },
      drive: { ic: '🚗', ja: 'うんてん', zh: '驾驶', dja: '足が速くなる', dzh: '移动更快' },
      armor: { ic: '🛡', ja: 'がんじょう', zh: '结实', dja: 'やられた後の無敵が長い', dzh: '被打后无敌更久' },
      luck: { ic: '🍀', ja: 'うん', zh: '运气', dja: '宝箱・ルーレット・強化が少し当たりやすい', dzh: '宝箱、转盘、强化稍微更容易成功' },
      courage: { ic: '🔥', ja: 'ゆうき', zh: '勇气', dja: 'ボスに強い', dzh: '对首领伤害更高' },
      team: { ic: '🤝', ja: 'なかま', zh: '伙伴', dja: '仲間かおうちの近くで強い', dzh: '在队友或小屋附近更强' } } };
  function driverBase(pr) {   // 合計 BASE_SUM、1 つは BASE_MIN〜BASE_MAX。全部 1 から始めて、残りを 1 点ずつ配る
    const n = DRV.STATS.length, b = new Array(n).fill(DRV.BASE_MIN); let left = DRV.BASE_SUM - n * DRV.BASE_MIN;
    while (left > 0) { const open = []; for (let i = 0; i < n; i++) if (b[i] < DRV.BASE_MAX) open.push(i); if (!open.length) break; b[open[Math.floor(roll(pr) * open.length)]]++; left--; }
    return b;
  }
  function driverNew(pr, face) {
    // 同じ瞬間に作った記録は種が同じになるので、名前をまぜる（同時に参加した人が同じドライバーにならないように）
    let h = 2166136261; for (const ch of String(pr.name || '')) h = Math.imul(h ^ ch.codePointAt(0), 16777619); pr.seed = (((pr.seed ^ h) >>> 0) % 2000000000) || 7;
    const f = Number.isInteger(face) ? toInt(face, 0, DRV.FACES - 1, 0) : Math.floor(roll(pr) * DRV.FACES);
    pr.driver = { f, b: driverBase(pr), a: [0, 0, 0, 0, 0, 0], lv: 1, xp: 0, pts: 0, rr: 0, bond: { a: 0, b: 0, c: 0, d: 0 } }; for (const k in P3D_BOSS_CARS) pr.driver.bond[k] = 0;   // P3D-2：ボス戦車の なかよし度
    return pr.driver;
  }
  function cleanDriver(d) {
    if (!d || typeof d !== 'object' || !Array.isArray(d.b) || d.b.length !== 6) return null;
    const b = d.b.map(v => toInt(v, DRV.BASE_MIN, DRV.BASE_MAX, DRV.BASE_MIN)); if (b.reduce((x, y) => x + y, 0) !== DRV.BASE_SUM) return null;   // 合計が合わない記録は作り直す（公平のため）
    const lv = toInt(d.lv, 1, DRV.MAX_LV, 1), a = [0, 1, 2, 3, 4, 5].map(i => toInt(d.a && d.a[i], 0, DRV.MAX_LV, 0)), bond = {};
    for (const k in CARS) bond[k] = toInt(d.bond && d.bond[k], 0, DRV.BOND_MAX, 0);
    let used = a.reduce((x, y) => x + y, 0); for (let i = 5; i >= 0 && used > lv - 1; i--) { const cut = Math.min(a[i], used - (lv - 1)); a[i] -= cut; used -= cut; }   // 足した点はレベルの分まで
    return { f: toInt(d.f, 0, DRV.FACES - 1, 0), b, a, lv, xp: toInt(d.xp, 0, 1e6, 0), pts: lv - 1 - used, rr: toInt(d.rr, 0, 9999, 0), bond };
  }
  function driverStat(pr, i) { const d = pr.driver; return d ? Math.min(DRV.STAT_MAX, d.b[i] + d.a[i]) : 0; }
  function driverStats(pr) { return DRV.STATS.map((_, i) => driverStat(pr, i)); }
  function driverInfo(pr) { const d = pr.driver; if (!d) return null; return { lv: d.lv, xp: d.xp, need: d.lv >= DRV.MAX_LV ? 0 : xpNeed(d.lv), max: d.lv >= DRV.MAX_LV, pts: d.pts }; }
  function bondInfo(pr, car) { const d = pr.driver, n = d ? d.bond[car || pr.car] | 0 : 0; return { n, hearts: Math.min(5, Math.floor(n / DRV.BOND_STEP)), max: n >= DRV.BOND_MAX }; }
  // 力（mods に足す分）
  function driverBonus(pr) {
    if (!pr || !pr.driver) return null; const s = driverStats(pr), P = DRV.PER;
    return { bullet: s[0] * P.aim, speed: s[1] * P.drive, inv: s[2] * P.armor, luck: Math.min(DRV.LUCK_CAP, s[3] * P.luck), bossDmg: s[4] * P.courage, team: s[5] * P.team, charge: bondInfo(pr).max ? DRV.BOND_CHARGE : 0 };
  }
  function luckOf(pr) { return pr && pr.driver ? Math.min(DRV.LUCK_CAP, driverStat(pr, 3) * DRV.PER.luck) : 0; }
  // 経験値。上がったレベルの数を返す（上がった分だけ pts が増える）
  function driverAddXp(pr, n) {
    const d = pr.driver; if (!d || d.lv >= DRV.MAX_LV) return 0; let up = 0; d.xp += Math.max(0, Math.round(n));
    while (d.lv < DRV.MAX_LV && d.xp >= xpNeed(d.lv)) { d.xp -= xpNeed(d.lv); d.lv++; d.pts++; up++; } if (d.lv >= DRV.MAX_LV) d.xp = 0; return up;
  }
  function driverSpend(pr, i) { const d = pr.driver; if (!d || d.pts <= 0 || !(i >= 0 && i < 6) || d.b[i] + d.a[i] >= DRV.STAT_MAX) return false; d.a[i]++; d.pts--; return true; }
  // えらばなかった点は、一番低い係数へ（同じなら上から）。入れた数を返す
  function driverAuto(pr) { const d = pr.driver; let n = 0; while (d && d.pts > 0) { let lo = -1; for (let i = 0; i < 6; i++) if (d.b[i] + d.a[i] < DRV.STAT_MAX && (lo < 0 || d.b[i] + d.a[i] < d.b[lo] + d.a[lo])) lo = i; if (lo < 0 || !driverSpend(pr, lo)) break; n++; } return n; }
  function rerollCost(pr) { return pr.driver && pr.driver.rr > 0 ? DRV.REROLL_COST : 0; }
  // なかよし度：その車で 1 面遊ぶごとに +1。MAX になった時だけ true を返す
  function bondAdd(pr, car) { const d = pr.driver, k = car || pr.car; if (!d || !CARS[k] || d.bond[k] >= DRV.BOND_MAX) return false; d.bond[k]++; return d.bond[k] >= DRV.BOND_MAX; }
  // スマホからの操作：係数に足す・ふりなおす・顔をかえる
  function driverAct(pr, a) {
    const d = pr.driver; if (!d) return { ok: false };
    if (a.op === 'stat') return driverSpend(pr, toInt(a.i, 0, 5, -1)) ? { ok: true, msg: 'stat' } : { ok: false, msg: 'ng' };
    if (a.op === 'face') { d.f = toInt(a.f, 0, DRV.FACES - 1, d.f); return { ok: true, msg: 'face' }; }
    if (a.op === 'reroll') { const cost = rerollCost(pr); if (pr.coins < cost) return { ok: false, msg: 'poor' }; pr.coins -= cost; d.b = driverBase(pr); d.rr++; return { ok: true, msg: 'reroll', cost }; }
    return { ok: false };
  }
  /* P2-5/26/14/11：実績・称号・ランキングの数・スキンは tank-book.js が中身を決める。ここは記録を安全に読むだけ */
  const numMap = (src, max) => { const o = {}; if (src && typeof src === 'object') for (const k of Object.keys(src).slice(0, max || 80)) { if (!/^[A-Za-z0-9_]{1,20}$/.test(k)) continue; const n = Number(src[k]); if (Number.isFinite(n) && n > 0) o[k] = Math.min(1e13, Math.floor(n)); } return o; };
  const idStr = v => (typeof v === 'string' && /^[A-Za-z0-9_]{1,20}$/.test(v) ? v : '');
  function cleanP2(o, p) {
    o.driver = cleanDriver(p.driver);
    const r = p.rec && typeof p.rec === 'object' ? p.rec : {};
    o.rec = { all: numMap(r.all), wk: numMap(r.wk), wid: toInt(r.wid, 0, 1e7, 0), boss: numMap(r.boss), x: numMap(r.x) };
    o.ach = numMap(p.ach, 120); o.title = idStr(p.title); o.skin = idStr(p.skin);
    o.skins = (Array.isArray(p.skins) ? p.skins : []).map(idStr).filter(Boolean).slice(0, 40);
  }
  /* ================= P2-1 END ================= */

  /* ===== P4B BEGIN（v0.21：ボスちょうせんの ボス装備 19 こ）=====
     - 1 人に 1 ボス 1 こ。部位と セットは きまっている（新しい セット・セットの 効果は 作らない）。item.bk＝ボスの名前
     - 強さの もとは ふつうの itemStats（色と +段）。ふつうの ランダム効果（赤 2・銀 3・金 3）＋ ボスの 決まった 効果（sig）が 1 つ
     - Lv10 で 赤（r5）、Lv18 で 銀（r6）、Lv20 で 金（r7）「でんせつ」。+段は そのまま。分解・合体は できない。強化の「こわれる」は +0 に なるだけ
     - 効果は ぜんぶ mods() の CAP の中（tank-sim.js の setMods も 同じ 上限で 受けとる）。p4b の 中身は 戦いの 中の 決まった効果（tank-sim.js が 使う） */
  const P4B_GEAR = {
    twin: { s: 'gun', set: 'wakaba', ja: 'ふたごの砲', zh: '双子炮', lja: 'でんせつの ふたご砲', lzh: '传说双子炮' },
    engineer: { s: 'body', set: 'wakaba', ja: 'こうへいの よろい', zh: '工兵装甲', lja: 'でんせつの こうへいよろい', lzh: '传说工兵装甲' },
    bigtank: { s: 'turret', set: 'wakaba', ja: 'どっしり砲塔', zh: '重型炮塔', lja: 'でんせつの どっしり砲塔', lzh: '传说重型炮塔' },
    burrower: { s: 'track', set: 'sand', ja: 'すなもぐりキャタピラ', zh: '钻沙履带', lja: 'でんせつの すなもぐり', lzh: '传说钻沙履带' },
    scorpion: { s: 'turret', set: 'sand', ja: 'さそりの しっぽ砲塔', zh: '蝎尾炮塔', lja: 'でんせつの さそり砲塔', lzh: '传说蝎尾炮塔' },
    sandship: { s: 'engine', set: 'sand', ja: 'せんかんエンジン', zh: '战舰引擎', lja: 'でんせつの せんかんエンジン', lzh: '传说战舰引擎' },
    plow: { s: 'track', set: 'silver', ja: 'じょせつキャタピラ', zh: '除雪履带', lja: 'でんせつの じょせつキャタピラ', lzh: '传说除雪履带' },
    icegun: { s: 'gun', set: 'silver', ja: 'こおりの砲', zh: '冰之炮', lja: 'でんせつの こおり砲', lzh: '传说冰之炮' },
    snowman: { s: 'charm', set: 'silver', ja: 'ゆきだるまの おまもり', zh: '雪人护符', lja: 'でんせつの ゆきだるま', lzh: '传说雪人护符' },
    flamer: { s: 'turret', set: 'crimson', ja: 'ほのおの砲塔', zh: '火焰炮塔', lja: 'でんせつの ほのお砲塔', lzh: '传说火焰炮塔' },
    golem: { s: 'body', set: 'crimson', ja: 'ようがんの よろい', zh: '熔岩装甲', lja: 'でんせつの ようがんよろい', lzh: '传说熔岩装甲' },
    dragon: { s: 'engine', set: 'crimson', ja: 'りゅうの しんぞう', zh: '火龙之心', lja: 'でんせつの りゅうのしんぞう', lzh: '传说火龙之心' },
    sis: { s: 'charm', set: 'steel', ja: 'ふたごの リボン', zh: '双子缎带', lja: 'でんせつの リボン', lzh: '传说缎带' },
    airship: { s: 'track', set: 'steel', ja: 'そらとぶキャタピラ', zh: '飞空履带', lja: 'でんせつの そらとぶキャタピラ', lzh: '传说飞空履带' },
    core: { s: 'body', set: 'steel', ja: 'コアの よろい', zh: '核心装甲', lja: 'でんせつの コアよろい', lzh: '传说核心装甲' },
    shadow: { s: 'charm', set: 'abyss', ja: 'かげの おまもり', zh: '影之护符', lja: 'でんせつの かげ', lzh: '传说影之护符' },
    superstar: { s: 'engine', set: 'abyss', ja: 'スターエンジン', zh: '明星引擎', lja: 'でんせつの スターエンジン', lzh: '传说明星引擎' },
    king: { s: 'gun', set: 'abyss', ja: 'おうの砲', zh: '王之炮', lja: 'でんせつの おうの砲', lzh: '传说王之炮' },
    gold: { s: 'charm', set: 'king', ja: 'きんぴかの おまもり', zh: '黄金护符', lja: 'でんせつの きんぴか', lzh: '传说黄金护符' }
  };
  // ボスの 決まった効果。[赤・銀, 金（でんせつ）]。数は mods の 名前（speed・bullet・dmgMul・power・armor・inv・coin・charge・tower・futon・grip・pierce）と、戦いの中の p4b の 名前
  //   p4b：twin＝面の始めに 2 れんしゃ、ice＝n 発ごとに こおらせる弾、sh＝面の始めの 盾（秒）、free＝1 面に 1 回 やられても へらない（fi＝その後の 無敵 秒）、lava＝溶岩で あつくなるまで +秒、mate＝仲間が 4 升の中で 必殺 +割合
  const P4B_SIG = {
    twin: [{ p4b: { twin: 1 } }, { p4b: { twin: 1 }, bullet: 0.05 }],
    engineer: [{ futon: 1 }, { futon: 1, inv: 1 }],
    bigtank: [{ dmgMul: 0.08 }, { dmgMul: 0.12 }],
    burrower: [{ grip: 1, speed: 0.03 }, { grip: 1, speed: 0.05 }],
    scorpion: [{ pierce: 1 }, { pierce: 1, dmgMul: 0.06 }],
    sandship: [{ charge: 0.12 }, { charge: 0.18, speed: 0.03 }],
    plow: [{ speed: 0.05, inv: 0.5 }, { speed: 0.07, inv: 1 }],
    icegun: [{ p4b: { ice: 6 } }, { p4b: { ice: 5 } }],
    snowman: [{ inv: 1.5 }, { inv: 2, futon: 1 }],
    flamer: [{ power: 1 }, { power: 1, dmgMul: 0.05 }],
    golem: [{ armor: 1 }, { armor: 1, p4b: { lava: 2 } }],
    dragon: [{ charge: 0.15 }, { charge: 0.2, bullet: 0.05 }],
    sis: [{ coin: 0.1, p4b: { mate: 0.1 } }, { coin: 0.15, p4b: { mate: 0.15 } }],
    airship: [{ speed: 0.06 }, { speed: 0.08, grip: 1 }],
    core: [{ tower: 1 }, { tower: 1, p4b: { sh: 3 } }],
    shadow: [{ p4b: { free: 1 } }, { p4b: { free: 1, fi: 2 } }],
    superstar: [{ charge: 0.15, coin: 0.1 }, { charge: 0.2, coin: 0.15 }],
    king: [{ bullet: 0.08, dmgMul: 0.08 }, { bullet: 0.1, dmgMul: 0.12 }],
    gold: [{ coin: 0.2 }, { coin: 0.25, p4b: { gold: 0.05 } }]
  };
  const p4bLegend = it => !!(it && it.bk && it.r >= R_TOP);
  function p4bSigOf(it) { const s = it && it.bk && P4B_SIG[it.bk]; return s ? s[p4bLegend(it) ? 1 : 0] : null; }
  // mods に 足す（上限を かける前）。p4b は 戦いの中の 効果（1 つずつ 一番 大きい 値）
  function p4bAddMods(pr, m) {
    for (const it of Object.values(equipped(pr))) {
      const sg = p4bSigOf(it); if (!sg) continue;
      for (const k in sg) { if (k === 'p4b') { m.p4b = m.p4b || {}; for (const q in sg.p4b) m.p4b[q] = q === 'ice' ? Math.min(m.p4b.ice || 99, sg.p4b.ice) : Math.max(m.p4b[q] || 0, sg.p4b[q]); }
        else if (k === 'grip') m.grip = true; else if (k === 'pierce') m.pierce = 1; else m[k] = (m[k] || 0) + sg[k]; }
    }
  }
  function p4bSigText(it, L) {
    const sg = p4bSigOf(it); if (!sg) return []; const t = [], pc = v => Math.round(v * 100), p = sg.p4b || {};
    if (p.twin) t.push(L('面の始めに 2 れんしゃ', '每关开始双炮'));
    if (p.ice) t.push(L(`${p.ice} 発ごとに こおらせる弾`, `每 ${p.ice} 发冻结弹`));
    if (p.sh) t.push(L(`面の始めに 盾 ${p.sh} 秒`, `每关开始护盾 ${p.sh} 秒`));
    if (p.free) t.push(L('1 面に 1 回、やられても 台数が へらない', '每关 1 次被击败不减坦克') + (p.fi ? L(`（そのあと 無敵 ${p.fi} 秒）`, `（之后无敌 ${p.fi} 秒）`) : ''));
    if (p.lava) t.push(L(`溶岩で あつくなるまで +${p.lava} 秒`, `熔岩烫伤慢 ${p.lava} 秒`));
    if (p.mate) t.push(L(`仲間が近いと 必殺 +${pc(p.mate)}%`, `队友在附近时必杀 +${pc(p.mate)}%`));
    if (p.gold) t.push(L('金の宝箱が 少し 出やすい', '金宝箱稍微更容易出'));
    if (sg.speed) t.push(L(`速さ +${pc(sg.speed)}%`, `速度 +${pc(sg.speed)}%`)); if (sg.bullet) t.push(L(`弾の速さ +${pc(sg.bullet)}%`, `弹速 +${pc(sg.bullet)}%`));
    if (sg.dmgMul) t.push(L(`弾の威力 +${pc(sg.dmgMul)}%`, `炮弹威力 +${pc(sg.dmgMul)}%`)); if (sg.power) t.push(L(`火力 +${sg.power}`, `火力 +${sg.power}`)); if (sg.armor) t.push(L(`よろい +${sg.armor}`, `护甲 +${sg.armor}`));
    if (sg.inv) t.push(L(`出直しの無敵 +${sg.inv} 秒`, `复活无敌 +${sg.inv} 秒`)); if (sg.coin) t.push(L(`コイン +${pc(sg.coin)}%`, `金币 +${pc(sg.coin)}%`)); if (sg.charge) t.push(L(`必殺技 +${pc(sg.charge)}%`, `必杀技 +${pc(sg.charge)}%`));
    if (sg.tower) t.push(L(`おうちの自衛 +${sg.tower}`, `小屋自卫 +${sg.tower}`)); if (sg.futon) t.push(L(`おうちに おふとん +${sg.futon}`, `小屋被子 +${sg.futon}`));
    if (sg.grip) t.push(L('氷・砂で すべらない', '冰面沙地不打滑')); if (sg.pierce) t.push(L('レンガを 2 枚ぬく', '连穿 2 块砖'));
    return t.map(x => '👑' + x);
  }
  // ボスの 装備を あげる（無ければ 作る。あれば 色を 上げる。+段は そのまま）。返すのは その装備
  function p4bGive(pr, boss, r) {
    const G0 = P4B_GEAR[boss]; if (!G0) return null; r = toInt(r, 5, R_TOP, 5);
    let it = pr.bag.find(i => i.bk === boss);
    if (!it) { it = { id: pr.nextId++, s: G0.s, r, set: G0.set, lv: 0, pi: 0, fx: [], bk: boss }; addFx(pr, it); pr.bag.push(it); }
    else if (it.r < r) { it.r = r; addFx(pr, it); }
    return it;
  }
  // 記録を読む時：ボスの印（bk）を のこす（cleanItem の あと。ボス 1 体に 1 こ）
  function p4bKeepBk(o, p) {
    const src = Array.isArray(p.bag) ? p.bag : [], seen = {};
    for (const it of o.bag) { const s = src.find(x => x && toInt(x.id, 1, 1e9, 0) === it.id), k = s && typeof s.bk === 'string' && P4B_GEAR[s.bk] ? s.bk : ''; if (k && !seen[k] && it.s === P4B_GEAR[k].s) { it.bk = k; seen[k] = 1; } }
    const q = p.p4b && typeof p.p4b === 'object' ? p.p4b : {}, got = {}, id = v => (typeof v === 'string' && /^[a-z]{2,10}$/.test(v) ? v : '');
    if (q.got && typeof q.got === 'object') for (const k of Object.keys(q.got).slice(0, 30)) if (P4B_GEAR[k]) { const n = toInt(q.got[k], 0, 20, 0); if (n) got[k] = n; }
    o.p4b = { got, sticker: id(q.sticker), flag: id(q.flag), trail: id(q.trail) };
  }
  // 分解・合体は できない（ボスの 装備を えらんだ時）
  function p4bAct(pr, a, it) { if (it && it.bk && (a.op === 'dismantle' || a.op === 'merge')) return { ok: false, msg: 'bk' }; return null; }
  /* ===== P4B END ===== */

  /* ===== P9 BEGIN（v0.26：おくる・こうかん（37）・まとめて分解と つくる（38）・家族の きち（10）。設計 v026-design.md §1.1・§2.1・§3.1）=====
     - コインを生む物は足さない。足すのは 使う所（つくる・きち・花火）と 家族の中で動かす道（おくる・こうかん）だけ
     - ボスの装備（bk。でんせつ も）・付けている物・ロック中の物は おくれない。銀・金は 今までどおり 同じ所の合体と 金の宝箱だけ */
  // つくる：札 1 つ・ふつう（緑〜黄）・じょうとう（青〜赤）。rw＝色の出やすさ（無色・銀・金は 0）
  const CRAFT = {
    charm: { parts: 12, coins: 60 },
    gear: { parts: 20, coins: 100, rw: [0, 45, 35, 15, 5, 0, 0, 0] },
    fine: { parts: 60, coins: 300, rw: [0, 0, 30, 40, 22, 8, 0, 0] } };
  const MERGE_ANY_R = 4;   // 所ばらばらの合体は 黄まで（できる物は 赤まで）
  const CRAFT_NO_SET = ['king'];   // 王者セットは つくれない（出やすさは 今のまま＝金の宝箱・ボスちょうせん）
  // つくれるセット＝今 持ち物に 1 つでも有るセット（見本）。SETS の順
  function craftSets(pr) { const has = {}; for (const i of pr.bag) has[i.set] = 1; return Object.keys(SETS).filter(k => has[k] && !CRAFT_NO_SET.includes(k)); }
  // まとめて分解の候補：r 以下（0〜2＝無色まで／緑まで／青まで）・+0・付けていない・ボスでない・ロックでない
  function dismantleAllInfo(pr, r) {
    const top = toInt(r, 0, 2, 0), used = Object.values(pr.gear), L = pr.bag.filter(i => i.r <= top && i.lv === 0 && !used.includes(i.id) && !i.bk && !i.lock);
    return { n: L.length, parts: L.reduce((a, i) => a + dismantleGain(i), 0), ids: L.map(i => i.id) };
  }
  function p9Act(pr, a, it) {
    if (a.op === 'lock') { if (!it) return { ok: false }; it.lock = !it.lock; return { ok: true, msg: it.lock ? 'locked' : 'unlocked' }; }   // ボスの装備にも付けられる
    if (a.op === 'dismantleAll') { const d = dismantleAllInfo(pr, a.r); if (!d.n) return { ok: false, msg: 'none' };
      pr.bag = pr.bag.filter(i => !d.ids.includes(i.id)); pr.parts += d.parts; return { ok: true, msg: 'dismantleAll', n: d.n, parts: d.parts }; }
    if (a.op === 'mergeAny') {   // 同じ色 3 つ（所は ばらばら）→ 色 +1・所は roll で 6 つから・セットは多い方
      const ids = Array.isArray(a.ids) && a.ids.length === 3 ? a.ids.map(v => toInt(v, 0, 1e9, 0)) : [], use = ids.map(id => itemOf(pr, id)).filter(Boolean), used = Object.values(pr.gear);
      if (use.length !== 3 || new Set(use).size !== 3) return { ok: false, msg: 'need3' };
      if (use.some(i => i.bk)) return { ok: false, msg: 'bk' }; if (use.some(i => i.lock)) return { ok: false, msg: 'lock' }; if (use.some(i => used.includes(i.id))) return { ok: false, msg: 'inuse' };
      const r = use[0].r; if (use.some(i => i.r !== r)) return { ok: false, msg: 'mix' }; if (r > MERGE_ANY_R) return { ok: false, msg: 'top' };
      const sets = {}; for (const u of use) sets[u.set] = (sets[u.set] || 0) + 1; const set = Object.keys(sets).sort((x, y) => sets[y] - sets[x])[0];
      pr.bag = pr.bag.filter(i => !use.includes(i)); const n = makeItem(pr, { r: r + 1, set }); return { ok: true, msg: 'mergeAny', item: n.id };
    }
    if (a.op === 'craft') {   // { what: 'charm'｜'gear'｜'fine', s, set }
      const w = String(a.what || ''), c = Object.keys(CRAFT).includes(w) ? CRAFT[w] : null; if (!c) return { ok: false };
      if (w === 'charm') { if (pr.charms >= 999) return { ok: false, msg: 'full' }; }
      else { if (!SLOTS.includes(a.s)) return { ok: false, msg: 'slot' }; if (!craftSets(pr).includes(a.set)) return { ok: false, msg: 'noset' }; if (pr.bag.length >= bagMaxOf(pr)) return { ok: false, msg: 'full' }; }
      if (pr.parts < c.parts || pr.coins < c.coins) return { ok: false, msg: 'poor' };
      pr.parts -= c.parts; pr.coins -= c.coins; bump(pr, 'craft');
      if (w === 'charm') { pr.charms++; return { ok: true, msg: 'craft', what: w }; }
      const n = makeItem(pr, { s: a.s, set: a.set, rw: c.rw }); return { ok: true, msg: 'craft', what: w, item: n.id };
    }
    return null;
  }

  // おくる・こうかん。上限（CAP）は テレビが 集まりごとに見る（V26.sent。保存しない）
  const GIFT = { COINS: [10, 50, 100], PARTS: [5, 20], CAP: { coins: 500, parts: 100, charm: 3 }, MSG: 6, LOG: 20, K: ['coins', 'parts', 'charm', 'gear', 'swap'],
    WORDS: [['いつも ありがとう！', '一直谢谢你！'], ['つかってね！', '拿去用吧！'], ['がんばったね！', '你真努力！'], ['だいすき！', '最喜欢你！'], ['おそろいに しよう！', '我们凑一套吧！'], ['また いっしょに あそぼう！', '下次还一起玩！']] };
  const HOLD = { coins: 1e8, parts: 1e7, charms: 999 };   // さいふの上限（cleanProfile と同じ）
  const okName = v => { const t = typeof v === 'string' ? v.slice(0, 12) : ''; return t && !(t in {}) ? t : ''; };   // 名前（12 文字まで。__proto__ などは外す）
  // おくれるか：'' なら おくれる。none＝無い・inuse＝付けている・bk＝ボスの装備・lock＝ロック中
  function giftOk(pr, it) { return !it ? 'none' : Object.values(pr.gear).includes(it.id) ? 'inuse' : it.bk ? 'bk' : it.lock ? 'lock' : ''; }
  const bump = (pr, k) => { pr.stats = pr.stats || {}; pr.stats[k] = (pr.stats[k] | 0) + 1; };   // 回数（前の版の記録でも NaN に しない）
  const giftCopy = (it, to, from) => Object.assign({}, it, { id: to.nextId++, fx: it.fx.slice(), from: okName(from.name), lock: false });   // 段・効果・セット・pi は そのまま
  function give(from, to, a) {   // a＝{ k: 'coins'｜'parts'｜'charm'｜'gear', n, id }。返す：{ ok, msg, k, n, item }
    if (!from || !to || from === to || !a) return { ok: false, msg: 'same' };
    if (a.k === 'gear') { const it = itemOf(from, toInt(a.id, 0, 1e9, 0)), why = giftOk(from, it); if (why) return { ok: false, msg: why };
      if (to.bag.length >= bagMaxOf(to)) return { ok: false, msg: 'full' };
      from.bag = from.bag.filter(i => i !== it); const n = giftCopy(it, to, from); to.bag.push(n);
      bump(from, 'gave'); bump(to, 'got'); return { ok: true, msg: 'gift', k: 'gear', item: n.id }; }
    const key = a.k === 'coins' ? 'coins' : a.k === 'parts' ? 'parts' : a.k === 'charm' ? 'charms' : '', n = Math.floor(Number(a.n));
    if (!key || !(n >= 1 && n <= 500)) return { ok: false, msg: 'ng' }; if (from[key] < n) return { ok: false, msg: 'poor' }; if (to[key] + n > HOLD[key]) return { ok: false, msg: 'full' };
    from[key] -= n; to[key] += n; bump(from, 'gave'); bump(to, 'got'); return { ok: true, msg: 'gift', k: a.k, n };
  }
  // こうかん：どちらも giftOk で 同時に入れかえる（数は変わらないので いっぱいでも できる）。片方でも だめなら 何も動かさない
  function swap(pa, pb, idA, idB) {
    if (!pa || !pb || pa === pb) return { ok: false, msg: 'same' };
    const x = itemOf(pa, toInt(idA, 0, 1e9, 0)), y = itemOf(pb, toInt(idB, 0, 1e9, 0)), w = giftOk(pa, x) || giftOk(pb, y); if (w) return { ok: false, msg: w };
    pa.bag = pa.bag.filter(i => i !== x); pb.bag = pb.bag.filter(i => i !== y);
    const nx = giftCopy(x, pb, pa), ny = giftCopy(y, pa, pb); pb.bag.push(nx); pa.bag.push(ny);
    bump(pa, 'gave'); bump(pb, 'gave'); bump(pa, 'got'); bump(pb, 'got'); return { ok: true, msg: 'swap', a: ny.id, b: nx.id };   // a＝pa が もらった物の id・b＝pb が もらった物の id
  }
  // おくりものの記録 'tank-v26-gifts'：{ v: 1, log: [ { at, from, to, k, n, name, m } ] }（新しい順に 20 まで）。m＝ひとこと 0〜5（-1＝なし）
  function giftRow(r) {
    if (!r || typeof r !== 'object' || !GIFT.K.includes(r.k)) return null; const from = okName(r.from), to = okName(r.to); if (!from || !to) return null;
    return { at: toInt(r.at, 0, 1e13, 0), from, to, k: r.k, n: toInt(r.n, 0, 1e8, 0), name: typeof r.name === 'string' ? r.name.slice(0, 40) : '', m: toInt(r.m, -1, GIFT.MSG - 1, -1) };
  }
  function cleanGifts(o) { const src = o && typeof o === 'object' && Array.isArray(o.log) ? o.log : []; return { v: 1, log: src.map(giftRow).filter(Boolean).slice(0, GIFT.LOG) }; }
  function giftNote(o, row) { const r = giftRow(row); if (r) { o.log.unshift(r); if (o.log.length > GIFT.LOG) o.log.length = GIFT.LOG; } return o; }   // 1 行 足す（o は cleanGifts の形）

  // 家族の きち（家族で 1 つ。'tank-v26-base'）。ねだんは どの建物も同じ（1 つ 5,000・6 つで 30,000）
  // COST＝設計の [200, 400, 700, 1100, 1600] の 1.25 倍（§4.3 の もしもの決まりを 1 回。v026-check 6 で Lv が高すぎた：装備のコインの上乗せで 収入が 一人 約 200）
  const BASE = { COST: [250, 500, 875, 1375, 2000], MAX: 5, FW: 300, ORDER: ['repair', 'lab', 'store', 'watch', 'gym', 'hall'],
    F: { repair: { ic: '🔧', ja: 'しゅうり工場', zh: '修理厂', t: [['やり直しで いのち +1', '重来时生命 +1'], ['塔の のぼりなおし +1 回', '爬塔重来 +1 次'], ['やり直しで よろい 1', '重来时护甲 1'], ['やり直しで いのち +2', '重来时生命 +2'], ['やり直しで おふとん +1', '重来时被子 +1']] },
      lab: { ic: '🔬', ja: '研究所', zh: '研究所', t: [1, 2, 3, 4, 5].map(n => [`強化の成功 +${n}%`, `强化成功率 +${n}%`]) },
      store: { ic: '📦', ja: 'そうこ', zh: '仓库', t: [1, 2, 3, 4, 5].map(n => [`持ち物 ${80 + 4 * n}`, `背包 ${80 + 4 * n}`]) },
      watch: { ic: '🔭', ja: '見はり台', zh: '瞭望塔', t: [1, 2, 3, 4, 5].map(n => [(n === 1 ? '宝箱の矢印・' : '') + `宝箱 +${n} 秒` + (n === 3 ? '・スマホが ふるえる' : ''), (n === 1 ? '宝箱箭头・' : '') + `宝箱 +${n} 秒` + (n === 3 ? '・手机震动' : '')]) },
      gym: { ic: '🎓', ja: 'くんれん場', zh: '训练场', t: [1, 2, 3, 4, 5].map(n => [`経験値 +${4 * n}%`, `经验 +${4 * n}%`]) },
      hall: { ic: '🏛', ja: 'きねん館', zh: '纪念馆', t: [['なかまのボスの像', '伙伴首领雕像'], ['アルバムの がく', '相册画框'], ['塔の旗と しんりゃくの記録', '塔之旗和入侵记录'], ['ゆうびんポスト', '邮筒'], ['金の屋根＋花火', '金屋顶＋烟花']] } } };
  const isF = f => BASE.ORDER.includes(f);
  // 効き目（小さく：負けた後・強化・経験値・宝箱の時間だけ。コインが ふえる物は無い）
  function baseFx(b) { const L0 = (b && b.lv) || {}, L = {}; for (const f of BASE.ORDER) L[f] = toInt(L0[f], 0, BASE.MAX, 0);
    return { life: L.repair >= 4 ? 2 : L.repair >= 1 ? 1 : 0, climbRetry: L.repair >= 2 ? 1 : 0, armor: L.repair >= 3 ? 1 : 0, futon: L.repair >= 5 ? 1 : 0,
      enh: L.lab * 0.01, bag: 80 + 4 * L.store, chestLife: L.watch, chestHint: L.watch >= 1, chestBuzz: L.watch >= 3, xp: L.gym * 0.04, hall: L.hall }; }
  const nowSec = () => Math.floor(Date.now() / 1000);
  // 出す：出しすぎない（残りと さいふの小さい方まで）。返す：{ ok, msg, f, paid, up, lv, names }。names＝Lv が上がった時、その Lv に出した人
  function baseDonate(b, pr, f, n, at) {
    if (!b || !pr || !isF(f)) return { ok: false, msg: 'ng' }; if (b.lv[f] >= BASE.MAX) return { ok: false, msg: 'max' };
    const need = BASE.COST[b.lv[f]] - b.fund[f], pay = Math.min(toInt(n, 0, 1e8, 0), need, pr.coins);
    if (!(pay > 0)) return { ok: false, msg: 'poor' };
    pr.coins -= pay; b.fund[f] += pay; const nm = okName(pr.name);
    if (nm) { b.by[nm] = (b.by[nm] || 0) + pay; const w = (b.who[f] = b.who[f] || []); if (!w.includes(nm) && w.length < 8) w.push(nm); }
    let up = false, names = [];
    if (b.fund[f] >= BASE.COST[b.lv[f]]) { names = b.who[f] || []; b.lv[f]++; b.fund[f] = 0; b.who[f] = []; up = true;
      b.log.unshift({ at: at === undefined ? nowSec() : toInt(at, 0, 1e13, 0), f, lv: b.lv[f], names: names.slice() }); if (b.log.length > 20) b.log.length = 20; }
    return { ok: true, msg: up ? 'up' : 'donate', f, paid: pay, up, lv: b.lv[f], names };
  }
  // 投票：一人 1 つ。同じ物を もう一度で 取り消し。返す：{ ok, f }（f＝今の票。'' は なし）
  function baseVote(b, name, f) {
    const nm = okName(name); if (!b || !nm || !isF(f)) return { ok: false, msg: 'ng' };
    if (b.vote[nm] === f) { delete b.vote[nm]; return { ok: true, f: '' }; } if (b.lv[f] >= BASE.MAX) return { ok: false, msg: 'max' };
    b.vote[nm] = f; return { ok: true, f };
  }
  // みんなの おすすめ：⭐ の一番多い建物（同じなら たまった割合の高い方・同じなら ORDER の前）。Lv 5 は外す。返す：ORDER の番号（ぜんぶ Lv 5 なら -1）
  function baseRec(b) { const c = {}; for (const k in b.vote) c[b.vote[k]] = (c[b.vote[k]] || 0) + 1; let best = -1, bv = null;
    BASE.ORDER.forEach((f, i) => { if (b.lv[f] >= BASE.MAX) return; const v = [c[f] || 0, b.fund[f] / BASE.COST[b.lv[f]]]; if (best < 0 || v[0] > bv[0] || (v[0] === bv[0] && v[1] > bv[1])) { best = i; bv = v; } }); return best; }
  function baseTotal(b) { let n = 0; for (const f of BASE.ORDER) n += toInt(b && b.lv && b.lv[f], 0, BASE.MAX, 0); return n; }   // 0〜30
  // 花火（きねん館 Lv 5）：🪙 300 で 1 回。かざりだけ
  function baseFw(b, pr) { if (!b || !pr || b.lv.hall < BASE.MAX) return { ok: false, msg: 'lock' }; if (pr.coins < BASE.FW) return { ok: false, msg: 'poor' }; pr.coins -= BASE.FW; b.fw++; return { ok: true, msg: 'fw', paid: BASE.FW, fw: b.fw }; }
  // 保存の形：{ v: 1, lv, fund, by: { 名前: 出した合計 }（20 人）, vote: { 名前: 鍵 }（20 人）, who: { 鍵: [今の Lv に出した人] }（8 人）, log: [ { at, f, lv, names } ]（20）, fw }
  const nameList = (v, max) => (Array.isArray(v) ? v.map(okName).filter((x, i, L) => x && L.indexOf(x) === i).slice(0, max) : []);
  function cleanBase(o) {
    const p = o && typeof o === 'object' && !Array.isArray(o) ? o : {}, b = { v: 1, lv: {}, fund: {}, by: {}, vote: {}, who: {}, log: [], fw: 0 }, obj = v => (v && typeof v === 'object' && !Array.isArray(v) ? v : {});
    const lv = obj(p.lv), fund = obj(p.fund), who = obj(p.who), by = obj(p.by), vote = obj(p.vote);
    for (const f of BASE.ORDER) { const L = toInt(lv[f], 0, BASE.MAX, 0); b.lv[f] = L; b.fund[f] = L >= BASE.MAX ? 0 : toInt(fund[f], 0, BASE.COST[L] - 1, 0); b.who[f] = L >= BASE.MAX ? [] : nameList(who[f], 8); }
    let ent = []; for (const k of Object.keys(by)) { const nm = okName(k), v = toInt(by[k], 0, 1e9, 0); if (nm && v > 0 && !ent.some(e => e[0] === nm)) ent.push([nm, v]); }
    if (ent.length > 20) { const keep = ent.slice().sort((x, y) => y[1] - x[1]).slice(0, 20); ent = ent.filter(e => keep.includes(e)); }   // 20 人まで（多く出した人を残す）
    for (const [k, v] of ent) b.by[k] = v;
    for (const k of Object.keys(vote)) { const nm = okName(k); if (nm && isF(vote[k]) && b.lv[vote[k]] < BASE.MAX && !(nm in b.vote) && Object.keys(b.vote).length < 20) b.vote[nm] = vote[k]; }
    b.log = (Array.isArray(p.log) ? p.log : []).filter(r => r && typeof r === 'object' && isF(r.f)).slice(0, 20).map(r => ({ at: toInt(r.at, 0, 1e13, 0), f: r.f, lv: toInt(r.lv, 1, BASE.MAX, 1), names: nameList(r.names, 8) }));
    b.fw = toInt(p.fw, 0, 1e7, 0); return b;
  }
  /* ===== P9 END ===== */

  const api = { BAG_MAX, SLOTS, SLOT_NAME, RARITY, R_TOP, RBASE, RW, CAR_MAX, xpNeed, carLv, carInfo, addXp, stageXp, CARS, SP_NAME, SP_NEED, FX, SETS, ENH, WHEEL, WHEEL_SUM, CHEST, MAX_LV,
    newProfile, cleanProfile, itemOf, equipped, makeItem, itemStats, statText, setCounts, mods, enhInfo, enhCost, dismantleGain, act, spin, wheelSpins, openChest, clearCoins, power,
    P3D_BOSS_CARS, p3dIsBossCar, /* P3D-2 */ DRV, driverNew, driverStat, driverStats, driverInfo, driverBonus, driverAddXp, driverSpend, driverAuto, driverAct, rerollCost, bondAdd, bondInfo, luckOf, cleanDriver };   // P2-1
  Object.assign(api, { P4B_GEAR, P4B_SIG, p4bSigOf, p4bSigText, p4bGive, p4bLegend });   // P4B
  Object.assign(api, { bagMaxOf, CRAFT, MERGE_ANY_R, craftSets, dismantleAllInfo, GIFT, giftOk, give, swap, cleanGifts, giftNote, BASE, baseFx, baseDonate, baseVote, baseRec, baseTotal, baseFw, cleanBase });   // P9 v0.26
  root.TankGear = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);

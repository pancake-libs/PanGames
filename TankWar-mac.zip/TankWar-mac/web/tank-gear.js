/* おうちを守れ！戦車隊：育ち（v0.12、開発 3 回目）。計算だけ（画面なし。node でも動く）。
   - 一人ずつの記録（名前ごと）：コイン・部品・まもりの札・車種・装備・袋
   - 車種 4 つ（ふつう・はやい・どっしり・おたすけ）と必殺技
   - 装備（砲・車体・キャタピラ・おまもり）、希少さ 4 段、特別な効果、セット 8 種
   - 強化 +0〜+10（確率。JUN の指示：+7 から失敗で段が下がり、+10 に挑む時は 10% で壊れる。失敗するたび次は +5%。札で守れる）
   - 分解・合体、面のあとのルーレット、戦い中の宝箱の中身
   乱数は種を決めたもの（mulberry32）。tank-sim.js には「強さ（mods）」だけを渡す */
(function (root) {
  'use strict';
  // 装備の部位（v0.15：JUN さん「部位と種類を増やす」→ 砲塔・エンジンを足して 6 か所）
  const SLOTS = ['gun', 'turret', 'body', 'track', 'engine', 'charm'];
  const SLOT_NAME = { gun: ['砲', '炮'], turret: ['砲塔', '炮塔'], body: ['車体', '车身'], track: ['キャタピラ', '履带'], engine: ['エンジン', '引擎'], charm: ['おまもり', '护身符'] };
  // 色（希少さ）8 段（v0.16：JUN さん「無色・緑・青・紫・黄・赤・銀・金。銀と金はピカピカ」）。[名前, 中国語, 色, 光るか]
  const RARITY = [['無色', '无色', '#d5dde2', 0], ['緑', '绿', '#5fd36a', 0], ['青', '蓝', '#4fa8ff', 0], ['紫', '紫', '#c27bff', 0],
    ['黄', '黄', '#ffd23a', 0], ['赤', '红', '#ff4f45', 0], ['銀', '银', '#e8f2ff', 1], ['金', '金', '#ffc21a', 2]];
  const R_TOP = RARITY.length - 1;
  const RBASE = [1, 1.5, 2, 3, 4, 4.8, 5.6, 6.5];   // 色ごとの強さのもと（前の 4 段：ふつう 1・いい 2・すごい 3・でんせつ 4 と同じ所に並ぶ）
  const OLD_R = [0, 2, 3, 4];   // 前の記録（4 段）→ 新しい色：ふつう→無色・いい→青・すごい→紫・でんせつ→黄
  // 戦車のレベル（v0.16：JUN さん「戦車をレベルアップ」）。車ごとに Lv1〜30。戦うと経験値
  const CAR_MAX = 30;
  function xpNeed(lv) { return 30 + 12 * lv; }   // lv → lv+1 に要る経験値（Lv30 まで合計 約 6100）
  const MAX_LV = 10;
  // 車種。sprite＝焼いた絵の形（a〜d）。sp＝必殺技
  const CARS = {
    a: { ja: 'ふつう', zh: '普通', dja: 'なんでもできる（足と弾が少し速い）。必殺技はまわりの敵に爆撃', dzh: '样样都行（移动和炮弹稍快）。必杀技：轰炸周围的敌人', speed: 1.05, bullet: 1.08, armor: 0, inv: 0, sp: 'bomb' },
    b: { ja: 'はやい', zh: '快速', dja: '足と弾が速い。必殺技は 3 秒の急加速（無敵）', dzh: '移动和炮弹快。必杀技：3 秒冲刺（无敌）', speed: 1.18, bullet: 1.1, armor: 0, inv: 0, sp: 'dash' },
    c: { ja: 'どっしり', zh: '重型', dja: '遅いけれどかたい（よろい +1）。必殺技はみんなに盾', dzh: '慢但很硬（护甲 +1）。必杀技：全队护盾', speed: 0.88, bullet: 1, armor: 1, inv: 1, sp: 'wall' },
    d: { ja: 'おたすけ', zh: '支援', dja: '仲間を助ける。必殺技で仲間の台数 +1・おうちにおふとん', dzh: '帮助队友。必杀技：队友坦克 +1、小屋加被子', speed: 1, bullet: 1, armor: 0, inv: 0.5, sp: 'heal' }
  };
  const SP_NAME = { bomb: ['ばくげき！', '轰炸！'], dash: ['きゅうかそく！', '冲刺！'], wall: ['みんなに盾！', '全队护盾！'], heal: ['おたすけ！', '支援！'] };
  const SP_NEED = 8;   // 必殺技がたまるまでに倒す敵の数（ボスに当てると 0.5）
  /* ===== P3D-2 BEGIN：ボス戦車（アイデア No.2、JUN さん「収服最終首領、換乗首領坦克」）。5 つ目の車種。ワールドの さいごの ボス 6 体と 1 体ずつ なかよくなると、その ボスの戦車に のれる（v0.20）。
     boss＝ボスの絵（tank.html が ボスの絵を 味方の大きさに縮めて、その人の色の ふちどりを付ける）。強さは ほかの車と同じくらい（速さ・弾・よろい・無敵の合計を そろえた）。
     のれるかどうかは 家族で 1 つ（テレビの記録 'tank-p3d-story'）。act の bossOk が無ければ のりかえられない ===== */
  const P3D_BOSS_CARS = {
    kk: { boss: 'king', ja: '戦車の王', zh: '坦克之王', dja: 'おうさまの戦車。必殺技は まわり ぜんぶに 王の弾（じぶんに 盾）', dzh: '国王的坦克。必杀技：向四周发射王之弹（自己获得护盾）', speed: 1, bullet: 1.06, armor: 0, inv: 0.5, sp: 'royal' },
    kb: { boss: 'bigtank', ja: '大型戦車', zh: '大型坦克', dja: 'おそいけれど かたい（よろい +1）。必殺技は 鉄も こわす 大きな弾', dzh: '慢但很硬（护甲 +1）。必杀技：能打穿钢板的大炮弹', speed: 0.9, bullet: 1.04, armor: 1, inv: 0.5, sp: 'bigshot' },
    kw: { boss: 'sandship', ja: '砂上戦艦', zh: '沙上战舰', dja: '弾が はやい。必殺技は 前へ 3 本の はやい 砲弾（つらぬく）', dzh: '炮弹很快。必杀技：向前射出 3 发快速炮弹（可穿透）', speed: 0.95, bullet: 1.08, armor: 0, inv: 0.5, sp: 'broadside' },
    kn: { boss: 'snowman', ja: '雪だるま戦車', zh: '雪人坦克', dja: 'のんびり やさしい。必殺技は 敵を 少しの間 こおらせる', dzh: '慢悠悠又温柔。必杀技：把敌人冻住一小会儿', speed: 0.96, bullet: 1, armor: 0, inv: 1, sp: 'snow' },
    kd: { boss: 'dragon', ja: '火竜戦車', zh: '火龙坦克', dja: '弾が はやい。必殺技は 前へ 炎の いき', dzh: '炮弹很快。必杀技：向前喷出火焰', speed: 1.04, bullet: 1.1, armor: 0, inv: 0, sp: 'flame' },
    kc: { boss: 'core', ja: '要塞コア', zh: '要塞核心', dja: 'みんなを まもる。必殺技は 家族みんなに 少しの 盾（じぶんは 長め）', dzh: '守护大家。必杀技：给全家人一点护盾（自己更久）', speed: 0.98, bullet: 1.04, armor: 0, inv: 0.5, sp: 'guard' }
  };
  Object.assign(CARS, P3D_BOSS_CARS);
  Object.assign(SP_NAME, { royal: ['王のごうれい！', '王之号令！'], bigshot: ['どっかん砲！', '轰天大炮！'], broadside: ['いっせいほうげき！', '齐射！'], guard: ['まもりの ひかり！', '守护之光！'], snow: ['ゆきやこんこ！', '漫天飞雪！'], flame: ['ほのおの いき！', '火焰吐息！'] });
  const p3dIsBossCar = k => !!(CARS[k] && CARS[k].boss);
  // ボス戦車のレベルも 記録から読む（newProfile の cars は a〜d だけなので）
  function p3dCleanCars(o, p) { if (p && p.cars && typeof p.cars === 'object') for (const k in P3D_BOSS_CARS) { const c = p.cars[k]; if (c && typeof c === 'object') o.cars[k] = { lv: toInt(c.lv, 1, 30, 1), xp: toInt(c.xp, 0, 1e6, 0) }; } }
  /* ===== P3D-2 END ===== */
  // 特別な効果
  const FX = {
    bounce: { s: 'gun', ja: '弾が 1 回はね返る', zh: '炮弹反弹 1 次' },
    pierce: { s: 'gun', ja: 'レンガを 2 枚ぬく', zh: '连穿 2 块砖' },
    longInv: { s: 'body', ja: '出直した時の無敵が長い', zh: '复活无敌更久' },
    lifeUp: { s: 'body', ja: '面の始めに台数 +1', zh: '每关开始坦克 +1' },
    swift: { s: 'track', ja: 'さらに速い（+8%）', zh: '更快（+8%）' },
    grip: { s: 'track', ja: '氷・砂ですべらない・遅くならない', zh: '冰面沙地不打滑不减速' },
    coin: { s: 'charm', ja: 'コイン +20%', zh: '金币 +20%' },
    house: { s: 'charm', ja: 'おうちの自衛 +1', zh: '小屋自卫 +1' },
    charge: { s: 'charm', ja: '必殺技が早くたまる（+25%）', zh: '必杀技充能更快（+25%）' },
    // v0.15 で足した効果
    longShot: { s: 'gun', ja: '弾がもっと速い（+10%）', zh: '炮弹更快（+10%）' },
    power1: { s: 'turret', ja: '火力 +1', zh: '火力 +1' },
    heavy: { s: 'turret', ja: '弾の威力 +15%', zh: '炮弹威力 +15%' },
    thick: { s: 'body', ja: 'よろい +1', zh: '护甲 +1' },
    turbo: { s: 'engine', ja: '速さ +6%・必殺技 +10%', zh: '速度 +6%・必杀技 +10%' },
    quickSp: { s: 'engine', ja: '必殺技が早くたまる（+30%）', zh: '必杀技充能更快（+30%）' },
    luck: { s: 'charm', ja: 'コイン +10%・おうちにおふとん', zh: '金币 +10%・小屋加被子' }
  };
  const FX_BY_SLOT = {}; for (const k in FX) (FX_BY_SLOT[FX[k].s] = FX_BY_SLOT[FX[k].s] || []).push(k);
  // セット 8 種。from＝出る所（v0.13 で 草原・砂漠・雪山・火山・ボス・ルーレット の 6 つが出る）
  const WORLD_SET = ['wakaba', 'sand', 'silver', 'crimson', 'steel', 'abyss', 'thunder'];   // 7 番目＝ランダムの面（v0.15）   // 世界ごとに出やすいセット（v0.13：雪山＝白銀・火山＝紅蓮）
  const SETS = {
    wakaba: { ja: '若葉', zh: '若叶', col: '#7fe08f', from: 'w1', two: ['速さ +10%', '速度 +10%'], four: ['やられた時、近くの仲間に盾', '被击败时给附近队友护盾'] },
    sand: { ja: '砂嵐', zh: '沙暴', col: '#e8c27a', from: 'w2', two: ['弾の速さ +15%', '炮弹速度 +15%'], four: ['3 発ごとに壁をぬける弾', '每 3 发一颗穿墙弹'] },
    silver: { ja: '白銀', zh: '白银', col: '#cfe8ff', from: 'w3', two: ['よろい +1', '护甲 +1'], four: ['当てた敵が少し遅くなる', '命中的敌人减速'] },
    crimson: { ja: '紅蓮', zh: '红莲', col: '#ff7a5c', from: 'w4', two: ['火力 +1', '火力 +1'], four: ['倒した敵が爆発する', '击败的敌人会爆炸'] },
    steel: { ja: '鋼鉄', zh: '钢铁', col: '#9aa6b8', from: 'w5', two: ['おうちの自衛 +1', '小屋自卫 +1'], four: ['おうちにおふとん +1', '小屋加 1 床被子'] },
    king: { ja: '王者', zh: '王者', col: '#ffd23a', from: 'boss', two: ['必殺技のたまり +20%', '必杀技充能 +20%'], four: ['必殺技を 2 回ためられる', '必杀技可存 2 次'] },
    abyss: { ja: '深淵', zh: '深渊', col: '#b07aff', from: 'hell', two: ['弾の威力 +20%', '炮弹威力 +20%'], four: ['のこり 1 台の時、威力 2 倍', '剩 1 辆时威力翻倍'] },
    bond: { ja: 'きずな', zh: '羁绊', col: '#ff9ad5', from: 'wheel', two: ['コイン +10%', '金币 +10%'], four: ['仲間が近いほど強い', '队友越近越强'] },
    thunder: { ja: '雷光', zh: '雷光', col: '#7ff0ff', from: 'rand', two: ['速さ +5%・弾 +5%', '速度 +5%・弹速 +5%'], four: ['必殺技 +25%', '必杀技 +25%'] }
  };
  const ENH = [   // 強化：今の段 → 次の段の成功の確率と、失敗した時（JUN の指示 2026-11-15）
    null, [1, 'none'], [1, 'none'], [1, 'none'], [.9, 'lose'], [.8, 'lose'], [.7, 'lose'], [.6, 'down'], [.5, 'down'], [.4, 'down'], [.3, 'break']];
  const PITY_STEP = 0.05, BREAK_RATE = 0.10;
  function rng(seed) { let a = seed >>> 0 || 1; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const toInt = (v, lo, hi, d) => { const n = Math.floor(Number(v)); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : d; };

  /* ---------- 一人ずつの記録 ---------- */
  function newProfile(name) { return { name, rv: 2, cars: { a: { lv: 1, xp: 0 }, b: { lv: 1, xp: 0 }, c: { lv: 1, xp: 0 }, d: { lv: 1, xp: 0 } }, coins: 0, parts: 0, charms: 0, car: 'a', gear: { gun: 0, turret: 0, body: 0, track: 0, engine: 0, charm: 0 }, bag: [], nextId: 1, pity: 0, wheelDry: 0, seed: (Date.now() % 1e9) | 0, buff: null, stats: { enh: 0, broke: 0, chests: 0, spins: 0 },
    driver: null, rec: { all: {}, wk: {}, wid: 0, boss: {}, x: {} }, ach: {}, title: '', skin: '', skins: [] }; }   // P2-1/5/26/14/11（driver はテレビが参加の時に作る）
  function cleanItem(it) {
    if (!it || typeof it !== 'object' || !SLOTS.includes(it.s)) return null;
    return { id: toInt(it.id, 1, 1e9, 1), s: it.s, r: toInt(it.r, 0, R_TOP, 0), set: SETS[it.set] ? it.set : 'wakaba', lv: toInt(it.lv, 0, MAX_LV, 0), pi: toInt(it.pi, 0, 1e6, 0),
      fx: Array.isArray(it.fx) ? it.fx.filter(k => FX[k]).slice(0, 4) : [] };
  }
  function cleanProfile(p, name) {
    const o = newProfile(name); if (!p || typeof p !== 'object') return o;
    o.coins = toInt(p.coins, 0, 1e8, 0); o.parts = toInt(p.parts, 0, 1e7, 0); o.charms = toInt(p.charms, 0, 999, 0); o.car = CARS[p.car] ? p.car : 'a';
    o.bag = (Array.isArray(p.bag) ? p.bag : []).map(cleanItem).filter(Boolean).slice(0, 80);
    if (p.rv !== 2) for (const it of o.bag) it.r = OLD_R[Math.min(3, it.r)];   // 前の 4 段の記録を 8 色に読み替える（強さは同じ）
    if (p.cars && typeof p.cars === 'object') for (const k in o.cars) { const c = p.cars[k]; if (c) o.cars[k] = { lv: toInt(c.lv, 1, CAR_MAX, 1), xp: toInt(c.xp, 0, 1e6, 0) }; }
    o.nextId = Math.max(toInt(p.nextId, 1, 1e9, 1), ...o.bag.map(i => i.id + 1), 1);
    for (const s of SLOTS) { const id = p.gear && toInt(p.gear[s], 0, 1e9, 0); o.gear[s] = id && o.bag.some(i => i.id === id && i.s === s) ? id : 0; }
    o.pity = Math.max(0, Math.min(1, Number(p.pity) || 0)); o.wheelDry = toInt(p.wheelDry, 0, 99, 0); o.seed = toInt(p.seed, 1, 2e9, o.seed);
    o.buff = p.buff === 'shield' || p.buff === 'power' ? p.buff : null;
    o.seenAt = toInt(p.seenAt, 0, 1e14, 0);
    if (p.stats && typeof p.stats === 'object') for (const k in o.stats) o.stats[k] = toInt(p.stats[k], 0, 1e7, 0);
    cleanP2(o, p);   // P2-1/5/26/14/11：ドライバー・実績・称号・ランキングの数・スキン（前の記録に無ければ空のまま）
    p3dCleanCars(o, p);   // P3D-2：ボス戦車のレベル
    return o;
  }
  function itemOf(pr, id) { return pr.bag.find(i => i.id === id) || null; }
  function equipped(pr) { const o = {}; for (const s of SLOTS) o[s] = pr.gear[s] ? itemOf(pr, pr.gear[s]) : null; return o; }
  function roll(pr) { const r = rng(pr.seed); const v = r(); pr.seed = (Math.floor(r() * 2e9) | 0) || 7; return v; }

  /* ---------- 装備を作る ---------- */
  function fxCount(r, lv) { return [0, 0, 0, 1, 2, 2, 3, 3][r] + (lv >= 5 ? 1 : 0) + (lv >= 10 ? 1 : 0); }
  function addFx(pr, it) { const pool = FX_BY_SLOT[it.s].filter(k => !it.fx.includes(k)); while (it.fx.length < fxCount(it.r, it.lv) && pool.length) it.fx.push(pool.splice(Math.floor(roll(pr) * pool.length), 1)[0]); }
  function makeItem(pr, opt) {
    const o = opt || {}; const s = SLOTS.includes(o.s) ? o.s : SLOTS[Math.floor(roll(pr) * SLOTS.length)];
    let r = o.r; if (r === undefined) { const v = roll(pr), w = o.rw || RW.base, sum = w.reduce((a, b) => a + b, 0); let acc = 0; r = 0; for (let i = 0; i < w.length; i++) { acc += w[i] / sum; if (v < acc) { r = i; break; } } }
    const it = { id: pr.nextId++, s, r, set: SETS[o.set] ? o.set : 'wakaba', lv: 0, pi: 0, fx: [] }; addFx(pr, it); pr.bag.push(it);
    // 持ち物は BAG_MAX まで。あふれたら、付けていない一番弱い物を部品にする（新しい物は残す）
    if (pr.bag.length > BAG_MAX) { const used = Object.values(pr.gear), cand = pr.bag.filter(i => i !== it && !used.includes(i.id)).sort((x, y) => power(x) - power(y))[0]; if (cand) { pr.bag = pr.bag.filter(i => i !== cand); pr.parts += dismantleGain(cand); } }
    return it;
  }
  const BAG_MAX = 80;
  // 色の出やすさ（無色・緑・青・紫・黄・赤・銀・金）。赤から上はめったに出ない。銀・金は主に合体とボスの金の宝箱
  const RW = { base: [38, 30, 18, 10, 4, 0, 0, 0], star3: [24, 30, 23, 15, 6, 2, 0, 0], wood: [70, 25, 5, 0, 0, 0, 0, 0],
    silver: [0, 0, 45, 35, 17, 3, 0, 0], gold: [0, 0, 0, 25, 45, 22, 6, 2] };
  // 装備の強さ（v＝1〜8）。希少さと段で上がる
  function power(it) { return RBASE[it.r] + it.lv * 0.4; }
  function itemStats(it) {
    const v = power(it);
    if (it.s === 'gun') return { bullet: 0.04 * v, power: Math.floor(v / 5) };
    if (it.s === 'body') return { armor: Math.floor(v / 4), inv: 0.3 * v };
    if (it.s === 'track') return { speed: 0.02 * v };
    if (it.s === 'turret') return { dmg: 0.025 * v, power: Math.floor(v / 7) };
    if (it.s === 'engine') return { speed: 0.012 * v, charge: 0.025 * v };
    return { coin: 0.05 * v, charge: 0.04 * v };
  }
  function statText(it, L) {
    const s = itemStats(it), t = [];
    if (s.bullet) t.push(L(`弾の速さ +${Math.round(s.bullet * 100)}%`, `弹速 +${Math.round(s.bullet * 100)}%`)); if (s.power) t.push(L(`火力 +${s.power}`, `火力 +${s.power}`));
    if (s.dmg) t.push(L(`弾の威力 +${Math.round(s.dmg * 100)}%`, `炮弹威力 +${Math.round(s.dmg * 100)}%`));
    if (s.armor) t.push(L(`よろい +${s.armor}`, `护甲 +${s.armor}`)); if (s.inv) t.push(L(`無敵 +${s.inv.toFixed(1)} 秒`, `无敌 +${s.inv.toFixed(1)} 秒`));
    if (s.speed) t.push(L(`速さ +${Math.round(s.speed * 100)}%`, `速度 +${Math.round(s.speed * 100)}%`));
    if (s.coin) t.push(L(`コイン +${Math.round(s.coin * 100)}%`, `金币 +${Math.round(s.coin * 100)}%`)); if (s.charge) t.push(L(`必殺技 +${Math.round(s.charge * 100)}%`, `必杀技 +${Math.round(s.charge * 100)}%`));
    for (const k of it.fx) t.push('★' + L(FX[k].ja, FX[k].zh));
    return t;
  }
  function setCounts(pr) { const c = {}; for (const it of Object.values(equipped(pr))) if (it) c[it.set] = (c[it.set] || 0) + 1; return c; }

  /* ---------- 戦いに渡す強さ（上限つき。強くなりすぎないように） ---------- */
  const CAP = { speed: 1.34, bullet: 1.55, power: 2, armor: 2, inv: 3, coin: 1.8, charge: 1.7, dmgMul: 1.5 };
  function mods(pr) {
    const car = CARS[pr.car] || CARS.a, m = { car: pr.car, sp: car.sp, speed: car.speed, bullet: car.bullet, power: 0, armor: car.armor, inv: car.inv, coin: 1, charge: 1, dmgMul: 1,
      bounce: 0, pierce: 0, grip: false, lifeUp: 0, tower: 0, futon: 0, spMax: 1, set4: {}, buff: pr.buff };
    for (const it of Object.values(equipped(pr))) {
      if (!it) continue; const s = itemStats(it);
      m.bullet += s.bullet || 0; m.power += s.power || 0; m.dmgMul += s.dmg || 0; m.armor += s.armor || 0; m.inv += s.inv || 0; m.speed += s.speed || 0; m.coin += s.coin || 0; m.charge += s.charge || 0;
      for (const k of it.fx) { if (k === 'bounce') m.bounce = 1; else if (k === 'pierce') m.pierce = 1; else if (k === 'longInv') m.inv += 2; else if (k === 'lifeUp') m.lifeUp = 1;
        else if (k === 'swift') m.speed += 0.08; else if (k === 'grip') m.grip = true; else if (k === 'coin') m.coin += 0.2; else if (k === 'house') m.tower += 1; else if (k === 'charge') m.charge += 0.25;
        else if (k === 'longShot') m.bullet += 0.1; else if (k === 'power1') m.power += 1; else if (k === 'heavy') m.dmgMul += 0.15; else if (k === 'thick') m.armor += 1;
        else if (k === 'turbo') { m.speed += 0.06; m.charge += 0.1; } else if (k === 'quickSp') m.charge += 0.3; else if (k === 'luck') { m.coin += 0.1; m.futon += 1; } }
    }
    const sc = setCounts(pr);
    for (const k in sc) {
      if (sc[k] >= 2) { if (k === 'wakaba') m.speed += 0.1; else if (k === 'sand') m.bullet += 0.15; else if (k === 'silver') m.armor += 1; else if (k === 'crimson') m.power += 1;
        else if (k === 'steel') m.tower += 1; else if (k === 'king') m.charge += 0.2; else if (k === 'abyss') m.dmgMul += 0.2; else if (k === 'bond') m.coin += 0.1; else if (k === 'thunder') { m.speed += 0.05; m.bullet += 0.05; } }
      if (sc[k] >= 4) { m.set4[k] = 1; if (k === 'king') m.spMax = 2; if (k === 'steel') m.futon += 1; if (k === 'thunder') m.charge += 0.25; }
    }
    m.speed = Math.min(CAP.speed, m.speed); m.bullet = Math.min(CAP.bullet, m.bullet); m.power = Math.min(CAP.power, m.power); m.armor = Math.min(CAP.armor, m.armor);
    m.inv = Math.min(CAP.inv + 2, m.inv); m.coin = Math.min(CAP.coin, m.coin); m.charge = Math.min(CAP.charge, m.charge); m.tower = Math.min(2, m.tower); m.dmgMul = Math.min(CAP.dmgMul, m.dmgMul); m.futon = Math.min(2, m.futon);
    // 戦車のレベル：上限のあとに少しずつ足す（どんな装備でもレベルの分は強くなる）。Lv10・20・30 で必殺技が強くなる
    const lv = carLv(pr, pr.car), k = lv - 1; m.lv = lv; m.spLv = Math.floor(lv / 10);
    m.speed += 0.003 * k; m.bullet += 0.005 * k; m.dmgMul += 0.005 * k; m.inv += 0.03 * k; m.charge += 0.01 * k;
    // P2-1 BEGIN：ドライバーの力も、車のレベルと同じく上限のあとに少しだけ足す（bossDmg・team は tank-sim.js が使う）
    const db = driverBonus(pr); if (db) { m.bullet += db.bullet; m.speed += db.speed; m.inv += db.inv; m.charge += db.charge; m.bossDmg = 1 + db.bossDmg; m.team = db.team; m.luck = db.luck; m.dlv = pr.driver.lv; }
    // P2-1 END
    return m;
  }

  /* ---------- 戦車のレベル ---------- */
  function carLv(pr, car) { const c = pr.cars && pr.cars[car]; return c ? c.lv : 1; }
  function carInfo(pr, car) { const c = (pr.cars && pr.cars[car]) || { lv: 1, xp: 0 }; return { lv: c.lv, xp: c.xp, need: c.lv >= CAR_MAX ? 0 : xpNeed(c.lv), max: c.lv >= CAR_MAX }; }
  // 経験値を足す。上がったレベルの数を返す
  function addXp(pr, n, car) {
    const k = car || pr.car; if (!pr.cars) pr.cars = {}; const c = pr.cars[k] = pr.cars[k] || { lv: 1, xp: 0 }; let up = 0; if (c.lv >= CAR_MAX) return 0;
    c.xp += Math.max(0, Math.round(n)); while (c.lv < CAR_MAX && c.xp >= xpNeed(c.lv)) { c.xp -= xpNeed(c.lv); c.lv++; up++; } if (c.lv >= CAR_MAX) c.xp = 0; return up;
  }
  // 面のあとの経験値：倒した数 ×2、クリア 20＋星 ×5、ボス ×15（クリアしなくても倒した分は入る）
  function stageXp(kills, clear, stars, bossKills) { return kills * 2 + (clear ? 20 + 5 * (stars ? stars.reduce((a, b) => a + (b ? 1 : 0), 0) : 0) + 15 * (bossKills || 0) : 0); }

  /* ---------- ガレージの操作（スマホから。結果を返す） ---------- */
  function enhCost(it) { return { coins: Math.round(15 * (it.lv + 1) * RBASE[it.r]), parts: 2 * (it.lv + 1) }; }
  function enhInfo(pr, it) {
    if (!it || it.lv >= MAX_LV) return null; const [p0, fail] = ENH[it.lv + 1], rate = Math.min(1, p0 + (p0 < 1 ? pr.pity + luckOf(pr) : 0));   // P2-1：うん（最大 +3%）
    return { to: it.lv + 1, rate, fail, breakRate: fail === 'break' ? BREAK_RATE : 0, cost: enhCost(it) };
  }
  function dismantleGain(it) { return Math.round(3 * RBASE[it.r]) + it.lv; }
  function act(pr, a) {
    const it = a.id ? itemOf(pr, toInt(a.id, 0, 1e9, 0)) : null;
    if (a.op === 'car') { if (!CARS[a.car]) return { ok: false }; if (p3dIsBossCar(a.car) && !a.bossOk) return { ok: false, msg: 'lock' };   // P3D-2：ボス戦車は なかよくなってから
      pr.car = a.car; return { ok: true, msg: 'car' }; }
    if (a.op === 'equip') { if (!it) return { ok: false }; pr.gear[it.s] = pr.gear[it.s] === it.id ? 0 : it.id; return { ok: true, msg: pr.gear[it.s] ? 'equip' : 'unequip' }; }
    if (a.op === 'dismantle') { if (!it || Object.values(pr.gear).includes(it.id)) return { ok: false, msg: 'inuse' }; pr.bag = pr.bag.filter(i => i !== it); const g = dismantleGain(it); pr.parts += g; return { ok: true, msg: 'dismantle', parts: g }; }
    if (a.op === 'merge') {   // 同じ所・同じ希少さの装備 3 つ（付けていない物）→ 1 つ上の希少さ
      if (!it || it.r >= R_TOP) return { ok: false }; const same = pr.bag.filter(i => i.s === it.s && i.r === it.r && !Object.values(pr.gear).includes(i.id));
      if (same.length < 3) return { ok: false, msg: 'need3' }; const use = [it, ...same.filter(i => i !== it)].slice(0, 3); if (!use.includes(it) || Object.values(pr.gear).includes(it.id)) return { ok: false, msg: 'inuse' };
      const sets = {}; for (const u of use) sets[u.set] = (sets[u.set] || 0) + 1; const set = Object.keys(sets).sort((x, y) => sets[y] - sets[x])[0];
      pr.bag = pr.bag.filter(i => !use.includes(i)); const n = makeItem(pr, { s: it.s, r: it.r + 1, set }); return { ok: true, msg: 'merge', item: n.id };
    }
    if (a.op === 'enh') {
      const info = enhInfo(pr, it); if (!info) return { ok: false };
      if (pr.coins < info.cost.coins || pr.parts < info.cost.parts) return { ok: false, msg: 'poor' };
      const guard = !!a.guard && pr.charms > 0 && info.fail !== 'none' && info.fail !== 'lose';
      pr.coins -= info.cost.coins; pr.parts -= info.cost.parts; it.pi += info.cost.parts; if (guard) pr.charms--; pr.stats.enh++;
      if (roll(pr) < info.rate) { it.lv++; addFx(pr, it); pr.pity = 0; return { ok: true, msg: 'up', lv: it.lv }; }
      pr.pity = Math.min(0.5, pr.pity + PITY_STEP);
      if (guard) return { ok: true, msg: 'guarded', lv: it.lv };
      if (info.fail === 'break' && roll(pr) < BREAK_RATE) { for (const s of SLOTS) if (pr.gear[s] === it.id) pr.gear[s] = 0; pr.bag = pr.bag.filter(i => i !== it); const back = Math.floor(it.pi / 2); pr.parts += back; pr.stats.broke++; return { ok: true, msg: 'broke', parts: back }; }
      if (info.fail === 'down' || info.fail === 'break') { it.lv = Math.max(0, it.lv - 1); return { ok: true, msg: 'down', lv: it.lv }; }
      return { ok: true, msg: 'fail', lv: it.lv };
    }
    return { ok: false };
  }

  /* ---------- 面のあとのルーレット ---------- */
  // 当たりの円。w＝割合（円の広さもこの割合）
  const WHEEL = [
    { k: 'coins', n: 30, w: 20, ja: 'コイン 30', zh: '金币 30', col: '#ffd23a' }, { k: 'gear', w: 12, ja: '装備', zh: '装备', col: '#c27bff' },
    { k: 'parts', n: 3, w: 16, ja: '部品 3', zh: '零件 3', col: '#8fd0ff' }, { k: 'coins', n: 60, w: 12, ja: 'コイン 60', zh: '金币 60', col: '#ffb53a' },
    { k: 'buff', b: 'shield', w: 8, ja: '次の面：たてで出発', zh: '下一关：带盾出发', col: '#7fe0ff' }, { k: 'charm', w: 7, ja: 'まもりの札', zh: '守护符', col: '#ff9ad5' },
    { k: 'parts', n: 6, w: 9, ja: '部品 6', zh: '零件 6', col: '#5fb8ff' }, { k: 'gear', w: 6, ja: '装備', zh: '装备', col: '#a46bff' },
    { k: 'buff', b: 'power', w: 6, ja: '次の面：火力 +1', zh: '下一关：火力 +1', col: '#ff8a5c' }, { k: 'coins', n: 200, w: 4, ja: 'コイン 200！', zh: '金币 200！', col: '#fff07a' }];
  const WHEEL_SUM = WHEEL.reduce((a, b) => a + b.w, 0);
  const WHEEL_PITY = 5;   // 5 回回して装備が出なければ、次は必ず装備
  function spin(pr, ctx) {   // ctx：{ world: 0/1, stars: 3 なら世界のセットが出やすい }
    let idx; const lk = luckOf(pr); if (pr.wheelDry >= WHEEL_PITY || (lk > 0 && roll(pr) < lk)) idx = WHEEL.findIndex(w => w.k === 'gear');   // P2-1：うん の分だけ装備が出やすい
    else { const v = roll(pr) * WHEEL_SUM; let acc = 0; idx = WHEEL.length - 1; for (let i = 0; i < WHEEL.length; i++) { acc += WHEEL[i].w; if (v < acc) { idx = i; break; } } }
    const w = WHEEL[idx], res = { idx, k: w.k, ja: w.ja, zh: w.zh }; pr.stats.spins++;
    if (w.k === 'gear') { pr.wheelDry = 0; const ws = WORLD_SET[(ctx && ctx.world) | 0] || 'wakaba', set = roll(pr) < 0.3 ? 'bond' : ws; const it = makeItem(pr, { set, rw: ctx && ctx.stars >= 3 ? RW.star3 : RW.base }); res.item = it.id; }
    else { pr.wheelDry++; if (w.k === 'coins') { const n = Math.round(w.n * mods(pr).coin); pr.coins += n; res.n = n; } else if (w.k === 'parts') { pr.parts += w.n; res.n = w.n; } else if (w.k === 'charm') pr.charms++; else if (w.k === 'buff') pr.buff = w.b; }
    return res;
  }
  function wheelSpins(stars) { return Math.min(4, 1 + (stars ? stars.reduce((a, b) => a + (b ? 1 : 0), 0) : 0)); }

  /* ---------- 宝箱の中身（拾った時） ---------- */
  const CHEST = { wood: { life: 10, col: '#b0763a' }, silver: { life: 12, col: '#cfd8e2' }, gold: { life: 15, col: '#ffd23a' } };
  function openChest(pr, kind, ctx) {
    const res = { kind }, m = mods(pr), ws = WORLD_SET[(ctx && ctx.world) | 0] || 'wakaba', lk = luckOf(pr); pr.stats.chests++;   // P2-1：lk＝うん
    if (kind === 'wood') { const v = roll(pr); if (v < 0.1 + lk) res.item = makeItem(pr, { set: ws, rw: RW.wood }).id; else if (v < 0.55) { res.parts = 1 + Math.floor(roll(pr) * 2); pr.parts += res.parts; } else { res.coins = Math.round((10 + Math.floor(roll(pr) * 16)) * m.coin); pr.coins += res.coins; } }
    else if (kind === 'silver') { res.coins = Math.round((30 + Math.floor(roll(pr) * 31)) * m.coin); pr.coins += res.coins; if (roll(pr) < 0.15) { pr.charms++; res.charm = 1; } if (roll(pr) < 0.45 + lk) res.item = makeItem(pr, { set: roll(pr) < 0.3 ? 'king' : ws, rw: RW.silver }).id; }
    else { res.item = makeItem(pr, { set: roll(pr) < 0.5 ? 'king' : ws, rw: RW.gold }).id; res.share = 50; }
    return res;
  }
  // 面のクリアのコイン（一人ずつ）
  function clearCoins(pr, stars) { const n = Math.round((20 + 10 * (stars ? stars.reduce((a, b) => a + b, 0) : 0)) * mods(pr).coin); pr.coins += n; return n; }

  /* ================= P2-1 BEGIN：ドライバー（JUN さん「戦車＋ドライバー 共同成長。いろいろな係数、はじめはランダム」） =================
     - 一人（名前）に一人。係数は 6 つ：ねらい・うんてん・がんじょう・うん・ゆうき・なかま
     - はじめはランダム。でも合計はみんな同じ 12（1 つは 1〜4）なので、だれも損をしない。ふりなおしは 1 回ただ、あとはコイン
     - 戦うと経験値（車と同じ stageXp）。Lv 1〜30。1 つ上がるたびに 1 点もらえて、好きな係数に足せる（足さなければ、次の面の始めに一番低い所へ）
     - なかよし度：ドライバーと車の組ごと。その車で遊んだ面の数。MAX で必殺技が少し早くたまる
     - 力はどれも小さい（車のレベルの半分くらい）。mods() で上限のあとに足す */
  const DRV = { STATS: ['aim', 'drive', 'armor', 'luck', 'courage', 'team'], FACES: 8, MAX_LV: 30, STAT_MAX: 15, BASE_SUM: 12, BASE_MIN: 1, BASE_MAX: 4, BOND_MAX: 30, BOND_STEP: 6, REROLL_COST: 150, LUCK_CAP: 0.03,
    // 1 点あたりの力
    PER: { aim: 0.005, drive: 0.003, armor: 0.04, luck: 0.002, courage: 0.01, team: 0.005 }, BOND_CHARGE: 0.05,
    INFO: {
      aim: { ic: '🎯', ja: 'ねらい', zh: '瞄准', dja: '弾が速くなる', dzh: '炮弹更快' },
      drive: { ic: '🚗', ja: 'うんてん', zh: '驾驶', dja: '足が速くなる', dzh: '移动更快' },
      armor: { ic: '🛡', ja: 'がんじょう', zh: '结实', dja: 'やられた後の無敵が長い', dzh: '被打后无敌更久' },
      luck: { ic: '🍀', ja: 'うん', zh: '运气', dja: '宝箱・ルーレット・強化が少し当たりやすい', dzh: '宝箱、转盘、强化稍微更容易成功' },
      courage: { ic: '🔥', ja: 'ゆうき', zh: '勇气', dja: 'ボスに強い', dzh: '对首领伤害更高' },
      team: { ic: '🤝', ja: 'なかま', zh: '伙伴', dja: '仲間かおうちの近くで強い', dzh: '在队友或小屋附近更强' } } };
  function driverBase(pr) {   // 合計 BASE_SUM、1 つは BASE_MIN〜BASE_MAX。全部 1 から始めて、残りを 1 点ずつ配る
    const n = DRV.STATS.length, b = new Array(n).fill(DRV.BASE_MIN); let left = DRV.BASE_SUM - n * DRV.BASE_MIN;
    while (left > 0) { const open = []; for (let i = 0; i < n; i++) if (b[i] < DRV.BASE_MAX) open.push(i); if (!open.length) break; b[open[Math.floor(roll(pr) * open.length)]]++; left--; }
    return b;
  }
  function driverNew(pr, face) {
    // 同じ瞬間に作った記録は種が同じになるので、名前をまぜる（同時に参加した人が同じドライバーにならないように）
    let h = 2166136261; for (const ch of String(pr.name || '')) h = Math.imul(h ^ ch.codePointAt(0), 16777619); pr.seed = (((pr.seed ^ h) >>> 0) % 2000000000) || 7;
    const f = Number.isInteger(face) ? toInt(face, 0, DRV.FACES - 1, 0) : Math.floor(roll(pr) * DRV.FACES);
    pr.driver = { f, b: driverBase(pr), a: [0, 0, 0, 0, 0, 0], lv: 1, xp: 0, pts: 0, rr: 0, bond: { a: 0, b: 0, c: 0, d: 0 } }; for (const k in P3D_BOSS_CARS) pr.driver.bond[k] = 0;   // P3D-2：ボス戦車の なかよし度
    return pr.driver;
  }
  function cleanDriver(d) {
    if (!d || typeof d !== 'object' || !Array.isArray(d.b) || d.b.length !== 6) return null;
    const b = d.b.map(v => toInt(v, DRV.BASE_MIN, DRV.BASE_MAX, DRV.BASE_MIN)); if (b.reduce((x, y) => x + y, 0) !== DRV.BASE_SUM) return null;   // 合計が合わない記録は作り直す（公平のため）
    const lv = toInt(d.lv, 1, DRV.MAX_LV, 1), a = [0, 1, 2, 3, 4, 5].map(i => toInt(d.a && d.a[i], 0, DRV.MAX_LV, 0)), bond = {};
    for (const k in CARS) bond[k] = toInt(d.bond && d.bond[k], 0, DRV.BOND_MAX, 0);
    let used = a.reduce((x, y) => x + y, 0); for (let i = 5; i >= 0 && used > lv - 1; i--) { const cut = Math.min(a[i], used - (lv - 1)); a[i] -= cut; used -= cut; }   // 足した点はレベルの分まで
    return { f: toInt(d.f, 0, DRV.FACES - 1, 0), b, a, lv, xp: toInt(d.xp, 0, 1e6, 0), pts: lv - 1 - used, rr: toInt(d.rr, 0, 9999, 0), bond };
  }
  function driverStat(pr, i) { const d = pr.driver; return d ? Math.min(DRV.STAT_MAX, d.b[i] + d.a[i]) : 0; }
  function driverStats(pr) { return DRV.STATS.map((_, i) => driverStat(pr, i)); }
  function driverInfo(pr) { const d = pr.driver; if (!d) return null; return { lv: d.lv, xp: d.xp, need: d.lv >= DRV.MAX_LV ? 0 : xpNeed(d.lv), max: d.lv >= DRV.MAX_LV, pts: d.pts }; }
  function bondInfo(pr, car) { const d = pr.driver, n = d ? d.bond[car || pr.car] | 0 : 0; return { n, hearts: Math.min(5, Math.floor(n / DRV.BOND_STEP)), max: n >= DRV.BOND_MAX }; }
  // 力（mods に足す分）
  function driverBonus(pr) {
    if (!pr || !pr.driver) return null; const s = driverStats(pr), P = DRV.PER;
    return { bullet: s[0] * P.aim, speed: s[1] * P.drive, inv: s[2] * P.armor, luck: Math.min(DRV.LUCK_CAP, s[3] * P.luck), bossDmg: s[4] * P.courage, team: s[5] * P.team, charge: bondInfo(pr).max ? DRV.BOND_CHARGE : 0 };
  }
  function luckOf(pr) { return pr && pr.driver ? Math.min(DRV.LUCK_CAP, driverStat(pr, 3) * DRV.PER.luck) : 0; }
  // 経験値。上がったレベルの数を返す（上がった分だけ pts が増える）
  function driverAddXp(pr, n) {
    const d = pr.driver; if (!d || d.lv >= DRV.MAX_LV) return 0; let up = 0; d.xp += Math.max(0, Math.round(n));
    while (d.lv < DRV.MAX_LV && d.xp >= xpNeed(d.lv)) { d.xp -= xpNeed(d.lv); d.lv++; d.pts++; up++; } if (d.lv >= DRV.MAX_LV) d.xp = 0; return up;
  }
  function driverSpend(pr, i) { const d = pr.driver; if (!d || d.pts <= 0 || !(i >= 0 && i < 6) || d.b[i] + d.a[i] >= DRV.STAT_MAX) return false; d.a[i]++; d.pts--; return true; }
  // えらばなかった点は、一番低い係数へ（同じなら上から）。入れた数を返す
  function driverAuto(pr) { const d = pr.driver; let n = 0; while (d && d.pts > 0) { let lo = -1; for (let i = 0; i < 6; i++) if (d.b[i] + d.a[i] < DRV.STAT_MAX && (lo < 0 || d.b[i] + d.a[i] < d.b[lo] + d.a[lo])) lo = i; if (lo < 0 || !driverSpend(pr, lo)) break; n++; } return n; }
  function rerollCost(pr) { return pr.driver && pr.driver.rr > 0 ? DRV.REROLL_COST : 0; }
  // なかよし度：その車で 1 面遊ぶごとに +1。MAX になった時だけ true を返す
  function bondAdd(pr, car) { const d = pr.driver, k = car || pr.car; if (!d || !CARS[k] || d.bond[k] >= DRV.BOND_MAX) return false; d.bond[k]++; return d.bond[k] >= DRV.BOND_MAX; }
  // スマホからの操作：係数に足す・ふりなおす・顔をかえる
  function driverAct(pr, a) {
    const d = pr.driver; if (!d) return { ok: false };
    if (a.op === 'stat') return driverSpend(pr, toInt(a.i, 0, 5, -1)) ? { ok: true, msg: 'stat' } : { ok: false, msg: 'ng' };
    if (a.op === 'face') { d.f = toInt(a.f, 0, DRV.FACES - 1, d.f); return { ok: true, msg: 'face' }; }
    if (a.op === 'reroll') { const cost = rerollCost(pr); if (pr.coins < cost) return { ok: false, msg: 'poor' }; pr.coins -= cost; d.b = driverBase(pr); d.rr++; return { ok: true, msg: 'reroll', cost }; }
    return { ok: false };
  }
  /* P2-5/26/14/11：実績・称号・ランキングの数・スキンは tank-book.js が中身を決める。ここは記録を安全に読むだけ */
  const numMap = (src, max) => { const o = {}; if (src && typeof src === 'object') for (const k of Object.keys(src).slice(0, max || 80)) { if (!/^[A-Za-z0-9_]{1,20}$/.test(k)) continue; const n = Number(src[k]); if (Number.isFinite(n) && n > 0) o[k] = Math.min(1e13, Math.floor(n)); } return o; };
  const idStr = v => (typeof v === 'string' && /^[A-Za-z0-9_]{1,20}$/.test(v) ? v : '');
  function cleanP2(o, p) {
    o.driver = cleanDriver(p.driver);
    const r = p.rec && typeof p.rec === 'object' ? p.rec : {};
    o.rec = { all: numMap(r.all), wk: numMap(r.wk), wid: toInt(r.wid, 0, 1e7, 0), boss: numMap(r.boss), x: numMap(r.x) };
    o.ach = numMap(p.ach, 120); o.title = idStr(p.title); o.skin = idStr(p.skin);
    o.skins = (Array.isArray(p.skins) ? p.skins : []).map(idStr).filter(Boolean).slice(0, 40);
  }
  /* ================= P2-1 END ================= */

  const api = { BAG_MAX, SLOTS, SLOT_NAME, RARITY, R_TOP, RBASE, RW, CAR_MAX, xpNeed, carLv, carInfo, addXp, stageXp, CARS, SP_NAME, SP_NEED, FX, SETS, ENH, WHEEL, WHEEL_SUM, CHEST, MAX_LV,
    newProfile, cleanProfile, itemOf, equipped, makeItem, itemStats, statText, setCounts, mods, enhInfo, enhCost, dismantleGain, act, spin, wheelSpins, openChest, clearCoins, power,
    P3D_BOSS_CARS, p3dIsBossCar, /* P3D-2 */ DRV, driverNew, driverStat, driverStats, driverInfo, driverBonus, driverAddXp, driverSpend, driverAuto, driverAct, rerollCost, bondAdd, bondInfo, luckOf, cleanDriver };   // P2-1
  root.TankGear = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);

/* おうちを守れ！戦車隊：育ち（v0.12、開発 3 回目）。計算だけ（画面なし。node でも動く）。
   - 一人ずつの記録（名前ごと）：コイン・部品・まもりの札・車種・装備・袋
   - 車種 4 つ（ふつう・はやい・どっしり・おたすけ）と必殺技
   - 装備（砲・車体・キャタピラ・おまもり）、希少さ 4 段、特別な効果、セット 8 種
   - 強化 +0〜+10（確率。JUN の指示：+7 から失敗で段が下がり、+10 に挑む時は 10% で壊れる。失敗するたび次は +5%。札で守れる）
   - 分解・合体、面のあとのルーレット、戦い中の宝箱の中身
   乱数は種を決めたもの（mulberry32）。tank-sim.js には「強さ（mods）」だけを渡す */
(function (root) {
  'use strict';
  const SLOTS = ['gun', 'body', 'track', 'charm'];
  const SLOT_NAME = { gun: ['砲', '炮'], body: ['車体', '车身'], track: ['キャタピラ', '履带'], charm: ['おまもり', '护身符'] };
  const RARITY = [['ふつう', '普通', '#e8eef2'], ['いい', '优秀', '#5fb8ff'], ['すごい', '史诗', '#c27bff'], ['でんせつ', '传说', '#ffc93a']];
  const MAX_LV = 10;
  // 車種。sprite＝焼いた絵の形（a〜d）。sp＝必殺技
  const CARS = {
    a: { ja: 'ふつう', zh: '普通', dja: 'なんでもできる（足と弾が少し速い）。必殺技はまわりの敵に爆撃', dzh: '样样都行（移动和炮弹稍快）。必杀技：轰炸周围的敌人', speed: 1.05, bullet: 1.08, armor: 0, inv: 0, sp: 'bomb' },
    b: { ja: 'はやい', zh: '快速', dja: '足と弾が速い。必殺技は 3 秒の急加速（無敵）', dzh: '移动和炮弹快。必杀技：3 秒冲刺（无敌）', speed: 1.18, bullet: 1.1, armor: 0, inv: 0, sp: 'dash' },
    c: { ja: 'どっしり', zh: '重型', dja: '遅いけれどかたい（よろい +1）。必殺技はみんなに盾', dzh: '慢但很硬（护甲 +1）。必杀技：全队护盾', speed: 0.88, bullet: 1, armor: 1, inv: 1, sp: 'wall' },
    d: { ja: 'おたすけ', zh: '支援', dja: '仲間を助ける。必殺技で仲間の台数 +1・おうちにおふとん', dzh: '帮助队友。必杀技：队友坦克 +1、小屋加被子', speed: 1, bullet: 1, armor: 0, inv: 0.5, sp: 'heal' }
  };
  const SP_NAME = { bomb: ['ばくげき！', '轰炸！'], dash: ['きゅうかそく！', '冲刺！'], wall: ['みんなに盾！', '全队护盾！'], heal: ['おたすけ！', '支援！'] };
  const SP_NEED = 8;   // 必殺技がたまるまでに倒す敵の数（ボスに当てると 0.5）
  // 特別な効果
  const FX = {
    bounce: { s: 'gun', ja: '弾が 1 回はね返る', zh: '炮弹反弹 1 次' },
    pierce: { s: 'gun', ja: 'レンガを 2 枚ぬく', zh: '连穿 2 块砖' },
    longInv: { s: 'body', ja: '出直した時の無敵が長い', zh: '复活无敌更久' },
    lifeUp: { s: 'body', ja: '面の始めに台数 +1', zh: '每关开始坦克 +1' },
    swift: { s: 'track', ja: 'さらに速い（+8%）', zh: '更快（+8%）' },
    grip: { s: 'track', ja: '氷・砂ですべらない・遅くならない', zh: '冰面沙地不打滑不减速' },
    coin: { s: 'charm', ja: 'コイン +20%', zh: '金币 +20%' },
    house: { s: 'charm', ja: 'おうちの自衛 +1', zh: '小屋自卫 +1' },
    charge: { s: 'charm', ja: '必殺技が早くたまる（+25%）', zh: '必杀技充能更快（+25%）' }
  };
  const FX_BY_SLOT = {}; for (const k in FX) (FX_BY_SLOT[FX[k].s] = FX_BY_SLOT[FX[k].s] || []).push(k);
  // セット 8 種。from＝出る所（v0.13 で 草原・砂漠・雪山・火山・ボス・ルーレット の 6 つが出る）
  const WORLD_SET = ['wakaba', 'sand', 'silver', 'crimson', 'steel', 'abyss'];   // 世界ごとに出やすいセット（v0.13：雪山＝白銀・火山＝紅蓮）
  const SETS = {
    wakaba: { ja: '若葉', zh: '若叶', col: '#7fe08f', from: 'w1', two: ['速さ +10%', '速度 +10%'], four: ['やられた時、近くの仲間に盾', '被击败时给附近队友护盾'] },
    sand: { ja: '砂嵐', zh: '沙暴', col: '#e8c27a', from: 'w2', two: ['弾の速さ +15%', '炮弹速度 +15%'], four: ['3 発ごとに壁をぬける弾', '每 3 发一颗穿墙弹'] },
    silver: { ja: '白銀', zh: '白银', col: '#cfe8ff', from: 'w3', two: ['よろい +1', '护甲 +1'], four: ['当てた敵が少し遅くなる', '命中的敌人减速'] },
    crimson: { ja: '紅蓮', zh: '红莲', col: '#ff7a5c', from: 'w4', two: ['火力 +1', '火力 +1'], four: ['倒した敵が爆発する', '击败的敌人会爆炸'] },
    steel: { ja: '鋼鉄', zh: '钢铁', col: '#9aa6b8', from: 'w5', two: ['おうちの自衛 +1', '小屋自卫 +1'], four: ['おうちにおふとん +1', '小屋加 1 床被子'] },
    king: { ja: '王者', zh: '王者', col: '#ffd23a', from: 'boss', two: ['必殺技のたまり +20%', '必杀技充能 +20%'], four: ['必殺技を 2 回ためられる', '必杀技可存 2 次'] },
    abyss: { ja: '深淵', zh: '深渊', col: '#b07aff', from: 'hell', two: ['弾の威力 +20%', '炮弹威力 +20%'], four: ['のこり 1 台の時、威力 2 倍', '剩 1 辆时威力翻倍'] },
    bond: { ja: 'きずな', zh: '羁绊', col: '#ff9ad5', from: 'wheel', two: ['コイン +10%', '金币 +10%'], four: ['仲間が近いほど強い', '队友越近越强'] }
  };
  const ENH = [   // 強化：今の段 → 次の段の成功の確率と、失敗した時（JUN の指示 2026-11-15）
    null, [1, 'none'], [1, 'none'], [1, 'none'], [.9, 'lose'], [.8, 'lose'], [.7, 'lose'], [.6, 'down'], [.5, 'down'], [.4, 'down'], [.3, 'break']];
  const PITY_STEP = 0.05, BREAK_RATE = 0.10;
  function rng(seed) { let a = seed >>> 0 || 1; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const toInt = (v, lo, hi, d) => { const n = Math.floor(Number(v)); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : d; };

  /* ---------- 一人ずつの記録 ---------- */
  function newProfile(name) { return { name, coins: 0, parts: 0, charms: 0, car: 'a', gear: { gun: 0, body: 0, track: 0, charm: 0 }, bag: [], nextId: 1, pity: 0, wheelDry: 0, seed: (Date.now() % 1e9) | 0, buff: null, stats: { enh: 0, broke: 0, chests: 0, spins: 0 } }; }
  function cleanItem(it) {
    if (!it || typeof it !== 'object' || !SLOTS.includes(it.s)) return null;
    return { id: toInt(it.id, 1, 1e9, 1), s: it.s, r: toInt(it.r, 0, 3, 0), set: SETS[it.set] ? it.set : 'wakaba', lv: toInt(it.lv, 0, MAX_LV, 0), pi: toInt(it.pi, 0, 1e6, 0),
      fx: Array.isArray(it.fx) ? it.fx.filter(k => FX[k]).slice(0, 4) : [] };
  }
  function cleanProfile(p, name) {
    const o = newProfile(name); if (!p || typeof p !== 'object') return o;
    o.coins = toInt(p.coins, 0, 1e8, 0); o.parts = toInt(p.parts, 0, 1e7, 0); o.charms = toInt(p.charms, 0, 999, 0); o.car = CARS[p.car] ? p.car : 'a';
    o.bag = (Array.isArray(p.bag) ? p.bag : []).map(cleanItem).filter(Boolean).slice(0, 80);
    o.nextId = Math.max(toInt(p.nextId, 1, 1e9, 1), ...o.bag.map(i => i.id + 1), 1);
    for (const s of SLOTS) { const id = p.gear && toInt(p.gear[s], 0, 1e9, 0); o.gear[s] = id && o.bag.some(i => i.id === id && i.s === s) ? id : 0; }
    o.pity = Math.max(0, Math.min(1, Number(p.pity) || 0)); o.wheelDry = toInt(p.wheelDry, 0, 99, 0); o.seed = toInt(p.seed, 1, 2e9, o.seed);
    o.buff = p.buff === 'shield' || p.buff === 'power' ? p.buff : null;
    if (p.stats && typeof p.stats === 'object') for (const k in o.stats) o.stats[k] = toInt(p.stats[k], 0, 1e7, 0);
    return o;
  }
  function itemOf(pr, id) { return pr.bag.find(i => i.id === id) || null; }
  function equipped(pr) { const o = {}; for (const s of SLOTS) o[s] = pr.gear[s] ? itemOf(pr, pr.gear[s]) : null; return o; }
  function roll(pr) { const r = rng(pr.seed); const v = r(); pr.seed = (Math.floor(r() * 2e9) | 0) || 7; return v; }

  /* ---------- 装備を作る ---------- */
  function fxCount(r, lv) { return [0, 0, 1, 2][r] + (lv >= 5 ? 1 : 0) + (lv >= 10 ? 1 : 0); }
  function addFx(pr, it) { const pool = FX_BY_SLOT[it.s].filter(k => !it.fx.includes(k)); while (it.fx.length < fxCount(it.r, it.lv) && pool.length) it.fx.push(pool.splice(Math.floor(roll(pr) * pool.length), 1)[0]); }
  function makeItem(pr, opt) {
    const o = opt || {}; const s = SLOTS.includes(o.s) ? o.s : SLOTS[Math.floor(roll(pr) * 4)];
    let r = o.r; if (r === undefined) { const v = roll(pr), w = o.rw || [60, 28, 10, 2], sum = w.reduce((a, b) => a + b, 0); let acc = 0; r = 0; for (let i = 0; i < 4; i++) { acc += w[i] / sum; if (v < acc) { r = i; break; } } }
    const it = { id: pr.nextId++, s, r, set: SETS[o.set] ? o.set : 'wakaba', lv: 0, pi: 0, fx: [] }; addFx(pr, it); pr.bag.push(it);
    // 持ち物は BAG_MAX まで。あふれたら、付けていない一番弱い物を部品にする（新しい物は残す）
    if (pr.bag.length > BAG_MAX) { const used = Object.values(pr.gear), cand = pr.bag.filter(i => i !== it && !used.includes(i.id)).sort((x, y) => power(x) - power(y))[0]; if (cand) { pr.bag = pr.bag.filter(i => i !== cand); pr.parts += dismantleGain(cand); } }
    return it;
  }
  const BAG_MAX = 80;
  // 装備の強さ（v＝1〜8）。希少さと段で上がる
  function power(it) { return (it.r + 1) + it.lv * 0.4; }
  function itemStats(it) {
    const v = power(it);
    if (it.s === 'gun') return { bullet: 0.04 * v, power: Math.floor(v / 5) };
    if (it.s === 'body') return { armor: Math.floor(v / 4), inv: 0.3 * v };
    if (it.s === 'track') return { speed: 0.02 * v };
    return { coin: 0.05 * v, charge: 0.04 * v };
  }
  function statText(it, L) {
    const s = itemStats(it), t = [];
    if (s.bullet) t.push(L(`弾の速さ +${Math.round(s.bullet * 100)}%`, `弹速 +${Math.round(s.bullet * 100)}%`)); if (s.power) t.push(L(`火力 +${s.power}`, `火力 +${s.power}`));
    if (s.armor) t.push(L(`よろい +${s.armor}`, `护甲 +${s.armor}`)); if (s.inv) t.push(L(`無敵 +${s.inv.toFixed(1)} 秒`, `无敌 +${s.inv.toFixed(1)} 秒`));
    if (s.speed) t.push(L(`速さ +${Math.round(s.speed * 100)}%`, `速度 +${Math.round(s.speed * 100)}%`));
    if (s.coin) t.push(L(`コイン +${Math.round(s.coin * 100)}%`, `金币 +${Math.round(s.coin * 100)}%`)); if (s.charge) t.push(L(`必殺技 +${Math.round(s.charge * 100)}%`, `必杀技 +${Math.round(s.charge * 100)}%`));
    for (const k of it.fx) t.push('★' + L(FX[k].ja, FX[k].zh));
    return t;
  }
  function setCounts(pr) { const c = {}; for (const it of Object.values(equipped(pr))) if (it) c[it.set] = (c[it.set] || 0) + 1; return c; }

  /* ---------- 戦いに渡す強さ（上限つき。強くなりすぎないように） ---------- */
  const CAP = { speed: 1.32, bullet: 1.5, power: 2, armor: 2, inv: 3, coin: 1.8, charge: 1.6 };
  function mods(pr) {
    const car = CARS[pr.car] || CARS.a, m = { car: pr.car, sp: car.sp, speed: car.speed, bullet: car.bullet, power: 0, armor: car.armor, inv: car.inv, coin: 1, charge: 1, dmgMul: 1,
      bounce: 0, pierce: 0, grip: false, lifeUp: 0, tower: 0, futon: 0, spMax: 1, set4: {}, buff: pr.buff };
    for (const it of Object.values(equipped(pr))) {
      if (!it) continue; const s = itemStats(it);
      m.bullet += s.bullet || 0; m.power += s.power || 0; m.armor += s.armor || 0; m.inv += s.inv || 0; m.speed += s.speed || 0; m.coin += s.coin || 0; m.charge += s.charge || 0;
      for (const k of it.fx) { if (k === 'bounce') m.bounce = 1; else if (k === 'pierce') m.pierce = 1; else if (k === 'longInv') m.inv += 2; else if (k === 'lifeUp') m.lifeUp = 1;
        else if (k === 'swift') m.speed += 0.08; else if (k === 'grip') m.grip = true; else if (k === 'coin') m.coin += 0.2; else if (k === 'house') m.tower += 1; else if (k === 'charge') m.charge += 0.25; }
    }
    const sc = setCounts(pr);
    for (const k in sc) {
      if (sc[k] >= 2) { if (k === 'wakaba') m.speed += 0.1; else if (k === 'sand') m.bullet += 0.15; else if (k === 'silver') m.armor += 1; else if (k === 'crimson') m.power += 1;
        else if (k === 'steel') m.tower += 1; else if (k === 'king') m.charge += 0.2; else if (k === 'abyss') m.dmgMul += 0.2; else if (k === 'bond') m.coin += 0.1; }
      if (sc[k] >= 4) { m.set4[k] = 1; if (k === 'king') m.spMax = 2; if (k === 'steel') m.futon += 1; }
    }
    m.speed = Math.min(CAP.speed, m.speed); m.bullet = Math.min(CAP.bullet, m.bullet); m.power = Math.min(CAP.power, m.power); m.armor = Math.min(CAP.armor, m.armor);
    m.inv = Math.min(CAP.inv + 2, m.inv); m.coin = Math.min(CAP.coin, m.coin); m.charge = Math.min(CAP.charge, m.charge); m.tower = Math.min(2, m.tower);
    return m;
  }

  /* ---------- ガレージの操作（スマホから。結果を返す） ---------- */
  function enhCost(it) { return { coins: 15 * (it.lv + 1) * (it.r + 1), parts: 2 * (it.lv + 1) }; }
  function enhInfo(pr, it) {
    if (!it || it.lv >= MAX_LV) return null; const [p0, fail] = ENH[it.lv + 1], rate = Math.min(1, p0 + (p0 < 1 ? pr.pity : 0));
    return { to: it.lv + 1, rate, fail, breakRate: fail === 'break' ? BREAK_RATE : 0, cost: enhCost(it) };
  }
  function dismantleGain(it) { return 3 * (it.r + 1) + it.lv; }
  function act(pr, a) {
    const it = a.id ? itemOf(pr, toInt(a.id, 0, 1e9, 0)) : null;
    if (a.op === 'car') { if (!CARS[a.car]) return { ok: false }; pr.car = a.car; return { ok: true, msg: 'car' }; }
    if (a.op === 'equip') { if (!it) return { ok: false }; pr.gear[it.s] = pr.gear[it.s] === it.id ? 0 : it.id; return { ok: true, msg: pr.gear[it.s] ? 'equip' : 'unequip' }; }
    if (a.op === 'dismantle') { if (!it || Object.values(pr.gear).includes(it.id)) return { ok: false, msg: 'inuse' }; pr.bag = pr.bag.filter(i => i !== it); const g = dismantleGain(it); pr.parts += g; return { ok: true, msg: 'dismantle', parts: g }; }
    if (a.op === 'merge') {   // 同じ所・同じ希少さの装備 3 つ（付けていない物）→ 1 つ上の希少さ
      if (!it || it.r >= 3) return { ok: false }; const same = pr.bag.filter(i => i.s === it.s && i.r === it.r && !Object.values(pr.gear).includes(i.id));
      if (same.length < 3) return { ok: false, msg: 'need3' }; const use = [it, ...same.filter(i => i !== it)].slice(0, 3); if (!use.includes(it) || Object.values(pr.gear).includes(it.id)) return { ok: false, msg: 'inuse' };
      const sets = {}; for (const u of use) sets[u.set] = (sets[u.set] || 0) + 1; const set = Object.keys(sets).sort((x, y) => sets[y] - sets[x])[0];
      pr.bag = pr.bag.filter(i => !use.includes(i)); const n = makeItem(pr, { s: it.s, r: it.r + 1, set }); return { ok: true, msg: 'merge', item: n.id };
    }
    if (a.op === 'enh') {
      const info = enhInfo(pr, it); if (!info) return { ok: false };
      if (pr.coins < info.cost.coins || pr.parts < info.cost.parts) return { ok: false, msg: 'poor' };
      const guard = !!a.guard && pr.charms > 0 && info.fail !== 'none' && info.fail !== 'lose';
      pr.coins -= info.cost.coins; pr.parts -= info.cost.parts; it.pi += info.cost.parts; if (guard) pr.charms--; pr.stats.enh++;
      if (roll(pr) < info.rate) { it.lv++; addFx(pr, it); pr.pity = 0; return { ok: true, msg: 'up', lv: it.lv }; }
      pr.pity = Math.min(0.5, pr.pity + PITY_STEP);
      if (guard) return { ok: true, msg: 'guarded', lv: it.lv };
      if (info.fail === 'break' && roll(pr) < BREAK_RATE) { for (const s of SLOTS) if (pr.gear[s] === it.id) pr.gear[s] = 0; pr.bag = pr.bag.filter(i => i !== it); const back = Math.floor(it.pi / 2); pr.parts += back; pr.stats.broke++; return { ok: true, msg: 'broke', parts: back }; }
      if (info.fail === 'down' || info.fail === 'break') { it.lv = Math.max(0, it.lv - 1); return { ok: true, msg: 'down', lv: it.lv }; }
      return { ok: true, msg: 'fail', lv: it.lv };
    }
    return { ok: false };
  }

  /* ---------- 面のあとのルーレット ---------- */
  // 当たりの円。w＝割合（円の広さもこの割合）
  const WHEEL = [
    { k: 'coins', n: 30, w: 20, ja: 'コイン 30', zh: '金币 30', col: '#ffd23a' }, { k: 'gear', w: 12, ja: '装備', zh: '装备', col: '#c27bff' },
    { k: 'parts', n: 3, w: 16, ja: '部品 3', zh: '零件 3', col: '#8fd0ff' }, { k: 'coins', n: 60, w: 12, ja: 'コイン 60', zh: '金币 60', col: '#ffb53a' },
    { k: 'buff', b: 'shield', w: 8, ja: '次の面：たてで出発', zh: '下一关：带盾出发', col: '#7fe0ff' }, { k: 'charm', w: 7, ja: 'まもりの札', zh: '守护符', col: '#ff9ad5' },
    { k: 'parts', n: 6, w: 9, ja: '部品 6', zh: '零件 6', col: '#5fb8ff' }, { k: 'gear', w: 6, ja: '装備', zh: '装备', col: '#a46bff' },
    { k: 'buff', b: 'power', w: 6, ja: '次の面：火力 +1', zh: '下一关：火力 +1', col: '#ff8a5c' }, { k: 'coins', n: 200, w: 4, ja: 'コイン 200！', zh: '金币 200！', col: '#fff07a' }];
  const WHEEL_SUM = WHEEL.reduce((a, b) => a + b.w, 0);
  const WHEEL_PITY = 5;   // 5 回回して装備が出なければ、次は必ず装備
  function spin(pr, ctx) {   // ctx：{ world: 0/1, stars: 3 なら世界のセットが出やすい }
    let idx; if (pr.wheelDry >= WHEEL_PITY) idx = WHEEL.findIndex(w => w.k === 'gear');
    else { const v = roll(pr) * WHEEL_SUM; let acc = 0; idx = WHEEL.length - 1; for (let i = 0; i < WHEEL.length; i++) { acc += WHEEL[i].w; if (v < acc) { idx = i; break; } } }
    const w = WHEEL[idx], res = { idx, k: w.k, ja: w.ja, zh: w.zh }; pr.stats.spins++;
    if (w.k === 'gear') { pr.wheelDry = 0; const ws = WORLD_SET[(ctx && ctx.world) | 0] || 'wakaba', set = roll(pr) < 0.3 ? 'bond' : ws; const it = makeItem(pr, { set, rw: ctx && ctx.stars >= 3 ? [45, 35, 16, 4] : [60, 28, 10, 2] }); res.item = it.id; }
    else { pr.wheelDry++; if (w.k === 'coins') { const n = Math.round(w.n * mods(pr).coin); pr.coins += n; res.n = n; } else if (w.k === 'parts') { pr.parts += w.n; res.n = w.n; } else if (w.k === 'charm') pr.charms++; else if (w.k === 'buff') pr.buff = w.b; }
    return res;
  }
  function wheelSpins(stars) { return Math.min(4, 1 + (stars ? stars.reduce((a, b) => a + (b ? 1 : 0), 0) : 0)); }

  /* ---------- 宝箱の中身（拾った時） ---------- */
  const CHEST = { wood: { life: 10, col: '#b0763a' }, silver: { life: 12, col: '#cfd8e2' }, gold: { life: 15, col: '#ffd23a' } };
  function openChest(pr, kind, ctx) {
    const res = { kind }, m = mods(pr), ws = WORLD_SET[(ctx && ctx.world) | 0] || 'wakaba'; pr.stats.chests++;
    if (kind === 'wood') { const v = roll(pr); if (v < 0.1) res.item = makeItem(pr, { set: ws, rw: [85, 15, 0, 0] }).id; else if (v < 0.55) { res.parts = 1 + Math.floor(roll(pr) * 2); pr.parts += res.parts; } else { res.coins = Math.round((10 + Math.floor(roll(pr) * 16)) * m.coin); pr.coins += res.coins; } }
    else if (kind === 'silver') { res.coins = Math.round((30 + Math.floor(roll(pr) * 31)) * m.coin); pr.coins += res.coins; if (roll(pr) < 0.15) { pr.charms++; res.charm = 1; } if (roll(pr) < 0.45) res.item = makeItem(pr, { set: roll(pr) < 0.3 ? 'king' : ws, rw: [0, 70, 30, 0] }).id; }
    else { res.item = makeItem(pr, { set: roll(pr) < 0.5 ? 'king' : ws, rw: [0, 0, 70, 30] }).id; res.share = 50; }
    return res;
  }
  // 面のクリアのコイン（一人ずつ）
  function clearCoins(pr, stars) { const n = Math.round((20 + 10 * (stars ? stars.reduce((a, b) => a + b, 0) : 0)) * mods(pr).coin); pr.coins += n; return n; }

  const api = { BAG_MAX, SLOTS, SLOT_NAME, RARITY, CARS, SP_NAME, SP_NEED, FX, SETS, ENH, WHEEL, WHEEL_SUM, CHEST, MAX_LV,
    newProfile, cleanProfile, itemOf, equipped, makeItem, itemStats, statText, setCounts, mods, enhInfo, enhCost, dismantleGain, act, spin, wheelSpins, openChest, clearCoins, power };
  root.TankGear = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);

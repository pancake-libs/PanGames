/* ==================== P13（v0.30）：アイデアポスト と「きょうの しゅくだい」（アイデア 66） ====================
   - 設計：v030-design.md §8（web の がわ）・§9（記録 'tank-tv30-post'）。サーバーの 道は §8.6（/ideas*。無い 時は 404 → この 部品は だまる）
   - ゲームは あつめる だけ。こどもの ことばで ゲームが かわる ことは ない。AI は つかわない
   - データは tank-postdata.js（window.TankPostData。tools/v030-postgen.mjs が post-lines.json から 作る）
   - テレビ：その日の きろく（log）・しゅくだい（1 日 1 つ）・スライド・ステッカー帳・「みんなの ポスト」（ロビーの P）・🌟（つかわれた アイデア）・クレジットの ページ
   - スマホ：#tv30Post（だれ → しつもん → こたえ（🎤・⌨・📷・👆）→ たしかめ → 📮）。🎤 は おした 時だけ。時間の 決まりは ない
   - スマホ → テレビ：cmd {a:'tv30', op:'post'|'hw', …}。テレビ → スマホ：presence の g.tv30.hw・g.tv30.post（g.tv30 の ほかの 欄は P13 の はなしの 半分の もの）
   - node でも 読める（純粋な 関数だけ module.exports）。ブラウザでは window.TankPost
   ==================== */
(function (root) {
  'use strict';
  const TV30P_KEY = 'tank-tv30-post';
  const KINDS = ['boss_move', 'boss_line', 'boss_pal', 'stage', 'enemy', 'vehicle', 'gear', 'color', 'sound', 'mini', 'talk', 'hard', 'free'];
  const BOSS_KINDS = ['boss_move', 'boss_line', 'boss_pal'];
  const TV30P_HW_MAX = 10, TV30P_ST_MAX = 200, TV30P_NAMES_MAX = 12, TV30P_SEEN_MAX = 200, TV30P_HIST = 4, TV30P_OLD = 3;
  const TV30P_CLIPS = 4, TV30P_TEXT = 400, TV30P_NAME = 12, TV30P_BOOK_IDEAS = 20, TV30P_SNIP = 20;
  const TV30P_SLIDE_STAGES = 3, TV30P_SLIDE_MIN = 20;          // スライドを 出す：ボスの 面の あと・3 面 おわった あと・20 分 あそんだ あと
  const TV30P_LOBBY_WAIT_MS = 1500;                            // ロビーに もどって から（ほかの スライドが 先に 出る ための 間）
  const TV30P_POLL_MS = 30000, TV30P_STT_MS = 8000;
  const TV30P_VER = '0.31.0';   // アイデアに つける ゲームの 版（v0.31.0）
  // 名前（かな）。ボス 6 人は v0.29 の persona と 同じ
  const BOSS_NAME = { bigtank: ['おおきな せんしゃ', '大坦克'], sandship: ['すなの ふね', '沙之船'], snowman: ['ゆきだるま', '雪人'], dragon: ['ドラゴン', '火龙'], core: ['ようさいコア', '要塞核心'], king: ['おう', '国王'],
    twin: ['ふたごほう', '双炮坦克'], engineer: ['こうへいしゃ', '工兵车'], burrower: ['すなもぐり', '钻沙者'], scorpion: ['さそり せんしゃ', '蝎子坦克'], plow: ['じょせつしゃ', '除雪车'], icegun: ['こおりの ほうだい', '冰之炮台'],
    flamer: ['かえん せんしゃ', '火焰喷射车'], golem: ['ようがん ゴーレム', '熔岩魔像'], sisA: ['ふたご せんしゃ', '双子坦克'], sisB: ['ふたご せんしゃ', '双子坦克'], airship: ['くうちゅうてい', '飞艇'], shadow: ['やみの せんしゃ', '暗黑坦克'], superstar: ['ちょう ボス', '超级首领'] };
  const WORLD_NAME = [['そうげん', '草原', '🌿'], ['さばく', '沙漠', '🏜'], ['ゆきやま', '雪山', '❄'], ['かざん', '火山', '🌋'], ['きかい ようさい', '机械要塞', '⚙'], ['じごく', '地狱', '🔥']];
  const VEH_NAME = { heli: ['ヘリコプター', '直升机', '🚁'], boat: ['ボート', '小船', '⛵'], train: ['れっしゃほう', '列车炮', '🚂'], exc: ['ショベルカー', '挖掘机', '🚜'] };
  const VEH_OF = { h: 'heli', b: 'boat', t: 'train', x: 'exc' };   // sim の veh_on の kind → 名前
  const clampI = (x, a, b) => Math.max(a, Math.min(b, Number.isFinite(+x) ? Math.floor(+x) : a));
  const uniqPush = (a, v, max) => { const i = a.indexOf(v); if (i >= 0) a.splice(i, 1); a.push(v); while (a.length > max) a.shift(); return a; };

  /* ==================== 純粋な 部分 ==================== */
  // 1 日＝ところの 日づけ。朝 4 時で かわる（20261117 の 数）
  function dayOf(now) { const d = new Date((now === undefined ? Date.now() : now) - 4 * 3600e3); return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate(); }
  const BAD_NAME = new RegExp('[\\u0000-\\u001f\\u007f-\\u009f\\u200b-\\u200f\\u2028\\u2029\\ufeff/\\\\:*?"<>|]', 'g');
  // 名前：1〜12 文字。制御文字・パスの 文字（/ \ : * ? " < > |）は とる
  function cleanName(s) { const t = String(s == null ? '' : s).normalize('NFC').replace(BAD_NAME, '').replace(/\s+/g, ' ').trim().replace(/^\.+/, '');
    return [...t].slice(0, TV30P_NAME).join('').trim(); }
  const isId = s => typeof s === 'string' && /^[0-9a-f]{12}$/.test(s);
  const isHwId = s => typeof s === 'string' && /^\d{8}$/.test(s);
  const okSub = s => typeof s === 'string' && /^[A-Za-z0-9]{0,12}$/.test(s) ? s : '';
  function emptyLog(day) { return { day: day | 0, n: 0, min: 0, boss: [], world: [], lost: 0, veh: [], gear: 0, mini: 0, talk: [] }; }
  function cleanLog(v) {
    v = v && typeof v === 'object' ? v : {}; const o = emptyLog(clampI(v.day, 0, 99991231));
    for (const k of ['n', 'min', 'lost', 'gear', 'mini']) o[k] = clampI(v[k], 0, 999);
    const ids = (a, ok, max) => (Array.isArray(a) ? a : []).filter(ok).filter((x, i, s) => s.lastIndexOf(x) === i).slice(-max);
    o.boss = ids(v.boss, x => typeof x === 'string' && BOSS_NAME[x], 8); o.talk = ids(v.talk, x => typeof x === 'string' && BOSS_NAME[x], 6);
    o.veh = ids(v.veh, x => typeof x === 'string' && VEH_NAME[x], 4); o.world = ids(v.world, x => Number.isInteger(x) && x >= 0 && x < WORLD_NAME.length, 6);
    return o;
  }
  // 読む 時に きれいに：知らない 欄は すてる、数は はばに、名前は cleanName、しゅくだいは 新しい 10、ステッカーは 1 人 200・12 人、seen は 200
  function cleanStore(v) {
    v = v && typeof v === 'object' ? v : {}; const c = v.cfg && typeof v.cfg === 'object' ? v.cfg : {};
    const out = { v: 1, cfg: { on: c.on === 0 ? 0 : 1, keep: c.keep === 0 ? 0 : 1 }, turn: clampI(v.turn, 0, 9999), log: cleanLog(v.log), hw: [], st: {}, seen: [] };
    const hw = Array.isArray(v.hw) ? v.hw : [];
    for (const h of hw) { if (!h || typeof h !== 'object' || !isHwId(h.id) || !KINDS.includes(h.kind) || out.hw.some(x => x.id === h.id)) continue;
      const done = []; for (const n of Array.isArray(h.done) ? h.done : []) { const nm = cleanName(n); if (nm && !done.includes(nm) && done.length < TV30P_NAMES_MAX) done.push(nm); }
      out.hw.push({ id: h.id, kind: h.kind, sub: okSub(h.sub), var: clampI(h.var, 0, 2), shown: h.shown ? 1 : 0, done }); }
    out.hw.sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0)); out.hw = out.hw.slice(-TV30P_HW_MAX);
    const st = v.st && typeof v.st === 'object' && !Array.isArray(v.st) ? v.st : {}, names = [];
    for (const k of Object.keys(st)) { const nm = cleanName(k); if (!nm || names.includes(nm) || !Array.isArray(st[k])) continue;
      const list = st[k].filter(e => e && typeof e === 'object' && KINDS.includes(e.k)).slice(-TV30P_ST_MAX).map(e => ({ d: clampI(e.d, 0, 99991231), k: e.k, s: okSub(e.s), g: e.g ? 1 : 0 }));
      if (!list.length) continue; names.push(nm); out.st[nm] = list; }
    if (names.length > TV30P_NAMES_MAX) { const last = n => Math.max(...out.st[n].map(e => e.d)); names.sort((a, b) => last(b) - last(a)); for (const n of names.slice(TV30P_NAMES_MAX)) delete out.st[n]; }
    out.seen = (Array.isArray(v.seen) ? v.seen : []).filter(isId).filter((x, i, s) => s.lastIndexOf(x) === i).slice(-TV30P_SEEN_MAX);
    return out;
  }
  // その日の きろくに 1 つ たす（store を かえて かえす）。日が かわったら きろくを あたらしく する
  //   ev：{k:'stage', world, boss:[…]}・{k:'clear'}・{k:'lose'}・{k:'mini'}・{k:'veh', v}・{k:'gear'}・{k:'talk', boss}・{k:'min', n}
  function logAdd(store, ev, now) {
    const day = dayOf(now); if (!store.log || store.log.day !== day) store.log = emptyLog(day); const L = store.log; if (!ev || typeof ev !== 'object') return store;
    if (ev.k === 'stage') { if (Number.isInteger(ev.world) && ev.world >= 0 && ev.world < WORLD_NAME.length) uniqPush(L.world, ev.world, 6);
      for (const b of Array.isArray(ev.boss) ? ev.boss : []) if (BOSS_NAME[b]) uniqPush(L.boss, b, 8); }
    else if (ev.k === 'clear') L.n = Math.min(999, L.n + 1);
    else if (ev.k === 'lose') { L.n = Math.min(999, L.n + 1); L.lost = Math.min(999, L.lost + 1); }
    else if (ev.k === 'mini') { L.n = Math.min(999, L.n + 1); L.mini = Math.min(999, L.mini + 1); }
    else if (ev.k === 'veh') { const v = VEH_NAME[ev.v] ? ev.v : VEH_OF[ev.v]; if (v) uniqPush(L.veh, v, 4); }
    else if (ev.k === 'gear') L.gear = Math.min(999, L.gear + 1);
    else if (ev.k === 'talk') { if (BOSS_NAME[ev.boss]) uniqPush(L.talk, ev.boss, 6); }
    else if (ev.k === 'min') L.min = Math.min(999, L.min + Math.max(1, ev.n | 0));
    return store;
  }
  const hasAny = l => !!(l && (l.n > 0 || l.world.length || l.boss.length || l.veh.length || l.gear > 0 || l.mini > 0 || l.talk.length || l.lost > 0));
  const NEED = {
    boss_move: l => l.boss.length > 0, boss_line: l => l.boss.length > 0, boss_pal: l => l.boss.length > 0, stage: l => l.world.length > 0, enemy: l => l.n > 0 || l.world.length > 0,
    vehicle: l => l.veh.length > 0, gear: l => l.gear > 0, color: () => true, sound: l => l.boss.length > 0, mini: l => l.mini > 0, talk: l => l.talk.length > 0, hard: l => l.lost > 0, free: () => false };
  // たねで きまる ばらばら（mulberry32）
  function rng(seed) { let a = (seed | 0) ^ 0x9e3779b9; return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const last = a => (a && a.length ? a[a.length - 1] : '');
  function subName(kind, sub, lang) {
    const li = lang === 'zh' ? 1 : 0; if (BOSS_NAME[sub]) return BOSS_NAME[sub][li];
    if (/^w[0-5]$/.test(sub)) return WORLD_NAME[+sub[1]][li]; if (VEH_NAME[sub]) return VEH_NAME[sub][li]; return '';
  }
  // しゅくだいの 文（{boss}・{world} を 入れる）
  function hwQ(kind, sub, vi, data) {
    const H = data && data.homework && data.homework[kind]; if (!H) return { ja: '', zh: '' }; const t = H.v[clampI(vi, 0, H.v.length - 1)];
    const f = (s, l) => String(s || '').replace(/\{boss\}/g, subName(kind, sub, l) || (l === 'zh' ? '首领' : 'ボス')).replace(/\{world\}/g, subName(kind, sub, l) || (l === 'zh' ? '这个世界' : 'この せかい'));
    return { ja: f(t.ja, 'ja'), zh: f(t.zh, 'zh') };
  }
  function hwCards(kind, sub, data) { const H = data && data.homework && data.homework[kind]; if (!H) return []; const per = H.per && H.per[sub];
    return (Array.isArray(per) && per.length === 3 ? per : H.ex).map(c => ({ ic: c.ic, ja: c.ja, zh: c.zh })); }
  // 1 日 1 つの しゅくだい。history＝まえの しゅくだい（kind の 文字か {kind} の じゅん。さいごが 新しい）。seed＝日（20261117）
  function pickHomework(log, history, seed, data) {
    if (!log || typeof log !== 'object') return null; log = cleanLog(log); if (!hasAny(log)) return null;
    const cands = KINDS.filter(k => NEED[k](log)), recent = (Array.isArray(history) ? history : []).map(x => (typeof x === 'string' ? x : x && x.kind)).slice(-TV30P_HIST);
    let c2 = cands.filter(k => !recent.includes(k)); if (!c2.length) c2 = cands; if (!c2.length) c2 = ['free'];
    const r = rng(seed), w = c2.map(k => (BOSS_KINDS.includes(k) ? 2 : 1)), tot = w.reduce((a, b) => a + b, 0); let u = r() * tot, kind = c2[c2.length - 1];
    for (let i = 0; i < c2.length; i++) { u -= w[i]; if (u < 0) { kind = c2[i]; break; } }
    const sub = BOSS_KINDS.includes(kind) || kind === 'sound' ? last(log.boss) : kind === 'talk' ? last(log.talk) : kind === 'stage' ? 'w' + last(log.world) : kind === 'vehicle' ? last(log.veh) : '';
    const vi = Math.floor(r() * 3) % 3;
    return { id: String(seed), kind, sub, var: vi, q: hwQ(kind, sub, vi, data), cards: hwCards(kind, sub, data) };
  }
  // ステッカー：しゅくだい 1 つに 1 人 1 まい。しゅくだい なしの アイデアは 💡 を 1 日 1 人 1 まい
  function stickerFor(store, name, hw, day) {
    const nm = cleanName(name); if (!nm) return { give: false, k: '', s: '' }; const mine = (store && store.st && store.st[nm]) || [];
    if (hw && KINDS.includes(hw.kind)) { const e = store && store.hw ? store.hw.find(h => h.id === hw.id) : null;
      const got = e ? e.done.includes(nm) : mine.some(x => !x.g && x.k === hw.kind && String(x.d) === String(hw.id));
      return { give: !got, k: hw.kind, s: okSub(hw.sub || '') }; }
    return { give: !mine.some(x => !x.g && x.k === 'free' && x.d === (day | 0)), k: 'free', s: '' };
  }
  // ポストに はいった：ステッカーを わたす（store を かえる）。hw の きろくが まだ 無い（その日の しゅくだい）時は つくる
  function postAdd(store, name, hw, day) {
    const nm = cleanName(name), sk = stickerFor(store, nm, hw, day); if (!nm) return { store, sticker: sk };
    if (hw && KINDS.includes(hw.kind) && isHwId(hw.id)) { let e = store.hw.find(h => h.id === hw.id);
      if (!e) { e = { id: hw.id, kind: hw.kind, sub: okSub(hw.sub || ''), var: clampI(hw.var, 0, 2), shown: 0, done: [] }; store.hw.push(e); store.hw.sort((a, b) => (a.id < b.id ? -1 : 1)); store.hw = store.hw.slice(-TV30P_HW_MAX); }
      if (!e.done.includes(nm) && e.done.length < TV30P_NAMES_MAX) e.done.push(nm); }
    if (sk.give) addSticker(store, nm, { d: hw && isHwId(hw.id) ? +hw.id : day | 0, k: sk.k, s: sk.s, g: 0 });
    return { store, sticker: sk };
  }
  function addSticker(store, nm, e) {
    if (!store.st[nm]) { const names = Object.keys(store.st); if (names.length >= TV30P_NAMES_MAX) { const lastD = n => Math.max(0, ...store.st[n].map(x => x.d)); names.sort((a, b) => lastD(a) - lastD(b)); delete store.st[names[0]]; } store.st[nm] = []; }
    store.st[nm].push(e); if (store.st[nm].length > TV30P_ST_MAX) store.st[nm].splice(0, store.st[nm].length - TV30P_ST_MAX); return store;
  }
  // いま こたえられる しゅくだい：きょうの（だれかが こたえても のこる）＋ まだ だれも こたえて いない 新しい 3 つ
  function openHw(store, day) {
    const today = String(day), out = [], t = store.hw.find(h => h.id === today); if (t) out.push(t);
    for (const h of store.hw.slice().reverse()) { if (out.length >= 1 + TV30P_OLD) break; if (h.id !== today && !h.done.length) out.push(h); }
    return out;
  }
  const badgeN = (store, day) => openHw(store, day).filter(h => !h.done.length).length;
  // ナレーターの 録った 声（v0.30 統合）：{name} の ない 文だけ /voice/t30_narr_post_<n>.ogg（n は {name} の ない 文の じゅん。tools/v030-gen.mjs の 台本と 同じ）。ほかは ライブの 声
  function voNarr(data, text) { const nr = ((data && data.narrator) || []).filter(l => l && typeof l.ja === 'string' && !l.ja.includes('{')); const i = nr.findIndex(l => l.ja === text); return i < 0 ? '' : 't30_narr_post_' + (i + 1); }

  const api = { KEY: TV30P_KEY, KINDS, BOSS_KINDS, BOSS_NAME, WORLD_NAME, VEH_NAME, dayOf, cleanName, cleanStore, cleanLog, emptyLog, logAdd, pickHomework, stickerFor, postAdd, addSticker, openHw, badgeN, voNarr, hwQ, hwCards, subName, hasAny,
    CONST: { TV30P_HW_MAX, TV30P_ST_MAX, TV30P_NAMES_MAX, TV30P_SEEN_MAX, TV30P_HIST, TV30P_OLD, TV30P_CLIPS, TV30P_TEXT, TV30P_SLIDE_STAGES, TV30P_SLIDE_MIN } };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (typeof window === 'undefined' || typeof document === 'undefined') { root.TankPost = api; return; }

  /* ==================== ここから ブラウザだけ ==================== */
  let C = null;
  const D = () => root.TankPostData || null;
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  // v0.31：日本語だけ（tank.html の JA_ONLY）。中国語の 小さい 行は 出さない（データは 残す）
  const ZS = s => (window.TANK_JA_ONLY ? '' : `<small>${esc(s)}</small>`);
  const Lx = (ja, zh) => C.L(ja, zh);
  const LANGx = () => (C.lang() === 'zh' ? 'zh' : 'ja');
  const U = (k, vars) => { const u = D() && D().ui[k]; if (!u) return ''; let s = Lx(u.ja, u.zh); for (const v in vars || {}) s = s.split('{' + v + '}').join(vars[v]); return s; };
  const Ub = (k, vars) => { const u = D() && D().ui[k]; if (!u) return ['', '']; return [u.ja, u.zh].map(s => { for (const v in vars || {}) s = s.split('{' + v + '}').join(vars[v]); return s; }); };
  const icOf = k => (D() && D().stickerIcons[k]) || '💡';
  function subIc(sub) { if (/^w[0-5]$/.test(sub)) return WORLD_NAME[+sub[1]][2]; if (VEH_NAME[sub]) return VEH_NAME[sub][2]; return ''; }
  // NG の ことばを ★ に（テレビの 一覧。ファイルには 本当の ことばが のこる）
  function mask(text) { const TE = root.TalkEngine, ng = root.TankChatData || root.TankTalkData; let t = String(text || '');
    try { for (const l of ['ja', 'zh']) t = TE && TE.maskNG && root.TankChatData ? TE.maskNG(t, '', l, root.TankChatData) : root.TankTalkVoice ? root.TankTalkVoice.maskNG(t, '', l, ng) : t; } catch (e) { /* 字は そのまま */ }
    return t; }
  const snip = t => { const a = [...String(t || '').replace(/\s+/g, ' ').trim()]; return a.length > TV30P_SNIP ? a.slice(0, TV30P_SNIP).join('') + '…' : a.join(''); };
  function attach(ctx) { C = api.ctx = ctx; if (!D()) { console.warn('P13：アイデアポストの データが ありません'); return; } css(); if (ctx.ROLE === 'tv') tvInit(); else padInit(); api.ready = true; }

  function css() { if (document.getElementById('tv30PostCss')) return; const s = document.createElement('style'); s.id = 'tv30PostCss'; s.textContent = `
#tv30Post{position:fixed;inset:0;z-index:45;background:#16241c;color:#fff;display:flex;flex-direction:column;gap:8px;padding:8px var(--padw-sr,14px) 10px var(--padw-sl,14px);overflow:auto;font-family:var(--body);-webkit-user-select:none;user-select:none}
#tv30Post.hide{display:none}#tv30Post .top{display:flex;gap:8px;align-items:center}
#tv30Post .who{flex:1 1 auto;text-align:left;border-radius:99px;border:3px solid #ffd23a;background:#24382c;color:#ffd23a;font:inherit;font-weight:900;font-size:clamp(14px,4.4vh,19px);padding:4px 14px;min-height:44px}
#tv30Post .x{flex:0 0 auto;min-width:48px;min-height:44px;border-radius:99px;border:3px solid #fff;background:transparent;color:#fff;font:inherit;font-weight:900;font-size:18px}
#tv30Post .q{background:#fff6dc;color:#1b2a22;border-radius:14px;padding:8px 12px;font-weight:900;font-size:clamp(15px,4.8vh,21px);line-height:1.3}#tv30Post .q small{display:block;font-size:.7em;opacity:.75;font-weight:700}
#tv30Post .q .k{float:left;font-size:1.6em;margin-right:8px;line-height:1}
#tv30Post .ex{display:flex;gap:6px;flex-wrap:wrap}#tv30Post .ex span{border-radius:99px;background:#2e4636;padding:3px 10px;font-size:clamp(12px,3.6vh,15px);font-weight:700}
#tv30Post .row{display:flex;flex-wrap:nowrap;gap:10px;align-items:stretch}#tv30Post .row>*{min-width:0}
#tv30Post .mic{flex:1 1 55%;min-height:min(34vh,150px);border-radius:24px;border:5px solid #10201a;box-shadow:0 7px 0 #10201a,0 0 0 calc(var(--lv,0)*14px) rgba(255,90,90,.45);background:#fff3b0;color:#10201a;font:inherit;font-weight:900;font-size:clamp(16px,5vh,22px);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px}
#tv30Post .mic i{font-style:normal;font-size:clamp(36px,13vh,60px);line-height:1}#tv30Post .mic.rec{background:#ff8a8a;animation:tv30Pulse 1s infinite}#tv30Post .mic.up{background:#c9cfc9}
#tv30Post .side{flex:1 1 45%;display:flex;flex-direction:column;gap:8px}
#tv30Post .btn{min-height:min(13vh,58px);border-radius:14px;border:3px solid #10201a;box-shadow:0 4px 0 #10201a;background:#fff;color:#1b2a22;font:inherit;font-weight:900;font-size:clamp(14px,4.2vh,18px);line-height:1.15;padding:4px 8px}
#tv30Post .btn:active,#tv30Post .mic:active{transform:translateY(3px);box-shadow:0 1px 0 #10201a}#tv30Post .btn[disabled]{opacity:.4}
#tv30Post .btn.ok{background:#7fe08f}#tv30Post .btn.post{background:#ffd23a;min-height:min(30vh,110px);font-size:clamp(20px,6.4vh,30px)}#tv30Post .btn.sub{background:#e8f4ff}
#tv30Post .acts{display:flex;gap:8px;flex-wrap:wrap}#tv30Post .acts .btn{flex:1 1 30%}
#tv30Post .cards{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}#tv30Post .cards button{min-height:min(30vh,110px);border-radius:16px;border:4px solid #10201a;box-shadow:0 5px 0 #10201a;background:#fff;color:#1b2a22;font:inherit;font-weight:900;font-size:clamp(15px,4.6vh,20px);line-height:1.15}
#tv30Post .cards button i{display:block;font-style:normal;font-size:1.6em}#tv30Post .cards button small{display:block;font-size:.7em;opacity:.75}
#tv30Post .heard{background:#24382c;border-radius:12px;padding:6px 10px;font-weight:900;font-size:clamp(14px,4.2vh,18px);line-height:1.3}#tv30Post .heard b{color:#ffd23a}
#tv30Post .msg{text-align:center;font-weight:900;font-size:clamp(13px,4vh,17px);color:#ffe9a8}#tv30Post .msg.err{color:#ff9a8a}
#tv30Post textarea,#tv30Post input[type=text]{width:100%;box-sizing:border-box;border-radius:12px;border:3px solid #ffd23a;background:#fff;color:#1b2a22;font:inherit;font-size:18px;font-weight:700;padding:8px}#tv30Post textarea{min-height:min(30vh,120px)}
#tv30Post .names{display:flex;gap:8px;flex-wrap:wrap}#tv30Post .names button{border-radius:99px;border:3px solid #10201a;background:#fff6dc;color:#1b2a22;font:inherit;font-weight:900;font-size:18px;padding:6px 14px;min-height:46px}#tv30Post .names button.on{background:#ffd23a}
#tv30Post .priv{background:#2b4a8a;border-radius:12px;padding:6px 10px;font-weight:900;font-size:14px;display:flex;gap:8px;align-items:center}#tv30Post .priv button{margin-left:auto;border-radius:99px;border:2px solid #fff;background:none;color:#fff;font:inherit;font-weight:900;padding:2px 12px;min-height:36px}
#tv30Post img.ph{max-height:min(30vh,120px);max-width:45%;border-radius:10px;border:3px solid #fff;object-fit:contain;background:#fff}
#tv30Post .hws button{display:block;width:100%;text-align:left;margin-bottom:8px}
#tv30Post .env{position:relative;height:min(34vh,130px);display:flex;align-items:center;justify-content:center;font-size:clamp(50px,18vh,90px)}#tv30Post .env b{position:absolute;animation:tv30Env 1.1s ease-in forwards}#tv30Post .env i{font-style:normal}
#tv30Post .stk{display:flex;flex-direction:column;align-items:center;gap:6px;animation:tv30Pop .5s ease-out}
#tv30Post .stk .disc{position:relative;width:min(34vh,130px);height:min(34vh,130px);border-radius:50%;border:6px solid #ffd23a;background:#fff6dc;display:flex;align-items:center;justify-content:center;font-size:min(16vh,62px);box-shadow:0 0 0 6px #10201a,0 0 30px #ffd23a}
#tv30Post .stk .disc canvas{position:absolute;inset:8%;width:84%;height:84%;border-radius:50%}#tv30Post .stk .disc em{position:absolute;right:-6px;bottom:-6px;font-style:normal;font-size:.6em;background:#10201a;border-radius:50%;padding:4px}
#tv30Post .stk h3{margin:0;font-family:var(--display);font-weight:400;color:#ffd23a;font-size:clamp(20px,6.4vh,30px);text-align:center}
#navBox button.tv30p{background:#ffe7a8}#navBox button.tv30p b{display:inline-block;min-width:1.4em;margin-left:4px;border-radius:99px;background:#e4483f;color:#fff;font-size:.85em;padding:0 4px}
@keyframes tv30Pulse{0%,100%{filter:brightness(1)}50%{filter:brightness(1.18)}}
@keyframes tv30Env{0%{transform:translate(-40vw,0) rotate(-20deg);opacity:1}70%{transform:translate(0,0) rotate(0);opacity:1}100%{transform:translate(0,4vh) scale(.4);opacity:0}}
@keyframes tv30Pop{0%{transform:scale(.3);opacity:0}70%{transform:scale(1.1);opacity:1}100%{transform:scale(1)}}
#tv30Badge{position:absolute;z-index:9;right:3.5vw;bottom:4vh;padding:8px 16px;border-radius:99px;background:#ffd23a;border:3px solid #1b2a22;font-size:22px;font-weight:900;color:#1b2a22;cursor:pointer;box-shadow:0 4px 0 #1b2a22}#tv30Badge.hide{display:none}
#tv30Book{position:absolute;inset:4vh 4vw;z-index:58;background:#fff6dc;color:#1b2a22;border:6px solid #1b2a22;border-radius:2vh;padding:2vh 2.4vw;display:flex;flex-direction:column;gap:1.2vh;font-size:2.3vh;overflow:hidden}
#tv30Book.hide{display:none}#tv30Book h2{margin:0;font-size:3.8vh;display:flex;gap:2vw;align-items:baseline}#tv30Book h2 small{font-size:2vh;opacity:.7}
#tv30Book .cols{display:flex;gap:2vw;flex:1 1 auto;min-height:0}#tv30Book .col{flex:1 1 0;min-width:0;display:flex;flex-direction:column;gap:.8vh;overflow:hidden}#tv30Book h3{margin:0;font-size:2.8vh;color:#6a4a00}
#tv30Book .nm{display:flex;align-items:center;gap:.6vw;padding:.5vh .6vw;border-radius:1vh;background:#fff}#tv30Book .nm b{flex:0 0 9vw;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#tv30Book .nm .sks{flex:1 1 auto;display:flex;gap:.3vw;flex-wrap:nowrap;overflow:hidden}#tv30Book .nm .sks span{flex:0 0 auto;width:3.8vh;height:3.8vh;border-radius:50%;border:.3vh solid #1b2a22;background:#fff3b0;display:flex;align-items:center;justify-content:center;font-size:2.2vh}
#tv30Book .nm .sks span.pic{background-size:84%;background-position:center;background-repeat:no-repeat;position:relative}#tv30Book .nm .sks span.pic em{position:absolute;right:-.6vh;bottom:-.6vh;font-style:normal;font-size:1.5vh}
#tv30Book .nm .sks span.g{background:#ffd23a;box-shadow:0 0 .8vh #ffb000;border-color:#b07800}#tv30Book .nm i{font-style:normal;flex:0 0 auto;font-weight:900;color:#6a4a00}
#tv30Book .idea{display:flex;align-items:center;gap:.8vw;padding:.4vh .6vw;border-radius:1vh;background:#fff;white-space:nowrap}#tv30Book .idea .d{flex:0 0 4.5vw;opacity:.7}#tv30Book .idea .n{flex:0 0 8vw;font-weight:900;overflow:hidden;text-overflow:ellipsis}
#tv30Book .idea .t{flex:1 1 auto;overflow:hidden;text-overflow:ellipsis}#tv30Book .idea button{flex:0 0 auto;font:inherit;font-weight:900;border-radius:99px;border:.3vh solid #1b2a22;background:#e8ffe0;padding:.2vh 1vw}#tv30Book .idea button.on{background:#ffd23a}
#tv30Book .idea .a{flex:0 0 auto;color:#b07800;font-weight:900}#tv30Book .foot{font-size:1.9vh;opacity:.7}#tv30Book .none{opacity:.6}
#tv30PostRows{margin:0}#tv30PostRows p{margin:.4vh 0}#tv30PostRows button{margin:.3vh .4vw;padding:.3vh 1vw;border-radius:99px;border:3px solid #1b2a22;background:#fff;font-weight:800}#tv30PostRows button.on{background:#ffd23a}`;
    document.head.appendChild(s); }

  /* ==================== テレビ ==================== */
  const T = { store: null, box: -1, ideas: [], credits: [], polled: -1e9, playSec: 0, talkSeen: '', pend: 0, pendBoss: 0, lobbyAt: 0, book: 0, mine: {}, doneIds: [], nowSeq: 0, nowId: '', sig: '', badgeSig: '', rowsSig: '',
    speaking: 0, audio: null, playing: '', slideHw: null, gotCredits: 0, dayChk: 0 };
  const now0 = () => (api.now ? api.now() : Date.now());   // 確かめ用に 時計を かえられる
  const today = () => dayOf(now0());
  function tvSave() { C.writeJSON(TV30P_KEY, T.store); }
  function tvInit() {
    T.store = cleanStore(C.readJSON(TV30P_KEY));
    const send = C.room.presence; C.room.presence = function (p) { if (p && p.role === 'tv' && p.g) { try { mergeTv30(p.g, tvPack()); } catch (e) { console.warn('P13：ポストの 様子を 作れませんでした', e); } } return send.call(C.room, p); };
    C.room.on('cmd', m => { const d = m.data; if (!d) return; try { if (d.a === 'tv30') tvCmd(m.peer, d); else if (d.a === 'gear' && ['equip', 'craft', 'car'].includes(String(d.op || '')) && C.G().pl[m.peer]) { logAdd(T.store, { k: 'gear' }, now0()); tvSave(); } }
      catch (e) { console.warn('P13：ポストの 操作を 処理できませんでした', e); } });
    const b = document.createElement('button'); b.id = 'tv30Badge'; b.className = 'hide'; b.onclick = () => { if (C.audioOn) C.audioOn(); bookOpen(); }; document.body.appendChild(b);
    const k = document.createElement('div'); k.id = 'tv30Book'; k.className = 'hide'; document.body.appendChild(k);
    k.addEventListener('click', ev => { const bt = ev.target.closest('button'); if (!bt) return; if (bt.dataset.play) playIdea(bt.dataset.play); else if (bt.dataset.k === 'close') bookClose(); });
    addEventListener('keydown', tvKey, true);
    C.hookAfter(tvAfter); tvPoll();
  }
  // g.tv30 は はなしの 半分（B2）と いっしょ：どちらが 先に 書いても、こちらの 欄（hw・post）が のこる
  function mergeTv30(g, mine) {
    let cur = Object.assign({}, g.tv30 && typeof g.tv30 === 'object' ? g.tv30 : {}, mine);
    Object.defineProperty(g, 'tv30', { configurable: true, enumerable: true, get() { return cur; }, set(v) { cur = Object.assign({}, v && typeof v === 'object' ? v : {}, mine); } });
  }
  const sceneOn = () => !!(C.SC && C.SC.on);
  const chatOn = () => !!(root.TankChat && root.TankChat._tv && root.TankChat._tv.on);
  const inLobby = () => { const G = C.G(); return G.ph === 'lobby' && C.view() === 'lobby'; };
  const quiet = () => !sceneOn() && !chatOn() && !(C.busy && C.busy()) && !document.getElementById('tv28Set');
  // きょうの しゅくだい：きろくに あれば それ。まだ なら いまの きろくから えらぶ（スライドか ポストで きまる）
  function hwToday() {
    const st = T.store, d = today(); if (!st.cfg.on || T.box !== 1 || st.log.day !== d || st.log.n < 1) return null;
    const e = st.hw.find(h => h.id === String(d)); if (e) return e;
    const p = pickHomework(st.log, st.hw.map(h => h.kind), d, D()); return p ? { id: p.id, kind: p.kind, sub: p.sub, var: p.var, shown: 0, done: [], tmp: 1 } : null;
  }
  function fixHw(h) { if (!h || !h.tmp) return h; const e = { id: h.id, kind: h.kind, sub: h.sub, var: h.var, shown: 0, done: [] }; T.store.hw.push(e); T.store.hw = T.store.hw.slice(-TV30P_HW_MAX); tvSave(); return e; }
  function tvPack() {
    const st = T.store, d = today(), h = hwToday(), o = {}, G = C.G();
    if (h) { const q = hwQ(h.kind, h.sub, h.var, D()); o.hw = [h.id, h.kind, q.ja, q.zh, h.sub, h.var]; } else o.hw = 0;
    const open = T.box === 1 ? openHw(st, d).filter(x => !h || x.id !== h.id) : [];
    const nm = [...new Set(C.players().map(p => cleanName(p.name)).concat((C.knownNames ? C.knownNames() : []).map(cleanName)).filter(Boolean))].slice(0, TV30P_NAMES_MAX);
    o.post = { box: T.box === 1 ? 1 : 0, keep: st.cfg.keep, n: T.box === 1 ? badgeN(st, d) + (h && h.tmp ? 1 : 0) : 0, old: open.map(x => [x.id, x.kind, x.sub, x.var]), nm, bk: T.book ? 1 : 0 };
    const mine = {}; for (const id in T.mine) if (G.pl[id]) mine[id] = T.mine[id]; if (Object.keys(mine).length) o.post.mine = mine;
    if (T.nowId) o.post.now = [T.nowId, T.nowSeq];
    return o;
  }
  function tvCmd(peer, d) {
    const G = C.G(); if (!G.pl[peer]) return;
    if (d.op === 'hw') { if (d.k === 'book') { if (T.book) bookClose(); else bookOpen(); } return; }
    if (d.op !== 'post' || !isId(d.id)) return;
    if (T.doneIds.includes(d.id)) return; T.doneIds.push(d.id); if (T.doneIds.length > 50) T.doneIds.shift();
    const name = cleanName(d.name) || cleanName(G.pl[peer].name); if (!name) return;
    let hw = null; const h = d.hw;
    if (h && typeof h === 'object' && isHwId(h.id) && KINDS.includes(h.kind)) { const e = T.store.hw.find(x => x.id === h.id), cur = hwToday();
      if (e) hw = e; else if (cur && cur.id === h.id) hw = { id: h.id, kind: cur.kind, sub: cur.sub, var: cur.var };
      else hw = { id: h.id, kind: h.kind, sub: okSub(h.sub || ''), var: clampI(h.var, 0, 2) }; }
    const day = today(), r = postAdd(T.store, name, hw, day); T.store = r.store; tvSave();
    T.mine[peer] = [d.id, r.sticker.give ? 1 : 0, r.sticker.k, r.sticker.s, name];
    const nr = D().narrator[1], line = [nr.ja, nr.zh].map(s => s.split('{name}').join(name));
    C.toast && C.toast('📮 ' + Lx(line[0], line[1]), '#ffe7a8', 'sh'); if (C.play) C.play('item_get');
    say(line[0]); T.polled = -1e9;   // 一覧を はやめに 読みなおす
  }
  async function tvPoll() {
    T.polled = performance.now();
    try { const r = await fetch('/ideas/list', { cache: 'no-store' }); if (r.status === 404) { T.box = 0; T.ideas = []; } else if (r.ok) { const j = await r.json(); const n0 = T.box === 1 ? T.ideas.length : -1; T.box = 1; T.ideas = j && Array.isArray(j.ideas) ? j.ideas : []; if (T.book && n0 >= 0 && T.ideas.length > n0) say(D().narrator[2].ja); } }
    catch (e) { /* つながらない 時は まえの まま */ }
    if (T.box !== 1) return;
    try { const r = await fetch('/ideas/credits', { cache: 'no-store' }); if (r.ok) { const j = await r.json(); T.credits = j && Array.isArray(j.credits) ? j.credits.filter(c => c && isId(c.id) && cleanName(c.name)) : []; } } catch (e) { /* まえの まま */ }
    T.gotCredits = 1; if (T.book) bookFill();
  }
  // テレビの 声（ナレーター）：VOICEVOX が あれば /tts、なければ 字だけ
  async function say(text) {
    if (!(C.voOn && C.voOn()) || !C.AC || !C.AC() || C.AC().state !== 'running') return; const ac = C.AC();
    try { const vo = voNarr(D(), text); let r = vo ? await fetch('/voice/' + vo + '.ogg', { cache: 'force-cache' }).catch(() => null) : null;   // 録った 声 → なければ /tts
      if (r && r.ok) T.voClip = (T.voClip | 0) + 1; else r = await fetch('/tts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ who: 'narr', text: String(text).slice(0, 80), keep: !/\{name\}/.test(text) }), cache: 'no-store' });
      if (!r.ok || !/audio/.test(r.headers.get('content-type') || '')) return; const ab = await r.arrayBuffer();
      const buf = await new Promise((res, rej) => { const p = ac.decodeAudioData(ab, res, rej); if (p && p.then) p.then(res, rej); });
      const src = ac.createBufferSource(); src.buffer = buf; src.connect(C.voiceOut ? C.voiceOut() : ac.destination); T.speaking++; src.onended = () => { T.speaking = Math.max(0, T.speaking - 1); }; src.start(); }
    catch (e) { /* 声は なくても よい */ }
  }
  // sim の 知らせ（P13 の ブロックの p3dEvent から）→ その日の きろく
  function onEvent(e) {
    if (!T.store || !e) return; const G = C.G(), st = G.stage, n0 = JSON.stringify(T.store.log); let ev = null;
    if (e.k === 'stage' && st && !st.p3dDuel) ev = { k: 'stage', world: Number.isInteger(st.world) ? st.world : -1, boss: Array.isArray(st.bosses) ? st.bosses : [] };
    else if (e.k === 'clear') ev = { k: 'clear' }; else if (e.k === 'lose') ev = { k: 'lose' }; else if (e.k === 'mini_done') ev = { k: 'mini' };
    else if (e.k === 'veh_on') ev = { k: 'veh', v: e.kind }; else if (e.k === 'chest') ev = { k: 'gear' };
    if (!ev) return; logAdd(T.store, ev, now0()); if (JSON.stringify(T.store.log) !== n0) tvSave();
  }
  // 結果の 画面 → ロビー・ワールドマップ（P13 の ブロックの toLobby から。toLobby の 前に よぶ）
  function fromResult() { const G = C.G(); if (G.ph !== 'over') return; T.pend = 1; T.lobbyAt = 0; if (G.stage && Array.isArray(G.stage.bosses) && G.stage.bosses.length && !G.stage.p3dDuel) T.pendBoss = 1; }
  function slideDue() { const h = hwToday(); if (!h || h.shown) return null; const L1 = T.store.log; return T.pendBoss || L1.n >= TV30P_SLIDE_STAGES || L1.min >= TV30P_SLIDE_MIN ? h : null; }
  function hwSlide(h0) {
    const h = fixHw(h0); h.shown = 1; const ps = C.players(); let inv = '';
    if (ps.length) { inv = cleanName(ps[T.store.turn % ps.length].name); T.store.turn = (T.store.turn + 1) % 10000; } tvSave();
    const q = hwQ(h.kind, h.sub, h.var, D()), U2 = D().ui, sub = BOSS_NAME[h.sub] ? h.sub : '';
    T.slideHw = h;
    return [{ t: 'choice', who: 'narr', tv30hw: { kind: h.kind, sub, ic: icOf(h.kind), sic: subIc(h.sub), inv }, theme: /^w[0-5]$/.test(h.sub) ? ['grass', 'sand', 'snow', 'lava', 'metal', 'hell'][+h.sub[1]] : 'grass',
      title: ['📮 ' + U2.slideTitle.ja, '📮 ' + U2.slideTitle.zh], ja: q.ja, zh: q.zh,
      opts: [{ ic: '📮', ja: U2.nowBtn.ja, zh: U2.nowBtn.zh }, { ic: '⏰', ja: U2.laterBtn.ja, zh: U2.laterBtn.zh }],
      enter: () => { say(D().narrator[0].ja); setTimeout(() => say(q.ja), 2600); },
      pick: v => { if (v === 0) { T.nowId = h.id; T.nowSeq++; } return null; } }];
  }
  function starSlides() {
    const c = T.credits.find(x => !T.store.seen.includes(x.id)); if (!c) return null; T.store.seen.push(c.id); T.store.seen = T.store.seen.slice(-TV30P_SEEN_MAX);
    const nm = cleanName(c.name), idea = T.ideas.find(i => i.id === c.id), hw = idea && idea.hw && KINDS.includes(idea.hw.kind) ? idea.hw : null;
    addSticker(T.store, nm, { d: today(), k: hw ? hw.kind : 'free', s: hw ? okSub(hw.sub || '') : '', g: 1 }); tvSave();
    const ti = Array.isArray(c.title) ? c.title : [String(c.title || ''), String(c.title || '')], ver = String(c.ver || '').replace(/[^0-9.]/g, '').slice(0, 8);
    const t2 = Ub('adoptedSlide', { name: nm }), tail = ver ? '（v' + ver + '）' : '';
    return [{ t: 'slide', art: 'tv30star', tv30star: { name: nm, ti }, who: 'narr', ja: t2[0].split('{title}').join(String(ti[0] || '').slice(0, 30)) + tail, zh: t2[1].split('{title}').join(String(ti[1] || ti[0] || '').slice(0, 30)) + tail,
      title: ['🌟 ' + D().ui.adopted.ja, '🌟 ' + D().ui.adopted.zh], enter: () => { if (C.fanfare) C.fanfare(true); else if (C.play) C.play('powerup'); say(D().narrator[5].ja.split('{name}').join(nm)); } }];
  }
  function tvAfter(dt, now) {
    const G = C.G(), st = T.store;
    if (G.ph === 'play' && !G.paused) { T.playSec += dt; if (T.playSec >= 60) { T.playSec -= 60; logAdd(st, { k: 'min', n: 1 }, now0()); tvSave(); } }
    if (now - T.dayChk > 5000) { T.dayChk = now; if (st.log.day && st.log.day !== today()) { logAdd(st, null, now0()); tvSave(); } }
    const tc = root.TankChat && root.TankChat._tv; if (tc && tc.on && tc.ui === 'talk' && tc.boss && T.talkSeen !== tc.boss) { T.talkSeen = tc.boss; logAdd(st, { k: 'talk', boss: tc.boss }, now0()); tvSave(); } else if (!(tc && tc.on)) T.talkSeen = '';
    if (G.ph !== 'lobby' && G.ph !== 'over') { T.pend = 0; T.pendBoss = 0; }
    // ロビーに もどった：しゅくだいの スライド → 🌟（1 つずつ。場面の あいだは 出さない）
    if (T.pend && G.ph === 'lobby' && quiet()) { if (!T.lobbyAt) T.lobbyAt = now;
      else if (now - T.lobbyAt > TV30P_LOBBY_WAIT_MS && T.gotCredits) { const h = slideDue(); let steps = h ? hwSlide(h) : null; if (!steps) steps = starSlides(); T.pend = 0; T.pendBoss = 0; if (steps && C.p3dScene) C.p3dScene(steps, null); } }
    else if (T.pend && G.ph === 'lobby') T.lobbyAt = 0;
    if (G.ph === 'lobby' && now - T.polled > TV30P_POLL_MS) tvPoll();
    if (T.speaking || T.playing) { if (C.duck) C.duck(true); }
    // ロビーの しるし「📮 1」
    const b = document.getElementById('tv30Badge'), n = T.box === 1 ? badgeN(st, today()) + (hwToday() && hwToday().tmp ? 1 : 0) : 0, show = n > 0 && inLobby() && quiet() && !T.book;
    if (b) { b.classList.toggle('hide', !show); const t = '📮 ' + n; if (show && b.textContent !== t) b.textContent = t; }
    if (T.book && (G.ph !== 'lobby' || sceneOn() || chatOn())) bookClose();
    tvRows();
  }
  function tvKey(ev) {
    const k = ev.key, stop = () => { ev.preventDefault(); ev.stopImmediatePropagation(); };
    if (ev.target && /INPUT|TEXTAREA/.test(ev.target.tagName)) return;
    if (T.book) { if (['Escape', 'GoBack', 'BrowserBack', 'Backspace', 'p', 'P'].includes(k)) { bookClose(); stop(); } else if (/^[1-9]$/.test(k)) { const it = bookIdeas()[+k - 1]; if (it && clipsN(it)) playIdea(it.id); stop(); } return; }
    if ((k === 'p' || k === 'P') && inLobby() && quiet() && T.box === 1) { if (C.audioOn) C.audioOn(); bookOpen(); stop(); }
  }
  /* ---------- 「みんなの ポスト」（ステッカー帳 ＋ 新しい アイデア 20） ---------- */
  const clipsN = it => (Array.isArray(it.clips) ? it.clips.length : it.clips | 0);
  const bookIdeas = () => T.ideas.slice().sort((a, b) => String(b.ts || b.day || '').localeCompare(String(a.ts || a.day || '')) || 0).slice(0, TV30P_BOOK_IDEAS);
  function bookOpen() { const G = C.G(); if (G.ph !== 'lobby' || sceneOn() || chatOn() || T.box !== 1) return; T.book = 1; bookFill(); tvPoll(); C.play && C.play('join'); say(D().narrator[3].ja); }
  function bookClose() { T.book = 0; stopIdea(); const k = document.getElementById('tv30Book'); if (k) k.classList.add('hide'); }
  function dateOf(it) { const s = String(it.day || ''); if (/^\d{8}$/.test(s)) return (+s.slice(4, 6)) + '/' + (+s.slice(6, 8)); const t = new Date(typeof it.ts === 'number' ? it.ts : String(it.ts || '')); return isNaN(t) ? '' : (t.getMonth() + 1) + '/' + t.getDate(); }
  // ステッカーの 絵：その ボスの いまの 絵（まるの 中）。1 回 作って おぼえる
  const PICS = {};
  function picUrl(sub) { if (!BOSS_NAME[sub] || !C.monPic) return ''; if (PICS[sub]) return PICS[sub]; try { const c = C.monPic(sub, 64, true); if (!c || !c.getContext) return ''; const px = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; let on = 0; for (let i = 3; i < px.length; i += 16) if (px[i] > 0) { on = 1; break; }
      if (!on) { if ((T.picTry = (T.picTry || 0) + 1) < 6) setTimeout(() => { if (T.book) bookFill(); }, 700); return ''; } return (PICS[sub] = c.toDataURL('image/png')); } catch (e) { return ''; } }
  function bookFill() {
    const k = document.getElementById('tv30Book'); if (!k) return; if (!T.book) { k.classList.add('hide'); return; } k.classList.remove('hide');
    const st = T.store, names = Object.keys(st.st).sort((a, b) => st.st[b].length - st.st[a].length), H = [];
    H.push(`<h2>📬 ${esc(U('bookTitle'))}${window.TANK_KEY_HINTS ? `<small>${esc(Lx('P か Esc で とじる', '按 P 或 Esc 关闭'))}</small>` : ''}</h2><div class="cols"><div class="col"><h3>⭐ ${esc(U('stickers'))}</h3>`);
    if (!names.length) H.push(`<div class="none">${esc(Lx('まだ ステッカーは ないよ。スマホの 📮 から アイデアを おくってね', '还没有贴纸。用手机的 📮 投递主意吧'))}</div>`);
    for (const nm of names) { const l = st.st[nm]; H.push(`<div class="nm"><b>${esc(nm)}</b><div class="sks">` + l.slice(-18).map(e => { const u = picUrl(e.s); return `<span class="${e.g ? 'g' : ''}${u ? ' pic' : ''}" title="${esc(Lx(D().stickerNames[e.k].ja, D().stickerNames[e.k].zh))}"${u ? ` style="background-image:url(${u})"` : ''}>${e.g ? '🌟' : u ? `<em>${esc(icOf(e.k))}</em>` : esc(subIc(e.s) || icOf(e.k))}</span>`; }).join('') + `</div><i>× ${l.length}</i></div>`); }
    H.push(`</div><div class="col"><h3>📮 ${esc(U('newest'))}</h3>`);
    const list = bookIdeas(); if (!list.length) H.push(`<div class="none">${esc(Lx('まだ アイデアは ないよ', '还没有主意'))}</div>`);
    list.forEach((it, i) => { const hk = it.hw && KINDS.includes(it.hw.kind) ? it.hw.kind : 'free', ad = it.st === 'adopted' || it.st === 'made', n = clipsN(it);
      const words = snip(mask(it.text || '')) || (n ? '🎤' : '') + (it.photo ? '📷' : '');
      H.push(`<div class="idea"><span class="d">${esc(dateOf(it))}</span><span class="n">${esc(cleanName(it.name))}</span><span>${esc(icOf(hk))}</span><span class="t">${esc(words)}</span>` + (ad ? `<span class="a">🌟</span>` : '') + (n ? `<button data-play="${esc(it.id)}" class="${T.playing === it.id ? 'on' : ''}">${i < 9 ? i + 1 + ' ' : ''}▶ ${esc(U('play'))}</button>` : '') + `</div>`); });
    H.push(`</div></div><div class="foot">${esc(Lx('アイデアは ぜんぶ おうちの Mac の save/ideas に のこって いるよ', '所有的主意都保存在家里 Mac 的 save/ideas 里'))}</div>`);
    k.innerHTML = H.join('');
  }
  function stopIdea() { if (T.audio) { try { T.audio.pause(); } catch (e) { /* もう 止まっている */ } } T.audio = null; T.playing = ''; }
  function playIdea(id) {
    const it = T.ideas.find(x => x.id === id); if (!it || !isId(id)) return; const was = T.playing === id; stopIdea(); if (was) { bookFill(); return; }
    const n = clipsN(it); let i = 0; T.playing = id;
    const next = () => { if (T.playing !== id || i >= n) { if (T.playing === id) { T.playing = ''; bookFill(); } return; }
      const a = new Audio('/ideas/clip?id=' + id + '&i=' + i); i++; T.audio = a; a.onended = next; a.onerror = next; a.play().catch(next); };
    next(); bookFill();
  }
  /* ---------- 設定（こえの じゅんびの 画面に 行を たす）：しゅくだい ON/OFF・こえを のこす・フォルダ ---------- */
  function tvRows() {
    const set = document.getElementById('tv28Set'); if (!set) return; const cols = set.querySelector('.st') || set; let box = document.getElementById('tv30PostRows'); const c = T.store.cfg;
    const html = `<p><b>📮 ${esc(U('freeIdea'))}：</b>${T.box === 1 ? '✓' : '✗ ' + esc(Lx('このサーバーにはありません', '这个服务器没有'))}</p><p><button id="tv30Hw" class="${c.on ? 'on' : ''}">📮 ${esc(Lx('今日のしゅくだい', ((D() && D().ui.navHomework) || {}).zh))}：${c.on ? 'ON' : 'OFF'}</button>`
      + `<button id="tv30Keep" class="${c.keep ? 'on' : ''}">🎤 ${esc(Lx('声を保存する', ((D() && D().ui.keepVoice) || {}).zh))}：${c.keep ? 'ON' : 'OFF'}</button>` + (T.box === 1 ? `<button id="tv30Dir">📂 ${esc(Lx('アイデアのフォルダーを開く', ((D() && D().ui.openFolder) || {}).zh))}</button>` : '') + '</p>';
    if (box && box.parentNode === cols && box.dataset.h === html) return;
    if (!box || box.parentNode !== cols) { box = document.createElement('div'); box.id = 'tv30PostRows'; cols.appendChild(box); }
    box.dataset.h = html; box.innerHTML = html; const on = (id, f) => { const b = document.getElementById(id); if (b) b.onclick = f; };
    on('tv30Hw', () => { c.on = c.on ? 0 : 1; tvSave(); }); on('tv30Keep', () => { c.keep = c.keep ? 0 : 1; tvSave(); });
    on('tv30Dir', () => { fetch('/ideas/open', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }).catch(e => console.warn('P13：フォルダを ひらけませんでした', e)); });
  }
  /* ---------- 場面の 絵（P13 の ブロックの p3dDrawChoice・p3dSlideArt・p3dDrawCredits から） ---------- */
  function drawHwArt(x, st, r, now, bub, ff) {
    const o = st.tv30hw; if (!o) return; const [cx0, cy0, cw, ch] = r, qh = ch * .4, pw = qh * 1.25; x.save();
    x.beginPath(); x.rect(cx0, cy0, pw, qh); x.clip(); x.fillStyle = '#fff6dc'; x.fillRect(cx0 + 4, cy0 + 4, pw - 8, qh - 8); const cx = cx0 + pw / 2, cy = cy0 + qh * .56;
    x.beginPath(); x.arc(cx, cy, qh * .38, 0, 7); x.fillStyle = '#fff3b0'; x.fill(); x.lineWidth = Math.max(4, qh * .03); x.strokeStyle = '#ffd23a'; x.stroke();
    let drew = false; if (o.sub && C.bossPic) { try { drew = C.bossPic(x, o.sub, 3, cx, cy + qh * .22, qh * .6) !== false; } catch (e) { drew = false; } }
    x.textAlign = 'center'; x.textBaseline = 'middle'; if (!drew) { x.font = `${qh * .38}px "M PLUS Rounded 1c",sans-serif`; x.fillText(o.sic || o.ic, cx, cy); }
    x.font = `${qh * .2}px "M PLUS Rounded 1c",sans-serif`; x.fillText('📮', cx0 + pw * .16, cy0 + qh * .17); x.fillText(o.ic, cx0 + pw * .84, cy0 + qh * .17);
    x.restore(); x.save(); x.lineWidth = Math.max(4, ch * .007); x.strokeStyle = '#1b2a22'; x.strokeRect(cx0, cy0, pw, qh);
    // v0.30.1：案内（スマホで こたえてね…・👉 きょうは …から）は ふきだしの 下と 札の 上の あいだに おさめる（かさならない）
    const fs0 = Math.min(ch * .045, cw * .028), F = ff || 'sans-serif', t1 = U('slideHint'), t2 = o.inv ? '👉 ' + U('invite', { name: o.inv }) : '';
    const top = bub ? Math.max(cy0 + qh * .3, bub[1] + bub[3] + ch * .016) : cy0 + qh - fs0 * 2.6, bot = cy0 + qh + ch * .03, av = Math.max(0, bot - top), xr = cx0 + cw - fs0 * .4, W = cw - pw - fs0;
    x.textAlign = 'right'; x.textBaseline = 'top'; let fs = fs0, rows = t2 ? [[t1, '#6a4a00'], [t2, '#b84a00']] : [[t1, '#6a4a00']];
    if (rows.length * fs * 1.2 > av) { const f2 = av / (rows.length * 1.2);
      if (rows.length > 1 && f2 < fs0 * .78) { x.font = `900 ${fs0}px ${F}`; const gap = fs0, w1 = x.measureText(t1).width, w2 = x.measureText(t2).width; fs = Math.min(fs0, av / 1.2, fs0 * W / (w1 + w2 + gap)); rows = [[t1, '#6a4a00', t2]]; }
      else fs = Math.min(fs0, f2); }
    x.font = `900 ${fs}px ${F}`; let wMax = 0;
    rows.forEach((rw, i) => { const y = top + i * fs * 1.2; x.fillStyle = rw[1];
      if (rw[2]) { const w2 = Math.min(W, x.measureText(rw[2]).width); x.fillStyle = '#b84a00'; x.fillText(rw[2], xr, y, W); x.fillStyle = rw[1]; const w1 = Math.min(Math.max(0, W - w2 - fs), x.measureText(rw[0]).width); x.fillText(rw[0], xr - w2 - fs, y, Math.max(1, W - w2 - fs)); wMax = Math.max(wMax, w1 + w2 + fs); }
      else { x.fillText(rw[0], xr, y, W); wMax = Math.max(wMax, Math.min(W, x.measureText(rw[0]).width)); } });
    T.hwLay = { bub: bub ? bub.slice() : null, hint: [xr - wMax, top, wMax, rows.length * fs * 1.2], cards: cy0 + qh + ch * .04, fs, rows: rows.length };   // 確かめ用（tools/look-v030-post.js）
    x.restore();
  }
  function drawStar(x, st, r, now) {
    const o = st.tv30star; if (!o) return; const [px, py, pw, ph] = r, cx = px + pw / 2, cy = py + ph * .5; x.save(); x.beginPath(); x.rect(px, py, pw, ph); x.clip();
    for (let i = 0; i < 14; i++) { const a = i / 14 * Math.PI * 2 + now / 3000, rr = ph * (.34 + .08 * Math.sin(now / 400 + i)); x.font = `${ph * .07}px "M PLUS Rounded 1c",sans-serif`; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(i % 2 ? '✨' : '⭐', cx + Math.cos(a) * rr * 1.6, cy + Math.sin(a) * rr); }
    x.beginPath(); x.arc(cx, cy, ph * .26, 0, 7); x.fillStyle = '#ffd23a'; x.fill(); x.lineWidth = ph * .025; x.strokeStyle = '#b07800'; x.stroke();
    x.font = `${ph * .2}px "M PLUS Rounded 1c",sans-serif`; x.fillText('🌟', cx, cy - ph * .04); x.font = `900 ${ph * .07}px "M PLUS Rounded 1c",sans-serif`; x.fillStyle = '#1b2a22'; x.fillText(o.name, cx, cy + ph * .15, ph * .44);
    x.restore();
  }
  function creditStep() { return { t: 'credits', tv30: 1, names: [], page: 0, who: 'narr', ja: '', zh: '', title: ['💡 アイデア', '💡 创意'] }; }
  const hasCredits = () => T.credits.length > 0;
  function drawCredits(x, st, r) {
    const [cx0, cy0, cw, ch] = r; x.save(); x.textAlign = 'left'; x.textBaseline = 'middle'; const fs = Math.min(ch * .045, cw * .026); let y = cy0 + ch * .1;
    x.font = `900 ${fs * 1.3}px "M PLUS Rounded 1c",sans-serif`; x.fillStyle = '#6a4a00'; x.fillText('💡 ' + Lx('子どもたちのアイデア', '孩子们的创意'), cx0 + cw * .06, y); y += fs * 2;
    x.font = `900 ${fs}px "M PLUS Rounded 1c",sans-serif`; x.fillStyle = '#1b2a22';
    for (const c of T.credits.slice(0, 12)) { const ti = Array.isArray(c.title) ? Lx(String(c.title[0] || ''), String(c.title[1] || c.title[0] || '')) : String(c.title || ''), ver = String(c.ver || '').replace(/[^0-9.]/g, '');
      x.fillText(U('credit', { name: cleanName(c.name) }) + '『' + ti + '』' + (ver ? '　v' + ver : ''), cx0 + cw * .09, y, cw * .84); y += fs * 1.6; }
    x.restore();
  }

  /* ==================== スマホ ==================== */
  const PS = { open: false, step: 'ans', id: '', name: '', hw: null, clips: [], typed: '', isTyped: false, pick: -1, photo: null, photoUrl: '', rec: null, tok: 0, msg: '', err: '', sending: false,
    sticker: null, nowSeq: -1, back: 'ans', sig: '', navSig: '', otherName: false, waitAt: 0, n: 0 };
  const sendTv = d => C.room.emit('cmd', Object.assign({ a: 'tv30' }, d)).catch(e => console.warn('P13：ポストの 操作を 送れませんでした', e));
  const newId = () => [...crypto.getRandomValues(new Uint8Array(6))].map(b => b.toString(16).padStart(2, '0')).join('');
  const lsGet = k => { try { return localStorage.getItem(k); } catch (e) { return null; } }, lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* おぼえない */ } };
  function padInit() {
    const d = document.createElement('div'); d.id = 'tv30Post'; d.className = 'hide'; document.body.appendChild(d);
    d.addEventListener('click', padClick); d.addEventListener('change', padChange);
    document.addEventListener('visibilitychange', () => { if (document.hidden) padStopRec(); });
    C.hookPad(padRender); if (C.hookNav) C.hookNav(padNav);
  }
  function padView() { const ps = C.room.peers(), host = ps.find(p => p.presence && p.presence.role === 'tv'), self = ps.find(p => p.isMe), g = host && host.presence.g ? host.presence.g : null, mine = g && self && g.pl ? g.pl[self.peer] : null;
    const t = g && g.tv30 && typeof g.tv30 === 'object' ? g.tv30 : null; return { g, self, mine, t, post: t && t.post && typeof t.post === 'object' ? t.post : null, hw: t && Array.isArray(t.hw) ? t.hw : null, v28: g && g.tv28 }; }
  const hwFromArr = a => (a && isHwId(a[0]) && KINDS.includes(a[1]) ? { id: a[0], kind: a[1], sub: okSub(a.length > 4 ? a[4] : a[2]), var: clampI(a.length > 4 ? a[5] : a[3], 0, 2) } : null);
  // ナビの ボタン（ロビー・結果の 画面）
  function padNav(S2, mine) {
    const box = document.getElementById('navBox'); if (!box) return; const v = padView(), P = v.post, joined = C.me && C.me.joined;
    let items = [];
    if (S2 && mine && joined && P && P.box && !S2.wh && !(S2.ph === 'lobby' && S2.view === 'map')) {
      const n = P.n | 0, hw = hwFromArr(v.hw), badge = n ? `<b>${n}</b>` : '';
      if (S2.ph === 'lobby') { if (hw) items.push(['hw', '📮 ' + esc(U('navHomework')) + badge]); items.push(['free', '📮 ' + esc(U('navPost'))]); items.push(['book', '📬 ' + esc(U('navBook'))]); }
      else if (S2.ph === 'over' && hw) items.push(['hw', '📮 ' + esc(U('navHomework')) + badge]);
    }
    const sig = JSON.stringify(items) + C.lang(); if (box.dataset.tv30p === sig && (!items.length || box.querySelector("button.tv30p"))) return; box.dataset.tv30p = sig; box.querySelectorAll('button.tv30p').forEach(b => b.remove());
    for (const [k, html] of items) { const b = document.createElement('button'); b.className = 'tv30p'; b.dataset.k = k; b.innerHTML = html;
      b.onclick = () => { const v2 = padView(); if (k === 'book') { sendTv({ op: 'hw', k: 'book' }); return; } padOpen(k === 'hw' ? hwFromArr(v2.hw) : null); }; box.appendChild(b); }
    if (items.length) box.classList.remove('hide');
  }
  function padReset(keepName) { padStopRec(); if (PS.photoUrl) { try { URL.revokeObjectURL(PS.photoUrl); } catch (e) { /* もう ない */ } }
    Object.assign(PS, { step: 'ans', id: newId(), clips: [], typed: '', isTyped: false, pick: -1, photo: null, photoUrl: '', msg: '', err: '', sending: false, sticker: null, otherName: false, back: 'ans', picT: 0, sig: '' });
    if (!keepName) PS.name = cleanName(C.me && C.me.name) || ''; }
  function padOpen(hw) { padReset(PS.open && PS.name); PS.hw = hw; PS.open = true; PS.sig = ''; if (!PS.name) PS.step = 'who'; C.vibrate && C.vibrate(15); padRender(); }
  function padClose() { padStopRec(); PS.open = false; PS.sig = ''; const d = document.getElementById('tv30Post'); if (d) d.classList.add('hide'); }
  const micCan = () => !!(root.TankTalkVoice && root.TankTalkVoice.Recorder && root.TankTalkVoice.Recorder.can() && window.isSecureContext);
  const sttOn = v => !!(v.v28 && v.v28.on === 1);
  const micOk = v => micCan() && (sttOn(v) || !!(v.post && v.post.keep));
  function padStopRec() { PS.tok++; if (PS.rec) { if (PS.rec.rec) PS.rec.stop(); PS.rec.close(); PS.rec = null; } if (PS.step === 'rec') PS.step = PS.clips.length ? 'check' : 'ans'; }
  function qOf() { if (!PS.hw) { const u = D().ui.freeHint; return { ja: u.ja, zh: u.zh }; } return hwQ(PS.hw.kind, PS.hw.sub, PS.hw.var, D()); }
  const cardsOf = () => (PS.hw ? hwCards(PS.hw.kind, PS.hw.sub, D()) : hwCards('free', '', D()));
  async function padMic(redo) {
    const V = root.TankTalkVoice, v = padView(); if (!V || !micOk(v)) return;
    if (PS.step === 'rec') { if (PS.rec && PS.rec.rec) padGot(PS.rec.stop()); return; }
    if (PS.step === 'up' || PS.sending) return; if (!redo && PS.clips.length >= TV30P_CLIPS) return;
    if (redo && PS.clips.length) PS.clips.pop();
    const tok = ++PS.tok; PS.msg = ''; PS.err = '';
    try { if (!PS.rec) PS.rec = new V.Recorder({ onAuto: (why, r) => padGot(r) }); await PS.rec.open(); }
    catch (e) { console.warn('P13：マイクが つかえません', e); if (tok === PS.tok) { PS.msg = U('noMic'); PS.sig = ''; } return; }
    if (tok !== PS.tok) return; PS.rec.start(); PS.step = 'rec'; PS.sig = ''; C.vibrate && C.vibrate(20);
  }
  async function padGot(r) {
    const V = root.TankTalkVoice, tok = ++PS.tok; PS.step = 'up'; PS.sig = '';
    let w = null; try { w = await V.toWav(r); } catch (e) { w = null; } if (tok !== PS.tok) return;
    if (!w || w.quiet) { PS.step = PS.clips.length ? 'check' : 'ans'; PS.msg = w && w.quiet ? Lx('こえが ちいさいよ。もういちど おしてね', '声音太小了，再按一次吧') : U('fail'); PS.sig = ''; return; }
    const clip = { blob: w.blob, sec: w.sec, text: '', kana: '', st: 'up' }; PS.clips.push(clip); const v = padView(), lang = LANGx();
    if (sttOn(v)) { const q = qOf(), res = await V.upload(w.blob, lang, lang === 'zh' ? q.zh : q.ja, TV30P_STT_MS);
      if (res && res.ok && String(res.text || '').trim()) { clip.text = String(res.text).trim().slice(0, 120); clip.kana = res.kana || ''; clip.st = 'ok'; } else clip.st = 'none'; }
    else clip.st = 'none';
    if (!PS.clips.includes(clip)) return; PS.step = 'check'; PS.msg = ''; PS.sig = ''; C.vibrate && C.vibrate([20, 40, 20]);
  }
  // 写真：1280 px までの JPEG（0.8）。800 kB を こえたら すこし ずつ ちいさく
  async function shrink(file) {
    const url = URL.createObjectURL(file); try { const img = new Image(); await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = url; });
      const k = Math.min(1, 1280 / Math.max(img.naturalWidth || 1, img.naturalHeight || 1)), c = document.createElement('canvas'); c.width = Math.max(1, Math.round(img.naturalWidth * k)); c.height = Math.max(1, Math.round(img.naturalHeight * k));
      const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height);
      let q = .8, b = null; for (;;) { b = await new Promise(res => c.toBlob(res, 'image/jpeg', q)); if (!b || b.size <= 800 * 1024 || q < .35) break; q -= .15; }
      if (b && b.size > 800 * 1024) { const c2 = document.createElement('canvas'); c2.width = Math.round(c.width / 2); c2.height = Math.round(c.height / 2); c2.getContext('2d').drawImage(c, 0, 0, c2.width, c2.height); b = await new Promise(res => c2.toBlob(res, 'image/jpeg', .7)); }
      return b; } finally { URL.revokeObjectURL(url); }
  }
  async function padChange(ev) {
    const el = ev.target; if (!el || el.dataset.k !== 'file' || !el.files || !el.files[0]) return; PS.msg = Lx('…しゃしんを じゅんび しているよ', '…正在准备照片'); PS.sig = ''; padRender();
    try { const b = await shrink(el.files[0]); if (!b) throw new Error('jpeg'); if (PS.photoUrl) URL.revokeObjectURL(PS.photoUrl); PS.photo = b; PS.photoUrl = URL.createObjectURL(b); PS.step = 'check'; PS.msg = ''; }
    catch (e) { console.warn('P13：しゃしんを よめませんでした', e); PS.msg = U('fail'); }
    PS.sig = ''; padRender();
  }
  const heardText = () => PS.clips.map(c => c.text).filter(Boolean).join('　');
  function ideaText() { if (PS.isTyped && PS.typed.trim()) return PS.typed.trim().slice(0, TV30P_TEXT); const h = heardText(); if (h) return h.slice(0, TV30P_TEXT);
    if (PS.pick >= 0) { const c = cardsOf()[PS.pick]; if (c) return (LANGx() === 'zh' ? c.zh : c.ja).slice(0, TV30P_TEXT); } return ''; }
  const hasAnswer = () => !!(PS.clips.length || (PS.isTyped && PS.typed.trim()) || PS.photo || PS.pick >= 0);
  const errText = j => { const e = j && j.err; return e === 'full' ? U('full') : e === 'busy' || e === 'rate' || e === 'many' ? U('tooMany') : U('fail'); };
  async function post(url, body, type) { const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': type }, body, cache: 'no-store' }); let j = null; try { j = await r.json(); } catch (e) { j = null; }
    if (r.status === 429 && !(j && j.err)) j = { ok: false, err: 'busy' }; return r.ok && j && j.ok ? { ok: true, j } : { ok: false, j: j || { ok: false, err: 'http' + r.status } }; }
  async function padSend() {
    if (PS.sending || !hasAnswer()) return; const v = padView(), keep = !!(v.post && v.post.keep), name = cleanName(PS.name); if (!name) { PS.step = 'who'; PS.sig = ''; return; }
    PS.sending = true; PS.err = ''; PS.step = 'sending'; PS.sig = ''; padRender();
    const fail = j => { PS.sending = false; PS.step = 'send'; PS.err = errText(j); PS.sig = ''; };
    try {
      const clips = keep ? PS.clips : [];
      for (let i = 0; i < clips.length; i++) { const r = await post('/ideas/clip?id=' + PS.id + '&i=' + i, clips[i].blob, 'audio/wav'); if (!r.ok) { fail(r.j); return; } }
      if (PS.photo) { const r = await post('/ideas/photo?id=' + PS.id, PS.photo, 'image/jpeg'); if (!r.ok) { fail(r.j); return; } }
      const lang = LANGx(), q = qOf(), body = { id: PS.id, name, lang, hw: PS.hw ? { id: PS.hw.id, kind: PS.hw.kind, sub: PS.hw.sub, q: lang === 'zh' ? q.zh : q.ja } : null, text: ideaText(), heard: PS.clips.map(c => c.text || ''),
        typed: !!(PS.isTyped && PS.typed.trim()), pick: PS.pick, clips: clips.length, photo: !!PS.photo, ver: TV30P_VER };
      const r = await post('/ideas', JSON.stringify(body), 'application/json'); if (!r.ok) { fail(r.j); return; }
      PS.sending = false; PS.step = 'done'; PS.waitAt = performance.now(); PS.sticker = null; PS.n = r.j.n | 0; PS.sig = '';
      sendTv({ op: 'post', id: PS.id, name, hw: PS.hw ? { id: PS.hw.id, kind: PS.hw.kind, sub: PS.hw.sub, var: PS.hw.var } : null }); C.vibrate && C.vibrate([30, 60, 30]);
    } catch (e) { console.warn('P13：ポストに いれられませんでした', e); fail(null); }
  }
  function padClick(ev) {
    const b = ev.target.closest('button'); if (!b || b.disabled) return; const k = b.dataset.k, v = padView();
    if (k === 'x') { padClose(); return; }
    if (k === 'priv') { lsSet('tv30-privacy', '1'); PS.sig = ''; return; }
    if (k === 'who') { padStopRec(); PS.back = PS.step === 'who' ? 'ans' : PS.step; PS.step = 'who'; PS.sig = ''; return; }
    if (k === 'name') { PS.name = cleanName(b.dataset.v); PS.otherName = false; PS.step = PS.back === 'who' ? 'ans' : PS.back || 'ans'; PS.sig = ''; return; }
    if (k === 'other') { PS.otherName = true; PS.sig = ''; return; }
    if (k === 'nameOk') { const inp = document.getElementById('tv30Name'), nm = cleanName(inp && inp.value); if (!nm) return; PS.name = nm; PS.otherName = false; PS.step = PS.back === 'who' ? 'ans' : PS.back || 'ans'; PS.sig = ''; return; }
    if (k === 'hws') { padStopRec(); PS.step = 'hws'; PS.sig = ''; return; }
    if (k === 'hwPick') { const a = b.dataset.v ? JSON.parse(b.dataset.v) : null; const keep = PS.name; padReset(true); PS.name = keep; PS.hw = a ? { id: a[0], kind: a[1], sub: okSub(a[2]), var: clampI(a[3], 0, 2) } : null; PS.sig = ''; return; }
    if (k === 'mic') { padMic(false); return; }
    if (k === 'again') { padMic(true); return; }
    if (k === 'more') { padMic(false); return; }
    if (k === 'type') { padStopRec(); PS.back = PS.clips.length || PS.photo || PS.pick >= 0 || PS.isTyped ? 'check' : 'ans'; if (!PS.isTyped && !PS.typed) PS.typed = heardText(); PS.step = 'type'; PS.sig = ''; return; }
    if (k === 'typeOk') { const ta = document.getElementById('tv30Text'), t = String(ta ? ta.value : '').slice(0, TV30P_TEXT); PS.typed = t; PS.isTyped = !!t.trim(); PS.step = hasAnswer() ? 'check' : 'ans'; PS.sig = ''; return; }
    if (k === 'pickOpen') { padStopRec(); PS.back = hasAnswer() ? 'check' : 'ans'; PS.step = 'pick'; PS.sig = ''; return; }
    if (k === 'card') { PS.pick = +b.dataset.v; PS.step = 'check'; PS.sig = ''; C.vibrate && C.vibrate(15); return; }
    if (k === 'photo') { const f = document.getElementById('tv30File'); if (f) { f.value = ''; f.click(); } return; }
    if (k === 'back') { PS.step = PS.back && PS.back !== PS.step ? PS.back : (hasAnswer() ? 'check' : 'ans'); PS.back = 'ans'; PS.sig = ''; return; }
    if (k === 'okAns') { PS.step = 'send'; PS.err = ''; PS.sig = ''; return; }
    if (k === 'send') { padSend(); return; }
    if (k === 'drop') { const what = b.dataset.v; if (what === 'photo') { PS.photo = null; if (PS.photoUrl) URL.revokeObjectURL(PS.photoUrl); PS.photoUrl = ''; } else if (what === 'pick') PS.pick = -1; else if (what === 'typed') { PS.isTyped = false; PS.typed = ''; } else if (/^\d$/.test(what)) PS.clips.splice(+what, 1);
      if (!hasAnswer()) PS.step = 'ans'; PS.sig = ''; return; }
    if (k === 'another') { const keep = PS.name, hw = PS.hw; padReset(true); PS.name = keep; PS.hw = hw; PS.step = 'who'; PS.back = 'ans'; PS.sig = ''; return; }
    void v;
  }
  function stickerHtml(k, s) {
    const nm = D().stickerNames[k] || D().stickerNames.free, done = k === 'free' ? D().stickerFree : D().stickerDone;
    return `<div class="stk"><div class="disc">${BOSS_NAME[s] ? `<canvas data-pic="${esc(s)}" width="160" height="160"></canvas>` : esc(subIc(s) || icOf(k))}<em>${esc(icOf(k))}</em></div><h3>${esc(Lx(done.ja, done.zh))}</h3><div class="msg">${esc(PS.name)}　—　${esc(Lx(nm.ja, nm.zh))}</div></div>`;
  }
  function padRender() {
    const d = document.getElementById('tv30Post'); if (!d) return; const v = padView(), P = v.post, joined = !!(C.me && C.me.joined);
    // テレビの「いま やる」→ ひらく
    if (P && Array.isArray(P.now)) { if (PS.nowSeq < 0) PS.nowSeq = P.now[1]; else if (P.now[1] !== PS.nowSeq) { PS.nowSeq = P.now[1]; if (joined && P.box && !PS.open) padOpen(hwFromArr(v.hw)); } }
    else if (P && PS.nowSeq < 0) PS.nowSeq = 0;
    if (!PS.open || !joined || !P || !P.box) { if (!d.classList.contains('hide')) { d.classList.add('hide'); if (PS.open && (!P || !P.box)) padClose(); } return; }
    // テレビの こたえ（ステッカー）
    if (PS.step === 'done' && !PS.sticker && P.mine && v.self) { const m = P.mine[v.self.peer]; if (Array.isArray(m) && m[0] === PS.id) { PS.sticker = { give: !!m[1], k: m[2], s: m[3] }; PS.sig = ''; } }
    const rec = PS.rec && PS.rec.rec, mic = micOk(v);
    if (rec) { const mb = d.querySelector('.mic'); if (mb) mb.style.setProperty('--lv', PS.rec.level.toFixed(2)); }
    const sig = JSON.stringify([PS.step, PS.name, PS.hw, PS.clips.map(c => [c.st, c.text]), PS.isTyped, PS.pick, !!PS.photo, PS.msg, PS.err, PS.sticker, PS.otherName, mic, sttOn(v), C.lang(), P.nm, P.old, v.hw, !!lsGet('tv30-privacy'), PS.step === 'done' && !PS.sticker && performance.now() - PS.waitAt > 3500]);
    if (sig === PS.sig) { d.classList.remove('hide'); return; } PS.sig = sig; d.classList.remove('hide');
    const H = [], q = qOf(), cards = cardsOf(), st = PS.step, kindIc = PS.hw ? icOf(PS.hw.kind) : '💡';
    const top = `<div class="top"><button class="who" data-k="who" ${st === 'sending' ? 'disabled' : ''}>👤 ${esc(PS.name ? U('who', { name: PS.name }) : U('whoType'))} ▾</button>` + (st === 'sending' ? '' : `<button class="x" data-k="x">✖</button>`) + '</div>';
    H.push(top);
    if (!lsGet('tv30-privacy') && st !== 'done') H.push(`<div class="priv">🏠 ${esc(U('privacy'))}<button data-k="priv">OK</button></div>`);
    const qBox = `<div class="q"><span class="k">${esc(kindIc)}</span>${esc(q.ja)}${ZS(q.zh)}</div>`;
    const ex = `<div class="ex">` + cards.map(c => `<span>${esc(c.ic)} ${esc(Lx(c.ja, c.zh))}</span>`).join('') + '</div>';
    if (st === 'who') {
      H.push(`<div class="msg">${esc(Lx('だれの アイデア？', '是谁的主意？'))}</div><div class="names">` + (P.nm || []).map(n => `<button data-k="name" data-v="${esc(n)}" class="${n === PS.name ? 'on' : ''}">👤 ${esc(n)}</button>`).join('') + `<button data-k="other">✏ ${esc(U('whoOther'))}</button></div>`);
      if (PS.otherName) H.push(`<input type="text" id="tv30Name" maxlength="12" placeholder="${esc(U('whoType'))}"><button class="btn ok" data-k="nameOk">✅ OK</button>`);
    } else if (st === 'hws') {
      const list = []; const t = hwFromArr(v.hw); if (t) list.push([t.id, t.kind, t.sub, t.var, 1]); for (const a of P.old || []) list.push([a[0], a[1], a[2], a[3], 0]);
      H.push(`<div class="msg">${esc(U('oldHw'))}</div><div class="hws">` + list.map(a => { const qq = hwQ(a[1], a[2], a[3], D()); return `<button class="btn" data-k="hwPick" data-v='${esc(JSON.stringify(a.slice(0, 4)))}'>${esc(icOf(a[1]))} ${a[4] ? '⭐ ' : esc(a[0].slice(4, 6) + '/' + a[0].slice(6)) + '　'}${esc(Lx(qq.ja, qq.zh))}</button>`; }).join('')
        + `<button class="btn sub" data-k="hwPick" data-v="">💡 ${esc(U('freeIdea'))}</button></div>`);
    } else if (st === 'ans' || st === 'rec' || st === 'up') {
      H.push(qBox + ex);
      const micBtn = mic ? `<button class="mic ${st === 'rec' ? 'rec' : st === 'up' ? 'up' : ''}" data-k="mic"><i>${st === 'rec' ? '⏹' : st === 'up' ? '⏳' : '🎤'}</i>${st === 'rec' ? esc(Lx('おわり', '结束')) : st === 'up' ? '' : esc(U('talk'))}</button>` : '';
      const dis = st === 'rec' || st === 'up' ? 'disabled' : '';
      H.push(`<div class="row">${micBtn}<div class="side"><button class="btn" data-k="type" ${dis}>⌨ ${esc(U('typeIt'))}</button><button class="btn" data-k="photo" ${dis}>📷 ${esc(U('photo'))}</button><button class="btn" data-k="pickOpen" ${dis}>👆 ${esc(U('pick'))}</button></div></div>`);
      H.push(`<div class="msg">${esc(st === 'rec' ? Lx('● きいてるよ…（もういちど おすと おわり）', '● 在听…（再按一次结束）') : st === 'up' ? Lx('…きいて いるよ', '…正在听') : PS.msg || (mic ? '' : U('noMic')))}</div>`);
      if ((P.old && P.old.length) && st === 'ans') H.push(`<button class="btn sub" data-k="hws">📚 ${esc(U('oldHw'))}</button>`);
    } else if (st === 'type') {
      H.push(qBox + `<textarea id="tv30Text" maxlength="${TV30P_TEXT}">${esc(PS.typed)}</textarea><div class="acts"><button class="btn ok" data-k="typeOk">✅ ${esc(U('okBtn'))}</button><button class="btn" data-k="back">◀ ${esc(Lx('もどる', '返回'))}</button></div>`);
    } else if (st === 'pick') {
      H.push(qBox + `<div class="cards">` + cards.map((c, i) => `<button data-k="card" data-v="${i}"><i>${esc(c.ic)}</i>${esc(c.ja)}${ZS(c.zh)}</button>`).join('') + `</div><button class="btn" data-k="back">◀ ${esc(Lx('もどる', '返回'))}</button>`);
    } else if (st === 'check' || st === 'send' || st === 'sending') {
      H.push(qBox);
      PS.clips.forEach((c, i) => H.push(`<div class="heard">🎤 ${PS.clips.length > 1 ? i + 1 + '　' : ''}` + (c.st === 'up' ? '…' : c.text ? `${esc(U('heard'))}：『<b>${esc(c.text)}</b>』` : esc(U('noText'))) + (st === 'check' ? ` <button class="btn" data-k="drop" data-v="${i}" style="min-height:32px;padding:0 8px;font-size:13px">✖</button>` : '') + '</div>'));
      if (PS.isTyped && PS.typed.trim()) H.push(`<div class="heard">⌨ 『<b>${esc(PS.typed.trim())}</b>』</div>`);
      if (PS.pick >= 0 && cards[PS.pick]) H.push(`<div class="heard">👆 ${esc(cards[PS.pick].ic)} <b>${esc(Lx(cards[PS.pick].ja, cards[PS.pick].zh))}</b>${st === 'check' ? ` <button class="btn" data-k="drop" data-v="pick" style="min-height:32px;padding:0 8px;font-size:13px">✖</button>` : ''}</div>`);
      if (PS.photoUrl) H.push(`<div class="row"><img class="ph" src="${PS.photoUrl}" alt="">${st === 'check' ? `<button class="btn" data-k="drop" data-v="photo" style="align-self:center">✖</button>` : ''}</div>`);
      if (st === 'check') {
        H.push(`<div class="acts"><button class="btn ok" data-k="okAns">✅ ${esc(U('okBtn'))}</button>` + (mic && PS.clips.length ? `<button class="btn" data-k="again">🎤 ${esc(U('again'))}</button>` : '') + `<button class="btn" data-k="type">⌨ ${esc(U('fix'))}</button></div>`);
        H.push(`<div class="acts">` + (mic && PS.clips.length < TV30P_CLIPS ? `<button class="btn sub" data-k="more">➕ ${esc(PS.clips.length ? U('talkMore') : U('talk'))}</button>` : '') + (!PS.photo ? `<button class="btn sub" data-k="photo">📷 ${esc(U('photo'))}</button>` : '') + (PS.pick < 0 ? `<button class="btn sub" data-k="pickOpen">👆 ${esc(U('pick'))}</button>` : '') + '</div>');
        if (PS.msg) H.push(`<div class="msg">${esc(PS.msg)}</div>`);
      } else if (st === 'send') {
        if (PS.err) H.push(`<div class="msg err">⚠ ${esc(PS.err)}</div>`);
        H.push(`<button class="btn post" data-k="send">📮 ${esc(U('send'))}</button><button class="btn" data-k="back">◀ ${esc(Lx('もどる', '返回'))}</button>`);
      } else H.push(`<div class="env"><i>📮</i><b>✉</b></div><div class="msg">${esc(U('sending'))}</div>`);
    } else if (st === 'done') {
      if (PS.sticker && PS.sticker.give) H.push(stickerHtml(PS.sticker.k, PS.sticker.s));
      else if (PS.sticker || performance.now() - PS.waitAt > 3500) H.push(`<div class="stk"><div class="disc">📮</div><h3>${esc(U('thanks'))}</h3><div class="msg">${esc(U('who', { name: PS.name }))}</div></div>`);
      else H.push(`<div class="env"><i>📮</i><b>✉</b></div>`);
      H.push(`<div class="acts"><button class="btn sub" data-k="another">📮 ${esc(Lx('もう ひとつ（ほかの ひとも）', '再投一个（别人也可以）'))}</button><button class="btn ok" data-k="x">✅ ${esc(Lx('とじる', '关闭'))}</button></div>`);
    }
    H.push(`<input type="file" id="tv30File" data-k="file" accept="image/*" capture="environment" style="display:none">`);
    d.innerHTML = H.join('');
    let blank = false;
    d.querySelectorAll('canvas[data-pic]').forEach(c => { if (!C.monPic) return; try { const x = c.getContext('2d'); x.drawImage(C.monPic(c.dataset.pic, c.width, true), 0, 0, c.width, c.height);
      const px = x.getImageData(0, 0, c.width, c.height).data; let on = false; for (let i = 3; i < px.length; i += 64) if (px[i]) { on = true; break; } if (!on) blank = true; } catch (e) { /* 絵は なくても よい */ } });
    if (blank && (PS.picT = (PS.picT || 0) + 1) < 8) setTimeout(() => { PS.sig = ''; }, 600);   // 絵は あとから 読みこまれる
    if (st === 'type') { const ta = document.getElementById('tv30Text'); if (ta) ta.focus(); }
    if (st === 'who' && PS.otherName) { const inp = document.getElementById('tv30Name'); if (inp) inp.focus(); }
  }

  Object.assign(api, { attach, onEvent, fromResult, drawHwArt, drawStar, drawCredits, creditStep, hasCredits, _tv: T, _pad: PS, poll: () => tvPoll(), bookOpen: () => bookOpen(), bookClose: () => bookClose(), open: hw => padOpen(hw || null) });
  root.TankPost = api;
})(typeof window !== 'undefined' ? window : globalThis);

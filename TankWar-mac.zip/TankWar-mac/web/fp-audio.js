/* 共通部品：音（効果音・曲）。tank.html・td.html の音のコードをまとめたもの（2026-11-15）。
   - 効果音は /sfx/<名前>.ogg を AudioContext で読み、鳴らす時に高さを 0.92〜1.08 倍でずらす（同じ音が続いても耳が疲れない）
   - 同じ音が短い間に重ならないよう、間隔（gap ミリ秒）をあける（敵がたくさん倒れても、うるさくならない）
   - 曲は /bgm/<名前>.ogg を 1 つの Audio で使い回す（作り直すと、テレビの中に再生の部品が溜まるため）
   - テレビのブラウザは、ボタンを押すまで音を出せない。on() をボタンやキーの処理から呼ぶ

   使い方：
     const snd = FPAudio.create({ sfx: ['fire', 'boom'], vol: { fire: .3 }, bgmVol: .3, onState(on) {...} });
     snd.on();                      // ボタンを押した時に呼ぶ（音を始める・読み込む）
     snd.play('boom', { gap: 90 }); // 効果音。opt：vol・rate・exact（高さをずらさない）・gap
     snd.combo('item_get', n);      // 続くほど高くなる音（ド・レ・ミ・ソ・ラ・ド）
     snd.setBgm('battle1');         // 曲を替える（'' で止める）
     snd.tone(600, 200, .15, 'square', .08);  // 作り音（素材が無い時の代わり） */
(function () {
  'use strict';
  const COMBO_NOTES = [1, 1, 1.0, 1.122, 1.26, 1.498, 1.682, 2.0];

  function create(opts) {
    opts = opts || {};
    const names = opts.sfx || [], VOL = opts.vol || {}, defGap = opts.gap === undefined ? 60 : opts.gap;
    const onState = opts.onState || function () {};
    let AC = null, master = null, sfxGain = null;
    const BUF = {}, last = {};
    let bgm = null, bgmName = '';

    function running() { return !!AC && AC.state === 'running'; }
    async function loadAll() {
      let ok = 0;
      for (const n of names) {
        try { const r = await fetch('/sfx/' + n + '.ogg'); if (!r.ok) throw new Error('HTTP ' + r.status); BUF[n] = await AC.decodeAudioData(await r.arrayBuffer()); ok++; }
        catch (e) { console.warn('効果音を読めませんでした：' + n, e); }
      }
      console.info('効果音を読みました：' + ok + '/' + names.length);
    }
    function on() {
      try {
        if (!AC) {
          AC = new (window.AudioContext || window.webkitAudioContext)();
          master = AC.createGain(); master.gain.value = 1; master.connect(AC.destination);
          sfxGain = AC.createGain(); sfxGain.gain.value = 1; sfxGain.connect(master);
          AC.onstatechange = () => { console.info('音の状態：' + AC.state); onState(running()); };
          loadAll();
        }
        if (AC.state !== 'running') AC.resume().then(() => onState(running())).catch(e => console.warn('音を再開できません', e));
      } catch (e) { console.warn('音を出せません', e); }
      if (bgm && bgm.paused && bgm.getAttribute('src')) bgm.play().catch(e => console.info('曲を始められません', e && e.name));
    }
    function tone(f0, f1, dur, type, vol, delay) {
      if (!running()) return;
      const t = AC.currentTime + (delay || 0), o = AC.createOscillator(), g = AC.createGain(); o.type = type || 'square';
      o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
      g.gain.setValueAtTime(vol || .08, t); g.gain.exponentialRampToValueAtTime(.001, t + dur); o.connect(g).connect(sfxGain); o.start(t); o.stop(t + dur);
    }
    function play(n, opt) {
      opt = opt || {};
      if (!running()) return false;
      const b = BUF[n]; if (!b) return false;
      const now = performance.now(), gap = opt.gap === undefined ? defGap : opt.gap;
      if (last[n] && now - last[n] < gap) return false; last[n] = now;
      const src = AC.createBufferSource(), g = AC.createGain(); src.buffer = b;
      src.playbackRate.value = (opt.rate || 1) * (opt.exact ? 1 : .92 + Math.random() * .16);
      g.gain.value = opt.vol !== undefined ? opt.vol : (VOL[n] !== undefined ? VOL[n] : .7);
      src.connect(g).connect(sfxGain); src.start();
      return true;
    }
    function combo(n, count, opt) { return play(n, Object.assign({ rate: COMBO_NOTES[Math.max(0, Math.min(count | 0, 7))], exact: true, gap: 0 }, opt || {})); }
    function setBgm(name) {
      if (bgmName === name) return; bgmName = name;
      if (!bgm) { bgm = new Audio(); bgm.loop = true; bgm.volume = opts.bgmVol === undefined ? .3 : opts.bgmVol; }
      bgm.pause();
      if (!name) { bgm.removeAttribute('src'); bgm.load(); return; }
      bgm.src = '/bgm/' + name + '.ogg';
      bgm.play().catch(e => console.info('曲はボタンを押した後に始まります', e && e.name));
    }
    function setVolume(sfx, music) {
      if (sfxGain && sfx !== undefined) sfxGain.gain.value = sfx;
      if (bgm && music !== undefined) bgm.volume = music;
    }
    return {
      on, play, combo, tone, setBgm, setVolume, running,
      get ctx() { return AC; }, get master() { return master; },
      loaded() { return Object.keys(BUF).length; },
    };
  }
  window.FPAudio = { create, COMBO_NOTES };
})();

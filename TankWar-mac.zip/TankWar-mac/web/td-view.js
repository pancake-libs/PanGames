/* タワーディフェンス「ひかりの木をまもれ！」のテレビの 3D 描画（v1.0）。Three.js（three-td.js、window.THREE）を使う。
   - 計算（td-sim.js）の状態 g を毎フレーム読み、塔・敵・弾・効果を描く。計算の状態は変えない
   - 模型はすべてコードで作る（外の素材を使わない）。同じ形のものはまとめて描き（InstancedMesh）、テレビでも重くしない
   - 重い時は自分で画質を下げる（光のにじみ → 影 → 解像度の順に止める）
   座標：升 (x, y) の真ん中 (x + 0.5, y + 0.5) を、3D の (X, Z) ＝ (x + 0.5 - 列数/2, y + 0.5 - 行数/2) に置く。高さは Y */
(function () {
  'use strict';
  const T3 = window.THREE;
  if (!T3) { console.error('Three.js が読めていません'); return; }

  /* ============ 見た目の設定 ============ */
  const PLAYER_COLORS = [0xffc93c, 0x4fe07a, 0x4aa8ff, 0xff6fb5];
  const BIOME_LOOK = {
    meadow:  { grass: [0x7ccf52, 0x6bbf45, 0x86d65c], path: 0xe8cf98, cliff: 0x8f6a47, water: [0x1c6fb0, 0x49c4e6], sky: ['#7fc8ff', '#e9f8ff'], sun: 0xfff1d6, hemi: [0xcfeaff, 0x5a7a3a], props: ['tree', 'tree2', 'rock', 'bush'], deco: 0xffe36b, glow: 0xffe08a, fog: 0xcdeeff },
    desert:  { grass: [0xeac27c, 0xe0b46a, 0xf0cd8c], path: 0xc8935a, cliff: 0xb27744, water: [0x0e7f8a, 0x3fd0c4], sky: ['#ffc98a', '#fff3dc'], sun: 0xffe2b0, hemi: [0xffe6c4, 0x8a6a3a], props: ['cactus', 'rock', 'rock', 'palm'], deco: 0xd88a4a, glow: 0xffd27a, fog: 0xffe6c2 },
    snow:    { grass: [0xd9e3ee, 0xcdd8e6, 0xe2eaf3], path: 0x93a4b8, cliff: 0x77879a, water: [0x1d4f8a, 0x6aa9df], sky: ['#a9cdf2', '#f1f7ff'], sun: 0xffffff, hemi: [0xe8f2ff, 0x7a8ca0], props: ['pine', 'pine', 'rock', 'icecrystal'], deco: 0x9fd8ff, glow: 0x9fe8ff, fog: 0xe4efff },
    autumn:  { grass: [0xd09146, 0xc27f39, 0xd9a052], path: 0x8a6a4c, cliff: 0x6b4a32, water: [0x23608a, 0x58a6c8], sky: ['#ffae7a', '#ffe9d2'], sun: 0xffd9a8, hemi: [0xffe0c0, 0x6a4a2a], props: ['tree_red', 'tree_orange', 'rock', 'shroomprop'], deco: 0xff7a3a, glow: 0xffc070, fog: 0xffe0c8 },
    volcano: { grass: [0x4a3c38, 0x3f3330, 0x55443f], path: 0x2b2321, cliff: 0x2a201e, water: [0xff5a10, 0xffb030], sky: ['#2a0f12', '#7a2f1c'], sun: 0xffb08a, hemi: [0xff9a70, 0x2a1210], props: ['obsidian', 'deadtree', 'obsidian', 'rock'], deco: 0xff6a20, glow: 0xff8a40, fog: 0x5a2418, lava: 1 },
    crystal: { grass: [0x3d4384, 0x353a76, 0x464d92], path: 0x6e6cb0, cliff: 0x23254a, water: [0x0d1440, 0x3a3aa0], sky: ['#070b26', '#2a1e5c'], sun: 0xb8c4ff, hemi: [0x8a9aff, 0x1a1640], props: ['crystal', 'crystal2', 'glowshroom', 'rock'], deco: 0x7af0ff, glow: 0x8ff6ff, fog: 0x1a1844, night: 1 },
  };
  const ENEMY_LOOK = { // 体の色（倒した時の粒の色にも使う）
    slime: 0x63d957, runner: 0xf1dcc0, bat: 0x8a5ad6, turtle: 0x4fa36a, shroom: 0xe2483f, sprout: 0xe2483f, ghost: 0xdff2ff,
    healer: 0x38c9a6, knight: 0x50586a, boss1: 0x7ee05a, boss2: 0x8d8478, boss3: 0x5b2f8a,
  };
  const QUALITY_NAMES = ['低', '中', '高'];
  const EXPOSURE = 0.82;          // 明るさ（大きいほど明るい。白くとびやすい）
  const BLOOM = { day: 0.32, night: 0.62, radius: 0.5, threshold: 0.93 };   // 光のにじみ（強さ・広がり・にじみ始める明るさ）

  /* ============ 形を作る道具 ============ */
  const _c = new T3.Color();
  // 形を「インデックスなし・頂点の色つき・uv なし」にそろえる（まとめる時に形式が同じである必要がある）
  function prep(geo, color) {
    let g2 = geo.index ? geo.toNonIndexed() : geo;
    if (g2.getAttribute('uv')) g2.deleteAttribute('uv');
    if (g2.getAttribute('uv1')) g2.deleteAttribute('uv1');
    const n = g2.getAttribute('position').count, col = new Float32Array(n * 3);
    _c.set(color);
    for (let i = 0; i < n; i++) { col[i * 3] = _c.r; col[i * 3 + 1] = _c.g; col[i * 3 + 2] = _c.b; }
    g2.setAttribute('color', new T3.BufferAttribute(col, 3));
    return g2;
  }
  const _m4 = new T3.Matrix4(), _q = new T3.Quaternion(), _e = new T3.Euler(), _v = new T3.Vector3(), _s = new T3.Vector3();
  function place(geo, p, r, s) {
    _e.set((r && r[0]) || 0, (r && r[1]) || 0, (r && r[2]) || 0); _q.setFromEuler(_e);
    _m4.compose(_v.set(p ? p[0] : 0, p ? p[1] : 0, p ? p[2] : 0), _q, typeof s === 'number' ? _s.set(s, s, s) : _s.set(s ? s[0] : 1, s ? s[1] : 1, s ? s[2] : 1));
    geo.applyMatrix4(_m4); return geo;
  }
  const merge = list => T3.BufferGeometryUtils.mergeGeometries(list, false);
  const G = {
    box: (w, h, d, c, p, r) => place(prep(new T3.BoxGeometry(w, h, d), c), p, r),
    rbox: (w, h, d, rad, c, p, r) => place(prep(new T3.RoundedBoxGeometry(w, h, d, 2, rad), c), p, r),
    cyl: (rt, rb, h, seg, c, p, r, s) => place(prep(new T3.CylinderGeometry(rt, rb, h, seg), c), p, r, s),
    cone: (rad, h, seg, c, p, r, s) => place(prep(new T3.ConeGeometry(rad, h, seg), c), p, r, s),
    sph: (rad, ws, hs, c, p, s, r) => place(prep(new T3.SphereGeometry(rad, ws, hs), c), p, r, s),
    hemi: (rad, ws, hs, c, p, s, r) => place(prep(new T3.SphereGeometry(rad, ws, hs, 0, Math.PI * 2, 0, Math.PI / 2), c), p, r, s),
    ico: (rad, det, c, p, s, r) => place(prep(new T3.IcosahedronGeometry(rad, det), c), p, r, s),
    dod: (rad, c, p, s, r) => place(prep(new T3.DodecahedronGeometry(rad, 0), c), p, r, s),
    oct: (rad, c, p, s, r) => place(prep(new T3.OctahedronGeometry(rad, 0), c), p, r, s),
    tor: (rad, tube, rs, ts, c, p, r, arc) => place(prep(new T3.TorusGeometry(rad, tube, rs, ts, arc || Math.PI * 2), c), p, r),
    cap: (rad, len, c, p, r, s) => place(prep(new T3.CapsuleGeometry(rad, len, 4, 10), c), p, r, s),
    lathe: (pts, seg, c, p, r, s) => place(prep(new T3.LatheGeometry(pts.map(q => new T3.Vector2(q[0], q[1])), seg), c), p, r, s),
    shape: (pts, depth, c, p, r, s) => {
      const sh = new T3.Shape(); pts.forEach((q, i) => (i ? sh.lineTo(q[0], q[1]) : sh.moveTo(q[0], q[1])));
      return place(prep(new T3.ExtrudeGeometry(sh, { depth, bevelEnabled: false }), c), p, r, s);
    },
  };
  function mat(o) { return new T3.MeshStandardMaterial(Object.assign({ vertexColors: true, roughness: 0.7, metalness: 0, envMapIntensity: 0.6 }, o)); }

  /* ============ 小さな粒（火花・煙・きらきら） ============ */
  const P_VERT = `attribute float size; attribute float alpha; attribute vec3 pcolor; varying vec3 vC; varying float vA; uniform float uScale;
    void main(){ vC=pcolor; vA=alpha; vec4 mv=modelViewMatrix*vec4(position,1.); gl_PointSize=size*uScale/max(.1,-mv.z); gl_Position=projectionMatrix*mv; }`;
  const P_FRAG = `varying vec3 vC; varying float vA; uniform float uSoft;
    void main(){ vec2 c=gl_PointCoord-.5; float d=length(c); if(d>.5) discard; float a=mix(1.-smoothstep(.35,.5,d), 1.-smoothstep(0.,.5,d), uSoft)*vA; gl_FragColor=vec4(vC,a);
    #include <colorspace_fragment>
    }`;
  class Particles {
    constructor(scene, max, additive, soft) {
      this.max = max; this.n = 0;
      this.p = new Float32Array(max * 3); this.v = new Float32Array(max * 3); this.c = new Float32Array(max * 3);
      this.size = new Float32Array(max); this.alpha = new Float32Array(max); this.life = new Float32Array(max); this.maxLife = new Float32Array(max);
      this.s0 = new Float32Array(max); this.s1 = new Float32Array(max); this.grav = new Float32Array(max); this.drag = new Float32Array(max);
      const geo = new T3.BufferGeometry();
      this.aP = new T3.BufferAttribute(this.p, 3).setUsage(T3.DynamicDrawUsage);
      this.aC = new T3.BufferAttribute(this.c, 3).setUsage(T3.DynamicDrawUsage);
      this.aS = new T3.BufferAttribute(this.size, 1).setUsage(T3.DynamicDrawUsage);
      this.aA = new T3.BufferAttribute(this.alpha, 1).setUsage(T3.DynamicDrawUsage);
      geo.setAttribute('position', this.aP); geo.setAttribute('pcolor', this.aC); geo.setAttribute('size', this.aS); geo.setAttribute('alpha', this.aA);
      geo.boundingSphere = new T3.Sphere(new T3.Vector3(), 1e4);
      this.mat = new T3.ShaderMaterial({ vertexShader: P_VERT, fragmentShader: P_FRAG, transparent: true, depthWrite: false,
        blending: additive ? T3.AdditiveBlending : T3.NormalBlending, uniforms: { uScale: { value: 500 }, uSoft: { value: soft ? 1 : 0.4 } } });
      this.pts = new T3.Points(geo, this.mat); this.pts.frustumCulled = false; this.pts.renderOrder = additive ? 20 : 15;
      scene.add(this.pts);
    }
    emit(x, y, z, vx, vy, vz, color, life, s0, s1, grav, drag) {
      let i = this.n < this.max ? this.n++ : Math.floor(Math.random() * this.max);
      this.p[i * 3] = x; this.p[i * 3 + 1] = y; this.p[i * 3 + 2] = z;
      this.v[i * 3] = vx; this.v[i * 3 + 1] = vy; this.v[i * 3 + 2] = vz;
      _c.set(color); this.c[i * 3] = _c.r; this.c[i * 3 + 1] = _c.g; this.c[i * 3 + 2] = _c.b;
      this.life[i] = life; this.maxLife[i] = life; this.s0[i] = s0; this.s1[i] = s1 === undefined ? s0 : s1; this.grav[i] = grav || 0; this.drag[i] = drag || 0;
    }
    burst(x, y, z, n, color, speed, life, s0, s1, grav, up) {
      for (let k = 0; k < n; k++) {
        const a = Math.random() * Math.PI * 2, el = Math.random() * Math.PI * 0.5, sp = speed * (0.4 + Math.random() * 0.6);
        this.emit(x, y, z, Math.cos(a) * Math.cos(el) * sp, Math.sin(el) * sp + (up || 0), Math.sin(a) * Math.cos(el) * sp, color, life * (0.6 + Math.random() * 0.6), s0, s1, grav, 1.5);
      }
    }
    update(dt) {
      for (let i = 0; i < this.n; i++) {
        this.life[i] -= dt;
        if (this.life[i] <= 0) {
          const j = --this.n; if (i !== j) {
            for (let k = 0; k < 3; k++) { this.p[i * 3 + k] = this.p[j * 3 + k]; this.v[i * 3 + k] = this.v[j * 3 + k]; this.c[i * 3 + k] = this.c[j * 3 + k]; }
            this.life[i] = this.life[j]; this.maxLife[i] = this.maxLife[j]; this.s0[i] = this.s0[j]; this.s1[i] = this.s1[j]; this.grav[i] = this.grav[j]; this.drag[i] = this.drag[j];
          }
          i--; continue;
        }
        const d = Math.max(0, 1 - this.drag[i] * dt);
        this.v[i * 3] *= d; this.v[i * 3 + 1] = this.v[i * 3 + 1] * d - this.grav[i] * dt; this.v[i * 3 + 2] *= d;
        this.p[i * 3] += this.v[i * 3] * dt; this.p[i * 3 + 1] += this.v[i * 3 + 1] * dt; this.p[i * 3 + 2] += this.v[i * 3 + 2] * dt;
        const t = 1 - this.life[i] / this.maxLife[i];
        this.size[i] = this.s0[i] + (this.s1[i] - this.s0[i]) * t;
        this.alpha[i] = t < 0.1 ? t * 10 : 1 - Math.pow((t - 0.1) / 0.9, 1.6);
      }
      this.pts.geometry.setDrawRange(0, this.n);
      this.aP.needsUpdate = this.aC.needsUpdate = this.aS.needsUpdate = this.aA.needsUpdate = true;
    }
  }

  /* ============ 敵の模型（部品ごとにまとめて描く） ============
     部品＝{ geo, mat, n（1 匹あたりの数）, f(e, i, t, m)：根元からの位置を m（Matrix4）に入れる, tint（色を変える体） } */
  const EYE_W = 0xffffff, EYE_B = 0x1a1420;
  function eyes(rad, dx, dy, dz, pupil) {
    const r2 = rad * (pupil || 0.55);
    return merge([G.sph(rad, 10, 8, EYE_W, [dx, dy, dz]), G.sph(rad, 10, 8, EYE_W, [dx, dy, -dz]),
      G.sph(r2, 8, 6, EYE_B, [dx + rad * 0.62, dy + rad * 0.08, dz]), G.sph(r2, 8, 6, EYE_B, [dx + rad * 0.62, dy + rad * 0.08, -dz])]);
  }
  const lm = new T3.Matrix4(), lq = new T3.Quaternion(), le = new T3.Euler(), lp = new T3.Vector3(), ls = new T3.Vector3();
  function L(m, px, py, pz, rx, ry, rz, sx, sy, sz) {
    le.set(rx || 0, ry || 0, rz || 0); lq.setFromEuler(le);
    m.compose(lp.set(px || 0, py || 0, pz || 0), lq, ls.set(sx === undefined ? 1 : sx, sy === undefined ? (sx === undefined ? 1 : sx) : sy, sz === undefined ? (sx === undefined ? 1 : sx) : sz));
    return m;
  }
  function buildEnemyModels(M) {
    const ph = e => e.ph;   // 歩きの位相
    const models = {};
    // スライム（ぷるぷる跳ねる）
    const slimeBody = G.lathe([[0, 0], [0.42, 0.02], [0.5, 0.16], [0.46, 0.36], [0.3, 0.55], [0.12, 0.64], [0, 0.66]], 20, 0xffffff);
    const slimeHi = G.sph(0.09, 8, 6, 0xffffff, [0.18, 0.5, -0.16], [1, 0.6, 1]);
    const squash = e => { const k = Math.abs(Math.sin(e.ph * 2.2)); return [1 + 0.12 * (1 - k), 0.82 + 0.3 * k, k * 0.18]; };
    models.slime = [
      { geo: slimeBody, mat: M.slime, tint: 1, n: 1, f: (e, i, t, m) => { const [w, h, y] = squash(e); return L(m, 0, y, 0, 0, 0, 0, w, h, w); } },
      { geo: merge([eyes(0.1, 0.33, 0.36, 0.14), slimeHi]), mat: M.eye, n: 1, f: (e, i, t, m) => { const [w, h, y] = squash(e); return L(m, 0, y, 0, 0, 0, 0, w, h, w); } },
    ];
    models.boss1 = models.slime.concat([
      { geo: merge([G.cyl(0.24, 0.26, 0.14, 10, 0xffc93c, [0, 0.07, 0]), G.cone(0.05, 0.14, 5, 0xffc93c, [0.22, 0.2, 0]), G.cone(0.05, 0.14, 5, 0xffc93c, [-0.22, 0.2, 0]),
        G.cone(0.05, 0.14, 5, 0xffc93c, [0, 0.2, 0.22]), G.cone(0.05, 0.14, 5, 0xffc93c, [0, 0.2, -0.22]), G.sph(0.045, 8, 6, 0xff4060, [0.25, 0.08, 0])]),
        mat: M.gold, n: 1, f: (e, i, t, m) => { const [w, h, y] = squash(e); return L(m, 0, y + 0.62 * h, 0, 0, t * 0.6, 0); } },
    ]);
    // はやうさぎ（耳と足が動く）
    models.runner = [
      { geo: merge([G.cap(0.2, 0.18, 0xffffff, [0, 0.36, 0], [0, 0, Math.PI / 2 - 0.3]), G.sph(0.19, 14, 10, 0xffffff, [0.24, 0.56, 0]), G.sph(0.08, 8, 6, 0xffd6e0, [-0.2, 0.34, 0])]), mat: M.fur, tint: 1, n: 1,
        f: (e, i, t, m) => L(m, 0, Math.abs(Math.sin(e.ph * 3)) * 0.12, 0, 0, 0, Math.sin(e.ph * 3) * 0.08) },
      { geo: eyes(0.055, 0.38, 0.6, 0.09, 0.6), mat: M.eye, n: 1, f: (e, i, t, m) => L(m, 0, Math.abs(Math.sin(e.ph * 3)) * 0.12, 0) },
      { geo: merge([G.cap(0.05, 0.28, 0xffffff, [0, 0.16, 0]), G.cap(0.025, 0.2, 0xffb4c6, [0.025, 0.16, 0])]), mat: M.fur, tint: 1, n: 2,
        f: (e, i, t, m) => L(m, 0.2, 0.7 + Math.abs(Math.sin(e.ph * 3)) * 0.12, i ? 0.08 : -0.08, (i ? 1 : -1) * 0.2 + Math.sin(e.ph * 3 + i) * 0.15, 0, -0.35) },
      { geo: G.cap(0.06, 0.16, 0xe8cfa8, [0, -0.1, 0]), mat: M.fur, tint: 1, n: 2, f: (e, i, t, m) => L(m, 0.02, 0.22, i ? 0.11 : -0.11, 0, 0, Math.sin(e.ph * 3 + i * Math.PI) * 0.9) },
    ];
    // コウモリ（羽ばたく。空を飛ぶ）
    const wing = G.shape([[0, 0], [0.55, 0.1], [0.62, -0.08], [0.45, -0.02], [0.38, -0.16], [0.24, -0.06], [0.12, -0.18], [0, -0.05]], 0.015, 0x6a3fb4);
    models.bat = [
      { geo: merge([G.sph(0.22, 14, 10, 0xffffff, [0, 0, 0], [1.1, 1, 1]), G.cone(0.06, 0.14, 4, 0xffffff, [0.08, 0.2, 0.1]), G.cone(0.06, 0.14, 4, 0xffffff, [0.08, 0.2, -0.1])]), mat: M.fur, tint: 1, n: 1,
        f: (e, i, t, m) => L(m, 0, Math.sin(e.ph * 4) * 0.06, 0) },
      { geo: merge([G.sph(0.045, 8, 6, 0xff3040, [0.19, 0.05, 0.08]), G.sph(0.045, 8, 6, 0xff3040, [0.19, 0.05, -0.08])]), mat: M.glowEye, n: 1, f: (e, i, t, m) => L(m, 0, Math.sin(e.ph * 4) * 0.06, 0) },
      { geo: wing, mat: M.wing, tint: 1, n: 2, f: (e, i, t, m) => { const a = Math.sin(t * 16 + e.id) * 0.8; return L(m, 0, 0.02 + Math.sin(e.ph * 4) * 0.06, i ? 0.12 : -0.12, (i ? 1 : -1) * (Math.PI / 2 + a), i ? Math.PI / 2 : -Math.PI / 2, 0); } },
    ];
    // よろいガメ（甲羅と 4 本の足）
    models.turtle = [
      { geo: merge([G.hemi(0.42, 10, 5, 0x4f8a46, [0, 0.12, 0], [1.05, 0.8, 0.95]), G.cyl(0.44, 0.44, 0.06, 14, 0xd8c28a, [0, 0.12, 0], null, [1.05, 1, 0.95]),
        G.ico(0.11, 0, 0x6aa85a, [0, 0.43, 0]), G.ico(0.09, 0, 0x6aa85a, [0.2, 0.34, 0.12]), G.ico(0.09, 0, 0x6aa85a, [-0.2, 0.34, -0.12]), G.ico(0.09, 0, 0x6aa85a, [0.18, 0.34, -0.16]), G.ico(0.09, 0, 0x6aa85a, [-0.18, 0.34, 0.16])]),
        mat: M.shell, tint: 1, n: 1, f: (e, i, t, m) => L(m, 0, Math.abs(Math.sin(e.ph * 2)) * 0.03, 0) },
      { geo: merge([G.sph(0.15, 12, 10, 0x9bd27a, [0.48, 0.22, 0]), eyes(0.045, 0.56, 0.28, 0.07)]), mat: M.skin, n: 1, f: (e, i, t, m) => L(m, Math.sin(e.ph * 2) * 0.03, 0, 0) },
      { geo: G.cap(0.08, 0.08, 0x9bd27a), mat: M.skin, n: 4, f: (e, i, t, m) => L(m, i < 2 ? 0.24 : -0.24, 0.08, i % 2 ? 0.28 : -0.28, Math.sin(e.ph * 2 + i * 1.6) * 0.6, 0, 0) },
    ];
    // わかれキノコ・こキノコ（よちよち歩く）
    const shroomCap = merge([G.hemi(0.36, 16, 8, 0xffffff, [0, 0.36, 0], [1, 0.85, 1]),
      G.sph(0.06, 6, 5, 0xfff6e0, [0.2, 0.55, 0.1]), G.sph(0.05, 6, 5, 0xfff6e0, [-0.1, 0.62, 0.15]), G.sph(0.07, 6, 5, 0xfff6e0, [-0.05, 0.55, -0.22]), G.sph(0.05, 6, 5, 0xfff6e0, [0.12, 0.64, -0.08])]);
    const wob = e => Math.sin(e.ph * 3) * 0.14;
    models.shroom = [
      { geo: shroomCap, mat: M.shroom, tint: 1, n: 1, f: (e, i, t, m) => L(m, 0, 0, 0, wob(e), 0, 0) },
      { geo: merge([G.cyl(0.17, 0.21, 0.38, 12, 0xfff1d8, [0, 0.19, 0]), eyes(0.06, 0.16, 0.26, 0.08)]), mat: M.skin, n: 1, f: (e, i, t, m) => L(m, 0, 0, 0, wob(e), 0, 0) },
    ];
    models.sprout = models.shroom;
    // まほうよけおばけ（ふわふわ。少し透ける）
    models.ghost = [
      { geo: G.lathe([[0, 0.05], [0.3, 0.02], [0.34, 0.12], [0.36, 0.4], [0.3, 0.62], [0.16, 0.74], [0, 0.77]], 18, 0xffffff), mat: M.ghost, tint: 1, n: 1,
        f: (e, i, t, m) => L(m, 0, 0.25 + Math.sin(t * 3 + e.id) * 0.08, 0, 0, 0, Math.sin(t * 2 + e.id) * 0.1) },
      { geo: merge([G.sph(0.07, 8, 6, EYE_B, [0.3, 0.52, 0.11], [0.6, 1.2, 1]), G.sph(0.07, 8, 6, EYE_B, [0.3, 0.52, -0.11], [0.6, 1.2, 1]), G.sph(0.06, 8, 6, 0x302040, [0.33, 0.36, 0], [0.5, 0.8, 1.2])]),
        mat: M.eye, n: 1, f: (e, i, t, m) => L(m, 0, 0.25 + Math.sin(t * 3 + e.id) * 0.08, 0, 0, 0, Math.sin(t * 2 + e.id) * 0.1) },
    ];
    // いやしガエル（光の輪）
    models.healer = [
      { geo: merge([G.sph(0.32, 16, 12, 0xffffff, [0, 0.26, 0], [1.1, 0.75, 1]), G.sph(0.18, 10, 8, 0xffffff, [0.12, 0.08, 0.2], [1.4, 0.5, 1]), G.sph(0.18, 10, 8, 0xffffff, [0.12, 0.08, -0.2], [1.4, 0.5, 1]), G.sph(0.18, 10, 8, 0xfff1c8, [0.2, 0.22, 0], [0.7, 0.5, 1.4])]),
        mat: M.skin, tint: 1, n: 1, f: (e, i, t, m) => { const k = Math.abs(Math.sin(e.ph * 1.6)); return L(m, 0, k * 0.2, 0, 0, 0, 0, 1, 0.9 + 0.15 * (1 - k), 1); } },
      { geo: eyes(0.09, 0.18, 0.48, 0.13, 0.6), mat: M.eye, n: 1, f: (e, i, t, m) => L(m, 0, Math.abs(Math.sin(e.ph * 1.6)) * 0.2, 0) },
      { geo: G.tor(0.22, 0.03, 6, 24, 0xc8ff7a, [0, 0, 0], [Math.PI / 2, 0, 0]), mat: M.glow, n: 1, f: (e, i, t, m) => L(m, 0, 0.9 + Math.sin(t * 3) * 0.05, 0, 0, t * 2, 0) },
    ];
    // くろ騎士（よろい・盾）
    models.knight = [
      { geo: merge([G.cyl(0.22, 0.28, 0.42, 8, 0xffffff, [0, 0.42, 0]), G.sph(0.2, 12, 10, 0xffffff, [0, 0.78, 0]), G.box(0.06, 0.04, 0.26, 0x101010, [0.18, 0.8, 0]), G.cone(0.05, 0.22, 6, 0xd03040, [-0.02, 1.02, 0], [0, 0, -0.4])]),
        mat: M.armor, tint: 1, n: 1, f: (e, i, t, m) => L(m, 0, Math.abs(Math.sin(e.ph * 2.4)) * 0.04, 0) },
      { geo: merge([G.cyl(0.24, 0.24, 0.05, 14, 0xb8323c, [0, 0, 0], [0, 0, Math.PI / 2]), G.cyl(0.12, 0.12, 0.06, 4, 0xffd75a, [0.005, 0, 0], [0, 0, Math.PI / 2])]), mat: M.metal, n: 1,
        f: (e, i, t, m) => L(m, 0.26, 0.45 + Math.abs(Math.sin(e.ph * 2.4)) * 0.04, 0.18, 0, -0.3, 0) },
      { geo: G.cap(0.08, 0.14, 0x3a3f4a, [0, -0.1, 0]), mat: M.armor, tint: 1, n: 2, f: (e, i, t, m) => L(m, 0, 0.22, i ? 0.12 : -0.12, 0, 0, Math.sin(e.ph * 2.4 + i * Math.PI) * 0.7) },
    ];
    // いわのゴーレム（腕を振る。目が光る）
    models.boss2 = [
      { geo: merge([G.dod(0.42, 0xffffff, [0, 0.62, 0], [1, 1.1, 1.1]), G.dod(0.24, 0xffffff, [0.22, 1.12, 0]), G.ico(0.12, 0, 0x6fa84a, [-0.1, 1.0, 0.2]), G.ico(0.1, 0, 0x6fa84a, [-0.2, 0.9, -0.25])]),
        mat: M.rock, tint: 1, n: 1, f: (e, i, t, m) => L(m, 0, Math.abs(Math.sin(e.ph * 1.5)) * 0.06, 0, 0, 0, Math.sin(e.ph * 1.5) * 0.06) },
      { geo: merge([G.sph(0.05, 8, 6, 0xff9a2a, [0.42, 1.15, 0.08]), G.sph(0.05, 8, 6, 0xff9a2a, [0.42, 1.15, -0.08])]), mat: M.glowEye, n: 1,
        f: (e, i, t, m) => L(m, 0, Math.abs(Math.sin(e.ph * 1.5)) * 0.06, 0, 0, 0, Math.sin(e.ph * 1.5) * 0.06) },
      { geo: merge([G.dod(0.16, 0xffffff, [0, -0.2, 0]), G.dod(0.14, 0xffffff, [0.02, -0.48, 0])]), mat: M.rock, tint: 1, n: 2,
        f: (e, i, t, m) => L(m, 0, 0.92, i ? 0.5 : -0.5, 0, 0, Math.sin(e.ph * 1.5 + i * Math.PI) * 0.7) },
      { geo: G.dod(0.17, 0xffffff, [0, -0.12, 0]), mat: M.rock, tint: 1, n: 2, f: (e, i, t, m) => L(m, 0, 0.28, i ? 0.2 : -0.2, 0, 0, Math.sin(e.ph * 1.5 + i * Math.PI) * 0.5) },
    ];
    // やみのドラゴン（角・羽・しっぽ）
    const dWing = G.shape([[0, 0], [0.3, 0.5], [0.8, 0.62], [0.7, 0.3], [0.9, 0.12], [0.55, 0.05], [0.6, -0.15], [0.3, -0.05]], 0.02, 0x3a1a5a);
    models.boss3 = [
      { geo: merge([G.cap(0.3, 0.5, 0xffffff, [0, 0.55, 0], [0, 0, Math.PI / 2 - 0.15]), G.sph(0.24, 14, 10, 0xffffff, [0.55, 0.85, 0]), G.cone(0.12, 0.3, 8, 0xffffff, [0.78, 0.82, 0], [0, 0, -Math.PI / 2]),
        G.cone(0.05, 0.25, 6, 0xf0e0c0, [0.5, 1.12, 0.1], [0.3, 0, -0.4]), G.cone(0.05, 0.25, 6, 0xf0e0c0, [0.5, 1.12, -0.1], [-0.3, 0, -0.4]),
        G.cone(0.14, 0.6, 8, 0xffffff, [-0.62, 0.42, 0], [0, 0, Math.PI / 2 + 0.3]), G.cyl(0.24, 0.26, 0.05, 12, 0x9a6ad0, [0.04, 0.42, 0], [0, 0, 0], [1, 1, 0.8])]),
        mat: M.scale, tint: 1, n: 1, f: (e, i, t, m) => L(m, 0, Math.abs(Math.sin(e.ph * 1.6)) * 0.05, 0) },
      { geo: merge([G.sph(0.045, 8, 6, 0xff2a2a, [0.72, 0.92, 0.12]), G.sph(0.045, 8, 6, 0xff2a2a, [0.72, 0.92, -0.12])]), mat: M.glowEye, n: 1,
        f: (e, i, t, m) => L(m, 0, Math.abs(Math.sin(e.ph * 1.6)) * 0.05, 0) },
      { geo: dWing, mat: M.wing, tint: 1, n: 2, f: (e, i, t, m) => { const a = Math.sin(t * 3 + e.id) * 0.35; return L(m, 0.05, 0.8, i ? 0.18 : -0.18, (i ? 1 : -1) * (Math.PI / 2 - 0.5 + a), i ? Math.PI / 2 : -Math.PI / 2, 0); } },
      { geo: G.cap(0.1, 0.2, 0xffffff, [0, -0.12, 0]), mat: M.scale, tint: 1, n: 2, f: (e, i, t, m) => L(m, 0.1, 0.28, i ? 0.2 : -0.2, 0, 0, Math.sin(e.ph * 1.6 + i * Math.PI) * 0.6) },
    ];
    return models;
  }

  /* ============ 塔の模型 ============ */
  const STONE = 0xb7b2a6, STONE_D = 0x8d877c, WOOD = 0x9a6a3e, WOOD_D = 0x6e4a2a, METAL = 0x5a6070, BRASS = 0xd9a441, ROOF = 0xc8473a;
  function towerParts(k, lvl, br, pc) {
    // 戻り値：{ body（動かない）, head（敵の方を向く）, glow（光る部品）, glowColor, headY }
    const big = lvl >= 3, s4 = lvl >= 4;
    const base = [G.cyl(0.4, 0.45, 0.16, 8, STONE_D, [0, 0.08, 0]), G.cyl(0.42, 0.42, 0.05, 20, pc, [0, 0.165, 0])];
    for (let i = 0; i < lvl; i++) base.push(G.sph(0.045, 8, 6, s4 ? 0xff6af0 : 0xffd84a, [0.36 * Math.cos(i * 0.5 - 0.75 + Math.PI), 0.2, 0.36 * Math.sin(i * 0.5 - 0.75 + Math.PI)]));
    let body = [], head = [], glow = [], glowColor = 0xffffff, headY = 0.8;
    if (k === 'arrow') {
      const h = 0.45 + lvl * 0.12;
      if (big) body.push(G.cyl(0.24, 0.3, h, 8, STONE, [0, 0.18 + h / 2, 0])); else body.push(G.cyl(0.22, 0.27, h, 6, WOOD, [0, 0.18 + h / 2, 0]));
      for (let i = 0; i < 4; i++) body.push(G.box(0.05, h, 0.05, WOOD_D, [0.22 * Math.cos(i * Math.PI / 2 + 0.78), 0.18 + h / 2, 0.22 * Math.sin(i * Math.PI / 2 + 0.78)]));
      headY = 0.2 + h;
      body.push(G.cyl(0.3, 0.3, 0.06, 8, WOOD_D, [0, headY, 0]));
      if (lvl >= 2) body.push(G.cone(0.34, 0.26, 8, s4 ? (br === 'B' ? 0x3a6ad0 : 0xd0453a) : ROOF, [0, headY + 0.42, 0]), G.cyl(0.03, 0.03, 0.3, 6, WOOD_D, [0, headY + 0.17, 0]));
      const bow = [G.box(0.36, 0.05, 0.06, WOOD_D, [0.06, 0.08, 0]), G.tor(0.16, 0.018, 4, 12, s4 ? BRASS : WOOD, [0.18, 0.08, 0], [Math.PI / 2, 0, Math.PI / 2], Math.PI * 0.9),
        G.cyl(0.012, 0.012, 0.36, 4, 0xffffff, [0.1, 0.08, 0], [0, 0, Math.PI / 2]), G.cone(0.03, 0.08, 5, 0xd0d6e0, [0.3, 0.08, 0], [0, 0, -Math.PI / 2])];
      head.push(...bow);
      if (s4 && br === 'A') head.push(...[G.box(0.36, 0.05, 0.06, WOOD_D, [0.06, 0.08, 0.14]), G.tor(0.16, 0.018, 4, 12, BRASS, [0.18, 0.08, 0.14], [Math.PI / 2, 0, Math.PI / 2], Math.PI * 0.9)]);
      if (s4 && br === 'B') head.push(G.cyl(0.035, 0.04, 0.5, 8, METAL, [0.3, 0.14, 0], [0, 0, Math.PI / 2]), G.cyl(0.04, 0.04, 0.12, 8, 0x223040, [0.1, 0.2, 0], [0, 0, Math.PI / 2]));
    } else if (k === 'cannon') {
      body.push(G.cyl(0.32, 0.38, 0.34, 8, STONE, [0, 0.35, 0]), G.cyl(0.34, 0.34, 0.06, 8, STONE_D, [0, 0.52, 0]));
      if (big) for (let i = 0; i < 8; i++) body.push(G.box(0.1, 0.1, 0.1, STONE_D, [0.3 * Math.cos(i * Math.PI / 4), 0.6, 0.3 * Math.sin(i * Math.PI / 4)]));
      headY = 0.58;
      const br2 = s4 && br === 'A' ? 1.35 : big ? 1.15 : 1;
      head.push(G.sph(0.2, 12, 10, METAL, [0, 0.12, 0]), G.cyl(0.09 * br2, 0.12 * br2, 0.42, 12, 0x30343c, [0.2, 0.2, 0], [0, 0, -Math.PI / 2 + 0.25]), G.tor(0.1 * br2, 0.025, 6, 14, BRASS, [0.38, 0.25, 0], [0, Math.PI / 2, 0.25]));
      if (s4 && br === 'A') head.push(G.cyl(0.09 * br2, 0.12 * br2, 0.42, 12, 0x30343c, [0.2, 0.2, 0.18], [0, 0, -Math.PI / 2 + 0.25]));
      if (s4 && br === 'B') head.push(G.box(0.22, 0.3, 0.22, 0x7a5232, [-0.05, 0.38, 0]), G.cyl(0.05, 0.05, 0.3, 8, METAL, [-0.05, 0.62, 0]));
    } else if (k === 'ice') {
      body.push(G.cyl(0.18, 0.3, 0.4, 6, 0xdfe9f5, [0, 0.38, 0]), G.cyl(0.26, 0.2, 0.08, 6, 0xbcd2ea, [0, 0.62, 0]));
      if (big) body.push(G.oct(0.12, 0xbfe6ff, [0.26, 0.3, 0.1], [0.6, 1.6, 0.6]), G.oct(0.1, 0xbfe6ff, [-0.22, 0.28, -0.16], [0.6, 1.5, 0.6]));
      headY = 0.95 + lvl * 0.05;
      glow.push(G.oct(0.2 + lvl * 0.03, 0xffffff, [0, 0, 0], [0.8, 1.5, 0.8]));
      if (s4 && br === 'B') glow.push(G.oct(0.1, 0xffffff, [0.2, -0.1, 0], [0.5, 1.3, 0.5]), G.oct(0.1, 0xffffff, [-0.2, -0.1, 0], [0.5, 1.3, 0.5]));
      glowColor = 0x8fe4ff;
    } else if (k === 'thunder') {
      const h = 0.5 + lvl * 0.08;
      body.push(G.cyl(0.14, 0.26, h, 8, 0x6b5a4a, [0, 0.18 + h / 2, 0]));
      for (let i = 0; i < 2 + lvl; i++) body.push(G.tor(0.17 - i * 0.015, 0.03, 6, 16, 0xd88a3a, [0, 0.3 + i * (h - 0.15) / (2 + lvl), 0], [Math.PI / 2, 0, 0]));
      headY = 0.3 + h;
      body.push(G.cyl(0.03, 0.03, 0.3, 6, METAL, [0, headY + 0.05, 0]));
      if (s4 && br === 'B') body.push(G.cyl(0.02, 0.03, 0.55, 6, BRASS, [0, headY + 0.4, 0]));
      glow.push(G.sph(0.13 + lvl * 0.015, 14, 10, 0xffffff, [0, 0.22, 0]));
      if (s4 && br === 'A') glow.push(G.sph(0.08, 10, 8, 0xffffff, [0.22, 0.05, 0]), G.sph(0.08, 10, 8, 0xffffff, [-0.11, 0.05, 0.19]), G.sph(0.08, 10, 8, 0xffffff, [-0.11, 0.05, -0.19]));
      glowColor = 0xfff07a;
    } else if (k === 'poison') {
      body.push(G.lathe([[0, 0.18], [0.3, 0.2], [0.36, 0.34], [0.34, 0.5], [0.28, 0.58], [0.3, 0.62], [0, 0.62]], 14, 0x3a3440));
      for (let i = 0; i < 3; i++) body.push(G.cyl(0.04, 0.05, 0.2, 6, 0x2a2430, [0.26 * Math.cos(i * 2.1), 0.12, 0.26 * Math.sin(i * 2.1)]));
      if (big) body.push(G.tor(0.34, 0.03, 6, 18, BRASS, [0, 0.45, 0], [Math.PI / 2, 0, 0]));
      headY = 0.7;
      head.push(G.cyl(0.05, 0.07, 0.3, 8, 0x5a4a62, [0.16, 0.1, 0], [0, 0, -Math.PI / 2 + 0.6]));
      glow.push(G.cyl(0.27, 0.27, 0.03, 14, 0xffffff, [0, -0.09, 0]), G.sph(0.06, 8, 6, 0xffffff, [0.1, -0.05, 0.06]), G.sph(0.045, 8, 6, 0xffffff, [-0.08, -0.04, -0.1]));
      glowColor = s4 && br === 'B' ? 0xffa040 : 0x7aff5a;
    } else if (k === 'gold') {
      body.push(G.cyl(0.07, 0.11, 0.55, 6, WOOD, [0, 0.45, 0]), G.cyl(0.04, 0.06, 0.3, 5, WOOD, [0.1, 0.62, 0.05], [0.3, 0, -0.6]));
      const n = 3 + lvl;
      for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; body.push(G.ico(0.17 + (big ? 0.03 : 0), 0, s4 && br === 'A' ? 0xffd23a : 0x4fbf4a, [Math.cos(a) * 0.2, 0.82 + (i % 2) * 0.1, Math.sin(a) * 0.2])); }
      body.push(G.ico(0.2, 0, s4 && br === 'A' ? 0xffe066 : 0x5ccf55, [0, 0.98, 0]));
      if (s4 && br === 'B') body.push(G.cyl(0.015, 0.015, 0.7, 4, WOOD_D, [0.3, 0.5, 0]), G.box(0.02, 0.2, 0.28, pc, [0.3, 0.75, 0.14]));
      headY = 1.1;
      glow.push(G.cyl(0.07, 0.07, 0.02, 12, 0xffffff, [0, 0, 0], [Math.PI / 2, 0, 0]));
      glowColor = 0xffd23a;
    }
    return { body: merge(base.concat(body)), head: head.length ? merge(head) : null, glow: glow.length ? merge(glow) : null, glowColor, headY };
  }

  /* ============ 描画のはじまり ============ */
  function create(canvas, overlay, opts) {
    opts = opts || {};
    const renderer = new T3.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    renderer.outputColorSpace = T3.SRGBColorSpace;
    renderer.toneMapping = T3.ACESFilmicToneMapping; renderer.toneMappingExposure = EXPOSURE;
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = T3.PCFSoftShadowMap;
    const ctx2 = overlay.getContext('2d');
    const scene = new T3.Scene();
    const camera = new T3.PerspectiveCamera(38, 16 / 9, 0.5, 200);
    const pmrem = new T3.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new T3.RoomEnvironment(), 0.04).texture;
    const hemi = new T3.HemisphereLight(0xffffff, 0x445533, 0.9); scene.add(hemi);
    const sun = new T3.DirectionalLight(0xffffff, 2.4);
    sun.position.set(-9, 20, 11); sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048); sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.03;
    Object.assign(sun.shadow.camera, { left: -16, right: 16, top: 12, bottom: -12, near: 1, far: 60 });
    scene.add(sun); scene.add(sun.target);
    let composer = null, bloom = null;
    let quality = Math.max(0, Math.min(2, opts.quality === undefined ? 2 : opts.quality)), autoQ = opts.quality === undefined;
    let W = 1, H = 1, PR = 1;

    /* 共通の素材 */
    const M = {
      tile: mat({ roughness: 0.85 }), path: mat({ roughness: 0.95 }), cliff: mat({ roughness: 0.95, flatShading: true }), prop: mat({ roughness: 0.8, flatShading: true }),
      tower: mat({ roughness: 0.6, metalness: 0.15 }), head: mat({ roughness: 0.45, metalness: 0.35 }),
      slime: mat({ roughness: 0.18, metalness: 0, envMapIntensity: 1.2 }), eye: mat({ roughness: 0.3 }), fur: mat({ roughness: 0.9 }), wing: mat({ roughness: 0.8, side: T3.DoubleSide }),
      shell: mat({ roughness: 0.6, flatShading: true }), skin: mat({ roughness: 0.65 }), shroom: mat({ roughness: 0.5 }), armor: mat({ roughness: 0.35, metalness: 0.7 }),
      metal: mat({ roughness: 0.3, metalness: 0.8 }), rock: mat({ roughness: 0.9, flatShading: true }), scale: mat({ roughness: 0.4, metalness: 0.3 }), gold: mat({ roughness: 0.25, metalness: 0.9 }),
      ghost: mat({ roughness: 0.2, transparent: true, opacity: 0.72, emissive: 0x6080ff, emissiveIntensity: 0.25, depthWrite: false }),
      glowEye: mat({ emissive: 0xffffff, emissiveIntensity: 2.2, roughness: 0.4 }), glow: mat({ emissive: 0xffffff, emissiveIntensity: 1.8 }),
    };
    M.glowEye.emissiveMap = null;
    for (const k in M) M[k].userData.shared = true;
    // 光る部品は、頂点の色を光の色として使う
    for (const k of ['glowEye', 'glow']) M[k].onBeforeCompile = sh => { sh.fragmentShader = sh.fragmentShader.replace('vec3 totalEmissiveRadiance = emissive;', 'vec3 totalEmissiveRadiance = emissive * vColor;'); };

    /* 背景・霧・水 */
    let skyTex = null;
    function setSky(top, bottom) {
      const c = document.createElement('canvas'); c.width = 4; c.height = 256; const x = c.getContext('2d');
      const gr = x.createLinearGradient(0, 0, 0, 256); gr.addColorStop(0, top); gr.addColorStop(0.6, bottom); gr.addColorStop(1, bottom); x.fillStyle = gr; x.fillRect(0, 0, 4, 256);
      if (skyTex) skyTex.dispose(); skyTex = new T3.CanvasTexture(c); skyTex.colorSpace = T3.SRGBColorSpace; scene.background = skyTex;
    }
    const waterMat = new T3.ShaderMaterial({
      uniforms: { uT: { value: 0 }, uDeep: { value: new T3.Color() }, uShallow: { value: new T3.Color() }, uFog: { value: new T3.Color() }, uCam: { value: new T3.Vector3() }, uIsland: { value: new T3.Vector2(12, 8) }, uLava: { value: 0 } },
      vertexShader: 'varying vec3 vW; void main(){ vec4 w=modelMatrix*vec4(position,1.); vW=w.xyz; gl_Position=projectionMatrix*viewMatrix*w; }',
      fragmentShader: `uniform float uT; uniform vec3 uDeep; uniform vec3 uShallow; uniform vec3 uFog; uniform vec3 uCam; uniform vec2 uIsland; uniform float uLava; varying vec3 vW;
        void main(){ vec2 p=vW.xz;
          float w=sin(p.x*1.3+uT*1.1)*sin(p.y*1.1-uT*.9)+sin((p.x+p.y)*.7+uT*.6)*.5+sin(p.x*3.1-p.y*2.3+uT*2.)*.15;
          vec2 q=abs(p)-uIsland; float dI=length(max(q,0.))+min(max(q.x,q.y),0.);
          float shore=smoothstep(4.,0.,dI);
          vec3 col=mix(uDeep,uShallow,clamp(shore*.85+w*.08,0.,1.));
          float foam=smoothstep(.35,.0,abs(dI-.35-.18*sin(uT*1.6+p.x*1.7+p.y)))*.75*(1.-uLava);
          col+=vec3(foam)+vec3(smoothstep(.9,1.15,w))*.18;
          col=mix(col,col*(1.+.6*sin(uT*2.+p.x*.8+p.y*.6)),uLava);
          float d=length(vW-uCam); col=mix(col,uFog,smoothstep(28.,80.,d));
          gl_FragColor=vec4(col,1.);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }` });
    const water = new T3.Mesh(new T3.PlaneGeometry(240, 240), waterMat); water.rotation.x = -Math.PI / 2; water.position.y = -1.25; scene.add(water);

    /* 地図（升・崖・飾り）。面が変わるたびに作り直す */
    let world = new T3.Group(); scene.add(world);
    let level = null, look = BIOME_LOOK.meadow, cols = 22, rows = 13, treeObj = null, portals = [], runes = [];
    const wx = x => x - cols / 2, wz = y => y - rows / 2;   // 升の座標 → 3D（升の角）
    // 面ごとに作った形・素材を捨てる（共有の素材 M.* などは userData.shared の印があるので残す）
    function disposeObj(root) {
      root.traverse(o => {
        if (o.isInstancedMesh) o.dispose();
        if (o.geometry) o.geometry.dispose();
        if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => { if (!m.userData.shared) m.dispose(); });
      });
    }
    function disposeWorld() {
      disposeObj(world);
      scene.remove(world); world = new T3.Group(); scene.add(world); portals = []; runes = []; treeObj = null;
    }
    function instanced(geo, material, list, cast, recv) {
      if (!list.length) return null;
      const im = new T3.InstancedMesh(geo, material, list.length);
      list.forEach((o, i) => { L(lm, o.p[0], o.p[1], o.p[2], o.r ? o.r[0] : 0, o.r ? o.r[1] : 0, o.r ? o.r[2] : 0, o.s ? o.s[0] : 1, o.s ? o.s[1] : 1, o.s ? o.s[2] : 1); im.setMatrixAt(i, lm); if (o.c !== undefined) im.setColorAt(i, _c.set(o.c)); });
      im.castShadow = !!cast; im.receiveShadow = !!recv; world.add(im); return im;
    }
    function propGeo(kind) {
      switch (kind) {
        case 'tree': return merge([G.cyl(0.07, 0.1, 0.5, 6, 0x7a5232, [0, 0.25, 0]), G.ico(0.34, 1, 0x58b548, [0, 0.72, 0]), G.ico(0.22, 1, 0x6cc85a, [0.12, 0.95, 0.06])]);
        case 'tree2': return merge([G.cyl(0.06, 0.09, 0.4, 6, 0x7a5232, [0, 0.2, 0]), G.cone(0.32, 0.5, 7, 0x3f9a46, [0, 0.6, 0]), G.cone(0.25, 0.42, 7, 0x4fae52, [0, 0.88, 0])]);
        case 'bush': return merge([G.ico(0.22, 1, 0x5cb04a, [0, 0.16, 0]), G.ico(0.16, 1, 0x6cc45a, [0.18, 0.12, 0.08]), G.sph(0.05, 6, 4, 0xff6a8a, [0.1, 0.32, 0.1]), G.sph(0.05, 6, 4, 0xffe066, [-0.12, 0.28, -0.05])]);
        case 'rock': return merge([G.dod(0.28, 0x9a958c, [0, 0.12, 0], [1.2, 0.7, 1]), G.dod(0.16, 0x8a857c, [0.22, 0.08, 0.12])]);
        case 'cactus': return merge([G.cap(0.1, 0.5, 0x4f9a4a, [0, 0.35, 0]), G.cap(0.06, 0.2, 0x4f9a4a, [0.14, 0.42, 0], [0, 0, -0.9]), G.cap(0.06, 0.16, 0x4f9a4a, [-0.12, 0.5, 0], [0, 0, 0.9]), G.sph(0.05, 6, 4, 0xff6aa0, [0, 0.72, 0])]);
        case 'palm': return merge([G.cyl(0.05, 0.08, 0.9, 6, 0x9a7a4a, [0.05, 0.45, 0], [0, 0, -0.12]), ...[0, 1, 2, 3, 4].map(i => G.cone(0.08, 0.6, 4, 0x4fae52, [0.1 + Math.cos(i * 1.26) * 0.22, 0.9, Math.sin(i * 1.26) * 0.22], [Math.sin(i * 1.26) * 1.1, 0, -Math.cos(i * 1.26) * 1.1]))]);
        case 'pine': return merge([G.cyl(0.06, 0.08, 0.3, 6, 0x6a4a32, [0, 0.15, 0]), G.cone(0.34, 0.45, 7, 0x2f7a4a, [0, 0.48, 0]), G.cone(0.26, 0.38, 7, 0x37885a, [0, 0.74, 0]), G.cone(0.18, 0.3, 7, 0x3f9466, [0, 0.98, 0]), G.cone(0.2, 0.12, 7, 0xffffff, [0, 0.62, 0]), G.cone(0.14, 0.1, 7, 0xffffff, [0, 1.06, 0])]);
        case 'icecrystal': return merge([G.oct(0.16, 0xbfe8ff, [0, 0.3, 0], [0.7, 2, 0.7]), G.oct(0.1, 0xd8f2ff, [0.14, 0.18, 0.06], [0.6, 1.6, 0.6], [0, 0, -0.4]), G.oct(0.1, 0xd8f2ff, [-0.12, 0.16, -0.05], [0.6, 1.5, 0.6], [0, 0, 0.4])]);
        case 'tree_red': return merge([G.cyl(0.07, 0.1, 0.5, 6, 0x6a4a32, [0, 0.25, 0]), G.ico(0.34, 1, 0xd8402a, [0, 0.72, 0]), G.ico(0.22, 1, 0xe85a32, [0.12, 0.95, 0.06])]);
        case 'tree_orange': return merge([G.cyl(0.07, 0.1, 0.5, 6, 0x6a4a32, [0, 0.25, 0]), G.ico(0.32, 1, 0xf09a2a, [0, 0.7, 0]), G.ico(0.2, 1, 0xffb84a, [-0.1, 0.92, 0.08])]);
        case 'shroomprop': return merge([G.cyl(0.06, 0.08, 0.25, 8, 0xfff1d8, [0, 0.12, 0]), G.hemi(0.2, 10, 5, 0xd8402a, [0, 0.24, 0]), G.cyl(0.04, 0.05, 0.15, 8, 0xfff1d8, [0.18, 0.07, 0.1]), G.hemi(0.11, 8, 4, 0xd8402a, [0.18, 0.14, 0.1])]);
        case 'obsidian': return merge([G.dod(0.3, 0x2a2226, [0, 0.15, 0], [1, 1.2, 0.9]), G.oct(0.14, 0x3a2a30, [0.2, 0.2, 0.1], [0.7, 1.8, 0.7])]);
        case 'deadtree': return merge([G.cyl(0.05, 0.09, 0.7, 5, 0x3a2a24, [0, 0.35, 0]), G.cyl(0.03, 0.04, 0.35, 4, 0x3a2a24, [0.12, 0.6, 0], [0, 0, -0.8]), G.cyl(0.025, 0.035, 0.3, 4, 0x3a2a24, [-0.1, 0.52, 0], [0, 0, 0.9])]);
        case 'crystal': return merge([G.dod(0.18, 0x2a2c50, [0, 0.06, 0], [1.3, 0.5, 1.2]), G.oct(0.15, 0x8af0ff, [0, 0.35, 0], [0.6, 2.2, 0.6]), G.oct(0.1, 0x6ad0ff, [0.13, 0.22, 0.05], [0.5, 1.8, 0.5], [0, 0, -0.35])]);
        case 'crystal2': return merge([G.dod(0.16, 0x2a2c50, [0, 0.05, 0], [1.3, 0.5, 1.2]), G.oct(0.14, 0xff8af0, [0, 0.3, 0], [0.6, 2, 0.6]), G.oct(0.09, 0xd06aff, [-0.12, 0.2, 0.06], [0.5, 1.6, 0.5], [0, 0, 0.35])]);
        case 'glowshroom': return merge([G.cyl(0.05, 0.07, 0.3, 8, 0xd8e8ff, [0, 0.15, 0]), G.hemi(0.18, 10, 5, 0x5af0d0, [0, 0.3, 0]), G.cyl(0.035, 0.05, 0.18, 8, 0xd8e8ff, [0.16, 0.09, -0.08]), G.hemi(0.1, 8, 4, 0x8a7aff, [0.16, 0.18, -0.08])]);
      }
      return G.box(0.3, 0.3, 0.3, 0x888888, [0, 0.15, 0]);
    }
    function setLevel(lv) {
      disposeWorld();
      level = lv; cols = lv.cols; rows = lv.rows; look = BIOME_LOOK[lv.biome.id] || BIOME_LOOK.meadow;
      const r = window.TdSim.rng(lv.seed + 5);
      setSky(look.sky[0], look.sky[1]);
      scene.fog = new T3.Fog(look.fog, 34, 85);
      hemi.color.set(look.hemi[0]); hemi.groundColor.set(look.hemi[1]); hemi.intensity = look.night ? 0.5 : look.lava ? 0.6 : 0.72;
      sun.color.set(look.sun); sun.intensity = look.night ? 0.9 : look.lava ? 1.2 : lv.biome.id === 'snow' ? 1.5 : 2.0;
      waterMat.uniforms.uDeep.value.set(look.water[0]); waterMat.uniforms.uShallow.value.set(look.water[1]); waterMat.uniforms.uFog.value.set(look.fog);
      waterMat.uniforms.uIsland.value.set(cols / 2 + 1.2, rows / 2 + 1.2); waterMat.uniforms.uLava.value = look.lava ? 1 : 0;
      if (bloom) bloom.strength = look.night || look.lava ? BLOOM.night : BLOOM.day;
      // 島の土台（崖）
      const base = new T3.Mesh(prep(new T3.RoundedBoxGeometry(cols + 2.6, 3.2, rows + 2.6, 3, 0.9), look.cliff), M.cliff);
      base.position.y = -1.85; base.receiveShadow = true; world.add(base);
      const chunks = [];
      for (let i = 0; i < 46; i++) {
        const side = i % 4, t = r() - 0.5;
        const x = side < 2 ? t * (cols + 2) : (side === 2 ? -1 : 1) * (cols / 2 + 1.3), z = side < 2 ? (side === 0 ? -1 : 1) * (rows / 2 + 1.3) : t * (rows + 2);
        chunks.push({ p: [x, -0.6 - r() * 1.6, z], r: [r() * 3, r() * 3, r() * 3], s: [0.5 + r() * 0.7, 0.5 + r() * 0.8, 0.5 + r() * 0.7] });
      }
      instanced(prep(new T3.DodecahedronGeometry(0.8, 0), look.cliff), M.cliff, chunks, false, true);
      // 升
      const grass = [], paths = [], deco = [], props = {}, rimTiles = [];
      const gcol = look.grass;
      for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
        const c = lv.cells[y * cols + x], X = wx(x) + 0.5, Z = wz(y) + 0.5;
        if (c === 'p' || c === 'S' || c === 'T') paths.push({ p: [X, -0.32, Z], c: shade(look.path, (r() - 0.5) * 0.06) });
        else grass.push({ p: [X, -0.25 + (r() - 0.5) * 0.02, Z], c: shade(gcol[Math.floor(r() * gcol.length)], (r() - 0.5) * 0.05) });
        if (c === 'x') { const kind = look.props[Math.floor(r() * look.props.length)]; (props[kind] = props[kind] || []).push({ p: [X + (r() - 0.5) * 0.2, 0, Z + (r() - 0.5) * 0.2], r: [0, r() * 6.3, 0], s: [0.85 + r() * 0.35, 0.85 + r() * 0.45, 0.85 + r() * 0.35] }); }
        if (c === '.' && r() < 0.28) deco.push({ p: [X + (r() - 0.5) * 0.7, 0, Z + (r() - 0.5) * 0.7], r: [0, r() * 6.3, 0], s: 0.6 + r() * 0.6 });
      }
      // 盤の外側のふち（飾りの木を置く）
      for (let y = -1; y <= rows; y++) for (let x = -1; x <= cols; x++) {
        if (x >= 0 && y >= 0 && x < cols && y < rows) continue;
        const X = wx(x) + 0.5, Z = wz(y) + 0.5;
        rimTiles.push({ p: [X, -0.27, Z], c: shade(gcol[0], -0.08 + (r() - 0.5) * 0.05) });
        if (r() < 0.45) { const kind = look.props[Math.floor(r() * look.props.length)]; (props[kind] = props[kind] || []).push({ p: [X + (r() - 0.5) * 0.3, -0.02, Z + (r() - 0.5) * 0.3], r: [0, r() * 6.3, 0], s: [0.8 + r() * 0.5, 0.8 + r() * 0.6, 0.8 + r() * 0.5] }); }
      }
      const tileGeo = new T3.RoundedBoxGeometry(0.98, 0.5, 0.98, 2, 0.07);
      const tg = prep(tileGeo, 0xffffff), pg = prep(new T3.RoundedBoxGeometry(1.0, 0.36, 1.0, 1, 0.03), 0xffffff);
      instanced(tg, M.tile, grass.concat(rimTiles), false, true);
      instanced(pg, M.path, paths, false, true);
      // 道の小石
      const pebbles = [];
      for (const pth of paths) for (let i = 0; i < 2; i++) if (r() < 0.7) pebbles.push({ p: [pth.p[0] + (r() - 0.5) * 0.8, -0.14, pth.p[2] + (r() - 0.5) * 0.8], r: [r() * 3, r() * 3, 0], s: 0.5 + r() * 0.8, c: shade(look.path, -0.18 + r() * 0.1) });
      instanced(prep(new T3.DodecahedronGeometry(0.05, 0), 0xffffff), M.prop, pebbles, false, true);
      // 草花
      const tuft = merge([G.cone(0.03, 0.16, 3, shade(gcol[0], -0.15), [0, 0.08, 0]), G.cone(0.025, 0.13, 3, shade(gcol[0], -0.1), [0.05, 0.06, 0.02], [0, 0, -0.4]), G.cone(0.025, 0.12, 3, shade(gcol[0], -0.1), [-0.04, 0.06, -0.02], [0, 0, 0.4]), G.sph(0.03, 5, 4, look.deco, [0.0, 0.17, 0.0])]);
      instanced(tuft, M.prop, deco, false, false);
      for (const kind in props) instanced(propGeo(kind), look.night && (kind === 'crystal' || kind === 'crystal2' || kind === 'glowshroom') ? glowPropMat() : M.prop, props[kind], true, true);
      // 光る石の升
      for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) if (lv.cells[y * cols + x] === 'h') {
        const g = new T3.Group(); g.position.set(wx(x) + 0.5, 0.005, wz(y) + 0.5);
        const ring = new T3.Mesh(new T3.RingGeometry(0.3, 0.4, 6), new T3.MeshBasicMaterial({ color: 0x7ff0ff, transparent: true, opacity: 0.8, toneMapped: false, depthWrite: false }));
        ring.rotation.x = -Math.PI / 2; g.add(ring);
        const gem = new T3.Mesh(prep(new T3.OctahedronGeometry(0.08, 0), 0x9ff6ff), M.glow); gem.position.y = 0.35; g.add(gem);
        g.userData = { ring, gem }; world.add(g); runes.push(g);
      }
      // ひかりの木
      treeObj = buildTree(lv.goal);
      // 敵の出口
      lv.spawns.forEach((s, i) => portals.push(buildPortal(s, lv.paths[i])));
      fitCamera();
    }
    let glowPropMatCache = null;
    function glowPropMat() {
      if (!glowPropMatCache) { glowPropMatCache = mat({ roughness: 0.3, flatShading: true, emissive: 0xffffff, emissiveIntensity: 0.55 }); glowPropMatCache.userData.shared = true; glowPropMatCache.onBeforeCompile = sh => { sh.fragmentShader = sh.fragmentShader.replace('vec3 totalEmissiveRadiance = emissive;', 'vec3 totalEmissiveRadiance = emissive * vColor;'); }; }
      return glowPropMatCache;
    }
    function shade(hex, k) { _c.set(hex); const h = { h: 0, s: 0, l: 0 }; _c.getHSL(h); _c.setHSL(h.h, h.s, Math.max(0, Math.min(1, h.l + k))); return _c.getHex(); }
    function buildTree(goal) {
      const g = new T3.Group(); g.position.set(wx(goal.x) + 0.5, -0.05, wz(goal.y) + 0.5);
      const trunk = new T3.Mesh(merge([G.cyl(0.22, 0.38, 1.2, 9, 0x7a5232, [0, 0.6, 0]), G.cyl(0.1, 0.16, 0.6, 6, 0x7a5232, [0.32, 1.25, 0.1], [0.2, 0, -0.8]), G.cyl(0.1, 0.15, 0.55, 6, 0x7a5232, [-0.3, 1.2, -0.1], [-0.2, 0, 0.8]),
        G.cap(0.1, 0.4, 0x6a4a2a, [0.36, 0.1, 0.1], [0, 0, 1.2]), G.cap(0.1, 0.4, 0x6a4a2a, [-0.3, 0.1, 0.25], [0.4, 0, -1.2]), G.cap(0.09, 0.35, 0x6a4a2a, [0, 0.1, -0.38], [1.2, 0, 0])]), M.prop);
      trunk.castShadow = true; trunk.receiveShadow = true; g.add(trunk);
      const leafMat = mat({ roughness: 0.55, flatShading: true, emissive: look.glow, emissiveIntensity: 0.1 });
      const leaves = new T3.Mesh(merge([G.ico(0.75, 1, 0xffffff, [0, 1.9, 0]), G.ico(0.5, 1, 0xffffff, [0.6, 1.6, 0.25]), G.ico(0.48, 1, 0xffffff, [-0.6, 1.62, -0.2]), G.ico(0.45, 1, 0xffffff, [0.15, 2.45, -0.2]), G.ico(0.4, 1, 0xffffff, [-0.25, 2.3, 0.45])]), leafMat);
      leaves.material.color.set(look.night || look.lava ? look.glow : 0x6fcf5a).lerp(_c.set(look.glow), 0.25); leaves.castShadow = true; g.add(leaves);
      const orbs = [];
      for (let i = 0; i < 7; i++) { const o = new T3.Mesh(prep(new T3.SphereGeometry(0.06, 8, 6), look.glow), M.glow); g.add(o); orbs.push(o); }
      const light = new T3.PointLight(look.glow, 6, 5, 1.6); light.position.set(0, 1.8, 0); g.add(light);
      g.userData = { leaves, orbs, light, leafMat, hurt: 0 };
      world.add(g); return g;
    }
    function buildPortal(s, path) {
      const g = new T3.Group(); g.position.set(wx(s.x) + 0.5, -0.15, wz(s.y) + 0.5);
      const p1 = path.pts[1] || path.pts[0]; g.rotation.y = -Math.atan2(p1.y - (s.y + 0.5), p1.x - (s.x + 0.5)) + Math.PI / 2;
      const frame = new T3.Mesh(merge([G.box(0.16, 1.1, 0.16, 0x4a4458, [-0.48, 0.55, 0]), G.box(0.16, 1.1, 0.16, 0x4a4458, [0.48, 0.55, 0]), G.tor(0.48, 0.09, 6, 16, 0x5a5468, [0, 1.05, 0], [0, 0, 0], Math.PI),
        G.box(0.2, 0.08, 0.2, 0x3a3448, [-0.48, 0.04, 0]), G.box(0.2, 0.08, 0.2, 0x3a3448, [0.48, 0.04, 0])]), M.prop);
      frame.castShadow = true; g.add(frame);
      const discMat = new T3.ShaderMaterial({ transparent: true, depthWrite: false, side: T3.DoubleSide, uniforms: { uT: { value: 0 } },
        vertexShader: 'varying vec2 vU; void main(){ vU=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.); }',
        fragmentShader: `uniform float uT; varying vec2 vU; void main(){ vec2 c=vU-.5; float r=length(c)*2.; float a=atan(c.y,c.x);
          float sw=sin(a*3.+r*9.-uT*4.)*.5+.5; vec3 col=mix(vec3(.35,.1,.8),vec3(1.,.45,1.),sw*(1.-r)); float al=smoothstep(1.,.75,r)*(.65+.35*sw);
          gl_FragColor=vec4(col*1.6,al);
          #include <colorspace_fragment>
          }` });
      const disc = new T3.Mesh(new T3.CircleGeometry(0.42, 32), discMat); disc.position.y = 0.62; disc.scale.y = 1.25; g.add(disc);
      g.userData = { discMat };
      world.add(g); return g;
    }

    /* カメラ：盤が画面に収まる所に置く */
    let camBase = new T3.Vector3(), camLook = new T3.Vector3(0, 0, 0.8), shake = 0, lobbyOrbit = false;
    function fitCamera() {
      const aspect = W / H; camera.aspect = aspect; camera.updateProjectionMatrix();
      const dir = new T3.Vector3(0, 1.15, 0.95).normalize();
      const corners = [[-cols / 2, -rows / 2], [cols / 2, -rows / 2], [-cols / 2, rows / 2], [cols / 2, rows / 2]].map(([x, z]) => new T3.Vector3(x, 0, z));
      let d = 10;
      for (let k = 0; k < 80; k++) {
        camera.position.copy(camLook).addScaledVector(dir, d); camera.lookAt(camLook); camera.updateMatrixWorld();
        // 上の帯（HUD）と下の札（人ごと）に隠れないよう、上下を空ける
        const okAll = corners.every(c => { const p = c.clone().project(camera); return Math.abs(p.x) < 0.95 && p.y < 0.70 && p.y > -0.80; });
        if (okAll) break; d += 0.5;
      }
      camBase.copy(camera.position);
    }

    /* 塔 */
    const towerObjs = new Map();
    const towerGlowMats = new Map();
    function glowMatFor(color) {
      let m = towerGlowMats.get(color);
      if (!m) { m = mat({ color: 0xffffff, emissive: color, emissiveIntensity: 1.1, roughness: 0.2 }); m.vertexColors = false; m.color.set(color); m.userData.shared = true; towerGlowMats.set(color, m); }
      return m;
    }
    function makeTower(t) {
      const pc = PLAYER_COLORS[t.owner] || 0xffffff;
      const parts = towerParts(t.k, t.lvl, t.br, pc);
      const g = new T3.Group(); g.position.set(wx(t.x) + 0.5, -0.07, wz(t.y) + 0.5);
      const body = new T3.Mesh(parts.body, M.tower); body.castShadow = true; body.receiveShadow = true; g.add(body);
      const headG = new T3.Group(); headG.position.y = parts.headY; g.add(headG);
      if (parts.head) { const h = new T3.Mesh(parts.head, M.head); h.castShadow = true; headG.add(h); }
      let glow = null;
      if (parts.glow) { glow = new T3.Mesh(parts.glow, glowMatFor(parts.glowColor)); headG.add(glow); }
      let aura = null;
      if (t.k === 'ice' && t.br === 'A') {
        aura = new T3.Mesh(new T3.RingGeometry(0.2, t.st.rng, 48, 1), new T3.MeshBasicMaterial({ color: 0x9fe8ff, transparent: true, opacity: 0.12, depthWrite: false, toneMapped: false }));
        aura.rotation.x = -Math.PI / 2; aura.position.y = 0.12; g.add(aura);
      }
      if (t.k === 'gold' && t.br === 'B') {
        aura = new T3.Mesh(new T3.RingGeometry(t.st.buffR - 0.06, t.st.buffR, 48, 1), new T3.MeshBasicMaterial({ color: 0xffd23a, transparent: true, opacity: 0.35, depthWrite: false, toneMapped: false }));
        aura.rotation.x = -Math.PI / 2; aura.position.y = 0.12; g.add(aura);
      }
      const o = { g, headG, glow, aura, key: t.k + t.lvl + t.br + t.owner, yaw: -t.yaw, recoil: 0, fireN: t.fireN, born: now, scale: 0, id: t.id, kind: t.k, stunFx: 0 };
      world.add(g); return o;
    }
    function removeTowerObj(o) { disposeObj(o.g); world.remove(o.g); }

    /* 敵 */
    let enemyModels = null, enemyParts = [];   // [{ type, part, im, cap }]
    const ENEMY_CAP = { slime: 220, runner: 120, bat: 120, turtle: 90, shroom: 90, sprout: 140, ghost: 90, healer: 70, knight: 70, boss1: 3, boss2: 3, boss3: 3 };
    const ENEMY_SCALE = { sprout: 0.55 };
    function buildEnemyMeshes() {
      enemyModels = buildEnemyModels(M);
      for (const type in ENEMY_CAP) {
        enemyModels[type].forEach((part, pi) => {
          const cap = ENEMY_CAP[type] * part.n;
          const im = new T3.InstancedMesh(part.geo, part.mat, cap);
          im.instanceMatrix.setUsage(T3.DynamicDrawUsage); im.count = 0; im.frustumCulled = false;
          im.castShadow = part.mat !== M.ghost && part.mat !== M.glowEye && part.mat !== M.glow; im.receiveShadow = false;
          im.setColorAt(0, _c.set(0xffffff)); im.instanceColor.setUsage(T3.DynamicDrawUsage);
          scene.add(im);
          enemyParts.push({ type, part, im, cap, pi });
        });
      }
    }
    const evis = new Map();   // 敵 id → 見た目の状態（なめらかな位置・歩きの位相）
    const rootM = new T3.Matrix4(), partM = new T3.Matrix4(), outM = new T3.Matrix4(), rq = new T3.Quaternion(), rp = new T3.Vector3(), rs = new T3.Vector3(), ry = new T3.Euler();
    const TINT_SLOW = new T3.Color(0.65, 0.85, 1.35), TINT_POISON = new T3.Color(0.75, 1.25, 0.6), TINT_FREEZE = new T3.Color(1.2, 1.6, 2.2), TINT_SHIELD = new T3.Color(1.4, 1.2, 2.0);
    const shadowBlobs = [];

    /* 弾 */
    let shotIM = {};
    function buildShotMeshes() {
      const defs = {
        arrow: { geo: merge([G.cyl(0.015, 0.015, 0.42, 4, 0x8a6a3a, [0, 0, 0], [0, 0, Math.PI / 2]), G.cone(0.035, 0.1, 4, 0xd8dde8, [0.24, 0, 0], [0, 0, -Math.PI / 2]), G.box(0.08, 0.005, 0.06, 0xffffff, [-0.18, 0, 0])]), mat: M.head },
        ball: { geo: G.sph(0.11, 12, 8, 0x2a2d34), mat: M.metal },
        shard: { geo: G.oct(0.09, 0xbff0ff, [0, 0, 0], [1.8, 0.7, 0.7]), mat: glowMatFor(0x9fe8ff) },
        orb: { geo: G.sph(0.09, 10, 8, 0x7aff5a), mat: glowMatFor(0x7aff5a) },
      };
      for (const k in defs) { const im = new T3.InstancedMesh(defs[k].geo, defs[k].mat, 220); im.count = 0; im.frustumCulled = false; im.instanceMatrix.setUsage(T3.DynamicDrawUsage); scene.add(im); shotIM[k] = im; }
    }
    // かみなり（細い光の棒を折れ線にする）
    const boltGeo = new T3.BoxGeometry(1, 1, 1);
    const boltMat = new T3.MeshBasicMaterial({ color: 0xfff6b0, toneMapped: false, transparent: true, opacity: 0.95, depthWrite: false, blending: T3.AdditiveBlending });
    const boltIM = new T3.InstancedMesh(boltGeo, boltMat, 400); boltIM.count = 0; boltIM.frustumCulled = false; boltIM.instanceMatrix.setUsage(T3.DynamicDrawUsage); scene.add(boltIM);
    let bolts = [];   // { a:[x,y,z], b:[x,y,z], life, w }
    // 広がる輪
    const ringGeo = new T3.RingGeometry(0.82, 1, 48, 1);
    const rings = [];
    function addRing(x, z, y, r, color, life, opacity) {
      const m = new T3.Mesh(ringGeo, new T3.MeshBasicMaterial({ color, transparent: true, opacity: opacity || 0.8, depthWrite: false, toneMapped: false, blending: T3.AdditiveBlending, side: T3.DoubleSide }));
      m.rotation.x = -Math.PI / 2; m.position.set(x, y, z); scene.add(m); rings.push({ m, life, max: life, r });
    }
    // 流れ星
    const meteors = [];
    const meteorGeo = new T3.IcosahedronGeometry(0.38, 1);
    const meteorMat = new T3.MeshStandardMaterial({ color: 0xff8a3a, emissive: 0xff5a10, emissiveIntensity: 3, roughness: 0.5, flatShading: true });
    // ボスの盾（泡）
    const bubbleMat = new T3.MeshStandardMaterial({ color: 0xb08aff, emissive: 0x6a3aff, emissiveIntensity: 0.7, transparent: true, opacity: 0.32, roughness: 0.1, depthWrite: false });
    const bubbles = [0, 1, 2].map(() => { const m = new T3.Mesh(new T3.SphereGeometry(1, 24, 16), bubbleMat); m.visible = false; scene.add(m); return m; });
    // 人ごとの選んでいる升の印
    const cursors = PLAYER_COLORS.map(col => {
      const g = new T3.Group();
      const sq = new T3.Mesh(new T3.RingGeometry(0.5, 0.6, 4, 1), new T3.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.95, depthWrite: false, toneMapped: false }));
      sq.rotation.x = -Math.PI / 2; sq.rotation.z = Math.PI / 4; sq.scale.set(0.98, 0.98, 1); g.add(sq);
      const fill = new T3.Mesh(new T3.PlaneGeometry(0.84, 0.84), new T3.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.18, depthWrite: false, toneMapped: false }));
      fill.rotation.x = -Math.PI / 2; fill.position.y = 0.005; g.add(fill);
      const arrow = new T3.Mesh(new T3.ConeGeometry(0.14, 0.3, 4), new T3.MeshStandardMaterial({ color: col, emissive: col, emissiveIntensity: 0.8 }));
      arrow.rotation.x = Math.PI; g.add(arrow);
      const range = new T3.Mesh(new T3.RingGeometry(0.96, 1, 64, 1), new T3.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.4, depthWrite: false, toneMapped: false }));
      range.rotation.x = -Math.PI / 2; range.position.y = 0.02; g.add(range);
      const rangeFill = new T3.Mesh(new T3.CircleGeometry(1, 48), new T3.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.08, depthWrite: false, toneMapped: false }));
      rangeFill.rotation.x = -Math.PI / 2; rangeFill.position.y = 0.015; g.add(rangeFill);
      g.visible = false; scene.add(g);
      return { g, sq, fill, arrow, range, rangeFill, x: -1, y: -1 };
    });

    const sparks = new Particles(scene, 2600, true, false);
    const smoke = new Particles(scene, 900, false, true);
    let now = 0, lastT = performance.now() / 1000;

    /* 画面の大きさ・画質 */
    function setupComposer() {
      if (composer) { composer.dispose && composer.dispose(); composer = null; bloom = null; }
      if (quality >= 2) {
        const rt = new T3.WebGLRenderTarget(Math.max(1, W * PR), Math.max(1, H * PR), { type: T3.HalfFloatType, samples: renderer.capabilities.isWebGL2 ? 4 : 0 });
        composer = new T3.EffectComposer(renderer, rt);
        composer.addPass(new T3.RenderPass(scene, camera));
        bloom = new T3.UnrealBloomPass(new T3.Vector2(W * PR / 2, H * PR / 2), look.night || look.lava ? BLOOM.night : BLOOM.day, BLOOM.radius, BLOOM.threshold);
        composer.addPass(bloom);
        composer.addPass(new T3.OutputPass());
        composer.setPixelRatio(PR); composer.setSize(W, H);
      }
      renderer.shadowMap.enabled = quality >= 1;
      sun.castShadow = quality >= 1;
      sun.shadow.mapSize.set(quality >= 2 ? 2048 : 1024, quality >= 2 ? 2048 : 1024);
      if (sun.shadow.map) { sun.shadow.map.dispose(); sun.shadow.map = null; }
      scene.traverse(o => { if (o.material) { (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => { m.needsUpdate = true; }); } });
    }
    function resize() {
      W = canvas.clientWidth || innerWidth; H = canvas.clientHeight || innerHeight;
      const maxW = quality >= 2 ? 1920 : quality >= 1 ? 1600 : 1280;
      PR = Math.min(window.devicePixelRatio || 1, maxW / Math.max(1, W));
      renderer.setPixelRatio(PR); renderer.setSize(W, H, false);
      overlay.width = Math.round(W * Math.min(2, window.devicePixelRatio || 1)); overlay.height = Math.round(H * Math.min(2, window.devicePixelRatio || 1));
      const vh = H * PR; sparks.mat.uniforms.uScale.value = smoke.mat.uniforms.uScale.value = vh / (2 * Math.tan(camera.fov * Math.PI / 360));
      setupComposer(); fitCamera();
    }
    // 重い時は画質を下げる（3 秒ごとに見て、平均が 40 フレーム/秒より遅ければ 1 段下げる）
    let fpsAcc = 0, fpsN = 0, fpsAt = 0, fpsShown = 60;
    function watchFps(dt) {
      fpsAcc += dt; fpsN++;
      if (fpsAcc >= 3) {
        fpsShown = fpsN / fpsAcc; fpsAcc = 0; fpsN = 0;
        if (autoQ && fpsShown < 40 && quality > 0 && now - fpsAt > 6) { quality--; fpsAt = now; console.info('重いので画質を下げました：' + QUALITY_NAMES[quality] + '（' + Math.round(fpsShown) + ' フレーム/秒）'); resize(); }
      }
    }

    /* ---------- 計算の知らせ（g.ev）から効果を出す ---------- */
    const pos3 = (x, y, h) => [wx(x), h || 0, wz(y)];
    const floaters = [];   // 画面の上に出す文字（+5 など）
    function fx(e) {
      switch (e.k) {
        case 'build': { const [X, , Z] = pos3(e.x + 0.5, e.y + 0.5); smoke.burst(X, 0.1, Z, 14, 0xd8c8a8, 1.6, 0.8, 0.25, 0.6, -0.3); addRing(X, Z, 0.05, 0.9, PLAYER_COLORS[e.slot], 0.5, 0.6); break; }
        case 'up': { const [X, , Z] = pos3(e.x + 0.5, e.y + 0.5); for (let i = 0; i < 30; i++) sparks.emit(X + (Math.random() - 0.5) * 0.6, 0.2 + Math.random() * 0.5, Z + (Math.random() - 0.5) * 0.6, 0, 1.5 + Math.random() * 2, 0, e.lvl >= 4 ? 0xff8af0 : 0xffe06a, 1.0, 0.12, 0.02, 0, 0.5); addRing(X, Z, 0.08, 1.2, 0xffe06a, 0.6); break; }
        case 'sell': { const [X, , Z] = pos3(e.x + 0.5, e.y + 0.5); sparks.burst(X, 0.5, Z, 18, 0xffd23a, 2.5, 0.8, 0.1, 0.05, 4, 2); floaters.push({ x: X, y: 1.2, z: Z, text: '+' + e.v, color: '#ffd84a', life: 1.2 }); break; }
        case 'shoot': { const o = towerObjs.get(e.id); if (o) { o.recoil = 1; const [X, Z] = [o.g.position.x, o.g.position.z]; if (e.tk === 'cannon') smoke.burst(X + Math.cos(-o.yaw) * 0.45, 0.85, Z - Math.sin(-o.yaw) * 0.45, 6, 0xcfcfcf, 0.8, 0.6, 0.2, 0.5, -0.4); } break; }
        case 'hit': { const [X, , Z] = pos3(e.x, e.y); sparks.burst(X, 0.45, Z, e.tk === 'ice' ? 8 : 5, e.tk === 'ice' ? 0xbff0ff : e.tk === 'poison' ? 0x8aff5a : 0xffe0a0, 1.6, 0.3, 0.08, 0.02, 3); if (e.tk === 'poison') smoke.burst(X, 0.4, Z, 4, 0x6ad04a, 0.5, 0.9, 0.2, 0.45, -0.2); break; }
        case 'boom': { const [X, , Z] = pos3(e.x, e.y); const big = e.r > 1.5; sparks.burst(X, 0.35, Z, big ? 46 : 26, 0xffa040, big ? 4 : 3, 0.45, 0.22, 0.04, 2); sparks.burst(X, 0.35, Z, 10, 0xfff0b0, 2, 0.25, 0.3, 0.05, 0); smoke.burst(X, 0.3, Z, big ? 16 : 9, 0x5a5048, 1.2, 1.1, 0.35, 0.9, -0.5); addRing(X, Z, 0.06, e.r, e.br === 'B' && e.tk === 'cannon' ? 0xc8a070 : 0xffa040, 0.35, 0.7); if (big) shake = Math.max(shake, 0.12); break; }
        case 'zap': {
          const pts = e.pts.map((p, i) => { const [X, , Z] = pos3(p[0], p[1]); return [X, i === 0 ? 1.15 : 0.45, Z]; });
          for (let i = 0; i < pts.length - 1; i++) {
            const a = pts[i], b = pts[i + 1], segs = 5; let prev = a;
            for (let s = 1; s <= segs; s++) {
              const t = s / segs, j = s === segs ? 0 : 0.18;
              const p = [a[0] + (b[0] - a[0]) * t + (Math.random() - 0.5) * j, a[1] + (b[1] - a[1]) * t + (Math.random() - 0.5) * j, a[2] + (b[2] - a[2]) * t + (Math.random() - 0.5) * j];
              bolts.push({ a: prev, b: p, life: 0.16, w: e.br === 'B' ? 0.09 : 0.045 }); prev = p;
            }
            sparks.burst(b[0], b[1], b[2], 6, 0xfff6a0, 2, 0.25, 0.1, 0.02, 2);
          }
          break;
        }
        case 'die': {
          const [X, , Z] = pos3(e.x, e.y); const col = ENEMY_LOOK[e.type] || 0xffffff, h = e.fly ? 1.3 : 0.35;
          if (e.boss) { sparks.burst(X, h + 0.5, Z, 120, col, 6, 1.2, 0.3, 0.05, 3); sparks.burst(X, h + 0.5, Z, 60, 0xfff0a0, 5, 0.9, 0.25, 0.04, 2); smoke.burst(X, h, Z, 30, 0x4a4040, 2.5, 1.6, 0.6, 1.5, -0.4); addRing(X, Z, 0.08, 4, 0xffe0a0, 0.8); shake = Math.max(shake, 0.5); }
          else { sparks.burst(X, h, Z, 14, col, 2.6, 0.55, 0.16, 0.03, 5); smoke.burst(X, h, Z, 4, 0xffffff, 0.8, 0.5, 0.2, 0.5, -0.3); }
          sparks.emit(X, h + 0.3, Z, 0, 1.6, 0, 0xffd23a, 0.7, 0.18, 0.05, 0.8, 1);
          if (e.boss || Math.random() < 0.35) floaters.push({ x: X, y: h + 0.6, z: Z, text: '+' + e.v, color: '#ffe066', life: 0.9, small: !e.boss });
          break;
        }
        case 'leak': {
          if (treeObj) { treeObj.userData.hurt = 1; const p = treeObj.position; sparks.burst(p.x, 1.8, p.z, 30, 0xff3a3a, 3.5, 0.7, 0.18, 0.04, 3); }
          shake = Math.max(shake, e.boss ? 0.6 : 0.18);
          break;
        }
        case 'meteor': {
          const [X, , Z] = pos3(e.x, e.y);
          const m = new T3.Mesh(meteorGeo, meteorMat); scene.add(m);
          meteors.push({ m, sx: X + 5, sy: 16, sz: Z - 7, tx: X, tz: Z, t: 0, dur: e.delay, slot: e.slot });
          addRing(X, Z, 0.06, 1.7, PLAYER_COLORS[e.slot] || 0xff4040, e.delay, 0.9);
          break;
        }
        case 'meteorhit': {
          const [X, , Z] = pos3(e.x, e.y);
          sparks.burst(X, 0.4, Z, 110, 0xff8a2a, 6.5, 0.8, 0.3, 0.04, 4); sparks.burst(X, 0.4, Z, 50, 0xffe0a0, 4, 0.5, 0.35, 0.05, 2);
          smoke.burst(X, 0.3, Z, 34, 0x3a3030, 2.6, 1.8, 0.5, 1.6, -0.6);
          for (let i = 0; i < 16; i++) smoke.emit(X, 0.3, Z, (Math.random() - 0.5) * 6, 3 + Math.random() * 3, (Math.random() - 0.5) * 6, 0x5a4a3a, 1.2, 0.18, 0.1, 9, 0.5);
          addRing(X, Z, 0.08, e.r * 1.6, 0xffa040, 0.6); addRing(X, Z, 0.1, e.r * 2.6, 0xffffff, 0.8, 0.5);
          shake = Math.max(shake, 0.55); flash = 1;
          break;
        }
        case 'stomp': { const [X, , Z] = pos3(e.x, e.y); addRing(X, Z, 0.08, e.r, 0xc89a6a, 0.7, 0.9); smoke.burst(X, 0.2, Z, 30, 0xb09070, 3.5, 1.0, 0.3, 0.8, -0.2); shake = Math.max(shake, 0.4); break; }
        case 'summon': { const [X, , Z] = pos3(e.x, e.y); sparks.burst(X, 0.5, Z, 24, 0x7ee05a, 2.5, 0.6, 0.18, 0.03, 3); break; }
        case 'shieldup': { const [X, , Z] = pos3(e.x, e.y); sparks.burst(X, 1, Z, 30, 0xb08aff, 3, 0.6, 0.18, 0.03, 0); break; }
        case 'heal': { const [X, , Z] = pos3(e.x, e.y); for (let i = 0; i < 6; i++) sparks.emit(X + (Math.random() - 0.5) * 1.6, 0.3, Z + (Math.random() - 0.5) * 1.6, 0, 1.2, 0, 0x9aff7a, 0.8, 0.14, 0.04, 0, 0.5); addRing(X, Z, 0.05, 1.8, 0x9aff7a, 0.5, 0.35); break; }
        case 'freeze': { const [X, , Z] = pos3(e.x, e.y); sparks.burst(X, 0.4, Z, 16, 0xd8f6ff, 2, 0.5, 0.12, 0.03, 2); break; }
        case 'crit': { const [X, , Z] = pos3(e.x, e.y); sparks.burst(X, 0.5, Z, 14, 0xffffff, 3, 0.3, 0.12, 0.02, 0); floaters.push({ x: X, y: 0.9, z: Z, text: '!!', color: '#ffffff', life: 0.6 }); break; }
        case 'income': { const [X, , Z] = pos3(e.x + 0.5, e.y + 0.5); sparks.burst(X, 1, Z, 16, 0xffd23a, 2, 0.9, 0.12, 0.05, 3, 2); floaters.push({ x: X, y: 1.5, z: Z, text: '+' + e.v, color: '#ffd84a', life: 1.6 }); break; }
        case 'deflect': { if (Math.random() < 0.3) { const [X, , Z] = pos3(e.x, e.y); sparks.burst(X, 0.9, Z, 3, 0xd0b0ff, 2, 0.25, 0.1, 0.02, 0); } break; }
        case 'waveclear': case 'wave': break;
      }
    }
    let flash = 0;

    /* ---------- 毎フレーム：計算の状態を写す ---------- */
    function sync(g, dt) {
      // 塔
      const seen = new Set();
      for (const t of g.towers) {
        seen.add(t.id);
        let o = towerObjs.get(t.id);
        const key = t.k + t.lvl + t.br + t.owner;
        if (o && o.key !== key) { const s = o.scale; removeTowerObj(o); o = makeTower(t); o.scale = Math.max(0.7, s); o.born = now - 0.2; towerObjs.set(t.id, o); }
        if (!o) { o = makeTower(t); towerObjs.set(t.id, o); }
        // 建つ時に、はずんで出る
        const age = now - o.born; o.scale = age < 0.45 ? easeBack(age / 0.45) : 1;
        o.g.scale.setScalar(o.scale);
        if (o.fireN !== t.fireN) { o.fireN = t.fireN; o.recoil = 1; }
        const target = -t.yaw; let d = target - o.yaw; d = Math.atan2(Math.sin(d), Math.cos(d)); o.yaw += d * Math.min(1, dt * 12);
        o.headG.rotation.y = o.yaw;
        o.recoil = Math.max(0, o.recoil - dt * 6);
        if (o.kind === 'cannon' || o.kind === 'arrow') o.headG.position.x = -Math.cos(o.yaw) * o.recoil * 0.06, o.headG.position.z = Math.sin(o.yaw) * o.recoil * 0.06;
        if (o.glow) { o.glow.rotation.y = now * (o.kind === 'ice' ? 1.2 : 0.6); o.glow.position.y = Math.sin(now * 2 + t.id) * 0.05; const s = 1 + o.recoil * 0.25; o.glow.scale.setScalar(s); }
        if (o.kind === 'gold' && o.glow) { o.glow.rotation.y = now * 3; o.glow.position.y = 0.15 + Math.sin(now * 2 + t.id) * 0.08; }
        if (o.aura) { o.aura.rotation.z = now * 0.4; o.aura.material.opacity = o.kind === 'ice' ? (t.active ? 0.2 : 0.08) : 0.25 + Math.sin(now * 3) * 0.1; if (o.kind === 'ice' && t.active && Math.random() < 0.4) { const a = Math.random() * 6.28, rr = Math.random() * t.st.rng; sparks.emit(o.g.position.x + Math.cos(a) * rr, 0.6, o.g.position.z + Math.sin(a) * rr, 0, -0.4, 0, 0xeaffff, 1.0, 0.08, 0.04, 0, 0); } }
        if (t.stun > 0) { o.stunFx += dt; if (o.stunFx > 0.25) { o.stunFx = 0; sparks.emit(o.g.position.x + (Math.random() - 0.5) * 0.4, 1.2, o.g.position.z + (Math.random() - 0.5) * 0.4, 0, 0.6, 0, 0xffe080, 0.6, 0.14, 0.06, 0, 0); } }
        if (o.kind === 'poison' && Math.random() < dt * 3) sparks.emit(o.g.position.x + (Math.random() - 0.5) * 0.3, 0.7, o.g.position.z + (Math.random() - 0.5) * 0.3, 0, 0.5, 0, t.br === 'B' ? 0xffa040 : 0x7aff5a, 0.8, 0.07, 0.12, 0, 0.3);
        if (o.kind === 'thunder' && Math.random() < dt * 2) { const p = o.g.position; sparks.emit(p.x, o.headG.position.y + 0.25, p.z, (Math.random() - 0.5) * 2, Math.random() * 2, (Math.random() - 0.5) * 2, 0xfff6a0, 0.25, 0.06, 0.02, 0, 2); }
      }
      for (const [id, o] of towerObjs) if (!seen.has(id)) { removeTowerObj(o); towerObjs.delete(id); }
      // 敵
      const counts = {}; for (const p of enemyParts) p.im.count = 0;
      const alive = new Set();
      let bi = 0;
      for (const e of g.enemies) {
        alive.add(e.id);
        let v = evis.get(e.id);
        const off = (((e.id * 37) % 11) / 10 - 0.5) * 0.36;
        const tx = wx(e.x) - Math.sin(e.dir) * off * (e.boss ? 0 : 1), tz = wz(e.y) + Math.cos(e.dir) * off * (e.boss ? 0 : 1);
        if (!v) { v = { x: tx, z: tz, yaw: -e.dir, ph: Math.random() * 6, born: now }; evis.set(e.id, v); sparks.burst(tx, 0.4, tz, 6, 0xc08aff, 1.2, 0.4, 0.12, 0.02, 0); }
        const k = Math.min(1, dt * 14); v.x += (tx - v.x) * k; v.z += (tz - v.z) * k;
        let dy = -e.dir - v.yaw; dy = Math.atan2(Math.sin(dy), Math.cos(dy)); v.yaw += dy * Math.min(1, dt * 8);
        const moving = !(e.freezeT > 0 || e.stunT > 0);
        if (moving) v.ph += dt * e.spd * (1 - e.slow) * 3.2;
        const parts = enemyModels[e.type]; if (!parts) continue;
        const sc = e.r * 1.65 * (ENEMY_SCALE[e.type] || 1) * Math.min(1, (now - v.born) * 4 + 0.2);
        const y = e.fly ? 1.15 + Math.sin(now * 2 + e.id) * 0.1 : -0.14;
        ry.set(0, v.yaw, 0); rq.setFromEuler(ry);
        rootM.compose(rp.set(v.x, y, v.z), rq, rs.set(sc, sc, sc));
        const st = { ph: v.ph, id: e.id };
        const flashK = e.hitT > 0 ? e.hitT / 0.12 : 0;
        _c.setRGB(1, 1, 1);
        if (e.freezeT > 0) _c.copy(TINT_FREEZE); else if (e.slow > 0) _c.copy(TINT_SLOW); else if (e.dotT > 0) _c.copy(TINT_POISON);
        if (e.shield > 0) _c.copy(TINT_SHIELD);
        if (flashK > 0) _c.lerp(FLASH_C, flashK * 0.7);
        const baseCol = ENEMY_LOOK[e.type];
        for (const p of enemyParts) {
          if (p.type !== (e.type === 'sprout' ? 'sprout' : e.type)) continue;
          for (let i = 0; i < p.part.n; i++) {
            if (p.im.count >= p.cap) break;
            p.part.f(st, i, now, partM);
            outM.multiplyMatrices(rootM, partM);
            const idx = p.im.count++;
            p.im.setMatrixAt(idx, outM);
            if (p.part.tint) { tintC.set(baseCol).multiply(_c); p.im.setColorAt(idx, tintC); } else p.im.setColorAt(idx, flashK > 0 ? _c : WHITE);
          }
        }
        // ボスの盾
        if (e.boss && e.shield > 0 && bi < bubbles.length) { const b = bubbles[bi++]; b.visible = true; b.position.set(v.x, 0.9 * sc, v.z); b.scale.setScalar(sc * 1.1 + Math.sin(now * 8) * 0.03); }
        // 毒・氷の粒
        if (e.dotT > 0 && Math.random() < dt * 4) smoke.emit(v.x, y + 0.5 * sc, v.z, 0, 0.5, 0, 0x6ad04a, 0.7, 0.12, 0.25, 0, 0.5);
        if (e.freezeT > 0 && Math.random() < dt * 6) sparks.emit(v.x + (Math.random() - 0.5) * 0.4, y + 0.4, v.z + (Math.random() - 0.5) * 0.4, 0, 0.3, 0, 0xeaffff, 0.5, 0.08, 0.03, 0, 0);
        if (e.stunT > 0 && Math.random() < dt * 5) sparks.emit(v.x, y + sc * 1.1, v.z, Math.cos(now * 8) * 0.8, 0, Math.sin(now * 8) * 0.8, 0xffe060, 0.4, 0.1, 0.05, 0, 0);
      }
      for (let i = bi; i < bubbles.length; i++) bubbles[i].visible = false;
      for (const p of enemyParts) { p.im.instanceMatrix.needsUpdate = true; if (p.im.instanceColor) p.im.instanceColor.needsUpdate = true; }
      for (const id of evis.keys()) if (!alive.has(id)) evis.delete(id);
      // 弾
      for (const k in shotIM) shotIM[k].count = 0;
      for (const s of g.shots) {
        const im = shotIM[s.kind]; if (!im || im.count >= 220) continue;
        const d0 = Math.hypot(s.x - s.sx, s.y - s.sy), d1 = Math.hypot(s.tx - s.x, s.ty - s.y), prog = d0 / Math.max(0.001, d0 + d1);
        let h = 1.0 + (0.45 - 1.0) * prog;
        if (s.kind === 'ball') h = 0.9 + Math.sin(Math.PI * prog) * 1.4 - 0.5 * prog;
        if (s.kind === 'orb') h = 0.8 + Math.sin(Math.PI * prog) * 0.6 - 0.4 * prog;
        const X = wx(s.x), Z = wz(s.y), yaw = -Math.atan2(s.ty - s.y, s.tx - s.x);
        const pitch = s.kind === 'ball' ? 0 : -0.25 * (1 - prog * 2);
        L(lm, X, h, Z, 0, yaw, s.kind === 'arrow' ? pitch : now * 6, 1, 1, 1);
        im.setMatrixAt(im.count++, lm);
        if (s.kind === 'ball' && Math.random() < 0.6) smoke.emit(X, h, Z, 0, 0.2, 0, 0x9a9a9a, 0.5, 0.12, 0.25, 0, 0.5);
        if (s.kind === 'shard' && Math.random() < 0.7) sparks.emit(X, h, Z, 0, 0, 0, 0xbff0ff, 0.25, 0.1, 0.02, 0, 0);
        if (s.kind === 'orb' && Math.random() < 0.7) sparks.emit(X, h, Z, 0, 0.1, 0, s.br === 'B' ? 0xffa040 : 0x8aff5a, 0.35, 0.12, 0.03, 0, 0);
        if (s.kind === 'arrow' && s.st && s.st.crit && Math.random() < 0.5) sparks.emit(X, h, Z, 0, 0, 0, 0xbfd8ff, 0.2, 0.08, 0.02, 0, 0);
      }
      for (const k in shotIM) shotIM[k].instanceMatrix.needsUpdate = true;
    }
    const tintC = new T3.Color(), WHITE = new T3.Color(1, 1, 1), FLASH_C = new T3.Color(3, 3, 3), X_AXIS = new T3.Vector3(1, 0, 0), _dir = new T3.Vector3(), _off = new T3.Vector3(), Y_AXIS = new T3.Vector3(0, 1, 0);
    function easeBack(t) { const c = 1.9; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); }

    /* 人の印（選んでいる升） */
    function setCursors(list, g) {
      const used = new Set();
      for (const c of list) {
        const cur = cursors[c.slot]; if (!cur) continue; used.add(c.slot);
        cur.g.visible = true;
        const X = wx(c.x) + 0.5, Z = wz(c.y) + 0.5;
        cur.g.position.x += (X - cur.g.position.x) * 0.35; cur.g.position.z += (Z - cur.g.position.z) * 0.35;
        if (cur.x !== c.x || cur.y !== c.y) { cur.x = c.x; cur.y = c.y; cur.bump = 1; }
        const t = g ? window.TdSim.towerAt(g, c.x, c.y) : null;
        const cell = g ? window.TdSim.cellAt(g, c.x, c.y) : '.';
        const top = t ? (0.9 + (t.lvl * 0.12)) : 0.15;
        cur.g.position.y = 0.02;
        cur.arrow.position.y = top + 0.9 + Math.sin(now * 4 + c.slot) * 0.12;
        cur.bump = Math.max(0, (cur.bump || 0) - 0.08);
        cur.sq.scale.setScalar(0.98 + cur.bump * 0.3 + Math.sin(now * 5) * 0.02);
        const bad = !t && cell !== '.' && cell !== 'h';
        cur.fill.material.opacity = bad ? 0.05 : 0.2;
        cur.sq.material.opacity = bad ? 0.4 : 0.95;
        const r = t && t.st && t.st.rng ? t.st.rng : c.rng || 0;
        cur.range.visible = cur.rangeFill.visible = r > 0;
        if (r > 0) { cur.range.scale.set(r, r, 1); cur.rangeFill.scale.set(r, r, 1); }
      }
      cursors.forEach((c, i) => { if (!used.has(i)) c.g.visible = false; });
    }

    /* 画面の上の 2D（体力の帯・名前・+お金） */
    function project(X, Y, Z) { _v.set(X, Y, Z).project(camera); return [(_v.x + 1) / 2 * overlay.width, (1 - _v.y) / 2 * overlay.height, _v.z]; }
    function drawOverlay(g, names) {
      const c = ctx2, sx = overlay.width / Math.max(1, W);
      c.clearRect(0, 0, overlay.width, overlay.height);
      if (!g || g.ph !== 'play') return;
      const bw = 34 * sx, bh = 5 * sx;
      for (const e of g.enemies) {
        if (e.hp >= e.maxHp - 0.01 || e.boss) continue;
        const v = evis.get(e.id); if (!v) continue;
        const sc = e.r * 1.65 * (ENEMY_SCALE[e.type] || 1);
        const [x, y] = project(v.x, (e.fly ? 1.2 : 0) + sc * 1.05 + 0.1, v.z);
        const w = bw * Math.max(0.6, sc * 1.4), f = Math.max(0, e.hp / e.maxHp);
        c.fillStyle = 'rgba(10,14,20,.7)'; c.fillRect(x - w / 2 - sx, y - sx, w + 2 * sx, bh + 2 * sx);
        c.fillStyle = f > 0.5 ? '#6be06b' : f > 0.25 ? '#ffc94a' : '#ff5a4a'; c.fillRect(x - w / 2, y, w * f, bh);
        if (e.shred > 0) { c.fillStyle = '#c8a0ff'; c.fillRect(x - w / 2, y + bh - 1.5 * sx, w, 1.5 * sx); }
      }
      c.textAlign = 'center'; c.textBaseline = 'middle';
      for (const f of floaters) {
        const [x, y] = project(f.x, f.y, f.z);
        c.globalAlpha = Math.min(1, f.life * 2);
        c.font = `900 ${(f.small ? 15 : 22) * sx}px "Dela Gothic One","Zen Maru Gothic",sans-serif`;
        c.lineWidth = 4 * sx; c.strokeStyle = 'rgba(30,20,10,.85)'; c.strokeText(f.text, x, y); c.fillStyle = f.color; c.fillText(f.text, x, y);
      }
      c.globalAlpha = 1;
      // 人の名前（印の上）
      for (const n of names || []) {
        const cur = cursors[n.slot]; if (!cur || !cur.g.visible) continue;
        const [x, y] = project(cur.g.position.x, cur.arrow.position.y + 0.35, cur.g.position.z);
        c.font = `900 ${15 * sx}px "Zen Maru Gothic",sans-serif`;
        const tw = c.measureText(n.name).width + 16 * sx;
        c.fillStyle = n.color; roundRect(c, x - tw / 2, y - 12 * sx, tw, 24 * sx, 12 * sx); c.fill();
        c.fillStyle = '#1b2230'; c.fillText(n.name, x, y + sx);
      }
    }
    function roundRect(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }

    /* 1 フレーム描く */
    function frame(g, opt) {
      const tnow = performance.now() / 1000, dt = Math.min(0.1, tnow - lastT); lastT = tnow; now += dt;
      watchFps(dt);
      if (g && g.ev) for (const e of opt.events || []) { try { fx(e); } catch (err) { console.warn('効果を出せませんでした：' + e.k, err); } }
      if (g && g.level && g.ph !== 'lobby') sync(g, dt); else clearDynamic();
      setCursors(opt.cursors || [], g);
      // 木・出口・光る石
      if (treeObj) {
        const u = treeObj.userData, life = g && g.maxLives ? g.lives / g.maxLives : 1;
        u.hurt = Math.max(0, u.hurt - dt * 2.5);
        u.leaves.rotation.y = Math.sin(now * 0.5) * 0.05;
        u.leaves.position.x = u.hurt * Math.sin(now * 60) * 0.06;
        u.leafMat.emissiveIntensity = 0.04 + 0.12 * life + Math.sin(now * 2) * 0.03 + u.hurt * 0.6;
        u.leafMat.emissive.set(look.glow).lerp(_c.set(0xff2020), u.hurt * 0.8);
        u.light.intensity = (1.5 + 2.5 * life) * (quality >= 1 ? 1 : 0.6);
        u.orbs.forEach((o, i) => { const a = now * 0.6 + i * 0.9; o.position.set(Math.cos(a) * (0.9 + 0.2 * Math.sin(i)), 1.4 + i * 0.16 + Math.sin(now * 2 + i) * 0.1, Math.sin(a) * (0.9 + 0.2 * Math.sin(i))); o.visible = i < Math.ceil(7 * life); });
        if (Math.random() < dt * 4) sparks.emit(treeObj.position.x + (Math.random() - 0.5) * 1.4, 1.2 + Math.random(), treeObj.position.z + (Math.random() - 0.5) * 1.4, 0, 0.35, 0, look.glow, 2.2, 0.1, 0.02, 0, 0);
      }
      for (const p of portals) { p.userData.discMat.uniforms.uT.value = now; if (Math.random() < dt * 5) sparks.emit(p.position.x + (Math.random() - 0.5) * 0.6, 0.4 + Math.random() * 0.6, p.position.z + (Math.random() - 0.5) * 0.6, 0, 0.4, 0, 0xc070ff, 0.8, 0.08, 0.02, 0, 0); }
      for (const r of runes) { r.userData.gem.position.y = 0.35 + Math.sin(now * 2 + r.position.x) * 0.06; r.userData.gem.rotation.y = now; r.userData.ring.material.opacity = 0.5 + Math.sin(now * 3 + r.position.z) * 0.25; }
      // かみなりの棒
      bolts = bolts.filter(b => (b.life -= dt) > 0);
      boltIM.count = 0;
      for (const b of bolts) {
        if (boltIM.count >= 400) break;
        const dx = b.b[0] - b.a[0], dy = b.b[1] - b.a[1], dz = b.b[2] - b.a[2], len = Math.hypot(dx, dy, dz);
        _v.set((b.a[0] + b.b[0]) / 2, (b.a[1] + b.b[1]) / 2, (b.a[2] + b.b[2]) / 2);
        _q.setFromUnitVectors(X_AXIS, _dir.set(dx / len, dy / len, dz / len));
        _m4.compose(_v, _q, _s.set(len, b.w * (b.life / 0.16 + 0.3), b.w * (b.life / 0.16 + 0.3)));
        boltIM.setMatrixAt(boltIM.count++, _m4);
      }
      boltIM.instanceMatrix.needsUpdate = true;
      // 流れ星
      for (let i = meteors.length - 1; i >= 0; i--) {
        const m = meteors[i]; m.t += dt; const k = Math.min(1, m.t / m.dur), e2 = k * k;
        m.m.position.set(m.sx + (m.tx - m.sx) * e2, m.sy + (0.3 - m.sy) * e2, m.sz + (m.tz - m.sz) * e2); m.m.rotation.x += dt * 8; m.m.rotation.z += dt * 5;
        for (let j = 0; j < 4; j++) { sparks.emit(m.m.position.x, m.m.position.y, m.m.position.z, (Math.random() - 0.5), (Math.random() - 0.5), (Math.random() - 0.5), j % 2 ? 0xffd080 : 0xff6a20, 0.5, 0.4, 0.05, 0, 0); }
        smoke.emit(m.m.position.x, m.m.position.y, m.m.position.z, 0, 0.3, 0, 0x6a5a50, 0.8, 0.3, 0.7, 0, 0.5);
        if (k >= 1) { scene.remove(m.m); meteors.splice(i, 1); }
      }
      // 輪
      for (let i = rings.length - 1; i >= 0; i--) {
        const r = rings[i]; r.life -= dt; const k = 1 - r.life / r.max;
        r.m.scale.setScalar(Math.max(0.01, r.r * (0.2 + 0.8 * Math.sqrt(k)))); r.m.material.opacity = (1 - k) * 0.8;
        if (r.life <= 0) { scene.remove(r.m); r.m.material.dispose(); rings.splice(i, 1); }
      }
      for (let i = floaters.length - 1; i >= 0; i--) { const f = floaters[i]; f.life -= dt; f.y += dt * 0.8; if (f.life <= 0) floaters.splice(i, 1); }
      sparks.update(dt); smoke.update(dt);
      waterMat.uniforms.uT.value = now; waterMat.uniforms.uCam.value.copy(camera.position);
      // カメラ（待合室ではゆっくり回る。揺れ）
      shake = Math.max(0, shake - dt * 1.6);
      if (lobbyOrbit) { const a = Math.sin(now * 0.15) * 0.25; _off.copy(camBase).sub(camLook).applyAxisAngle(Y_AXIS, a); camera.position.copy(camLook).add(_off); }
      else camera.position.copy(camBase);
      camera.position.x += Math.sin(now * 0.3) * 0.15 + (Math.random() - 0.5) * shake * 0.5;
      camera.position.y += (Math.random() - 0.5) * shake * 0.5;
      camera.lookAt(camLook);
      flash = Math.max(0, flash - dt * 3);
      renderer.toneMappingExposure = EXPOSURE + flash * 0.5;
      if (composer) composer.render(); else renderer.render(scene, camera);
      drawOverlay(g, opt.names);
    }
    function clearDynamic() {
      for (const [, o] of towerObjs) removeTowerObj(o); towerObjs.clear();
      for (const p of enemyParts) p.im.count = 0;
      for (const k in shotIM) shotIM[k].count = 0;
      evis.clear();
    }

    buildEnemyMeshes(); buildShotMeshes();
    resize();
    return {
      setLevel, frame, resize, project,
      setLobby(on) { lobbyOrbit = !!on; },
      get quality() { return quality; }, get fps() { return fpsShown; }, get calls() { return renderer.info.render.calls; },
      setQuality(q) { quality = Math.max(0, Math.min(2, q)); autoQ = false; resize(); },
      PLAYER_COLORS,
    };
  }

  window.TdView = { create, PLAYER_COLORS, ENEMY_LOOK, towerParts };
})();

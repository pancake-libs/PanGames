/* 共通部品：手応え（止める・揺らす・白くする・押し戻す）。戦車のゲームと AIGAMEリサーチの調べ（20261114_hit-feel-bundle）の値をまとめたもの（2026-11-15）。
   決まり：
   - 全体の時間は止めない。止めるのは当たった物だけ（論理の状態に「止まる残り秒」を持つ）
   - 揺れ・白は描画だけで行い、論理の座標を動かさない
   - 揺れは短く小さく（テレビの大きな画面・祖父母は酔いやすい）。上限 SHAKE_MAX
   - 層ごとに ON/OFF（FPFeel.layers）。家族で 1 つずつ足して比べる

   使い方：
     const p = FPFeel.preset('heavy');   // { freeze, shake, flash, push } 秒・強さ
     obj.freeze = p.freeze;              // 論理側：当たった物を止める
     view.shake.add(p.shake);            // 描画側：const [dx, dy] = view.shake.offset(dt)
     const k = FPFeel.flashAlpha(obj.flashLeft, p.flash);  // 白くする強さ 0〜1 */
(function () {
  'use strict';
  // 30 フレーム/秒で数えた作者の例を、秒に直したもの
  const PRESETS = {
    light:  { freeze: 0.10, shake: 0.06, flash: 0.08, push: 0.15 },   // ふつうの弾がレンガ・敵に当たる
    medium: { freeze: 0.18, shake: 0.12, flash: 0.08, push: 0.30 },
    heavy:  { freeze: 0.33, shake: 0.30, flash: 0.09, push: 0.60 },   // 強い弾・敵を倒す・大きな爆発
    boss:   { freeze: 0.40, shake: 0.50, flash: 0.10, push: 0.80 },   // ボスを倒す（これ以上は「止まった」に見える）
  };
  const FREEZE_MAX = 0.8, SHAKE_MAX = 0.6;
  const layers = { freeze: true, shake: true, flash: true, push: true };

  function preset(name) {
    const p = PRESETS[name] || PRESETS.light;
    return { freeze: layers.freeze ? Math.min(FREEZE_MAX, p.freeze) : 0, shake: layers.shake ? p.shake : 0, flash: layers.flash ? p.flash : 0, push: layers.push ? p.push : 0 };
  }
  // 揺れ：強さを足して、時間で消す。dir（ラジアン）を渡すと、その向きに強く揺らす
  function Shake(scale) {
    let amt = 0, dir = null;
    return {
      add(v, d) { if (!layers.shake) return; amt = Math.min(SHAKE_MAX, Math.max(amt, v)); dir = d === undefined ? null : d; },
      offset(dt) {
        amt = Math.max(0, amt - dt * 1.6);
        if (amt <= 0) return [0, 0];
        const a = amt * (scale || 1);
        if (dir === null) return [(Math.random() - .5) * a, (Math.random() - .5) * a];
        const r = (Math.random() - .5) * a, s = (Math.random() - .5) * a * .35;
        return [Math.cos(dir) * r - Math.sin(dir) * s, Math.sin(dir) * r + Math.cos(dir) * s];
      },
      get value() { return amt; },
    };
  }
  function flashAlpha(left, total) { return total > 0 && left > 0 ? Math.min(1, left / total) : 0; }
  // 続くほど段を上げる（音の高さ・文字の大きさ・揺れ）。n＝続いた数
  function comboLevel(n) { return Math.max(0, Math.min(7, n | 0)); }
  window.FPFeel = { PRESETS, layers, preset, Shake, flashAlpha, comboLevel, FREEZE_MAX, SHAKE_MAX };
})();

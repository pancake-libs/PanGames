/* 共通部品：3D の舞台（描画の準備・光・空・霧・カメラ）。タワーディフェンス（td-view.js）の作りをまとめたもの（2026-11-15）。
   Three.js（three-td.js の window.THREE）を使う。

   使い方：
     const st = FPScene3d.create(canvas, { exposure: .82 });   // { renderer, scene, camera, sun, hemi }
     st.applyLook('meadow');                // 景色の光の組（LOOKS）を当てる。オブジェクトも渡せる
     st.fit(cols, rows);                    // 盤（cols × rows、真ん中が原点）が画面に収まる所へカメラを置く
     st.renderer.render(st.scene, st.camera);
   景色の光の組は td-view.js の BIOME_LOOK の光の部分と同じ値。地面の色・飾りは各ゲームで持つ */
(function () {
  'use strict';
  const T3 = window.THREE;
  if (!T3) { console.error('Three.js が読めていません（three-td.js を先に読む）'); return; }

  const LOOKS = {
    meadow:  { sky: ['#7fc8ff', '#e9f8ff'], sun: 0xfff1d6, sunI: 2.0, hemi: [0xcfeaff, 0x5a7a3a], hemiI: .72, fog: 0xcdeeff },
    desert:  { sky: ['#ffc98a', '#fff3dc'], sun: 0xffe2b0, sunI: 2.0, hemi: [0xffe6c4, 0x8a6a3a], hemiI: .72, fog: 0xffe6c2 },
    snow:    { sky: ['#a9cdf2', '#f1f7ff'], sun: 0xffffff, sunI: 1.5, hemi: [0xe8f2ff, 0x7a8ca0], hemiI: .72, fog: 0xe4efff },
    autumn:  { sky: ['#ffae7a', '#ffe9d2'], sun: 0xffd9a8, sunI: 2.0, hemi: [0xffe0c0, 0x6a4a2a], hemiI: .72, fog: 0xffe0c8 },
    volcano: { sky: ['#2a0f12', '#7a2f1c'], sun: 0xffb08a, sunI: 1.2, hemi: [0xff9a70, 0x2a1210], hemiI: .6, fog: 0x5a2418, glowy: true },
    crystal: { sky: ['#070b26', '#2a1e5c'], sun: 0xb8c4ff, sunI: .9, hemi: [0x8a9aff, 0x1a1640], hemiI: .5, fog: 0x1a1844, glowy: true },
  };

  function create(canvas, opts) {
    opts = opts || {};
    const renderer = new T3.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    renderer.outputColorSpace = T3.SRGBColorSpace;
    renderer.toneMapping = T3.ACESFilmicToneMapping; renderer.toneMappingExposure = opts.exposure || .82;
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = T3.PCFSoftShadowMap;
    const scene = new T3.Scene();
    const camera = new T3.PerspectiveCamera(opts.fov || 38, 16 / 9, .5, 200);
    const pmrem = new T3.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new T3.RoomEnvironment(), .04).texture;   // 金属・つやの映り込み
    const hemi = new T3.HemisphereLight(0xffffff, 0x445533, .9); scene.add(hemi);
    const sun = new T3.DirectionalLight(0xffffff, 2.4);
    sun.position.set(-9, 20, 11); sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048); sun.shadow.bias = -.0004; sun.shadow.normalBias = .03;
    const sb = opts.shadowBox || [16, 12];
    Object.assign(sun.shadow.camera, { left: -sb[0], right: sb[0], top: sb[1], bottom: -sb[1], near: 1, far: 60 });
    scene.add(sun); scene.add(sun.target);

    let skyTex = null, look = LOOKS.meadow;
    function setSky(top, bottom) {
      const c = document.createElement('canvas'); c.width = 4; c.height = 256; const x = c.getContext('2d');
      const gr = x.createLinearGradient(0, 0, 0, 256); gr.addColorStop(0, top); gr.addColorStop(.6, bottom); gr.addColorStop(1, bottom); x.fillStyle = gr; x.fillRect(0, 0, 4, 256);
      if (skyTex) skyTex.dispose(); skyTex = new T3.CanvasTexture(c); skyTex.colorSpace = T3.SRGBColorSpace; scene.background = skyTex;
    }
    function applyLook(l) {
      look = typeof l === 'string' ? (LOOKS[l] || LOOKS.meadow) : l;
      setSky(look.sky[0], look.sky[1]);
      scene.fog = new T3.Fog(look.fog, opts.fogNear || 34, opts.fogFar || 85);
      hemi.color.set(look.hemi[0]); hemi.groundColor.set(look.hemi[1]); hemi.intensity = look.hemiI;
      sun.color.set(look.sun); sun.intensity = look.sunI;
      return look;
    }
    // 盤が画面に収まる所にカメラを置く。margin：上と下に空ける割合（HUD・札に隠れないように）
    const camLook = new T3.Vector3(0, 0, 0);
    function fit(cols, rows, margin) {
      margin = margin || { top: .70, bottom: -.80, side: .95 };
      const el = renderer.domElement, W = el.clientWidth || innerWidth, H = el.clientHeight || innerHeight;
      camera.aspect = W / H; camera.updateProjectionMatrix();
      const dir = new T3.Vector3(0, 1.15, .95).normalize();
      const corners = [[-cols / 2, -rows / 2], [cols / 2, -rows / 2], [-cols / 2, rows / 2], [cols / 2, rows / 2]].map(([x, z]) => new T3.Vector3(x, 0, z));
      let d = 6;
      for (let k = 0; k < 120; k++) {
        camera.position.copy(camLook).addScaledVector(dir, d); camera.lookAt(camLook); camera.updateMatrixWorld();
        const ok = corners.every(c => { const p = c.clone().project(camera); return Math.abs(p.x) < margin.side && p.y < margin.top && p.y > margin.bottom; });
        if (ok) break; d += .5;
      }
      return camera.position.clone();
    }
    return { renderer, scene, camera, sun, hemi, setSky, applyLook, fit, camLook, get look() { return look; } };
  }
  window.FPScene3d = { create, LOOKS };
})();

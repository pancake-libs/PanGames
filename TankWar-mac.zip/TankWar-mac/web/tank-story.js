/* 戦車のゲームの「物語」（v0.20、P3D）。中身（文・決まり）だけを ここに置く。絵と やりとりは tank.html の P3D の所。node からも読める。
   No.2  ボスと なかよくなる（CAPTURE：6 体）→ ボス戦車（車の中身は tank-gear.js の P3D_BOSS_CARS）／けっとう（DUEL：1 対 1）
   No.30 エンディング（ENDING）と 2 周目
   No.21 わかれ道（BRANCH）：世界の最後のボスの あとに、家族で 2 つから えらぶ。多数決、同じ数なら 最初に押した人
   No.41 まんが（OPENING・DEFEAT）：世界の始まり・ボスを たおした後
   No.42 こえ（VOICE）：ボスごとの 高さ・速さ
   No.49 ひみつ（SECRETS）：ひみつの かべ → ひみつの面・かくし宝箱・ひみつのボス
   文は ぜんぶ 日本語と中国語。{names}＝参加者みんな、{top}＝いちばん がんばった人 */
(function (root) {
  'use strict';
  const Stages = root.TankStages || (typeof require !== 'undefined' ? require('./tank-stages.js') : null);
  const PER = Stages.PER_WORLD, ADV = Stages.ADV, WORLDS = Stages.WORLDS;

  /* ---------- No.49 ひみつ ----------
     door＝ひみつの かべ（こわすと ワールドマップに ひみつの面が出る）、item＝かくし宝箱（こわすと 金の宝箱）。
     面は「ふつうの面」（ボス・旗・護送などでない面）から、世界ごとに 2 つ。地獄の door は ひみつのボスへ */
  const SECRETS = [
    { id: 'd0', kind: 'door', world: 0, no: 5 }, { id: 'i0', kind: 'item', world: 0, no: 14 },
    { id: 'd1', kind: 'door', world: 1, no: 4 }, { id: 'i1', kind: 'item', world: 1, no: 17 },
    { id: 'd2', kind: 'door', world: 2, no: 6 }, { id: 'i2', kind: 'item', world: 2, no: 14 },
    { id: 'd3', kind: 'door', world: 3, no: 12 }, { id: 'i3', kind: 'item', world: 3, no: 2 },
    { id: 'd4', kind: 'door', world: 4, no: 4 }, { id: 'i4', kind: 'item', world: 4, no: 12 },
    { id: 'd5', kind: 'door', world: 5, no: 14 }, { id: 'i5', kind: 'item', world: 5, no: 2 }
  ];
  const SECRET_BOSS_ID = 'sb';                 // ひみつのボスを たおした
  const SECRET_TOTAL = SECRETS.length + 1;
  const SECRET_BY = {};
  for (const s of SECRETS) { s.gi = s.world * PER + s.no - 1; SECRET_BY[s.id] = s; const st = ADV[s.gi]; if (st && !st.bosses && !st.type) st.p3dSec = { id: s.id, kind: s.kind }; }
  const doorOf = world => SECRETS.find(s => s.kind === 'door' && s.world === world) || null;
  const secretAt = gi => SECRETS.find(s => s.gi === gi) || null;
  // ひみつの面。世界 0〜4＝たからの部屋（やさしい敵・宝箱 4 つ）、世界 5＝ひみつのボス「きんぴか戦車」
  function bonusStage(world) {
    const w = WORLDS[world]; if (!w) return null;
    // v0.22 P5A：ひみつの面は いつも ふるさとの場面・おうちは下（A）。もとの面が旗などに変わっても たからべやは 今と同じ形
    const H = Stages.SCENES[w.home], home = { scene: w.home, sceneNew: false, theme: H.theme, fx: H.fx, base: 'A', baseSide: 'L', event: null, type: null, survive: 0 };
    if (world === 5) {
      const base = ADV[world * PER + 7];
      return Object.assign({}, base, { id: 'x-boss', p3dBonus: world, p3dGold: true, ja: 'ひみつのボス：きんぴか戦車', zh: '秘密首领：黄金坦克', bosses: ['boss'], reunion: null, p3dSec: null,
        seed: base.seed + 777, p3dChests: ['gold'], night: false }, home);
    }
    const base = ADV[world * PER + 1];
    return Object.assign({}, base, { id: 'x-' + world, p3dBonus: world, ja: 'ひみつの たからべや（' + w.ja + '）', zh: '秘密宝藏屋（' + w.zh + '）', easy: true, s: Math.max(0, base.s - 1), em: base.em * 0.6,
      captains: 0, night: false, blizzard: false, storm: false, reunion: null, p3dSec: null, type: null, survive: 0, rows: 26, seed: base.seed + 555, p3dChests: ['silver', 'silver', 'silver', 'gold'] }, home);
  }

  /* ---------- No.21 わかれ道 ----------
     世界 w（0〜4）の最後のボスを たおした後に きく。a＝まもりの こたえ（つぎの世界：おうちの守り +1）、b＝ゆうきの こたえ（つぎの世界：はじめの盾 +4 秒）。
     open＝つぎの世界の始まりの まんがの 2 こま目（えらんだ方で 変わる）。エンディングは a・b の数で 3 通り */
  const HELP = { a: { k: 'futon', n: 1, ja: '🏠 つぎの せかいでは、おうちの まもりが +1', zh: '🏠 在下一个世界，小屋防护 +1' }, b: { k: 'shield', n: 4, ja: '🛡 つぎの せかいでは、はじめの たてが +4 びょう', zh: '🛡 在下一个世界，开场护盾 +4 秒' } };
  const BRANCH = [
    { who: 'bigtank', ja: 'おれも ちからに なりたい。なにを すれば いい？', zh: '我也想出一份力。我该做什么？',
      a: { ic: '🏠', ja: 'おうちを まもって！', zh: '帮我们守小屋！', re: ['まかせろ。まもるものが、また できた', '交给我。我又有想守护的东西了'], open: ['おうちの まえは おれに まかせろ。おまえたちは まえへ すすめ！', '小屋门口交给我。你们往前冲！'] },
      b: { ic: '🚀', ja: 'いっしょに たたかって！', zh: '和我们一起战斗！', re: ['よし、となりを はしるぞ！', '好，我跑在你们旁边！'], open: ['いっしょに いくぞ！ さいしょの いっぱつは おれが うけとめる！', '一起走！第一发炮弹我来挡！'] } },
    { who: 'sandship', ja: 'ゆきやまへ いくのか。どうやって のぼる？', zh: '要去雪山吗。怎么上去？',
      a: { ic: '⛵', ja: 'ふねで のんびり', zh: '坐船慢慢走', re: ['ゆきの うみか。…わるくない！', '雪的海洋吗。…不坏！'], open: ['ゆきの うみを すすむぞ！ おうちへの にもつは まかせろ', '在雪的海洋里前进！给小屋送东西的事交给我'] },
      b: { ic: '🛷', ja: 'そりで びゅーん！', zh: '坐雪橇嗖——！', re: ['はやいのも すきだ！ つかまれー！', '我也喜欢快的！抓紧——！'], open: ['そりで びゅーんと いくぞ！ しっかり つかまれ！', '坐雪橇嗖地出发！抓紧了！'] } },
    { who: 'snowman', ja: 'かざんは あついよ。なにを もっていく？', zh: '火山很热哦。带什么去？',
      a: { ic: '🧣', ja: 'ゆきの マフラー', zh: '雪围巾', re: ['おうちに まいて あげるね', '我帮你们围在小屋上'], open: ['マフラーを おうちに まいて おいたよ。あつくても だいじょうぶ！', '我把围巾围在小屋上了。再热也不怕！'] },
      b: { ic: '🍧', ja: 'かきごおり', zh: '刨冰', re: ['みんなで たべてね。ひんやり！', '大家一起吃吧。凉冰冰！'], open: ['かきごおりを どうぞ！ ひんやり たてに なるよ', '请吃刨冰！会变成凉凉的护盾哦'] } },
    { who: 'dragon', ja: 'ようさいまで とんでやろう。どこに おりる？', zh: '我带你们飞到要塞。在哪里降落？',
      a: { ic: '🚪', ja: 'しょうめんの もん', zh: '正门', re: ['どうどうと いくか。きにいった', '堂堂正正地去吗。我喜欢'], open: ['しょうめんの もんに おろすぞ。おうちの そらは われが まもる', '在正门把你们放下。小屋的天空由我守护'] },
      b: { ic: '🪂', ja: 'やねの うえ', zh: '屋顶上', re: ['だいたんだな。おちるなよ！', '真大胆。别掉下去！'], open: ['やねの うえから いくぞ！ わが つばさの かげに かくれよ', '从屋顶上进去！躲在我翅膀的影子里'] } },
    { who: 'core', ja: 'さいごの しつもん です。あなたたちの つよさは、なんですか', zh: '最后一个问题。你们的强大，是什么？',
      a: { ic: '🤝', ja: 'みんなで まもること', zh: '大家一起守护', re: ['きろく しました。とても あたたかい こたえ です', '已记录。非常温暖的答案'], open: ['まもる ちから、かくにん。おうちの まもりを ついか します', '确认守护之力。为小屋追加防护'] },
      b: { ic: '🔥', ja: 'ゆうきを だすこと', zh: '拿出勇气', re: ['きろく しました。とても まぶしい こたえ です', '已记录。非常耀眼的答案'], open: ['ゆうき、かくにん。ぜんいんに たてを てんかい します', '确认勇气。为全员展开护盾'] } }
  ];
  /* 多数決。votes＝{ id: 0〜n-1 }、order＝押した順の id、n＝こたえの数（2 か 3。むかしは 2 だけ）。いちばん多い こたえ。同じ数なら 最初に押した人の こたえ */
  function tally(votes, order, n) {
    n = n === 3 ? 3 : 2; const c = [0, 0, 0]; for (const id in votes) { const v = votes[id]; if (Number.isInteger(v) && v >= 0 && v < n) c[v]++; }
    const best = Math.max(...c.slice(0, n)), top = []; for (let i = 0; i < n; i++) if (c[i] === best) top.push(i);
    if (top.length === 1) return top[0];
    for (const id of order || []) if (top.includes(votes[id])) return votes[id];
    return top[0];
  }
  /* エンディング 3 通り。choices＝{ 0〜4: 'a'｜'b' }。まもり（a）が 4 つ以上＝home、ゆうき（b）が 4 つ以上＝brave、そのほか＝bond */
  function endingOf(choices) { let a = 0, b = 0; for (let w = 0; w < BRANCH.length; w++) { const c = choices && choices[w]; if (c === 'a') a++; else if (c === 'b') b++; } return a >= 4 ? 'home' : b >= 4 ? 'brave' : 'bond'; }
  // 世界 world（1〜5）で もらえる てつだい（前の世界の わかれ道）。無ければ null
  function helpFor(choices, world) { const c = choices && choices[world - 1]; return c === 'a' || c === 'b' ? Object.assign({ c, who: BRANCH[world - 1].who }, HELP[c]) : null; }

  /* ---------- No.41 まんが ----------
     こま：{ who：'narr'（ナレーション）・'fam'（家族の戦車）・ボスの種類、art：絵の形（house・fam・boss・far・boom・vs・duo・gold）、ja・zh、sfx：[ja, zh]（かきもじ）、
           with：true＝前の こまと いっしょに出す（「読んだ」は 1 回）、theme：地面の色、kinds：duo の時の 2 体 } */
  const OPENING = [
    [{ who: 'narr', art: 'house', ja: 'ここは みどりの はらっぱ。みんなの おうちが あります', zh: '这里是绿油油的草原。大家的小屋就在这里' },
      { who: 'twin', art: 'far', ja: 'あの おうち、いいなあ…。よし、もらっちゃおう！', zh: '那个小屋真好啊…。好，抢过来！', sfx: ['ジロッ', '盯——'] },
      { who: 'fam', art: 'fam', ja: '{names}、しゅつどう！ おうちを まもるぞ！', zh: '{names}，出动！保卫小屋！', sfx: ['ブロロロ！', '轰隆隆！'] }],
    [{ who: 'narr', art: 'fam', ja: 'はらっぱを こえると、あつい あつい さばく でした', zh: '越过草原，是好热好热的沙漠', sfx: ['ジリジリ…', '火辣辣…'] },
      { who: 'fam', art: 'fam', ja: 'あつい〜！ アイス たべたい！', zh: '好热～！想吃冰淇淋！', branch: 0 },
      { who: 'sandship', art: 'far', ja: 'うみは どこだー！ ふねを だせー！', zh: '大海在哪里——！开船——！', sfx: ['ザザーン', '哗啦——'] }],
    [{ who: 'narr', art: 'fam', ja: 'さばくの つぎは、まっしろな ゆきやま', zh: '沙漠的后面，是雪白的雪山', sfx: ['ヒュウウ…', '呼呼…'] },
      { who: 'fam', art: 'fam', ja: 'さ、さむい〜！ てぶくろ わすれた！', zh: '好、好冷～！忘带手套了！', branch: 1 },
      { who: 'snowman', art: 'far', ja: 'だれか きた！ あそんで くれるかな？', zh: '有人来了！会陪我玩吗？', sfx: ['ワクワク', '好期待'] }],
    [{ who: 'narr', art: 'fam', ja: 'ゆきが とけると、そこは まっかな かざん でした', zh: '雪融化之后，眼前是通红的火山', sfx: ['ゴゴゴ…', '轰轰轰…'] },
      { who: 'fam', art: 'fam', ja: 'あちち！ キャタピラが やけちゃう！', zh: '烫烫烫！履带要烤焦啦！', branch: 2 },
      { who: 'dragon', art: 'far', ja: 'ちいさき ものたちよ。ここまで のぼって こられるか？', zh: '小家伙们。你们爬得到这里吗？', sfx: ['バサッ', '呼啦'] }],
    [{ who: 'narr', art: 'fam', ja: 'かざんの むこうに、てつの おしろが そびえて います', zh: '火山的另一边，耸立着钢铁的城堡', sfx: ['ガシャーン', '哐当——'] },
      { who: 'fam', art: 'fam', ja: 'おおきい…！ いりぐちは どこ？', zh: '好大…！入口在哪里？', branch: 3 },
      { who: 'core', art: 'far', ja: 'しんにゅうしゃ、せっきん。…すこし、たのしみ です', zh: '入侵者接近。…有一点点，期待', sfx: ['ピピピ', '哔哔哔'] }],
    [{ who: 'narr', art: 'fam', ja: 'おしろの いちばん したに、じごくへの とびらが ありました', zh: '城堡的最底层，有一扇通往地狱的门', sfx: ['ギギギ…', '吱呀呀…'] },
      { who: 'fam', art: 'fam', ja: 'まっくら…。でも、みんな いっしょなら こわくない！', zh: '黑漆漆的…。不过，大家在一起就不怕！', branch: 4 },
      { who: 'king', art: 'far', ja: '…きたか。わがこらを こえた ものたちよ', zh: '…来了吗。超越了我孩子们的人啊', sfx: ['ドドドド', '咚咚咚咚'] }]
  ];
  const BOOM = [['ドカーン！', '轰隆！'], ['ズドーン！', '咚——！'], ['バコーン！', '砰——！'], ['ドッカン！', '轰——！']];
  // ボスを たおした後の ひとこと（面の ボスの並びで決める。2 体の面は after2）
  const AFTER = {
    twin: ['つぎは けんか しないで くる！', '下次我们不吵架再来！'], engineer: ['かべ… また つくれば いいか', '墙…再砌就是了'],
    burrower: ['あなが あったら はいりたい…（ズボッ）', '有洞我就想钻进去…（噗）'], scorpion: ['しゃしん… いっしょに とる？', '照片…要一起拍吗？'],
    plow: ['どうろは きれいに なりました…', '路已经清干净了…'], icegun: ['…また きても、いい', '…你们再来，也行'],
    flamer: ['もえつきた… まっしろに…', '燃尽了…一片雪白…'], golem: ['みんな… あったかい…', '大家…好暖和…'],
    sisA: ['おやつの じかんに しよっか', '该吃点心了吧'], airship: ['おりて みるのも、わるく ありませんわ', '下来看看，也不坏呢'],
    shadow: ['ともだちって、ふやせるんだね', '朋友，原来是可以变多的'], superstar: ['サインは あとで な！', '签名等会儿再说！'],
    bigtank: ['…おまえたちを みていたら、まもりたい ものを おもいだした', '…看着你们，我想起了自己想守护的东西'], sandship: ['この すなの なみも、わるくない うみ だったな', '这片沙浪，也是不错的大海啊'],
    snowman: ['とけても だいじょうぶ。また つくって くれるもんね', '融化了也没关系。你们会再把我堆起来的'], dragon: ['みごと。つぎは わが せなかに のせて やろう', '漂亮。下次让你们坐上我的背'],
    core: ['まもりたい ものが、できました', '我有了想守护的东西'], king: ['…みごとだ。おうは、まけた', '…漂亮。王，输了'],
    boss: ['みーつかった！ つぎは きみたちが かくれる ばん だよ', '被——找到啦！下次轮到你们藏了哦']
  };
  const AFTER2 = [['twin', 'みんなで きても かてない〜！', '一起上也打不过～！'], ['scorpion', 'ふたりの ポーズ、きまってた のに…', '我们俩的姿势明明摆好了…'], ['plow', 'ゆきかき、てつだって くれる？', '能帮我一起铲雪吗？'],
    ['golem', 'いっしょに おふろ… はいろう…', '一起…泡澡吧…'], ['airship', 'さんにんで おちゃに しましょう', '我们三个喝茶去吧'], ['superstar', 'ふたりの ステージも まんいん だった ぜ', '我们俩的舞台也是满座啊']];
  const CHEER = [['やったー！ {top} が だいかつやく！', '太好了！{top} 大显身手！'], ['{names}、ちからを あわせて だいしょうり！', '{names}，齐心协力大胜利！'], ['{top}、ナイス！ みんなも すごい！', '{top}，漂亮！大家都好棒！']];
  /* ボスの面を クリアした後の まんが。st＝面。world の最後のボス（no 24）は 3 こま（どかん・ひとこと・家族）、ほかは 2 こま */
  function defeatPanels(st) {
    const ks = (st.bosses || []).filter(k => k !== 'sisB'), last = st.no === PER || !!st.p3dGold, n = st.gi | 0;
    let who = ks[ks.length - 1] || 'boss', line = AFTER[who] || AFTER.boss;
    if (ks.length > 1) { const a2 = AFTER2[st.world] || AFTER2[0]; who = a2[0]; line = [a2[1], a2[2]]; }
    const boom = BOOM[n % BOOM.length], out = [
      { who: 'fam', art: 'boom', kinds: ks, ja: '', zh: '', sfx: boom },
      { who, art: ks.length > 1 ? 'duo' : (st.p3dGold ? 'gold' : 'boss'), kinds: ks, ja: line[0], zh: line[1], with: true }];
    if (last) { const c = CHEER[n % CHEER.length]; out.push({ who: 'fam', art: 'fam', ja: c[0], zh: c[1], sfx: ['わーい！', '好耶！'] }); }
    return out;
  }
  const SECRET_BOSS_OPEN = [
    { who: 'narr', art: 'fam', ja: 'かべの おくに、だれも しらない へやが ありました', zh: '墙的后面，有一间谁也不知道的房间', sfx: ['キラキラ', '闪闪'] },
    { who: 'boss', art: 'gold', ja: 'みつけちゃった？ ぼくは きんぴか戦車。ずっと かくれんぼ してたんだ！', zh: '被找到啦？我是黄金坦克。一直在玩捉迷藏呢！', sfx: ['ピカーッ', '金光——'] }];

  /* ==================== P3D v0.20 BEGIN：せりふの表・なかよし（No.2）・けっとう（1対1）====================
     LINES：せりふの表（設計書 B8 の slot id）。中身は 文の人が書いた v020-lines.json を そのまま写した（slot id も そのまま）。
       { who：話す人（ボスの種類・'narr'・'card'（札）・'button'・'ui'・'note'・'boss'＝今の けっとうの ボス）, ic：札の絵, ja, zh }。
       {name}＝けっとうの人、{n}・{m}＝数。表に無い slot は 'TODO <id>' と出る（p3d-check が 調べる） */
  const LINES = {
    "cap.bigtank.intro": { who: "bigtank", ja: "まけた。…だが さいごに ひとつ。じゃんけんで しょうぶだ", zh: "我输了。…不过最后来一局，石头剪刀布" },
    "cap.bigtank.ok": { who: "bigtank", ja: "いいぞ。おれの せんしゃ、おまえたちに かそう", zh: "好。我的坦克，借给你们" },
    "cap.bigtank.ng": { who: "bigtank", ja: "おれの かちだ。…また こい。つぎは まけるかも な", zh: "这次我赢。…再来吧，下次说不定我会输" },
    "cap.bigtank.again": { who: "bigtank", ja: "また きたか。じゃんけんより、いっしょに はしろう", zh: "又来啦。比起猜拳，一起跑吧" },
    "cap.bigtank.draw": { who: "bigtank", ja: "あいこ か。…もう いっかい だ！", zh: "平局吗。…再来一次！" },
    "cap.sandship.intro": { who: "sandship", ja: "この かじを まわせ！ ♥ に とまれば、おまえたちの ふねだ", zh: "转这个舵轮！停在♥上，这艘船就是你们的" },
    "cap.sandship.ok": { who: "sandship", ja: "いい かぜだ！ この ふね、おまえたちに あずけた！", zh: "好风！这艘船，托付给你们了！" },
    "cap.sandship.ng": { who: "sandship", ja: "かじが そっぽを むいた！ また まわしに こい！", zh: "舵轮转歪了！再来转一次吧！" },
    "cap.sandship.again": { who: "sandship", ja: "おお、ともよ！ のっていくか？ すなの うみへ！", zh: "哦，朋友！上船吗？去沙子的大海！" },
    "cap.snowman.intro": { who: "snowman", ja: "ゆきがっせんの かわりに、じゃんけん しよう！", zh: "我们不打雪仗，来猜拳吧！" },
    "cap.snowman.ok": { who: "snowman", ja: "やったー！ ぼくの せんしゃ、いっしょに のろう！", zh: "太好啦！我的坦克，一起坐吧！" },
    "cap.snowman.ng": { who: "snowman", ja: "あはは、ぼくの かち！ また あそびに きてね", zh: "哈哈，我赢啦！下次再来玩哦" },
    "cap.snowman.again": { who: "snowman", ja: "あっ、ともだち！ きょうも あそぼう！", zh: "啊，朋友！今天也一起玩吧！" },
    "cap.snowman.draw": { who: "snowman", ja: "おんなじ だ！ すごーい、もう いっかい！", zh: "一样耶！好厉害，再来一次！" },
    "cap.dragon.intro": { who: "dragon", ja: "ほのおの わを とめよ。♥ に とまれば、ともと なろう", zh: "让火焰之轮停下吧。停在♥上，就与你们为友" },
    "cap.dragon.ok": { who: "dragon", ja: "みごと。わが つばさ、おまえたちに かそう", zh: "漂亮。我的翅膀，借给你们" },
    "cap.dragon.ng": { who: "dragon", ja: "ほのおは きまぐれ よ。また とびに くるが よい", zh: "火焰很任性。欢迎再来飞一次" },
    "cap.dragon.again": { who: "dragon", ja: "ともよ、よく きた。そらへ ゆこうぞ", zh: "朋友，欢迎。一起上天吧" },
    "cap.core.intro": { who: "core", ja: "しょうぶ ではなく、はなしを しましょう。みっつ、おねがい します", zh: "我们不比赛，聊聊吧。请回答三个问题" },
    "cap.core.ok": { who: "core", ja: "とうろく かんりょう。わたしの せんしゃ、つかって ください", zh: "登记完成。请使用我的坦克" },
    "cap.core.ng": { who: "core", ja: "もういちど かんがえます。また きて ください。まって います", zh: "我再想一想。请再来。我等你们" },
    "cap.core.again": { who: "core", ja: "おかえりなさい、ともだち。コアは ずっと ここに います", zh: "欢迎回来，朋友。核心一直在这里" },
    "cap.core.q1": { who: "core", ja: "しつもん です。わたしは なにを まもって いますか", zh: "提问。我在守护什么呢？" },
    "cap.core.q2": { who: "core", ja: "ひとりで まもるのは さびしい です。どう すれば？", zh: "一个人守护好寂寞。该怎么办呢？" },
    "cap.core.q3": { who: "core", ja: "さいごです。この さきも、わたしと いて くれますか", zh: "最后一个。以后，你们也会陪着我吗？" },
    "cap.core.ok1": { who: "core", ja: "だれか…。きろく しました。つぎの しつもん です", zh: "是某个人…。已记录。下一个问题" },
    "cap.core.ok2": { who: "core", ja: "いっしょに…。ふしぎ です。コアが あたたかい", zh: "一起…。真奇妙。核心暖暖的" },
    "cap.core.bad": { who: "core", ja: "…ふむ。その こたえは、まだ すこし ちがう ようです", zh: "…嗯。这个答案，好像还差一点点" },
    "cap.core.c1": { who: "card", ic: "💡", ja: "まもりたいのは だれか、だよ", zh: "想守护的是谁才对哦" },
    "cap.core.c2": { who: "card", ic: "🏠", ja: "いっしょに かえろう", zh: "一起回家吧" },
    "cap.core.c3": { who: "card", ic: "🤝", ja: "ずっと ともだち", zh: "永远是朋友" },
    "cap.king.intro": { who: "king", ja: "まけた…。おうは、もう ひとりぼっち だ", zh: "输了…。王，已经孤零零一个了" },
    "cap.king.ok": { who: "king", ja: "ふはは！ よし、きょうから ともだち だ！ わが せんしゃに のれ！", zh: "哈哈哈！好，从今天起我们是朋友！坐上本王的坦克！" },
    "cap.king.ng": { who: "king", ja: "…また きて くれ。おうは ここで まっている", zh: "…请再来。本王就在这里等着" },
    "cap.king.again": { who: "king", ja: "また きたか、ともよ。なんどでも あいてに なろう！", zh: "又来了吗，朋友。不管多少次我都奉陪！" },
    "cap.king.q1": { who: "king", ja: "わがこらは みな まけた。おまえたちは、わらうか？", zh: "我的孩子们都输了。你们，会笑话他们吗？" },
    "cap.king.q2": { who: "king", ja: "では、この おうに なにを のぞむ？", zh: "那么，你们想要本王做什么？" },
    "cap.king.q3": { who: "king", ja: "…さいごに。やくそく できるか？", zh: "…最后。你们能和我约定吗？" },
    "cap.king.ok1": { who: "king", ja: "…そうか。わがこらを、ほめて くれるのか", zh: "…是吗。你们，在夸我的孩子们啊" },
    "cap.king.ok2": { who: "king", ja: "あそびに…？ おうを、さそって くれるのか", zh: "去玩…？你们，在邀请本王吗" },
    "cap.king.bad": { who: "king", ja: "…それは ちがう ぞ。おうは すこし しょんぼり だ", zh: "…不对哦。本王有一点点沮丧" },
    "cap.king.c1": { who: "card", ic: "🤗", ja: "みんな つよかったよ！", zh: "他们都很强哦！" },
    "cap.king.c2": { who: "card", ic: "🏠", ja: "うちに あそびに きて！", zh: "来我们家玩吧！" },
    "cap.king.c3": { who: "card", ic: "🤝", ja: "また いっしょに あそぼう！", zh: "下次再一起玩！" },
    "cap.ui.chance": { who: "ui", ja: "♥ なかよしチャンス {n}%（{m} かいめ）", zh: "♥ 交朋友机会 {n}%（第 {m} 次）" },
    "cap.ui.next": { who: "ui", ja: "つぎは ♥ {n}%", zh: "下次是 ♥ {n}%" },
    "cap.ui.got": { who: "ui", ja: "あたらしい なかま！ ガレージで のれるよ", zh: "新伙伴！可以在车库里乘坐啦" },
    "cap.ui.rep": { who: "ui", ja: "{name} が まわすよ", zh: "轮到 {name} 来转" },
    "cap.ui.stop": { who: "ui", ja: "とめる", zh: "停" },
    "cap.ui.rps": { who: "ui", ja: "じゃん・けん・ぽん！", zh: "石头·剪刀·布！" },
    "cap.ui.hand.0": { who: "ui", ja: "ぐー", zh: "石头" },
    "cap.ui.hand.1": { who: "ui", ja: "ちょき", zh: "剪刀" },
    "cap.ui.hand.2": { who: "ui", ja: "ぱー", zh: "布" },
    "cap.ui.hint": { who: "ui", ja: "♥ ヒント", zh: "♥ 提示" },
    "cap.ui.lock": { who: "ui", ja: "ワールド {n} の さいごの ボスと なかよくなろう", zh: "和世界 {n} 的最终首领交朋友吧" },
    "duel.twin.dare": { who: "twin", ja: "{name}、ぼくら ふたりで あいてを する！ いい？", zh: "{name}，我们两个一起当对手！可以吗？" },
    "duel.twin.lose": { who: "twin", ja: "{name}、すごい！ ふたりで まけた〜！", zh: "{name}好厉害！我们两个都输了～！" },
    "duel.twin.win": { who: "twin", ja: "やった！ …でも {name}、いい しょうぶ だった！", zh: "赢啦！…不过{name}，打得真棒！" },
    "duel.engineer.dare": { who: "engineer", ja: "{name}、しょうぶ だ。…かべは こわすなよ？", zh: "{name}，来比一场。…别把墙打坏哦？" },
    "duel.engineer.lose": { who: "engineer", ja: "かべが ぜんぶ…。{name}、いい うでだ", zh: "墙全都…。{name}，好身手" },
    "duel.engineer.win": { who: "engineer", ja: "かべが まもって くれた。{name}、また こい", zh: "是墙保护了我。{name}，再来哦" },
    "duel.burrower.dare": { who: "burrower", ja: "{name}、みつけて みて！ …あっ、でてきちゃった！", zh: "{name}，来找我！…啊，我钻出来了！" },
    "duel.burrower.lose": { who: "burrower", ja: "みつかった〜！ {name}、つよい！", zh: "被找到啦～！{name}好强！" },
    "duel.burrower.win": { who: "burrower", ja: "ズボッと にげきった！ {name}、また あそぼう！", zh: "我钻进沙里逃掉啦！{name}，下次再玩！" },
    "duel.scorpion.dare": { who: "scorpion", ja: "{name}！ どっちが かっこいいか、1たい1で きめよう！", zh: "{name}！谁更帅，一对一来决定！" },
    "duel.scorpion.lose": { who: "scorpion", ja: "{name}、かっこいい…！ しゃしんは むりょう だ！", zh: "{name}，好帅…！照片免费送你！" },
    "duel.scorpion.win": { who: "scorpion", ja: "おれの ポーズの かち！ {name}も かっこよかった！", zh: "我的姿势赢啦！{name}也很帅！" },
    "duel.plow.dare": { who: "plow", ja: "{name}！ ゆきかきより はやく、しょうぶ です！", zh: "{name}！比铲雪还快，来比一场！" },
    "duel.plow.lose": { who: "plow", ja: "きれいに まけました！ {name}、おみごと です", zh: "输得干干净净！{name}，真漂亮" },
    "duel.plow.win": { who: "plow", ja: "おそうじ かんりょう！ {name}、つぎも がんばって", zh: "打扫完毕！{name}，下次也加油" },
    "duel.icegun.dare": { who: "icegun", ja: "…{name}。ひとりで きた。…しょうぶ、する", zh: "…{name}。一个人来了。…来比一场" },
    "duel.icegun.lose": { who: "icegun", ja: "…つよい。{name}、また きても、いい", zh: "…好强。{name}，再来也行" },
    "duel.icegun.win": { who: "icegun", ja: "…わるくなかった。つぎは みんなで きなさい", zh: "…还不错。下次大家一起来吧" },
    "duel.flamer.dare": { who: "flamer", ja: "{name}ォォ！ オレと もえる しょうぶ だァ！", zh: "{name}！和我来一场燃烧的对决！" },
    "duel.flamer.lose": { who: "flamer", ja: "あっちち！ {name}、つよい！ みず ください", zh: "烫烫烫！{name}好强！给我点水" },
    "duel.flamer.win": { who: "flamer", ja: "オレの ほのおの かち！ {name}、いい ひだった！", zh: "我的火焰赢啦！{name}，今天过得真棒！" },
    "duel.golem.dare": { who: "golem", ja: "{name}… ボクと… あそんで くれる…？", zh: "{name}…能陪我…玩吗…？" },
    "duel.golem.lose": { who: "golem", ja: "{name}… つよい…。あったかい しょうぶ だった…", zh: "{name}…好强…。是场暖暖的对决…" },
    "duel.golem.win": { who: "golem", ja: "ボク かった…？ {name}、あとで おふろ… いっしょに…", zh: "我赢了…？{name}，等会儿…一起泡澡…" },
    "duel.airship.dare": { who: "airship", ja: "ごきげんよう、{name}。おちゃの まえに、いっしょうぶ いかが？", zh: "日安，{name}。喝茶之前，来比一场如何？" },
    "duel.airship.lose": { who: "airship", ja: "まあ！ {name}、おみごと ですわ。おちゃに しましょう", zh: "哎呀！{name}，真漂亮。我们去喝茶吧" },
    "duel.airship.win": { who: "airship", ja: "うふふ、わたくしの かち。{name}、つぎは おちゃを どうぞ", zh: "呵呵，我赢啦。{name}，下次请喝茶" },
    "duel.shadow.dare": { who: "shadow", ja: "{name}。きみと ぼく、ふたりだけで あそびたい", zh: "{name}。我想和你，只有我们两个玩" },
    "duel.shadow.lose": { who: "shadow", ja: "{name}、きみは ひとりでも かがやくね", zh: "{name}，你一个人也闪闪发光呢" },
    "duel.shadow.win": { who: "shadow", ja: "たのしかった。{name}、また あそんで くれる？", zh: "好开心。{name}，还会陪我玩吗？" },
    "duel.superstar.dare": { who: "superstar", ja: "{name}！ ステージに あがれ！ 1たい1の ライブ だ！", zh: "{name}！上舞台！一对一的演唱会！" },
    "duel.superstar.lose": { who: "superstar", ja: "ブラボー！ {name}、きみが こんやの スターだ！", zh: "太棒了！{name}，你是今晚的明星！" },
    "duel.superstar.win": { who: "superstar", ja: "ごせいえん ありがとう！ {name}も ナイスファイト！", zh: "谢谢捧场！{name}也打得漂亮！" },
    "duel.bigtank.dare": { who: "bigtank", ja: "{name}、ひとりで こい。おれが ずっしり うけとめる", zh: "{name}，一个人来吧。我稳稳地接住" },
    "duel.bigtank.lose": { who: "bigtank", ja: "ひとりで ここまで…。{name}、いい うでだ", zh: "一个人做到这一步…。{name}，好身手" },
    "duel.bigtank.win": { who: "bigtank", ja: "まだまだ だな。…だが {name}、いい め を している", zh: "还早呢。…不过{name}，眼神很好" },
    "duel.sandship.dare": { who: "sandship", ja: "{name}！ ふねと いっきうち だー！ ぜんほうもん ひらけ！", zh: "{name}！和战舰单挑啦！全炮门开火！" },
    "duel.sandship.lose": { who: "sandship", ja: "ぶじ ちんぼつ！ {name}、いい かんちょう だ！", zh: "顺利沉没！{name}，好船长！" },
    "duel.sandship.win": { who: "sandship", ja: "ふねの かち！ だが {name}、いい ほうげき だった！", zh: "战舰赢啦！不过{name}，炮打得真棒！" },
    "duel.snowman.dare": { who: "snowman", ja: "{name}！ ぼくと ふたりで ゆきだま しょうぶ しよう！", zh: "{name}！我们两个来比雪球吧！" },
    "duel.snowman.lose": { who: "snowman", ja: "わあ、とけちゃう〜！ {name}、すごーい！", zh: "哇，要化啦～！{name}好厉害！" },
    "duel.snowman.win": { who: "snowman", ja: "ぼくの かち！ でも {name}、たのしかった ね！", zh: "我赢啦！不过{name}，好开心呀！" },
    "duel.dragon.dare": { who: "dragon", ja: "{name}よ、ひとりで われに いどむか。よい ゆうきだ", zh: "{name}啊，你要一个人挑战我吗。好勇气" },
    "duel.dragon.lose": { who: "dragon", ja: "ひとりで ここまで…。{name}、われも みとめよう", zh: "一个人做到这一步…。{name}，我也认可你" },
    "duel.dragon.win": { who: "dragon", ja: "ほのおの かち。…だが {name}、ゆうきは ほんもの だ", zh: "火焰获胜。…不过{name}，勇气是真的" },
    "duel.core.dare": { who: "core", ja: "{name}。1たい1の データを とりたい です。おねがい します", zh: "{name}。我想收集一对一的数据。拜托了" },
    "duel.core.lose": { who: "core", ja: "{name}、けいさん がい です。…とても すてき でした", zh: "{name}，超出计算。…非常精彩" },
    "duel.core.win": { who: "core", ja: "こんかいは わたしの かち です。つぎは みんなで どうぞ", zh: "这次是我赢了。下次请大家一起来" },
    "duel.king.dare": { who: "king", ja: "{name}よ、ひとりで おうの まえに たて。かかって こい！", zh: "{name}啊，一个人站到本王面前。放马过来！" },
    "duel.king.lose": { who: "king", ja: "ひとりで ここまで…。{name}、おうも みとめよう", zh: "一个人做到这一步…。{name}，本王认可你" },
    "duel.king.win": { who: "king", ja: "まだ おうの かち。…だが {name}、りっぱな せんしだ", zh: "这次本王赢。…不过{name}，你是出色的战士" },
    "duel.letter": { who: "narr", ja: "ボスから ちょうせんじょうが とどいた！『1たい1で しょうぶだ』", zh: "首领送来了挑战书！“一对一决胜负”" },
    "duel.reply.0": { who: "card", ic: "😤", ja: "まけないぞ！", zh: "我不会输！" },
    "duel.reply.1": { who: "card", ic: "🙇", ja: "よろしく おねがいします！", zh: "请多指教！" },
    "duel.reply.2": { who: "card", ic: "😜", ja: "おやつを かけて しょうぶ！", zh: "赌上点心来比！" },
    "duel.re.0.0": { who: "boss", ja: "いい め だ！ ぜんりょくで いくぞ！", zh: "好眼神！我要全力以赴！" },
    "duel.re.0.1": { who: "boss", ja: "ていねいだな！ こちらこそ よろしく！", zh: "真有礼貌！我才要请你多指教！" },
    "duel.re.0.2": { who: "boss", ja: "おやつ？ いいね、のった！", zh: "点心？好呀，我接了！" },
    "duel.re.1.0": { who: "boss", ja: "その いきだ！ ほんきで あいて しよう！", zh: "就是这股气势！我来认真应战！" },
    "duel.re.1.1": { who: "boss", ja: "れいぎ ただしい。わたしも ほんきで むかえよう", zh: "礼数周到。我也认真迎战" },
    "duel.re.1.2": { who: "boss", ja: "ふはは、おやつか！ かった ほうが たべよう！", zh: "哈哈，点心吗！赢的人来吃！" },
    "duel.perk.0": { who: "note", ja: "🔥 ひっさつわざが はんぶん たまった！", zh: "🔥 必杀技攒了一半！" },
    "duel.perk.1": { who: "note", ja: "🛡 はじめの たてが +4 びょう！", zh: "🛡 开场护盾 +4 秒！" },
    "duel.perk.2": { who: "note", ja: "🎁 おうえんの おたすけが +1 かい！", zh: "🎁 观战支援 +1 次！" },
    "duel.pass": { who: "boss", ja: "ひとりは むずかしい か。じゃあ、みんなで こい！", zh: "一个人有点难吗。那就大家一起来吧！" },
    "duel.draw.0": { who: "boss", ja: "ひきわけ だな！ また ゆっくり しょうぶ しよう", zh: "平局啦！下次再慢慢比" },
    "duel.draw.1": { who: "boss", ja: "ひきわけ か。いい しょうぶ だった。つぎは ほんばん だ", zh: "平局吗。打得很好。下次是正式比赛了" },
    "duel.dec": { who: "narr", ja: "じかんぎれ！ {name} が おして いた。はんてい がち！", zh: "时间到！{name}占了上风。判定胜！" },
    "duel.again.0": { who: "button", ic: "🔁", ja: "もう いちど", zh: "再来一次" },
    "duel.again.1": { who: "button", ic: "🏃", ja: "バトンタッチ", zh: "换人接力" },
    "duel.again.2": { who: "button", ic: "👪", ja: "みんなで いく", zh: "大家一起上" },
    "duel.ui.accept": { who: "ui", ja: "⚔ うける！", zh: "⚔ 接受！" },
    "duel.ui.pass": { who: "ui", ja: "🙅 ほかの人に おねがい", zh: "🙅 请别人上" },
    "duel.ui.wait": { who: "ui", ja: "{name} に ちょうせんじょう！", zh: "{name} 收到了挑战书！" },
    "duel.ui.cheer": { who: "ui", ja: "おうえん しよう！", zh: "一起加油吧！" },
    "duel.ui.help.shield": { who: "ui", ja: "🛡 たて", zh: "🛡 护盾" },
    "duel.ui.help.fix": { who: "ui", ja: "🔧 かいふく", zh: "🔧 恢复" },
    "duel.ui.help.ice": { who: "ui", ja: "❄ とめる", zh: "❄ 暂停" },
    "duel.ui.help.none": { who: "ui", ja: "もう おたすけは ないよ", zh: "支援用完啦" },
    "duel.ui.full": { who: "ui", ja: "おうえんパワー！", zh: "加油能量！" },
    "duel.ui.tired.win": { who: "ui", ja: "ボスは けっとうで つかれている！（たいりょく -30%）", zh: "首领决斗后累了！（体力 -30%）" },
    "duel.ui.tired.draw": { who: "ui", ja: "ボスは ちょっと つかれている！（たいりょく -10%）", zh: "首领有点累了！（体力 -10%）" },
    "duel.ui.reward.win": { who: "ui", ja: "かった ごほうび！ コインを ゲット", zh: "获胜的奖励！得到金币" },
    "duel.ui.reward.watch": { who: "ui", ja: "おうえんした みんなにも コイン！", zh: "加油的大家也有金币！" },
    "duel.ui.reward.lose": { who: "ui", ja: "がんばった ごほうび！ みんなに コイン", zh: "努力的奖励！大家都有金币" },
    "duel.ui.medal": { who: "ui", ja: "⚔ けっとうメダル を ゲット！", zh: "⚔ 得到决斗奖章！" }
  };
  const line = id => LINES[id] || null;
  // 文を 1 つの言葉で。vars＝{ name, n, m }
  function lineText(id, lang, vars) { const l = LINES[id]; if (!l) return 'TODO ' + id; let s = lang === 'zh' ? l.zh : l.ja; for (const k in vars || {}) s = s.split('{' + k + '}').join(String(vars[k])); return s; }
  // 文を 両方の言葉で（{ who, ic, ja, zh }）。who を かえる時は who2
  function lineBoth(id, vars, who2) { const l = LINES[id] || { who: 'narr' }; return { who: who2 || l.who, ic: l.ic || '', ja: lineText(id, 'ja', vars), zh: lineText(id, 'zh', vars) }; }

  /* ---------- No.2 ボスと なかよくなる（6 体：ワールドの さいごの ボス）----------
     ボスを たおすたびに 1 回。成功の確率 30% → 50% → 70% → かならず（fails＝しっぱいの数）。
     rps＝じゃんけん（ボスの手は 家族の手が きまってから、確率で きめる）、wheel＝ルーレット（♥ の広さ＝確率）、talk＝会話（3 枚の札を 正しい順に。ヒントが ふえる） */
  const P3D_CAP_CHANCE = [0.30, 0.50, 0.70, 1.00];
  const CAPTURE = { order: ['bigtank', 'sandship', 'snowman', 'dragon', 'core', 'king'],
    by: { bigtank: { method: 'rps', car: 'kb', world: 0 }, sandship: { method: 'wheel', car: 'kw', world: 1 }, snowman: { method: 'rps', car: 'kn', world: 2 },
      dragon: { method: 'wheel', car: 'kd', world: 3 }, core: { method: 'talk', car: 'kc', world: 4 }, king: { method: 'talk', car: 'kk', world: 5 } } };
  const capChance = fails => P3D_CAP_CHANCE[Math.max(0, Math.min(3, fails | 0))];
  function capTry(fails, rnd) { const p = capChance(fails); return { p, lucky: rnd() < p }; }
  // じゃんけん：0＝ぐー、1＝ちょき、2＝ぱー。RPS_WIN[i]＝i が かつ手
  const RPS_WIN = [1, 2, 0];
  function rpsBossHand(fam, lucky) { fam = (((fam | 0) % 3) + 3) % 3; return lucky ? RPS_WIN[fam] : (fam + 2) % 3; }
  function rpsResult(fam, boss) { return fam === boss ? 0 : RPS_WIN[fam] === boss ? 1 : -1; }   // 1＝家族の かち、-1＝まけ、0＝あいこ
  // ルーレット：10 まいの うち round(10p) まいが ♥（なるべく ばらけて）
  function wheelSlices(p) { const h = Math.round(10 * p), out = []; for (let i = 0; i < 10; i++) out.push(Math.floor((i + 1) * h / 10) > Math.floor(i * h / 10) ? 1 : 0); return out; }
  // 先に きめて（u < p で 成功）、その種類の まいの どれかに とまる
  function wheelStop(p, u) { const sl = wheelSlices(p), ok = u < p, idx = []; sl.forEach((s, i) => { if (s === (ok ? 1 : 0)) idx.push(i); }); if (!idx.length) return 0;
    const f = ok ? u / p : (u - p) / Math.max(1e-9, 1 - p); return idx[Math.min(idx.length - 1, Math.floor(Math.max(0, f) * idx.length))]; }
  // 会話：n＝ヒントが光る 札の数（1 まいめ から）、off＝まちがいの札を おせない
  function talkHints(fails) { const n = Math.max(0, Math.min(3, fails | 0)); return { n, off: n >= 3 }; }
  function talkCheck(kind, picks) { return Array.isArray(picks) && picks.length === 3 && picks[0] === 0 && picks[1] === 1 && picks[2] === 2; }
  const TALK_PERMS = [[1, 2, 0], [2, 0, 1], [0, 2, 1], [1, 0, 2], [2, 1, 0]];   // 正しい順と おなじ並び（0,1,2）は 使わない
  const talkOrder = (kind, fails) => TALK_PERMS[((fails | 0) * 3 + String(kind).length) % TALK_PERMS.length].slice();

  /* ---------- けっとう（1 対 1）----------
     ぼうけんの ボスの面（8・16＝中、24＝大）を始める時、2 人以上なら ときどき ボスから ちょうせんじょう。ボスは 体力が半分くらい・うつのも ゆっくり */
  const DUEL = {
    kinds: { twin: 0, engineer: 0, burrower: 0, scorpion: 0, plow: 0, icegun: 0, flamer: 0, golem: 0, airship: 0, shadow: 0, superstar: 0, bigtank: 1, sandship: 1, snowman: 1, dragon: 1, core: 1, king: 1 },
    dropped: [],                                         // 1 人で たおせなかった ボス（p3d-check の 結果）
    TIER: [{ hp: 0.45, fire: 1.35, spd: 0.90, sec: 75, coin: 60, floor: 30, cap: [1.2, 3], tempo: 0.6, arm: 3 }, { hp: 0.55, fire: 1.20, spd: 0.95, sec: 90, coin: 100, floor: 45, cap: [1.2, 3], tempo: 0.6, arm: 3 }],   // floor＝体力の 下限、cap＝[1 秒に 入る ダメージ, ためられる 上限]、tempo＝ボスの こうげきの はやさ、arm＝出るたびの よろい（どれも けっとうだけ）
    KHP: { airship: 0.5, sandship: 0.5, core: 0.8, king: 0.7 },   // けっとう：とくべつな うごきの ボスは 体力を へらす
    BASE: [0.50, 0.60], PITY: 0.10, CUT: { win: 0.7, draw: 0.9 }, WATCH_COIN: 20, LOSE_COIN: 20, HEARTS: 3, RETRY: 0.75, STREAK: 0.15, MIN_HP: 6,   // v0.22（No.59 JUN）：はじめの 確率 中ボス 25→50%、大ボス 35→60%
    HELP: { shield: 3, ice: 2, fixMax: 2, cd: 6 }, CHEER_STEP: 8, CHEER_MAX: 2, TOKENS: [0, 3, 2, 2], PERK_SHIELD: 4, PERK_SP: 0.5
  };
  // -1＝けっとう なし、0＝中ボス（8・16 面）、1＝大ボス（24 面）
  function duelTier(st) {
    if (!st || !st.bosses || st.bosses.length !== 1 || st.p3dBonus !== undefined || st.p3dDuel) return -1;
    const t = DUEL.kinds[st.bosses[0]]; if (t === undefined) return -1;
    if (st.no === PER) return t === 1 ? 1 : -1;
    return (st.no === 8 || st.no === 16) && t === 0 ? 0 : -1;
  }
  // つぎの ボスの面で けっとうが あるか。state＝{ pity, cool }。かえすのは つぎの state（テレビが けっとうを 本当に始めた時に つかう）
  function duelNext(state, tier, rnd) {
    const s = { pity: Math.max(0, Math.min(10, (state && state.pity) | 0)), cool: state && state.cool ? 1 : 0 };
    const p = s.cool ? 0 : Math.min(1, DUEL.BASE[tier ? 1 : 0] + DUEL.PITY * s.pity), duel = rnd() < p;
    if (duel) { s.pity = 0; s.cool = 1; } else { if (!s.cool) s.pity = Math.min(10, s.pity + 1); s.cool = 0; }
    return { duel, p, state: s };
  }
  // だれが けっとうするか：たのまれた回数が いちばん少ない人 → いちばん長く まっている人 → くじ
  function duelPick(names, turn, lastAt, rnd) {
    const ns = (names || []).slice(); if (!ns.length) return null; const tv = n => (turn && turn[n]) | 0, av = n => (lastAt && lastAt[n]) || 0;
    const lo = Math.min(...ns.map(tv)), c1 = ns.filter(n => tv(n) === lo), lo2 = Math.min(...c1.map(av)), c2 = c1.filter(n => av(n) === lo2);
    return c2[Math.min(c2.length - 1, Math.floor(rnd() * c2.length))];
  }
  function duelBaseHp(kind) { const Sim = root.TankSim || (typeof require !== 'undefined' ? require('./tank-sim.js') : null), e = Sim && Sim.ENEMY[kind]; return e ? e.hp : 30; }
  // ボスの強さ。carLv＝けっとうする人の 今の車の レベル、streak＝つづけて まけた数、retries＝この けっとうで もう まけた回数
  function duelScale(kind, tier, carLv, streak, retries) {
    const T = DUEL.TIER[tier ? 1 : 0], lvK = Math.min(1.3, 0.85 + 0.015 * (Math.max(1, Math.min(30, carLv | 0 || 1)) - 1)), sK = 1 - DUEL.STREAK * Math.max(0, Math.min(3, streak | 0)), rK = Math.pow(DUEL.RETRY, Math.max(0, retries | 0));
    return { hp: Math.max(DUEL.MIN_HP, Math.round(Math.max(T.floor || 0, duelBaseHp(kind) * T.hp) * (DUEL.KHP[kind] || 1) * lvK * sK * rK)), fireMul: T.fire, spdMul: T.spd, sec: T.sec, cap: T.cap || null, tempo: T.tempo || 0, arm: T.arm || 0 };
  }
  // けっとうの面。o＝{ st：本当の ボスの面, pid, carLv, streak, retries }
  function duelStage(kind, tier, o) {
    o = o || {}; const base = o.st || ADV.find(s => s.bosses && s.bosses.includes(kind)) || ADV[0], sc = duelScale(kind, tier, o.carLv, o.streak, o.retries);
    const bt = Stages.BOSS_TALK && Stages.BOSS_TALK[kind] && Stages.BOSS_TALK[kind].name;
    return Object.assign({}, base, { id: 'x-duel', p3dDuel: { pid: o.pid || '', kind, tier: tier ? 1 : 0, hpMul: sc.hp / duelBaseHp(kind), hp: sc.hp, fireMul: sc.fireMul, spdMul: sc.spdMul, hearts: DUEL.HEARTS, sec: sc.sec, cap: sc.cap, tempo: sc.tempo, arm: sc.arm },
      bosses: [kind], boss: null, fx: 'none', rows: 26, night: false, blizzard: false, storm: false, captains: 0, reunion: null, p3dSec: null, p3dChests: null, type: null, survive: 0, specials: [],
      music: base.music || 'boss', ja: 'けっとう：' + (bt ? bt[0] : kind), zh: '决斗：' + (bt ? bt[1] : kind) });
  }
  // 結果：'ko'（ボスの体力 0）・'lose'（♥ 0）・時間切れなら 'dec'（ボスの体力が 半分以下）か 'draw'。まだなら null
  function duelResult(bossHp, maxHp, hearts, secLeft) { if (bossHp <= 0) return 'ko'; if (hearts <= 0) return 'lose'; if (secLeft <= 0) return bossHp <= maxHp * 0.5 ? 'dec' : 'draw'; return null; }
  // 中身の 確かめ：使う slot ぜんぶ
  function slotsUsed() {
    const ids = [];
    for (const k of CAPTURE.order) { for (const s of ['intro', 'ok', 'ng', 'again']) ids.push('cap.' + k + '.' + s); const m = CAPTURE.by[k].method; if (m === 'rps') ids.push('cap.' + k + '.draw');
      if (m === 'talk') for (const s of ['q1', 'q2', 'q3', 'c1', 'c2', 'c3', 'ok1', 'ok2', 'bad']) ids.push('cap.' + k + '.' + s); }
    for (const s of ['chance', 'next', 'got', 'rep', 'stop', 'rps', 'hand.0', 'hand.1', 'hand.2', 'hint', 'lock']) ids.push('cap.ui.' + s);
    for (const k in DUEL.kinds) for (const s of ['dare', 'lose', 'win']) ids.push('duel.' + k + '.' + s);
    ids.push('duel.letter', 'duel.pass', 'duel.dec', 'duel.draw.0', 'duel.draw.1');
    for (const v of [0, 1, 2]) ids.push('duel.reply.' + v, 'duel.re.0.' + v, 'duel.re.1.' + v, 'duel.perk.' + v, 'duel.again.' + v);
    for (const s of ['accept', 'pass', 'wait', 'cheer', 'help.shield', 'help.fix', 'help.ice', 'help.none', 'full', 'tired.win', 'tired.draw', 'reward.win', 'reward.watch', 'reward.lose', 'medal']) ids.push('duel.ui.' + s);
    return ids;
  }
  /* ==================== P3D v0.20 END ==================== */

  /* ---------- No.30 エンディング ---------- art＝絵（tank.html の p3dSlideArt） */
  const ENDING = {
    head: [
      { art: 'dawn', ja: 'じごくの そらが、すこしずつ はれて いきます', zh: '地狱的天空，一点一点放晴了' },
      { art: 'all', ja: 'ボスたちは、みんな ともだちに なりました', zh: '首领们，都成了大家的朋友' }],
    home: { name: ['まもりの おわり「みんなの おうち」', '守护结局“大家的小屋”'], art: 'home', ja: 'みんなは おうちへ かえりました。ボスたちは まいにち あそびに きます', zh: '大家回到了小屋。首领们每天都来玩' },
    brave: { name: ['ゆうきの おわり「あたらしい たび」', '勇气结局“新的旅程”'], art: 'road', ja: 'みんなは ボスたちと いっしょに、あたらしい せかいへ たびに でました', zh: '大家和首领们一起，向新的世界出发了' },
    bond: { name: ['きずなの おわり「おおきな かぞく」', '羁绊结局“大大的一家人”'], art: 'bighouse', ja: 'おうちは おおきく なって、ボスも かぞくも いっしょに くらしました', zh: '小屋变大了，首领和家人住在了一起' },
    tail: [{ art: 'thanks', ja: 'おうちを まもったのは、{names} の ゆうきと やさしさ でした', zh: '保护了小屋的，是{names}的勇气和温柔' }],
    lap2: { ja: 'おしまい… では ありません！ ★ 2 しゅうめ が ひらきました。もっと つよい てきが まって います', zh: '结束了…才怪！★ 二周目开放了。更强的敌人在等着你们' },
    lap2done: { ja: '★ 2 しゅうめも クリア！ ほんものの でんせつの せんしゃたい です', zh: '★ 二周目也通关了！你们是真正的传说坦克队' }
  };

  /* ---------- No.42 こえ ---------- pitch（高さ 0〜2）・rate（速さ）。speechSynthesis が無い時は 同じ高さの「ピポ」音 */
  const VOICE = {
    narr: { pitch: 1.0, rate: 0.95 }, fam: { pitch: 1.45, rate: 1.05 },
    twin: { pitch: 1.5, rate: 1.15 }, engineer: { pitch: 0.9, rate: 0.95 }, bigtank: { pitch: 0.55, rate: 0.85 },
    burrower: { pitch: 1.6, rate: 1.2 }, scorpion: { pitch: 1.25, rate: 1.15 }, sandship: { pitch: 0.7, rate: 0.9 },
    plow: { pitch: 1.3, rate: 1.25 }, icegun: { pitch: 1.1, rate: 0.8 }, snowman: { pitch: 1.75, rate: 1.0 }, snowkid: { pitch: 2.0, rate: 1.1 },
    flamer: { pitch: 0.95, rate: 1.3 }, golem: { pitch: 0.4, rate: 0.7 }, dragon: { pitch: 0.5, rate: 0.9 },
    sisA: { pitch: 1.4, rate: 1.05 }, sisB: { pitch: 1.8, rate: 1.1 }, airship: { pitch: 1.55, rate: 0.9 }, core: { pitch: 1.0, rate: 0.8 },
    shadow: { pitch: 0.75, rate: 0.85 }, superstar: { pitch: 1.15, rate: 1.2 }, king: { pitch: 0.3, rate: 0.8 }, boss: { pitch: 1.65, rate: 1.1 }
  };
  const voiceOf = who => VOICE[who] || { pitch: 0.9, rate: 1 };

  // 名前を入れる。ps＝[{ name, kills }]
  function fill(text, ps, lang) {
    const names = (ps || []).map(p => p.name).filter(Boolean), top = (ps || []).slice().sort((a, b) => (b.kills || 0) - (a.kills || 0))[0];
    const all = names.length ? names.join(lang === 'zh' ? ' 和 ' : ' と ') : (lang === 'zh' ? '大家' : 'みんな');
    return String(text).replace('{names}', all).replace('{top}', top && top.name ? top.name : (lang === 'zh' ? '大家' : 'みんな'));
  }

  const api = { SECRETS, SECRET_BY, SECRET_TOTAL, SECRET_BOSS_ID, doorOf, secretAt, bonusStage, HELP, BRANCH, tally, endingOf, helpFor, OPENING, defeatPanels, SECRET_BOSS_OPEN, ENDING, VOICE, voiceOf, fill,
    LINES, line, lineText, lineBoth, P3D_CAP_CHANCE, CAPTURE, capChance, capTry, RPS_WIN, rpsBossHand, rpsResult, wheelSlices, wheelStop, talkHints, talkCheck, talkOrder,
    DUEL, duelTier, duelNext, duelPick, duelScale, duelStage, duelResult, slotsUsed };   // P3D v0.20
  root.TankStory = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);

/* P2-12：思い出のアルバム（アイデア No.12）。テレビ（Mac の Chrome）の IndexedDB に、名場面の写真を新しい順に MAX 枚まで残す。
   1 枚＝{ id, at（日時）, kind（boss・perfect・levelup・gear・reunion）, caps（[[ja, zh], …]）, stage（[ja, zh]）, names（参加者の名前）, w, h, blob（JPEG） }
   使い方：TankAlbum.add(rec) → Promise<id>、TankAlbum.list() → Promise<新しい順の配列>、TankAlbum.count()、TankAlbum.remove(id)、TankAlbum.clear()
   IndexedDB が使えない時（プライベートウィンドウなど）は、この画面を閉じるまでだけ覚えておく */
(function () {
  'use strict';
  const DB_NAME = 'tank-album', STORE = 'photos', MAX = 60;
  let dbP = null, mem = null, memId = 0;
  function open() {
    if (mem) return Promise.resolve(null);
    if (dbP) return dbP;
    dbP = new Promise(resolve => {
      let done = false; const fail = why => { if (done) return; done = true; console.warn('アルバムの保存場所を開けませんでした（この画面の間だけ覚えます）', why); mem = []; resolve(null); };
      try {
        if (typeof indexedDB === 'undefined' || !indexedDB) { fail('no indexedDB'); return; }
        const rq = indexedDB.open(DB_NAME, 1);
        rq.onupgradeneeded = () => { const db = rq.result; if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: 'id', autoIncrement: true }); };
        rq.onsuccess = () => { if (done) return; done = true; resolve(rq.result); };
        rq.onerror = () => fail(rq.error); rq.onblocked = () => fail('blocked');
      } catch (e) { fail(e); }
    });
    return dbP;
  }
  function tx(db, mode, fn) {
    return new Promise((resolve, reject) => {
      let out; const t = db.transaction(STORE, mode), st = t.objectStore(STORE);
      t.oncomplete = () => resolve(out); t.onerror = () => reject(t.error); t.onabort = () => reject(t.error || new Error('abort'));
      fn(st, v => { out = v; });
    });
  }
  async function add(rec) {
    const db = await open();
    if (!db) { rec.id = ++memId; mem.push(rec); while (mem.length > MAX) mem.shift(); return rec.id; }
    return tx(db, 'readwrite', (st, set) => {
      const rq = st.add(rec); rq.onsuccess = () => {
        set(rq.result);
        const kq = st.getAllKeys(); kq.onsuccess = () => { const keys = kq.result; for (let i = 0; i < keys.length - MAX; i++) st.delete(keys[i]); };   // 古い写真から消す
      };
    });
  }
  async function list() {
    const db = await open(); if (!db) return mem.slice().reverse();
    return tx(db, 'readonly', (st, set) => { const rq = st.getAll(); rq.onsuccess = () => set(rq.result.reverse()); });
  }
  async function count() {
    const db = await open(); if (!db) return mem.length;
    return tx(db, 'readonly', (st, set) => { const rq = st.count(); rq.onsuccess = () => set(rq.result); });
  }
  async function remove(id) {
    const db = await open(); if (!db) { mem = mem.filter(r => r.id !== id); return; }
    return tx(db, 'readwrite', st => { st.delete(id); });
  }
  async function clear() {
    const db = await open(); if (!db) { mem = []; return; }
    return tx(db, 'readwrite', st => { st.clear(); });
  }
  window.TankAlbum = { MAX, add, list, count, remove, clear };
})();

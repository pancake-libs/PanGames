/* ==================== P12（v0.29）：ボスと おしゃべり — 戦車の ゲームの アダプター ====================
   - 設計：v028-part2-design.md §4〜7・9.3。会話の しくみ（じゅんばん・AI・見張り）は 会話エンジン talk-engine.js（window.TalkEngine）
   - ここ：場面（テレビの #tv29Chat・スマホの #tv29Pad・声の じゅんばん）と 物語の 効果（cleanStore・charmsFor・helpersFor・endingPages）
   - データは tank-chatdata.js（window.TankChatData。tools/v029-gen.mjs が 作る）。記録は テレビの 'tank-tv29-chat'
   - スマホ → テレビ：cmd {a:'tv29', op:'open'|'pick'|'topic'|'say'|'yes'|'no'|'stop'|'rec'|'heard'|'ok'|'back'|'cheer', i, …}
     テレビ → スマホ：presence の g.tv29。PART 1（tank-talkvoice.js）の 録音と /stt を つかう（PART 1 は かえない）
   - 会話は 勝手に すすまない。時間の 決まりは ない。マイクは おした 時だけ。タップは いつでも 同じ 結果
   - node でも 読める（物語の 純粋な 関数だけ module.exports）。ブラウザでは window.TankChat
   ==================== */
(function (root) {
  'use strict';
  const req = n => (typeof require !== 'undefined' ? require(n) : null);
  const TE = root.TalkEngine || req('./talk-engine.js'), TD = () => root.TankChatData || (typeof require !== 'undefined' ? req('./tank-chatdata.js') : null);
  const TV29_KEY = 'tank-tv29-chat';
  const TV29_ORDER = ['bigtank', 'sandship', 'snowman', 'dragon', 'core', 'king'];
  const TV29_SLOTS = ['fav', 'gift', 'help', 'promise', 'nick'];
  const TV29_MEMO_MAX = 8, TV29_CHARMS_MAX = 2, TV29_HELPERS_MAX = 2, TV29_HELP_AT = [12, 30], TV29_PAGES_MAX = 3;
  const TV29_CHARM = { 1: ['futon', 1], 2: ['shield', 3] };          // gift 1＝おうちの まもり +1、2＝はじめの たて +3 秒（3＝かざり だけ）
  const TV29_HELP = { 1: 'futon', 2: 'shield', 3: 'freeze' };        // help 1＝まもる、2＝たて（みんな +4 秒）、3＝とめる
  const TV29_HELP_SHIELD = 4, TV29_FREEZE = 8, TV29_SP_MOOD = 4, TV29_AWAY_DAYS = 7;
  const clampI = (x, a, b) => Math.max(a, Math.min(b, Number.isFinite(+x) ? Math.floor(+x) : a));

  /* ==================== 物語（純粋） ==================== */
  function emptyBoss() { return { lv: 0, n: 0, done: [0, 0, 0, 0, 0], f: { fav: 0, gift: 0, help: 0, promise: 0, nick: 0 }, charm: 0, sp: 0, memo: [], last: 0 }; }
  // 読む 時に きれいに（p3dCleanStore と 同じ 考え）：知らない ボス・欄は すてる、数は はばに、memo.w は 16 文字・かな／漢字・NG なし
  function cleanStore(v) {
    v = v && typeof v === 'object' ? v : {}; const D = TD(), lists = D ? { ng: D.ng, allow: D.allow } : null, out = { v: 1, turn: clampI(v.turn, 0, 9999), cfg: { brain: 'auto' }, b: {} };
    const c = v.cfg && typeof v.cfg === 'object' ? v.cfg : {}; if (['auto', 'llm', 'written'].includes(c.brain)) out.cfg.brain = c.brain;
    const src = v.b && typeof v.b === 'object' ? v.b : {};
    for (const k of TV29_ORDER) { const s = src[k], o = emptyBoss(); out.b[k] = o; if (!s || typeof s !== 'object') continue;
      o.n = clampI(s.n, 0, 9999); o.sp = clampI(s.sp, 0, 99); o.charm = s.charm ? 1 : 0; o.last = clampI(s.last, 0, 9e15);
      if (Array.isArray(s.done)) o.done = [0, 1, 2, 3, 4].map(i => (s.done[i] ? 1 : 0)); o.lv = o.done.reduce((a, b) => a + b, 0);   // ♥ は すんだ はなしの 数（s.lv は 信じない）
      const f = s.f && typeof s.f === 'object' ? s.f : {}; for (const sl of TV29_SLOTS) o.f[sl] = clampI(f[sl], 0, 3);
      if (Array.isArray(s.memo)) for (const m of s.memo.slice(-TV29_MEMO_MAX)) { if (!m || typeof m !== 'object') continue; const b = String(m.b || ''), cc = String(m.c || '');
        if (!/^[a-z0-9]{1,6}$/.test(b) || !/^[a-z0-9]{1,6}$/.test(cc)) continue; const e = { t: clampI(m.t, 0, 4), b, c: cc };
        if (typeof m.w === 'string' && TE) { const w = TE.cleanKeep(m.w, lists); if (w) e.w = w; } o.memo.push(e); }
      if (o.f.gift !== 1 && o.f.gift !== 2) o.charm = 0; }
    return out;
  }
  const story = (store, k) => (store && store.b && store.b[k]) || emptyBoss();
  const byLv = store => (a, b) => story(store, b).lv - story(store, a).lv || TV29_ORDER.indexOf(a) - TV29_ORDER.indexOf(b);
  const isBossStage = st => !!(st && Array.isArray(st.bosses) && st.bosses.length && !st.p3dDuel && st.p3dBonus == null && !st.p4b && !st.p3dGold);
  // おまもり（♥2 の gift 1・2）：ボスの いる 面の はじめに 2 つまで（♥ の 高い じゅん）。使った ボスは useCharm
  function charmsFor(store, stage) {
    if (!isBossStage(stage)) return [];
    return TV29_ORDER.filter(k => { const s = story(store, k); return s.charm && s.lv >= 2 && TV29_CHARM[s.f.gift]; }).sort(byLv(store)).slice(0, TV29_CHARMS_MAX)
      .map(k => { const [kk, n] = TV29_CHARM[story(store, k).f.gift]; return { boss: k, k: kk, n }; });
  }
  function useCharm(store, k) { if (store && store.b && store.b[k]) store.b[k].charm = 0; return store; }
  // さいごの たたかいの おてつだい（♥3）：王の 面・ひみつのボス（2 周目も）。たたかう ボスは のぞく。王は ひみつのボスの 時だけ。2 人まで
  function finalKind(stage) { if (!stage || stage.p3dDuel || stage.p4b) return ''; if (stage.p3dGold) return 'gold'; if (Array.isArray(stage.bosses) && stage.bosses.includes('king') && stage.p3dBonus == null) return 'king'; return ''; }
  function helpersFor(store, stage, lap) {
    const kind = finalKind(stage); if (!kind) return []; void lap;
    const fought = (stage.bosses || []);
    return TV29_ORDER.filter(k => { const s = story(store, k); return s.lv >= 3 && TV29_HELP[s.f.help] && !fought.includes(k) && (k !== 'king' || kind === 'gold'); })
      .sort(byLv(store)).slice(0, TV29_HELPERS_MAX).map((k, i) => ({ boss: k, k: TV29_HELP[story(store, k).f.help], at: TV29_HELP_AT[i] }));
  }
  const fill = (s, fav, nick) => String(s || '').replace(/\{fav\}/g, fav).replace(/\{nick\}/g, nick);
  function favNick(store, k, data, lang) { const C = data.chars[k], s = story(store, k), li = lang === 'zh' ? 1 : 0;
    const fav = C.words.fav[(s.f.fav || 1) - 1][li], nick = s.lv >= 5 && s.f.nick ? C.words.nick[s.f.nick - 1][li] : C.persona.name[li]; return [fav, nick]; }
  // エンディングの「ともだちの ページ」：♥1 以上の ボス 3 人まで（♥ → 物語の じゅん）。やくそくは ♥4 から。4 人が 同じ やくそく → みんなの やくそく。6 人 ♥5 → ほんとうの ともだち
  function endingPages(store, data) {
    data = data || TD(); if (!data) return []; const out = [], fr = TV29_ORDER.filter(k => story(store, k).lv >= 1).sort(byLv(store));
    for (const k of fr.slice(0, TV29_PAGES_MAX)) { const s = story(store, k), p = s.lv >= 4 ? s.f.promise | 0 : 0, line = data.chars[k].fixed.end[String(p)], fj = favNick(store, k, data, 'ja'), fz = favNick(store, k, data, 'zh');
      out.push({ kind: 'friend', who: k, lv: s.lv, promise: p, nick: s.lv >= 5 && s.f.nick ? data.chars[k].words.nick[s.f.nick - 1] : null, ja: fill(line.ja, fj[0], fj[1]), zh: fill(line.zh, fz[0], fz[1]), tts: true }); }
    const cnt = {}; for (const k of TV29_ORDER) { const s = story(store, k); if (s.lv >= 4 && s.f.promise) cnt[s.f.promise] = (cnt[s.f.promise] | 0) + 1; }
    const pv = Object.keys(cnt).find(v => cnt[v] >= 4); if (pv && data.slides && data.slides.promiseAll && data.slides.promiseAll[pv]) { const P = data.slides.promiseAll[pv];
      out.push({ kind: 'promise', who: 'narr', promise: +pv, title: [P.title.ja, P.title.zh], ja: P.lines.map(l => l.ja).join('　'), zh: P.lines.map(l => l.zh).join('　'), tts: true }); }
    if (TV29_ORDER.every(k => story(store, k).lv >= 5) && data.slides && data.slides.trueFriends) { const T = data.slides.trueFriends;
      out.push({ kind: 'true', who: 'narr', title: [T.title.ja, T.title.zh], ja: T.lines.map(l => l.ja).join('　'), zh: T.lines.map(l => l.zh).join('　'), tts: true }); }
    return out;
  }
  const heartTotal = store => TV29_ORDER.reduce((a, k) => a + story(store, k).lv, 0);
  const memoryLines = (store, k, data, lang) => (TE ? TE.memoryLines(store, k, data || TD(), lang) : []);
  // おしゃべりの 結果を 記録へ（complete＝♥ が ふえる。stop でも きまった フラグは のこる。gone は 何も しない）
  function applyVisit(store, k, ti, res, now) {
    store = cleanStore(store); const s = store.b[k], before = { lv: s.lv, f: Object.assign({}, s.f), charm: s.charm }; if (!res || res.why === 'gone') return { store, before, after: before, changed: [] };
    const changed = [];
    for (const sl of TV29_SLOTS) if (res.flags && res.flags[sl]) { const v = clampI(res.flags[sl], 1, 3); if (s.f[sl] !== v) changed.push([sl, v, s.f[sl]]); s.f[sl] = v; }
    for (const m of res.memo || []) { const e = { t: clampI(ti, 0, 4), b: m.b, c: m.c }; if (m.w) e.w = m.w; s.memo.push(e); } s.memo = s.memo.slice(-TV29_MEMO_MAX);
    if (res.complete) { s.done[ti] = 1; s.lv = s.done.reduce((a, b) => a + b, 0); s.n = Math.min(9999, s.n + 1); if (s.f.gift === 1 || s.f.gift === 2) s.charm = 1; if ((res.mood | 0) >= TV29_SP_MOOD) s.sp = Math.min(99, s.sp + 1); }
    if (s.f.gift !== 1 && s.f.gift !== 2) s.charm = 0;
    s.last = now || Date.now(); store.turn = (store.turn + 1) % 10000;
    return { store, before, after: { lv: s.lv, f: Object.assign({}, s.f), charm: s.charm }, changed };
  }
  const nextTopic = (store, k) => { const d = story(store, k).done; const i = d.indexOf(0); return i < 0 ? -1 : i; };

  const api = { KEY: TV29_KEY, ORDER: TV29_ORDER, SLOTS: TV29_SLOTS, cleanStore, charmsFor, useCharm, helpersFor, endingPages, heartTotal, memoryLines, applyVisit, nextTopic, finalKind, isBossStage,
    CONST: { TV29_CHARMS_MAX, TV29_HELPERS_MAX, TV29_HELP_AT, TV29_HELP_SHIELD, TV29_FREEZE, TV29_PAGES_MAX },
    CREDITS: [['🎤 音声認識', '🎤 语音识别', ['whisper.cpp — MIT（© Georgi Gerganov and contributors）', 'Whisper models — MIT（© OpenAI）', 'whisper-jni — Apache-2.0（© Miguel Álvarez Díez）', 'Kuromoji — Apache-2.0（© Atilika Inc.）・mecab-ipadic（NAIST）']],
      ['🧠 AI（会話）', '🧠 AI（聊天）', ['Ollama — MIT（© Ollama）', 'Qwen3 — Apache-2.0（© Alibaba Cloud）', 'Gemma 3 — Gemma Terms of Use（© Google）※ 選んだ時だけ']],
      ['🗣 ボスの声（その場で合成）', '🗣 首领的声音（实时生成）', ['VOICEVOX:青山龍星', 'VOICEVOX:麒ヶ島宗麟', 'VOICEVOX:ずんだもん', 'VOICEVOX:櫻歌ミコ', 'VOICEVOX:ちび式じい', 'VOICEVOX:ナースロボ＿タイプＴ', 'VOICEVOX:剣崎雌雄', 'VOICEVOX:No.7']]] };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (typeof window === 'undefined' || typeof document === 'undefined') { root.TankChat = api; return; }

  /* ==================== ここから ブラウザだけ ==================== */
  let C = null;
  const Lx = (ja, zh) => C.L(ja, zh), LANGx = () => (C.lang() === 'zh' ? 'zh' : 'ja');
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  // v0.31：日本語だけ（tank.html の JA_ONLY）。中国語の 小さい 行は 出さない（データは 残す）
  const ZS = s => (window.TANK_JA_ONLY ? '' : `<small>${esc(s)}</small>`);
  const bossName = (k, lang) => { const D = TD(), C2 = D && D.chars[k]; if (!C2) return ''; return C2.persona.name[(lang || LANGx()) === 'zh' ? 1 : 0]; };
  const nickOf = (store, k) => { const s = story(store, k), D = TD(); return s.lv >= 5 && s.f.nick && D ? D.chars[k].words.nick[s.f.nick - 1] : null; };
  const hearts = n => '♥'.repeat(n) + '♡'.repeat(5 - n);
  function attach(ctx) { C = api.ctx = ctx; css(); if (ctx.ROLE === 'tv') tvInit(); else padInit(); api.ready = true; }

  function css() { if (document.getElementById('tv29Css')) return; const s = document.createElement('style'); s.id = 'tv29Css'; s.textContent = `
#tv29Chat{position:fixed;inset:0;z-index:31;background:radial-gradient(ellipse at 50% 30%,#2a3a30,#0c1410 75%);color:#fff6dc;font-family:var(--body);display:flex;flex-direction:column;padding:3vh 4vw;gap:1.6vh;overflow:hidden}
#tv29Chat.hide{display:none}
#tv29Chat .hd{display:flex;align-items:center;gap:2vw;font-size:3vh;font-weight:900;white-space:nowrap}#tv29Chat .hd>*{flex:none}#tv29Chat .hd .sp{flex:1 1 auto}#tv29Chat .hd b{font-family:var(--display);font-weight:400;font-size:4.4vh;color:#ffd23a}
#tv29Chat .hd .hearts{color:#ff6a8a;letter-spacing:.1em}#tv29Chat .hd .sp{flex:1}#tv29Chat .hd .brain{font-size:2.2vh;opacity:.9;background:rgba(255,255,255,.1);padding:.4vh 1vw;border-radius:99px}
#tv29Chat .body{flex:1 1 auto;min-height:0;display:flex;gap:3vw;align-items:center}
#tv29Chat .pt{flex:0 0 34vh;height:34vh;border-radius:3vh;background:rgba(255,246,220,.12);border:.5vh solid #ffd23a;position:relative;display:flex;align-items:center;justify-content:center}
#tv29Chat .pt canvas{width:30vh;height:30vh}#tv29Chat .pt.happy canvas{animation:tv29Bounce .5s ease-in-out 3}#tv29Chat .pt.think canvas{transform:rotate(-6deg)}
#tv29Chat .pt .bub{position:absolute;right:-2vh;top:-2vh;background:#fff;color:#1b2a22;border-radius:2vh;padding:.6vh 1.4vh;font-weight:900;font-size:3vh;display:none}#tv29Chat .pt.think .bub{display:block;animation:tv29Pulse 1s infinite}
#tv29Chat .pt .nick{position:absolute;bottom:-1.6vh;left:50%;transform:translateX(-50%);white-space:nowrap;background:#ff6a8a;color:#fff;font-weight:900;font-size:2.2vh;padding:.2vh 1.2vh;border-radius:99px}
#tv29Chat .lines{flex:1 1 auto;min-width:0;display:flex;flex-direction:column;gap:2vh}
#tv29Chat .ln{background:#fff6dc;color:#1b2a22;border-radius:2.4vh;padding:1.6vh 2.4vh;border:.4vh solid #1b2a22;box-shadow:0 .6vh 0 #000;opacity:.55}
#tv29Chat .ln.now,#tv29Chat .ln.done{opacity:1}#tv29Chat .ln.q{background:#ffe08a}#tv29Chat .ln .ja{font-size:4.2vh;font-weight:900;line-height:1.3}#tv29Chat .ln .zh{font-size:2.8vh;opacity:.8;margin-top:.4vh}
#tv29Chat .ln.now .ja::after{content:" 🔊";font-size:3vh}#tv29Chat .ln small{display:block;font-size:2vh;color:#c0392b;font-weight:900}
#tv29Chat .cards{display:flex;gap:1.4vw;justify-content:center;flex-wrap:wrap}#tv29Chat .cards button{font:inherit;font-weight:900;font-size:3vh;background:#fff;color:#1b2a22;border:.4vh solid #1b2a22;border-radius:2vh;padding:1vh 2vw;box-shadow:0 .5vh 0 #000;cursor:pointer}
#tv29Chat .cards button i{font-style:normal;margin-right:.6vw}#tv29Chat .cards button small{display:block;font-size:2vh;opacity:.75}#tv29Chat .cards.off button{opacity:.45}#tv29Chat .cards.xl button{font-size:4vh;padding:1.6vh 3vw}
#tv29Chat .cards button.glow{outline:.6vh solid #ffbf2f;background:#ffe08a}
#tv29Chat .who{text-align:center;font-size:3vh;font-weight:900;color:#ffd23a}#tv29Chat .cap{text-align:center;font-size:2.8vh;font-weight:900;min-height:3.4vh}#tv29Chat .cap.rec{animation:tv29Pulse 1s infinite;color:#ff9a9a}
#tv29Chat .grid{flex:1 1 auto;min-height:0;display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:repeat(2,1fr);gap:2vh 2vw}
#tv29Chat .grid button{font:inherit;color:#1b2a22;background:#fff6dc;border:.5vh solid #1b2a22;border-radius:2.4vh;box-shadow:0 .7vh 0 #000;display:flex;align-items:center;gap:1.4vw;padding:1.4vh 1.4vw;text-align:left;cursor:pointer;min-width:0}
#tv29Chat .grid button canvas{flex:0 0 auto;width:16vh;height:16vh}#tv29Chat .grid button.lock{background:#4a544e;color:#cfd8d2}
#tv29Chat .grid button b{display:block;font-size:3.4vh;font-family:var(--display);font-weight:400}#tv29Chat .grid button span{display:block;font-size:2.4vh;font-weight:900;margin-top:.6vh}
#tv29Chat .grid button .h{color:#e0466a;font-size:3vh;letter-spacing:.06em}#tv29Chat .grid button small{display:block;font-size:2vh;margin-top:.4vh;opacity:.8}
#tv29Chat .foot{text-align:center;font-size:2.4vh;font-weight:900;opacity:.9}
#tv29Chat .rw{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2.4vh;text-align:center}#tv29Chat .rw .hl{font-family:var(--display);font-size:8vh;color:#ff6a8a}
#tv29Chat .rw p{margin:0;font-size:3.4vh;font-weight:900}#tv29Chat .rw p small{display:block;font-size:2.4vh;opacity:.8}
#tv29Chat .cheer{position:absolute;font-size:7vh;animation:tv29Up 2s ease-out forwards;pointer-events:none}
@keyframes tv29Bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-2vh)}}@keyframes tv29Pulse{0%,100%{opacity:1}50%{opacity:.45}}@keyframes tv29Up{from{transform:translateY(0);opacity:1}to{transform:translateY(-30vh);opacity:0}}
#tv29Pad{position:fixed;inset:0;z-index:40;background:#121a14;color:#fff;display:flex;flex-direction:column;gap:1.2vh;padding:10px var(--padw-sr,16px) 10px var(--padw-sl,16px);overflow:auto;font-family:var(--body)}
#tv29Pad.hide{display:none}#tv29Pad h2{margin:0;font-family:var(--display);font-weight:400;font-size:clamp(16px,5vh,24px);color:#ffd23a;text-align:center;line-height:1.2}
#tv29Pad .q{background:#fff6dc;color:#1b2a22;border-radius:14px;padding:8px 12px;font-weight:900;font-size:clamp(15px,4.6vh,22px);line-height:1.3}#tv29Pad .q small{display:block;font-size:.72em;opacity:.75;font-weight:700}
#tv29Pad .msg{text-align:center;font-weight:900;font-size:clamp(13px,4vh,18px)}
#tv29Pad .row{display:flex;gap:10px;align-items:stretch}#tv29Pad .cards{flex:1 1 auto;display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px}
#tv29Pad .cards button,#tv29Pad .btn{min-height:min(18vh,74px);border-radius:16px;border:4px solid #10201a;box-shadow:0 5px 0 #10201a;background:#fff;color:#1b2a22;font:inherit;font-weight:900;font-size:clamp(14px,4.4vh,20px);line-height:1.15;padding:4px 6px}
#tv29Pad .cards button i{display:block;font-style:normal;font-size:1.5em}#tv29Pad .cards button small{display:block;font-size:.7em;opacity:.75}
#tv29Pad .cards.xl button{min-height:min(32vh,130px);font-size:clamp(18px,6vh,28px)}#tv29Pad .cards.off button{opacity:.4}#tv29Pad .cards button.glow{outline:5px solid #ffbf2f;background:#ffe08a}
#tv29Pad .cards button.other{background:#e8f4ff}
#tv29Pad .mic{flex:0 0 22%;min-width:96px;max-width:190px;border-radius:24px;border:5px solid #10201a;box-shadow:0 7px 0 #10201a;background:#fff3b0;color:#10201a;font:inherit;font-weight:900;font-size:clamp(14px,4.6vh,20px);display:flex;flex-direction:column;align-items:center;justify-content:center}
#tv29Pad .mic i{font-style:normal;font-size:clamp(34px,13vh,58px);line-height:1}#tv29Pad .mic.rec{background:#ff8a8a;animation:tv29Pulse 1s infinite}#tv29Pad .mic.small{flex-basis:76px;min-width:76px;font-size:12px}#tv29Pad .mic.small i{font-size:28px}
#tv29Pad .acts{display:flex;gap:8px;flex-wrap:wrap}#tv29Pad .acts .btn{flex:1 1 30%}#tv29Pad .btn.ok{background:#7fe08f;color:#10201a;display:block;width:auto}#tv29Pad .btn.no{background:#ffd0c8}
#tv29Pad .end{align-self:flex-end;font-size:13px;min-height:36px;padding:4px 12px;border-radius:99px;border:2px solid #fff;background:transparent;color:#fff;font-weight:900}#tv29Pad .end.arm{background:#e4483f;border-color:#e4483f}
#tv29Pad .list{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}#tv29Pad .list button{display:flex;align-items:center;gap:6px;text-align:left;border-radius:14px;border:3px solid #10201a;background:#fff6dc;color:#1b2a22;font:inherit;font-weight:900;font-size:15px;line-height:1.2;padding:4px 6px;min-height:64px;min-width:0}#tv29Pad .list button>div{min-width:0}
#tv29Pad .list button canvas{width:52px;height:52px;flex:none}#tv29Pad .list button.lock{background:#4a544e;color:#cfd8d2}#tv29Pad .list button small{display:block;font-size:11px;opacity:.85}#tv29Pad .list .h{color:#e0466a}
#tv29Pad .cheers{display:flex;gap:10px;justify-content:center}#tv29Pad .cheers button{font-size:34px;min-width:72px;min-height:64px;border-radius:16px;border:3px solid #fff;background:#24302a}
#tv29Pad .big1{font-family:var(--display);font-size:clamp(30px,12vh,56px);color:#ff6a8a;text-align:center}
#navBox button.tv29{background:#ffd0e0}
#tv29Rows{margin:0}#tv29Rows p{margin:.4vh 0}#tv29Rows button{margin:.3vh .4vw;padding:.3vh 1vw;border-radius:99px;border:3px solid #1b2a22;background:#fff;font-weight:800}
#tv29Rows button.on{background:#ffd23a}
#tv29Shelf{position:fixed;z-index:15;padding:8px 16px;border-radius:99px;border:3px solid #1b2a22;background:#ffd0e0;font-size:20px;font-weight:900;color:#1b2a22;cursor:pointer}#tv29Shelf.hide{display:none}`;
    document.head.appendChild(s); }

  /* ==================== テレビ ==================== */
  const S = { on: 0, ui: '', boss: '', ti: 0, talk: null, step: null, st: '', i: 0, sp: '', order: [], oi: 0, lastB: '', lines: [], li: -1, hd: '', rec: '', tok: 0, rw: null, status: null, polled: 0,
    store: null, eng: null, sig: '', audio: { q: [], cur: null, busy: false, cache: new Map(), gen: 0 }, helpers: [], helped: [], think: null, mood: '', stopArm: 0, ended: null, warmed: 0, cheers: [] };
  function tvSave() { C.writeJSON(TV29_KEY, S.store); }
  const llmReady = () => !!(S.status && S.status.on && S.status.llm && S.status.llm.state === 'ready');
  const ttsReady = () => !!(S.status && S.status.on && S.status.tts && S.status.tts.state === 'ready');
  const friend = k => !!(C.friend && C.friend(k));
  function tvInit() {
    S.store = cleanStore(C.readJSON(TV29_KEY));
    S.eng = TE.create({ data: TD(), brains: { llm: TE.brains.http('/brain/chat') }, brain: () => S.store.cfg.brain, ready: llmReady });
    const send = C.room.presence; C.room.presence = function (p) { if (p && p.role === 'tv' && p.g) { try { p.g.tv29 = tvPack(); const p30 = p13Pack(); if (p30) p.g.tv30 = Object.assign({}, p.g.tv30 || {}, p30); /*P13*/ } catch (e) { console.warn('P12：おしゃべりの 様子を 作れませんでした', e); } } return send.call(C.room, p); };
    C.room.on('cmd', m => { if (m.data && m.data.a === 'tv29') try { tvCmd(m.peer, m.data); } catch (e) { console.warn('P12：おしゃべりの 操作を 処理できませんでした', e); } });
    C.room.on('cmd', m => { if (m.data && m.data.a === 'tv30') try { p13Cmd(m.peer, m.data); } catch (e) { console.warn('P13：そうだんの 操作を 処理できませんでした', e); } });   /*P13*/
    const d = document.createElement('div'); d.id = 'tv29Chat'; d.className = 'hide'; document.body.appendChild(d);
    d.addEventListener('click', tvClick);
    const sb = document.createElement('button'); sb.id = 'tv29Shelf'; sb.className = 'hide'; sb.onclick = () => { const p = C.p4b && C.p4b(); if (p && p.id) { if (C.audioOn) C.audioOn(); tvOpen(p.id); } }; document.body.appendChild(sb);
    addEventListener('keydown', tvKey, true);
    C.hookAfter(tvAfter); tvPoll();
  }
  // かざりだなの ボスの 画面（P4B の pick）で、なかまの ボスなら その id
  function shelfId() { const p = C.p4b && C.p4b(), G = C.G(); return p && p.ui === 'pick' && TV29_ORDER.includes(p.id) && friend(p.id) && !S.on && G.ph === 'lobby' && !C.SC().on ? p.id : ''; }
  function canOpen() { const G = C.G(); return G.ph === 'lobby' && !C.SC().on && !S.on && !(C.busy && C.busy()) && !document.getElementById('tv28Set'); }
  function tvOpen(boss) {
    if (!canOpen()) return false; S.on = 1; S.picT = 0; S.ui = 'list'; S.sig = ''; S.rw = null; C.play && C.play('join'); tvPoll(); tvWarm();
    if (boss && TV29_ORDER.includes(boss)) tvPick(boss); return true;
  }
  function tvClose() { S.on = 0; S.ui = ''; S.talk = null; S.step = null; audioStop(); S.sig = ''; S.run = null; S.hsp = ''; S.ans = ''; S.hb = ''; S.pops = []; S.waitOn = null; /*P13*/ const d = document.getElementById('tv29Chat'); if (d) d.classList.add('hide'); }
  function tvWarm() { if (S.warmed && Date.now() - S.warmed < 60000) return; S.warmed = Date.now(); if (S.store.cfg.brain === 'written') return;
    const b = S.eng.brains.llm; if (b && b.warm) b.warm().catch(() => {}); }
  async function tvPoll() { S.polled = performance.now();
    try { const r = await fetch('/brain/status', { cache: 'no-store' }); S.status = r.ok ? await r.json() : null; } catch (e) { S.status = null; } S.sig = ''; tvRows(); }
  function brainLabel() { const st = S.status, cfg = S.store.cfg.brain;
    if (cfg === 'written' || !st || !st.on || !st.llm) return ['📖 きまった へんじで はなすよ', '📖 用固定回答聊天', 'written'];
    const L1 = st.llm; if (L1.state === 'ready') return S.talk && S.talk.fails >= 3 ? ['📖 きまった へんじで はなすよ', '📖 用固定回答聊天', 'written'] : ['🧠 AI：OK', '🧠 AI：OK', 'llm'];
    if (L1.state === 'pulling' || L1.state === 'loading' || L1.state === 'starting') { const p = L1.total ? Math.floor(100 * (L1.done || 0) / L1.total) : 0; return [`🧠 AI：じゅんびちゅう ${p}%`, `🧠 AI：准备中 ${p}%`, 'written', p]; }
    return ['📖 きまった へんじで はなすよ', '📖 用固定回答聊天', 'written']; }
  function tvPick(boss) {
    if (!S.on || S.ui === 'talk') return; if (!friend(boss)) { C.tone && C.tone(300, 200, .12, 'square', .08); return; }
    const t = nextTopic(S.store, boss); if (t < 0) { S.ui = 'topics'; S.boss = boss; S.sig = ''; return; } tvStart(boss, t);
  }
  function tvStart(boss, ti, noKeep) {
    const ps = C.players(); if (!ps.length) { C.toast && C.toast(Lx('📱 スマホで 参加してね', '📱 请用手机加入'), '#ffd23a'); return; }
    if (!noKeep) { const kc = p13Keep(boss, ti); if (kc) { css30(); S.picT = 0; runStart(kc); return; } }   /*P13：やくそくを まもる？（§4.3）→ visit で この 話へ*/
    const s = story(S.store, boss), D = TD(), lang = LANGx(), F = D.chars[boss].fixed;
    const greet = s.lv >= 1 && s.f.fav && F.hiFav && F.hiFav[s.f.fav] ? Object.assign({ fx: ['hifav', s.f.fav - 1] }, F.hiFav[s.f.fav]) : null;
    S.boss = boss; S.ti = ti; S.ui = 'talk'; S.order = ps.map(p => p.id); S.oi = S.store.turn % S.order.length; S.sp = S.order[S.oi]; S.lastB = ''; S.hd = ''; S.rec = ''; S.stopArm = 0; S.ended = null;
    const open = gr => { S.talk = S.eng.open({ who: boss, character: p13Sheet(boss), topic: ti, memory: p13Mem(boss, memoryLines(S.store, boss, D, 'ja')), lang, names: ps.map(p => p.name), greet: gr });
      if (ttsReady() && voiceOn()) fetch('/tts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ who: boss, warm: true }) }).catch(() => {});   // さいしょの 声を はやく（p12a-interface §3）
      const tok = ++S.tok; S.st = 'say'; S.sig = '';
      S.talk.start().then(st => { if (tok === S.tok) tvStep(st); }); };
    const g30 = noKeep ? null : p13Greet(boss);   /*P13：ext.greet（おぼえている ボス）。Promise でも よい。やくそくの あとは もう あいさつ しない*/
    if (g30 && typeof g30.then === 'function') { const tok = ++S.tok; S.st = 'think'; S.sig = ''; S.talk = null; g30.then(g => g, () => null).then(g => { if (tok === S.tok && S.on && S.ui === 'talk' && S.boss === boss) open(g || greet); }); }
    else open(g30 || greet);
  }
  function rotate(b) { const G = C.G(); S.order = C.players().map(p => p.id); if (!S.order.length) return;
    if (b !== S.lastB) { const at = S.order.indexOf(S.sp); S.oi = at < 0 ? S.oi % S.order.length : (at + 1) % S.order.length; if (S.lastB === '') S.oi = S.store.turn % S.order.length; S.sp = S.order[S.oi]; }
    else if (!G.pl[S.sp]) { S.oi = S.oi % S.order.length; S.sp = S.order[S.oi]; } S.lastB = b; }
  function tvStep(st) {
    const h30 = p13Pre(st);   /*P13*/
    S.step = st; S.lines = st.say.map(l => Object.assign({}, l)); S.li = -1; S.st = 'say'; S.hd = ''; S.sig = ''; S.mood = st.say.some(l => l.src === 'llm' || l.src === 'written') ? 'happy' : '';
    if (st.ask && !h30) rotate(st.ask.b);
    const tok = S.tok; audioSay(S.lines, tok, () => { if (tok !== S.tok) return; if (st.done) tvEnd(st); else { S.st = p13AskSt(st); S.hudAt = 0; S.i++; S.sig = ''; } });
  }
  async function tvAnswer(h) {
    if (!S.talk) return; const tok = ++S.tok, sp30 = S.sp; S.st = 'think'; S.sig = ''; S.mood = 'think';
    const th = S.talk.thinking(); S.lines = th ? [Object.assign({ think: 1 }, th)] : []; S.li = -1; if (th) audioSay(S.lines, tok, null);
    const p = C.players().find(q => q.id === S.sp), idx = Math.max(0, S.order.indexOf(S.sp)) + 1;
    let st; try { st = await S.talk.answer(Object.assign({ speaker: idx, lang: LANGx() }, h, p13ExtraLines())); } catch (e) { console.warn('P12：こたえを 処理できませんでした', e); return; }
    void p; if (tok !== S.tok) return; p13Turn(st, sp30); await audioIdle(tok); if (tok !== S.tok) return; tvStep(st);
  }
  async function tvConfirm(yes) { if (!S.talk) return; const tok = ++S.tok, sp30 = S.sp; S.st = 'think'; const st = await S.talk.confirm(yes); if (tok === S.tok) { p13Turn(st, sp30); tvStep(st); } }
  function tvStop() { if (!S.talk || S.ui !== 'talk') return; const tok = ++S.tok; audioStop(); tvStep(S.talk.stop()); void tok; }
  function tvGone() { if (!S.talk) return; ++S.tok; audioStop(); S.talk.gone(); if (S.run) runGone(); else tvClose(); C.toast && C.toast(Lx('💬 だれも いなくなったので おしゃべりを やめたよ', '💬 没有人了，聊天结束'), '#ffd0e0'); }
  function tvEnd(st) {
    if (S.run) { runEnd(st); return; }   /*P13*/
    const boss = S.boss, ti = S.ti, D = TD(), ts = S.talk && S.talk.state, res = applyVisit(S.store, boss, ti, Object.assign({}, st, ts ? { flags: ts.flags, memo: ts.memo, mood: ts.mood } : {}), Date.now());
    S.store = res.store; tvSave();   // Step の flags／memo は その 回の 分だけ なので talk.state から
    const lines = [];
    for (const [sl, v] of res.changed) { const tp = D.chars[boss].topics[TV29_SLOTS.indexOf(sl)], kb = tp && tp.beats.find(b => b.key), c = kb && kb.cats.find(x => x.val === v);
      const what = { gift: [['🏠 おうちの おまもり（つぎの ボスの 面で おうちの まもり +1）', '🏠 小屋护身符（下个首领关卡小屋防护 +1）'], ['🛡 たての おまもり（つぎの ボスの 面で はじめの たて +3 びょう）', '🛡 盾护身符（下个首领关卡开场护盾 +3 秒）'], ['🎀 かざり（かざりだなに かざるよ）', '🎀 装饰（摆在展示架上）']],
        help: [['🏠 さいごの たたかいで おうちを まもる', '🏠 最终战守护小屋'], ['🛡 さいごの たたかいで たてを はる', '🛡 最终战撑起护盾'], ['❄ さいごの たたかいで てきを とめる', '❄ 最终战冻住敌人']],
        promise: [['🏠 やくそく：おうちで あそぶ', '🏠 约定：在小屋玩'], ['🚀 やくそく：いっしょに たびに でる', '🚀 约定：一起去旅行'], ['🏘 やくそく：いっしょに くらす', '🏘 约定：一起生活']] }[sl];
      if (what) lines.push(what[v - 1]); else if (c) lines.push(sl === 'nick' ? [`💖 あだな：${c.ja}`, `💖 昵称：${c.zh}`] : [`⭐ すきな もの：${c.ja}`, `⭐ 喜欢的：${c.zh}`]); }
    if (st.complete && res.after.charm && !res.before.charm) lines.push(['🎁 おまもりが たまった！', '🎁 护身符充好了！']);
    S.rw = { lv0: res.before.lv, lv1: res.after.lv, complete: st.complete, why: st.why, lines, sp: (st.mood | 0) >= TV29_SP_MOOD && st.complete };
    S.ui = 'reward'; S.st = 'reward'; S.talk = null; S.sig = '';
    if (st.complete) { C.play && C.play('powerup'); tvAlbum(boss, res.after.lv); }
  }
  function tvAlbum(boss, lv) { if (!window.TankAlbum) return;
    try { const c = document.createElement('canvas'); c.width = 960; c.height = 540; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 540); g.addColorStop(0, '#ffe8f0'); g.addColorStop(1, '#fff6dc'); x.fillStyle = g; x.fillRect(0, 0, 960, 540);
      if (C.bossPic) C.bossPic(x, boss, 3, 300, 330, 300); x.fillStyle = '#e0466a'; x.font = '900 64px "M PLUS Rounded 1c",sans-serif'; x.fillText(hearts(lv), 520, 220); x.fillStyle = '#1b2a22'; x.font = '900 48px "M PLUS Rounded 1c",sans-serif';
      x.fillText('💬 ' + bossName(boss, 'ja'), 520, 320); if (!window.TANK_JA_ONLY) { x.font = '900 36px "M PLUS Rounded 1c",sans-serif'; x.fillText(bossName(boss, 'zh'), 520, 380); }
      const nm = C.players().map(p => p.name);
      c.toBlob(b => { if (!b) return; window.TankAlbum.add({ at: Date.now(), kind: 'reunion', caps: [[`💬 ${bossName(boss, 'ja')} と おしゃべりした！`, `💬 和${bossName(boss, 'zh')}聊天了！`]], stage: ['ボスと おしゃべり', '和首领聊天'], mode: 'chat', names: nm, w: 960, h: 540, blob: b }).catch(e => console.warn('P12：写真を 残せませんでした', e)); }, 'image/jpeg', .88);
    } catch (e) { console.warn('P12：写真を 作れませんでした', e); } }
  function tvCmd(peer, d) {
    const G = C.G(); if (!G.pl[peer]) return; const str = v => String(v == null ? '' : v).slice(0, 120);
    if (d.op === 'open') { if (S.on && d.boss) tvPick(d.boss); else tvOpen(d.boss); return; }
    if (!S.on) return;
    if (d.op === 'back') { if (S.ui === 'topics') { S.ui = 'list'; S.sig = ''; } else if (S.ui === 'list') tvClose(); return; }
    if (d.op === 'pick' && S.ui === 'list') { tvPick(String(d.boss || '')); return; }
    if (d.op === 'topic' && S.ui === 'topics') { const t = d.t | 0; if (t >= 0 && t < 5) tvStart(S.boss, t); return; }
    if (d.op === 'ok' && S.ui === 'reward') { rwClose(); return; }
    if (d.op === 'cheer' && S.ui === 'talk' && ['👏', '❤️', '😄', '⭐'].includes(d.e)) { S.cheers.push({ e: d.e, at: performance.now(), x: 10 + Math.random() * 80 }); return; }
    if (S.ui !== 'talk' || peer !== S.sp) return;
    if (d.op === 'stop') { tvStop(); return; }
    if (d.i !== S.i) return;
    if (d.op === 'rec') { S.rec = d.on ? peer : ''; if (d.on) S.hd = ''; S.sig = ''; return; }
    if (d.op === 'heard') { S.rec = ''; S.hd = TE.maskNG(str(d.text), str(d.kana), d.l === 'zh' ? 'zh' : 'ja', TD()); S.sig = ''; return; }
    if (S.st === 'check' && (d.op === 'yes' || d.op === 'no')) { tvConfirm(d.op === 'yes'); return; }
    if (d.op === 'say' && (S.st === 'ask' || S.st === 'check')) { S.rec = '';
      tvAnswer({ text: str(d.text), kana: str(d.kana), pick: Number.isInteger(d.pick) ? d.pick : -1, m: Number.isInteger(d.m) ? d.m : undefined, sc: +d.sc || 0, lang: d.l === 'zh' ? 'zh' : d.l === 'ja' ? 'ja' : LANGx() }); }
  }
  // テレビの 画面を クリック（タッチ）：札＝話す人の タップ、一覧の ボス、ごほうびの OK
  function tvClick(ev) { const o30 = ev.target.closest('[data-op30]'); if (o30 && X().badgeTap) { ev.stopPropagation(); X().badgeTap(o30.dataset.boss, o30.dataset.op30); return; }   /*P13*/
    const b = ev.target.closest('button'); if (!b) return; if (C.audioOn) C.audioOn();
    if (b.dataset.boss) tvPick(b.dataset.boss); else if (b.dataset.t) tvStart(S.boss, +b.dataset.t); else if (b.dataset.card && S.ui === 'talk' && (S.st === 'ask' || S.st === 'hud')) { if (S.st === 'hud') p13Go(S.sp); tvAnswer({ text: '', pick: +b.dataset.card }); }
    else if (b.dataset.yn && S.st === 'check') tvConfirm(b.dataset.yn === 'y'); else if (b.dataset.k === 'ok') rwClose(); else if (b.dataset.k === 'back') { if (S.ui === 'topics') { S.ui = 'list'; S.sig = ''; } else tvClose(); } }
  function tvKey(ev) {
    const k = ev.key, G = C.G(), stop = () => { ev.preventDefault(); ev.stopImmediatePropagation(); };
    if (!S.on) { if (ev.target && /INPUT|TEXTAREA/.test(ev.target.tagName)) return; const sh = shelfId();
      if ((k === 't' || k === 'T') && G.ph === 'lobby' && C.view() === 'lobby' && canOpen()) { if (C.audioOn) C.audioOn(); if (tvOpen()) stop(); }
      else if ((k === 'c' || k === 'C') && sh && canOpen()) { if (C.audioOn) C.audioOn(); if (tvOpen(sh)) stop(); } return; }
    if (S.ui === 'list') { const fr = TV29_ORDER.filter(friend); if (['Escape', 'GoBack', 'BrowserBack', 'Backspace'].includes(k)) tvClose(); else if (/^[1-6]$/.test(k)) tvPick(TV29_ORDER[+k - 1]); else if (k === 'Enter' && fr.length) tvPick(fr[0]); }
    else if (S.ui === 'topics') { if (/^[1-5]$/.test(k)) tvStart(S.boss, +k - 1); else if (['Escape', 'Backspace'].includes(k)) { S.ui = 'list'; S.sig = ''; } }
    else if (S.ui === 'reward') { if (k === 'Enter' || k === ' ' || k === 'Escape') rwClose(); }
    else if (S.ui === 'talk') { if (S.st === 'hud' && (k === 'Enter' || /^[1-4]$/.test(k))) { p13Go(S.sp); if (k !== 'Enter' && S.step && S.step.ask && S.step.ask.cards[+k - 1]) tvAnswer({ text: '', pick: +k - 1 }); }   /*P13：Enter＝じゅんばんの 人*/
      else if (S.st === 'ask' && /^[1-4]$/.test(k) && S.step && S.step.ask && S.step.ask.cards[+k - 1]) tvAnswer({ text: '', pick: +k - 1 });
      else if (S.st === 'check' && (k === 'y' || k === 'n')) tvConfirm(k === 'y');
      else if (k === 'Escape') { if (S.stopArm && performance.now() - S.stopArm < 3000) tvStop(); else { S.stopArm = performance.now(); C.toast && C.toast(Lx('もういちど Esc で おしゃべりを おわる', '再按一次 Esc 结束聊天'), '#ffd0e0'); } } }
    stop();
  }
  function tvPack() {
    const G = C.G(), o = { on: S.on, fr: TV29_ORDER.filter(friend).length }, sh = shelfId(); if (sh) o.sh = [sh, TD().chars[sh].persona.name[0], TD().chars[sh].persona.name[1]];
    if (!S.on) return o; const bl = brainLabel(); o.ui = S.ui; o.brain = bl[2]; o.bl = [bl[0], bl[1]];
    if (S.ui === 'list') o.list = TV29_ORDER.map(k => { const s = story(S.store, k), t = nextTopic(S.store, k), tp = t >= 0 ? TD().chars[k].topics[t].title : null, nk = nickOf(S.store, k);
      return [k, s.lv, friend(k) ? 1 : 0, tp ? tp[0] : '', tp ? tp[1] : '', s.charm, nk ? nk[0] : '', nk ? nk[1] : '', TD().chars[k].persona.name[0], TD().chars[k].persona.name[1]]; });
    if (S.ui === 'list' && xOn()) { const b30 = {}; for (const k of TV29_ORDER) { const bs = p13Badges(k); if (bs.length) b30[k] = bs.map(b => [b.ic, b.ja, b.zh, b.op]); } if (Object.keys(b30).length) o.b30 = b30; }   /*P13*/
    if (S.ui === 'topics') { o.boss = S.boss; o.tps = TD().chars[S.boss].topics.map((t, i) => [t.title[0], t.title[1], story(S.store, S.boss).done[i]]); }
    if (S.ui === 'talk' || S.ui === 'reward') { o.boss = S.boss; o.nm = TD().chars[S.boss].persona.name; o.lv = story(S.store, S.boss).lv; o.tp = S.ti; o.tt = TD().chars[S.boss].topics[S.ti].title; if (S.run) { o.run = 1; if (S.run.title) o.tt = S.run.title; } }
    if (S.ui === 'talk') { const a = S.step && S.step.ask; o.i = S.i; o.st = S.st; o.sp = G.pl[S.sp] ? G.pl[S.sp].slot : -1; o.spn = G.pl[S.sp] ? G.pl[S.sp].name : '';
      if (a) { o.bt = a.n | 0; o.of = a.of | 0; o.q = [a.q.ja, a.q.zh]; o.cards = a.cards.map(c => [c.ic, c.ja, c.zh]); if (a.cards.some(c => c.glow)) o.gl = a.cards.map((c, i) => (c.glow ? i : -1)).filter(i => i >= 0); o.kw = a.cards.map(c => c.kw || {}); o.open = a.type === 'open' ? 1 : 0; o.big = a.big | 0; o.chk = a.check ? [a.check.ic, a.check.ja, a.check.zh] : 0; }
      if (S.hd) o.hd = S.hd; if (S.rec && G.pl[S.rec]) o.rec = G.pl[S.rec].slot; }
    if (S.ui === 'reward' && S.rw) o.rw = S.rw;
    return o;
  }
  /* ---------- 声（§9.3）：録った 声 → VOICEVOX（/tts）→ 字だけ（ピポ） ---------- */
  const REC_KEYS = { hi: 'hi', think: 'think', huh: 'huh', dunno: 'dunno', bad: 'bad', stop: 'stop', check: 'check', byeWarm: 'byeWarm', bye: 'bye', help: 'help' };
  const voFor = (boss, l) => { const v30 = l.who === boss ? p13Vo(boss, l) : ''; if (v30) return v30;   /*P13：t30_*（録った v0.30 の 声）*/
    return l.fx && REC_KEYS[l.fx[0]] && (l.who === boss) ? 'chat_' + boss + '_' + l.fx[0].toLowerCase() + '_' + (Math.max(0, l.fx[1]) + 1) : ''; };
  function decode(ab) { const AC = C.AC(); return new Promise((res, rej) => { try { const p = AC.decodeAudioData(ab, res, rej); if (p && p.then) p.then(res, rej); } catch (e) { rej(e); } }); }
  async function loadVo(id) { const A = S.audio; if (A.cache.has(id)) return A.cache.get(id); const pr = fetch('/voice/' + id + '.ogg').then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.arrayBuffer(); }).then(decode).catch(() => null); A.cache.set(id, pr); return pr; }
  async function loadTts(who, text, keep) { const A = S.audio, key = 'tts|' + who + '|' + text; if (keep && A.cache.has(key)) return A.cache.get(key);
    const pr = fetch('/tts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ boss: S.boss || who, who, text, keep: !!keep }), cache: 'no-store' })
      .then(r => { if (!r.ok || !/audio/.test(r.headers.get('content-type') || '')) throw new Error('tts ' + r.status); return r.arrayBuffer(); }).then(decode).catch(() => null);
    if (keep) A.cache.set(key, pr); return pr; }
  const voiceOn = () => !!(C.voOn && C.voOn() && C.AC() && C.AC().state === 'running');
  const sentences = s => (String(s).match(/[^。！？]+[。！？]*/g) || [String(s)]).map(x => x.trim()).filter(Boolean);
  function audioStop() { const A = S.audio; A.gen++; A.q = []; if (A.cur) { try { A.cur.onended = null; A.cur.stop(); } catch (e) { /* もう 止まっている */ } } A.cur = null; A.busy = false; if (A.done) { const d = A.done; A.done = null; d(); } }
  function audioIdle(tok) { return new Promise(res => { const t0 = performance.now(), chk = () => { if (!S.audio.busy || tok !== S.tok || performance.now() - t0 > 20000) res(); else setTimeout(chk, 60); }; chk(); }); }
  // lines を じゅんに 言う。おわったら done（声が ない 時は すぐ）。字は さきに 出ている
  function audioSay(lines, tok, done) {
    audioStop(); const A = S.audio, gen = A.gen; A.busy = true; A.done = null;
    const boss = S.boss, play = async () => {
      for (let i = 0; i < lines.length; i++) { if (gen !== A.gen) return; S.li = i; S.sig = ''; const l = lines[i];
        let bufs = []; if (voiceOn()) { const vo = voFor(boss, l); let b = vo ? await loadVo(vo) : null; if (b) bufs = [Promise.resolve(b)];
          else if (ttsReady() && l.who !== 'narr' && l.spk !== '') bufs = sentences(l.spk || l.ja).map(s => loadTts(l.who || boss, s, l.src === 'fixed')); }
        if (!bufs.length) { if (C.tone && voiceOn()) C.tone(880, 1320, .06, 'sine', .08); await wait(gen, l.think ? 200 : 350); l.done = 1; continue; }
        for (const bp of bufs) { const b = await bp; if (gen !== A.gen) return; if (!b) continue; await playBuf(b, gen); }
        l.done = 1; }
      if (gen !== A.gen) return; A.busy = false; S.li = lines.length; S.sig = ''; if (done) done(); };
    play().catch(e => { console.warn('P12：声を 出せませんでした', e); A.busy = false; if (done && gen === A.gen) done(); });
  }
  function wait(gen, ms) { return new Promise(res => setTimeout(res, ms)); }
  function playBuf(b, gen) { return new Promise(res => { const AC = C.AC(), A = S.audio; try { const src = AC.createBufferSource(); src.buffer = b; src.connect(C.voiceOut()); A.cur = src;
      const t = setTimeout(() => { if (A.cur === src) A.cur = null; res(); }, (b.duration + 1.5) * 1000);   // 止まらない 時の みはり
      src.onended = () => { clearTimeout(t); if (A.cur === src) A.cur = null; res(); }; src.start(); C.duck && C.duck(true); } catch (e) { res(); } void gen; }); }
  /* ---------- 毎コマ ---------- */
  function tvAfter(dt, now) {
    const G = C.G(), d = document.getElementById('tv29Chat');
    if (S.on && ((G.ph !== 'lobby' && !(S.run && G.ph === 'over')) || C.SC().on)) tvClose();
    if (S.on && S.ui === 'talk') {
      const ps = C.players(); if (!ps.length) { tvGone(); return; }
      if (S.hsp && S.st === 'ask' && !G.pl[S.sp]) p13Back(now);   /*P13：こたえる 人が いなくなった → そうだん*/
      if (!G.pl[S.sp]) { S.order = ps.map(p => p.id); S.oi = S.oi % S.order.length; S.sp = S.order[S.oi]; S.sig = ''; }
      if (S.audio.busy || S.rec) { C.duck && C.duck(true); if (C.P4V) C.P4V.idleAt = performance.now(); }
    }
    p13Tick(now);   /*P13*/
    if (S.on && now - S.polled > 3000) tvPoll();
    if (d) { d.classList.toggle('hide', !S.on); if (S.on) tvRender(d, now); }
    const sb = document.getElementById('tv29Shelf'); if (sb) { const show = !!shelfId();
      sb.classList.toggle('hide', !show); if (show) { const t = Lx('💬 おしゃべり' + (window.TANK_KEY_HINTS ? '（C）' : ''), '💬 聊天' + (window.TANK_KEY_HINTS ? '（C）' : '')); if (sb.textContent !== t) sb.textContent = t; sb.style.right = '9vw'; sb.style.bottom = '17vh'; } }
    tvRows(); tvHelpTick();
  }
  function cardsHtml(a, off) { if (!a || !a.cards.length) return ''; return `<div class="cards ${off ? 'off' : ''} ${a.big ? 'xl' : ''}">` + a.cards.map((c, i) => `<button data-card="${i}"${c.glow ? ' class="glow"' : ''}><i>${esc(c.ic)}</i>${esc(c.ja)}${ZS(c.zh)}</button>`).join('') + (a.type === 'open' ? `<button disabled><i>💭</i>${Lx('ほかの こと', '别的')}</button>` : '') + '</div>'; }
  function tvRender(d, now) {
    const sig = [S.ui, S.st, S.li, S.i, S.hd, S.rec, S.sp, C.lang(), S.lines.length, S.mood, JSON.stringify(brainLabel()), S.cheers.length, p13Sig()].join('|'); if (S.cheers.length) S.cheers = S.cheers.filter(c => now - c.at < 2000);
    if (sig === S.sig) return; S.sig = sig; const G = C.G(), bl = brainLabel();
    if (S.ui === 'list') {
      d.innerHTML = `<div class="hd"><b>💬 ${Lx('ボスと おしゃべり', '和首领聊天')}</b><span class="sp"></span><span class="brain">${esc(Lx(bl[0], bl[1]))}</span></div><div class="grid">` + TV29_ORDER.map((k, i) => { const s = story(S.store, k), f = friend(k), t = nextTopic(S.store, k), D = TD(), nk = nickOf(S.store, k);
        const tp = t >= 0 ? D.chars[k].topics[t].title : null, w = (C.STY && C.STY.CAPTURE && C.STY.CAPTURE.by[k] ? C.STY.CAPTURE.by[k].world : i) + 1;
        const away = s.last && Date.now() - s.last > TV29_AWAY_DAYS * 864e5 ? Lx('・ひさしぶり！', '・好久不见！') : '';
        return `<button data-boss="${k}" class="${f ? '' : 'lock'}"><canvas data-pic="${k}" data-lock="${f ? 0 : 1}" width="160" height="160"></canvas><div><b>${i + 1} ${f ? esc(bossName(k)) : '？？？'}${nk ? ' 「' + esc(Lx(nk[0], nk[1])) + '」' : ''}</b>`
          + (f ? `<span class="h">${hearts(s.lv)}${s.lv >= 5 ? ' 💖' : ''}${s.charm ? ' 🎁' : ''}</span><small>${tp ? Lx('つぎ：', '下一个：') + esc(Lx(tp[0], tp[1])) : Lx('ぜんぶ はなした！ すきな はなしを えらべるよ', '全部聊过了！可以选喜欢的话题')}${away}</small>`
            : `<small>🔒 ${esc(C.STY && C.STY.lineText ? C.STY.lineText('cap.ui.lock', LANGx(), { n: w }) : Lx(`ワールド ${w} の さいごの ボスと なかよくなろう`, `和世界 ${w} 的最后首领交朋友吧`))}</small>`) + p13Badges(k).map(b => `<span class="b30" data-op30="${esc(b.op)}" data-boss="${k}">${esc(b.ic)} ${esc(Lx(b.ja, b.zh))}</span>`).join('') + '</div></button>'; }).join('')
        + `</div><div class="foot">${window.TANK_KEY_HINTS ? Lx('スマホで ボスを えらんでね（キー 1〜6）　・　Esc：もどる', '请在手机上选首领（按键 1〜6）　・　Esc：返回') : Lx('📱 スマホで ボスを えらんでね', '📱 请在手机上选首领')}</div>`;
      d.querySelectorAll('canvas[data-pic]').forEach(c => drawPic(c, c.dataset.pic, c.dataset.lock === '1')); return; }
    if (S.ui === 'topics') { const D = TD(); d.innerHTML = `<div class="hd"><b>💬 ${esc(bossName(S.boss))}</b><span class="sp"></span><span>${Lx('どの はなしに する？', '聊哪个话题？')}</span></div><div class="grid">`
      + D.chars[S.boss].topics.map((t, i) => `<button data-t="${i}"><div><b>${i + 1}　${esc(Lx(t.title[0], t.title[1]))}</b><span>${story(S.store, S.boss).done[i] ? '✅' : ''}</span></div></button>`).join('') + `</div><div class="foot">${Lx('もういちど はなすと、だいじな こたえを かえられるよ', '再聊一次可以改变重要的回答')}</div>`; return; }
    if (S.ui === 'reward' && S.rw) { const r = S.rw; d.innerHTML = `<div class="hd"><b>💬 ${esc(bossName(S.boss))}</b></div><div class="rw">`
      + (r.big ? `<div class="hl" style="font-size:6vh">${esc(Lx(r.big[0], r.big[1]))}</div>` : r.run ? '' : r.complete ? `<div class="hl">♥ ${Lx('なかよし', '友好度')} ${r.lv0} → ${r.lv1}${r.sp ? ' ✨' : ''}</div>` : `<p>${Lx('また こんど おはなし しようね', '下次再聊吧')}<small>${Lx('（さいごまで はなすと ♥ が ふえるよ）', '（聊到最后 ♥ 会增加）')}</small></p>`)
      + r.lines.map(l => `<p>${esc(Lx(l[0], l[1]))}</p>`).join('') + `<button data-k="ok" style="font-size:3.4vh;padding:1.4vh 4vw;border-radius:99px;border:.4vh solid #1b2a22;font-weight:900">✅ OK</button></div>`; return; }
    if (S.ui !== 'talk') return;
    const a = S.step && S.step.ask, s = story(S.store, S.boss), tt = TD().chars[S.boss].topics[S.ti].title, sp = G.pl[S.sp], nk = nickOf(S.store, S.boss);
    const ln = S.lines.map((l, i) => `<div class="ln ${l.q ? 'q' : ''} ${i === S.li && S.audio.busy ? 'now' : i < S.li || l.done ? 'done' : ''}">${l.who && l.who !== S.boss ? `<small>${esc(l.who === 'snowkid' ? Lx('ゆきんこ', '小雪人') : l.who)}</small>` : ''}<div class="ja">「${esc(l.ja)}」</div>${window.TANK_JA_ONLY ? '' : `<div class="zh">${esc(l.zh)}</div>`}</div>`).join('');
    const who = S.st === 'hud' ? Lx(`📱 スマホの 💬 で こたえる 人が きまるよ${window.TANK_KEY_HINTS ? `（Enter：${esc(sp ? sp.name : '')}）` : ''}`, `📱 按手机上的 💬 决定谁回答${window.TANK_KEY_HINTS ? `（Enter：${esc(sp ? sp.name : '')}）` : ''}`) : S.st === 'think' ? Lx(`…${bossName(S.boss, 'ja')} が かんがえちゅう`, `…${bossName(S.boss, 'zh')} 正在想`) : S.st === 'check' ? Lx('これで きめる？ ✅ うん ／ ↩ ちがう', '就这样定了吗？✅ 嗯 ／ ↩ 不是')
      : S.st === 'ask' && sp ? (a && a.big === 2 ? Lx(`👆 ${esc(sp.name)}、カードを タップしてね`, `👆 ${esc(sp.name)}，请点卡片`) : Lx(`🎤 ${esc(sp.name)} が こたえるよ`, `🎤 ${esc(sp.name)} 来回答`)) : Lx('👂 きいてね', '👂 请听');
    const cap = S.rec && G.pl[S.rec] ? `<div class="cap rec">🎤 ${Lx(`${esc(G.pl[S.rec].name)} が はなしています…`, `${esc(G.pl[S.rec].name)} 正在说…`)}</div>` : `<div class="cap">${S.hd ? '🎤 ' + Lx('きこえた ことば：', '听到的话：') + '『' + esc(S.hd) + '』' : ''}</div>`;
    const x30 = p13Extra(), h30 = p13Head(tt);   /*P13*/
    d.innerHTML = `<div class="hd">${h30 || `<b>💬 ${Lx(`${esc(bossName(S.boss))} と おしゃべり`, `和${esc(bossName(S.boss))}聊天`)}</b><span class="hearts">${hearts(s.lv)}</span><span>${Lx('はなし：', '话题：')}${esc(Lx(tt[0], tt[1]))}</span>`}<span class="sp"></span>`
      + `<span>${a && a.n ? `${a.n} / ${a.of}` : ''}</span><span class="brain">${esc(Lx(bl[0], bl[1]))}</span></div>`
      + `<div class="body"><div class="pt ${S.mood || p13Mood()}"><canvas data-pic="${S.boss}" width="240" height="240"></canvas><span class="bub">…</span>${x30 ? x30.note + x30.w : ''}${nk ? `<span class="nick">💖 ${esc(Lx(nk[0], nk[1]))}</span>` : ''}</div><div class="lines">${ln}</div></div>`
      + (S.st === 'check' && a && a.check ? `<div class="cards xl"><button data-yn="y"><i>✅</i>${Lx('うん', '嗯')}</button><button class="glow" disabled><i>${esc(a.check.ic)}</i>${esc(a.check.ja)}${ZS(a.check.zh)}</button><button data-yn="n"><i>↩</i>${Lx('ちがう', '不是')}</button></div>` : (S.run && S.run.board ? S.run.board() : '') + (S.st === 'hud' ? p13HudHtml() + cardsHtml(Object.assign({}, a, { big: 1 }), false) : cardsHtml(a, S.st !== 'ask')))
      + `<div class="who">${who}</div>${cap}` + S.cheers.map(c => `<span class="cheer" style="left:${c.x}%;bottom:10%">${c.e}</span>`).join('') + (x30 ? x30.pops : '');
    d.querySelectorAll('canvas[data-pic]').forEach(c => drawPic(c, c.dataset.pic, false));
  }
  function drawPic(c, k, lock) { const x = c.getContext('2d'); x.clearRect(0, 0, c.width, c.height);
    if (C.monPic) { const p = C.monPic(k, c.width, !lock); x.drawImage(p, 0, 0, c.width, c.height); if ((S.picT | 0) < 3) { S.picT = (S.picT | 0) + 1; setTimeout(() => { S.sig = ''; }, 800); } } }
  /* ---------- テレビの「🎤 こえの じゅんび」に 2 行（🧠 AI・🗣 ボスの こえ）。PART 1 の 画面は かえずに 足す ---------- */
  function tvRows() {
    const set = document.getElementById('tv28Set'); if (!set) return; const cols = set.querySelector('.st') || set; let box = document.getElementById('tv29Rows');
    const st = S.status, cfg = S.store.cfg.brain, L1 = st && st.llm, T1 = st && st.tts;
    const ai = !st ? `✗ ${Lx('AI が未導入です（決まった返事で会話できます）', '没有 AI 组件（可以用固定回答聊天）')}` : !st.on || !L1 ? `✗ ${Lx('AI はオフです', 'AI 关闭')}`
      : L1.state === 'ready' ? `✓ ${Lx('準備完了', '准备好了')}・${esc(L1.model || '')}${L1.tps ? '・' + L1.tps + ' tok/s' : ''}`
      : L1.state === 'pulling' ? `⏳ ${Lx('ダウンロード中', '下载中')} ${L1.total ? Math.floor(100 * (L1.done || 0) / L1.total) : 0}%（${((L1.done || 0) / 1e9).toFixed(1)} / ${((L1.total || 0) / 1e9).toFixed(1)} GB）`
      : L1.state === 'noapp' ? `✗ ${Lx('Ollama がありません', '没有 Ollama')}` : L1.state === 'nomodel' ? `✗ ${Lx('AI のデータがありません', '没有 AI 数据')}` : `⏳ ${esc(L1.state)}${L1.err ? '：' + esc(L1.err) : ''}`;
    const tv = !st || !T1 ? `✗ ${Lx('なし（録音済みの声と文字で進みます）', '无（录好的声音和文字）')}` : T1.state === 'ready' ? `✓ ${Lx('準備完了', 'OK')}${T1.version ? '・' + esc(T1.version) : ''}${T1.missing && T1.missing.length ? '・' + Lx('不足：', '缺少：') + esc(T1.missing.join('・')) : ''}` : `✗ ${esc(T1.state)}`;
    const html = `<p><b>🧠 AI：</b>${ai}</p><p><button id="tv29Pull">⬇ ${Lx('ダウンロード', '下载')}</button><button id="tv29Big">🧠 ${Lx('高性能なモデル（9 GB）', '更聪明的模型（9 GB）')}</button><button id="tv29Wr" class="${cfg === 'written' ? 'on' : ''}">📖 ${Lx('決まった返事だけ使う', '只用固定回答')}：${cfg === 'written' ? 'ON' : 'OFF'}</button></p>`
      + `<p><b>🗣 ${Lx('ボスの声', '首领的声音')}：</b>${tv}</p><p><button id="tv29Test">🔊 ${Lx('テスト', '测试')}</button><button id="tv29Tts">▶ ${Lx('音声合成を起動', '启动声音')}</button></p>`;
    if (box && box.parentNode === cols && box.dataset.h === html) return;
    if (!box || box.parentNode !== cols) { box = document.createElement('div'); box.id = 'tv29Rows'; cols.appendChild(box); }
    box.dataset.h = html; box.innerHTML = html;
    const post = body => fetch('/brain/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then(() => tvPoll()).catch(e => console.warn('P12：設定を 送れませんでした', e));
    const on = (id, f) => { const b = document.getElementById(id); if (b) b.onclick = f; };
    on('tv29Pull', () => post({ pull: true })); on('tv29Big', () => post({ model: 'qwen3:14b' })); on('tv29Tts', () => post({ startTts: true }));
    on('tv29Wr', () => { S.store.cfg.brain = cfg === 'written' ? 'auto' : 'written'; tvSave(); box.dataset.h = ''; tvRows(); });
    on('tv29Test', () => { if (C.audioOn) C.audioOn(); const D = TD(); S.boss = ''; audioSay(TV29_ORDER.map(k => Object.assign({ who: k, src: 'fixed' }, D.chars[k].fixed.hi[0])), S.tok, null); });
    if (!S.on && performance.now() - S.polled > 3000) tvPoll();
  }
  /* ---------- 物語の 効果（テレビ）：面の はじめ（おまもり）・さいごの たたかいの おてつだい ---------- */
  function onStage(o) {
    S.helpers = []; S.helped = []; const G = C.G(); if (!o || o.mode !== 'adv' || !o.stage) return;
    if (!o.list) { const cs = charmsFor(S.store, o.stage); for (const c of cs) { if (c.k === 'futon') G.futon = Math.min(o.maxFuton, G.futon + c.n); else for (const id in G.pl) G.pl[id].firstShield = (G.pl[id].firstShield || 0) + c.n;
      useCharm(S.store, c.boss); C.toast && C.toast(Lx(`${bossName(c.boss, 'ja')}の おまもり：`, `${bossName(c.boss, 'zh')}的护身符：`) + (c.k === 'futon' ? Lx('🏠 おうちの まもり +1', '🏠 小屋防护 +1') : Lx('🛡 はじめの たて +3 びょう', '🛡 开场护盾 +3 秒')), '#ffd0e0'); }
      if (cs.length) tvSave(); }
    S.helpers = p13Helpers(helpersFor(S.store, o.stage, o.lap), o.stage, o.lap);
  }
  function tvHelpTick() {
    const G = C.G(); if (!S.helpers.length || G.ph !== 'play' || G.paused || G.talk) return;
    for (const h of S.helpers) { if (S.helped.includes(h.boss) || G.t < h.at || G.cameo) continue; S.helped.push(h.boss); applyHelp(h); break; }
    for (const h of S.helpers) if (S.helped.includes(h.boss) && G.cameo && G.cameo.tv29 === h.boss && !G.cameo.leave && G.cameo.t > 4) G.cameo.leave = 1.2;
  }
  function applyHelp(h) {
    const G = C.G(), D = TD(), bx = Math.max(4, Math.min(G.cols - 4, Math.round(G.cols / 2)));
    G.cameo = { kind: h.boss, x: bx, y: Math.max(6, G.hy - 6.5), t: 0, role: 'help', leave: 0, tv29: h.boss };
    G.ev.push({ k: 'reunion', role: 'help', kind: h.boss, x: bx, y: G.cameo.y });
    if (h.k === 'futon') { G.futon = Math.min(C.S.CFG.maxFuton, G.futon + (h.n || 1)); G.texts.push({ x: G.hx, y: G.hy - 2.2, s: 'おうちの守り +' + (h.n || 1), zh: '小屋防护 +' + (h.n || 1), t: 2, col: '#cfeeff', big: 2 }); }
    else if (h.k === 'freeze') { G.stopT = Math.max(G.stopT, h.fz || TV29_FREEZE); G.texts.push({ x: G.cols / 2, y: 6, s: 'てきが こおった！', zh: '敌人被冻住了！', t: 2, col: '#bfe6ff', big: 2 }); }
    else for (const t of G.tanks) if (t.side === 'p' && t.alive) { t.shield = Math.max(0, t.shield || 0) + (h.sec || TV29_HELP_SHIELD); G.texts.push({ x: t.x, y: t.y - 1.6, s: 'たて！', zh: '护盾！', t: 1.6, col: '#9fe8ff' }); }
    G.ev.push({ k: 'reunion_gift', gift: h.k, kind: h.boss, name: D.chars[h.boss].persona.name });
    const n = { futon: 1, shield: 2, freeze: 3 }[h.k], line = h.line || D.chars[h.boss].fixed.help[n];
    C.toast && C.toast(Lx(`${bossName(h.boss, 'ja')}：${line.ja}`, `${bossName(h.boss, 'zh')}：${line.zh}`), '#ffd0e0', 'sh');
    if (C.audioOn) { const keep = S.boss; S.boss = h.boss; audioSay([{ who: h.boss, ja: line.ja, zh: line.zh, src: 'fixed', fx: h.line ? ['helpPr', -1] : ['help', n - 1] }], S.tok, null); S.boss = keep; }
    api.lastHelp = h;
  }
  // エンディング：ともだちの ページ（p3d の 場面の slide）
  function endingSteps() {
    const D = TD(), pages = p13Pages(endingPages(S.store, D)), T2 = ['💬 ともだちの ページ', '💬 朋友的一页'];
    return pages.map(p => ({ t: 'slide', art: p.art || 'tv29', tv29: p, who: p.who === 'narr' ? 'narr' : p.who, ja: p.ja, zh: p.zh, title: p.title || T2,
      enter: () => { if (p.kind === 'true' && C.P3) { const P3 = C.P3(); P3.ends.heart = 1; if (C.p3dSave) C.p3dSave(); }
        if (!voiceOn()) return; const keep = S.boss; S.boss = p.who === 'narr' ? '' : p.who; audioSay([{ who: p.who, ja: p.ja.replace(/　/g, '。'), zh: p.zh, src: 'fixed' }].map(l => Object.assign(l, { who: l.who === 'narr' ? 'narr' : l.who })), S.tok, null); S.boss = keep; } }));
  }
  function drawSlideArt(x, st, r, now) {
    const p = st.tv29; if (!p) return; if (X().drawPage) { try { if (X().drawPage(x, st, r, now)) return; } catch (e) { console.warn('P13：ページを 描けませんでした', e); } }   /*P13*/
    const [px, py, pw, ph] = r, cx = px + pw / 2; x.save(); x.beginPath(); x.rect(px, py, pw, ph); x.clip();
    const ks = p.kind === 'friend' ? [p.who] : TV29_ORDER.filter(k => p.kind === 'true' || story(S.store, k).f.promise === p.promise);
    ks.forEach((k, i) => { const n = ks.length, bx = n === 1 ? cx : px + pw * (.12 + .76 * i / Math.max(1, n - 1)), by = py + ph * (n === 1 ? .6 : .62) + Math.sin(now / 300 + i) * ph * .012; if (C.bossPic) C.bossPic(x, k, 3 + (i % 3), bx, by, ph * (n === 1 ? .42 : .2)); });
    x.font = `${ph * .09}px "Dela Gothic One",sans-serif`; x.textAlign = 'center'; x.textBaseline = 'middle'; x.lineJoin = 'round'; x.lineWidth = ph * .02; x.strokeStyle = '#1b2a22'; x.fillStyle = '#ff6a8a';
    const head = p.kind === 'friend' ? bossName(p.who) + (p.nick ? '「' + Lx(p.nick[0], p.nick[1]) + '」' : '') + '　' + hearts(p.lv) : Lx(st.title[0], st.title[1]);
    x.strokeText(head, cx, py + ph * .14, pw * .9); x.fillText(head, cx, py + ph * .14, pw * .9);
    x.restore();
  }
  // クレジット（こえと AI）の 1 ページ
  function creditStep() { return { t: 'credits', tv29: 1, names: [], page: 0, who: 'narr', ja: '', zh: '', title: ['📜 クレジット（音声認識・AI・音声）', '📜 制作名单（识别・AI・声音）'] }; }
  function drawCredits(x, st, r) {
    const [cx0, cy0, cw, ch] = r; x.save(); x.textAlign = 'left'; x.textBaseline = 'middle'; let y = cy0 + ch * .07; const fs = Math.min(ch * .036, cw * .022), model = S.status && S.status.llm && S.status.llm.model;
    for (const [hj, hz, list] of api.CREDITS) { x.font = `900 ${fs * 1.25}px "M PLUS Rounded 1c",sans-serif`; x.fillStyle = '#6a4a00'; x.fillText(Lx(hj, hz), cx0 + cw * .06, y); y += fs * 1.7;
      x.font = `900 ${fs}px "M PLUS Rounded 1c",sans-serif`; x.fillStyle = '#1b2a22'; const cols = list.length > 4 ? 2 : 1, rows = Math.ceil(list.length / cols);
      list.forEach((n, i) => x.fillText(n, cx0 + cw * (.09 + (i >= rows ? .45 : 0)), y + (i % rows) * fs * 1.45, cw * .42 * (cols === 1 ? 2 : 1))); y += rows * fs * 1.45 + fs * .9; }
    x.font = `900 ${fs * .9}px "M PLUS Rounded 1c",sans-serif`; x.fillStyle = '#5a665f';
    x.fillText(Lx('AI と音声はこの Mac の中だけで動きます。子どもの言葉は外部に送信しません。', 'AI 和声音只在这台 Mac 里运行。孩子的话不会发到网上') + (model ? '　（' + model + '）' : ''), cx0 + cw * .06, cy0 + ch * .95, cw * .9);
    x.restore();
  }
  // かざりだな：♥・💖・あだな・🎀（ボスちょうせんの 一覧と レベルの 画面に 重ねて 描く）
  // かざりだな：♥（💖）・🎀（かざりの おくりもの）・⭐（すきな もの）・あだな。list＝ボスの 一覧の カード、pick＝レベルの 画面（右上）。open＝その カードが ひらいて いるか
  function drawShelf(x, hits, ids, mode, open) {
    if (!Array.isArray(hits)) return; x.save(); x.textBaseline = 'middle'; x.lineJoin = 'round';
    const txt = (t, px, py, sz, col, al, mw) => { x.font = `900 ${sz}px "M PLUS Rounded 1c",sans-serif`; x.textAlign = al; x.lineWidth = sz * .22; x.strokeStyle = 'rgba(255,246,220,.95)'; x.strokeText(t, px, py, mw); x.fillStyle = col; x.fillText(t, px, py, mw); };
    for (const h of hits) { if (mode === 'pick' ? !h.go : h.i === undefined) continue; const id = mode === 'pick' ? ids : ids[h.i];
      if (!TV29_ORDER.includes(id) || !friend(id) || (open && !open(id))) continue; const s = story(S.store, id), e30 = p13Shelf(id); if (!s.lv && !s.f.gift && !e30) continue;   /*P13：🤝*/
      const nk = nickOf(S.store, id), hs = (s.lv >= 5 ? '💖' : '') + '♥'.repeat(s.lv); let extra = ''; if (s.f.gift === 3) extra += '🎀'; if (s.f.fav) extra += '⭐'; extra += e30;
      if (mode === 'pick') { const sz = h.h * .04, tx = h.x + h.w * .975, ty = h.y + h.h * .43;
        if (hs) txt(hs, tx, ty, sz, '#e0466a', 'right', h.w * .4); if (extra) txt(extra, tx, ty + sz * 1.3, sz, '#e0466a', 'right'); if (nk) txt('「' + Lx(nk[0], nk[1]) + '」', tx, ty + sz * 2.6, sz * .9, '#1b2a22', 'right', h.w * .4); }
      else { const sz = h.w * .085, cx = h.x + h.w / 2;
        if (hs) txt(hs, cx, h.y + h.h * .125, sz, '#e0466a', 'center', h.w * .9); if (extra) txt(extra, h.x + h.w * .95, h.y + h.h * .2, sz, '#e0466a', 'right');
        if (nk) txt('「' + Lx(nk[0], nk[1]) + '」', cx, h.y + h.h * .74, sz * .95, '#1b2a22', 'center', h.w * .9); } }
    x.restore();
  }
  const drawMatesHearts = (x, r) => { const [bx, by, bw, bh] = r, n = heartTotal(S.store); if (!n) return; x.save(); x.font = `900 ${bh * .34}px "M PLUS Rounded 1c",sans-serif`; x.textAlign = 'right'; x.textBaseline = 'middle'; x.fillStyle = '#ff8aa8'; x.lineWidth = bh * .08; x.strokeStyle = 'rgba(27,42,34,.85)'; x.lineJoin = 'round'; const t = '💬 ♥ ' + n + ' / 30'; x.strokeText(t, bx + bw * .9, by - bh * .3); x.fillText(t, bx + bw * .9, by - bh * .3); x.restore(); };

  /* ==================== スマホ ==================== */
  const PS = { picT: 0, i: -1, st: '', state: 'idle', rec: null, tok: 0, heard: '', text: '', kana: '', m: -1, sc: 0, small: false, sig: '', arm: 0, navSig: '' };
  const sendTv = d => { C.room.emit('cmd', Object.assign({ a: 'tv29', i: PS.i }, d)).catch(e => console.warn('P12：おしゃべりの 操作を 送れませんでした', e)); C.vibrate && C.vibrate(15); };
  function padInit() {
    const d = document.createElement('div'); d.id = 'tv29Pad'; d.className = 'hide'; document.body.appendChild(d); d.addEventListener('click', padClick);
    document.addEventListener('visibilitychange', () => { if (document.hidden) padEnd(); });
    C.hookPad(padRender); if (C.hookNav) C.hookNav(padNav);
  }
  function padView() { const ps = C.room.peers(), host = ps.find(p => p.presence && p.presence.role === 'tv'), self = ps.find(p => p.isMe), g = host && host.presence.g ? host.presence.g : null, mine = g && self && g.pl ? g.pl[self.peer] : null;
    return { g, self, mine, t: g && g.tv29 && typeof g.tv29 === 'object' ? g.tv29 : null, v28: g && g.tv28 }; }
  function padNav(S2, mine) { const box = document.getElementById('navBox'); if (!box) return; const t = S2 && S2.tv29, sh = t && t.sh, show = !!(t && !t.on && t.fr > 0 && mine && S2.ph === 'lobby' && (S2.view === 'lobby' || sh) && C.me && C.me.joined);
    const sig = show + C.lang() + (sh ? sh[0] : ''); if (box.dataset.tv29 === sig && (!show || box.querySelector('button.tv29'))) return; box.dataset.tv29 = sig; box.querySelectorAll('button.tv29').forEach(b => b.remove());
    if (show) { const b = document.createElement('button'); b.className = 'tv29'; b.innerHTML = '💬 ' + (sh ? Lx(`${sh[1]} と おしゃべり`, `和${sh[2]}聊天`) : Lx('ボスと おしゃべり', '和首领聊天')); b.onclick = () => { PS.i = -1; sendTv(sh ? { op: 'open', boss: sh[0] } : { op: 'open' }); }; box.appendChild(b); box.classList.remove('hide'); } }
  function padEnd() { PS.tok++; if (PS.rec) { if (PS.rec.rec) { PS.rec.stop(); sendTv({ op: 'rec', on: 0 }); } PS.rec.close(); PS.rec = null; } PS.state = 'idle'; PS.heard = ''; PS.m = -1; PS.small = false; PS.arm = 0; }
  const micOk = v => !!(window.TankTalkVoice && window.TankTalkVoice.Recorder && window.TankTalkVoice.Recorder.can() && window.isSecureContext && v.v28 && v.v28.on === 1);
  function padCards(t) { return (t.cards || []).map((c, i) => ({ id: 'abcd'[i], ic: c[0], ja: c[1], zh: c[2], kw: (t.kw && t.kw[i]) || {} })); }
  async function padMic() {
    const v = padView(), t = v.t, V = window.TankTalkVoice; if (!t || !V) return;
    if (PS.state === 'rec') { if (PS.rec && PS.rec.rec) padGot(PS.rec.stop()); return; }
    if (PS.state === 'up') return; const tok = ++PS.tok, i = PS.i; PS.heard = ''; PS.m = -1;
    try { if (!PS.rec) PS.rec = new V.Recorder({ onAuto: (why, r) => padGot(r) }); await PS.rec.open(); } catch (e) { console.warn('P12：マイクが つかえません', e); if (tok === PS.tok) { PS.state = 'denied'; PS.sig = ''; } return; }
    if (tok !== PS.tok || i !== PS.i) return; PS.rec.start(); PS.state = 'rec'; PS.sig = ''; sendTv({ op: 'rec', on: 1 });
  }
  async function padGot(r) {
    const V = window.TankTalkVoice, tok = ++PS.tok, i = PS.i, t0 = performance.now(); PS.state = 'up'; PS.sig = ''; sendTv({ op: 'rec', on: 0 });
    let w = null; try { w = await V.toWav(r); } catch (e) { w = null; } if (tok !== PS.tok || i !== PS.i) return;
    if (!w || w.quiet) { PS.state = w && w.quiet ? 'quiet' : 'err'; PS.small = true; PS.sig = ''; return; }
    const t = padView().t, cards = padCards(t), lang = LANGx(), res = await V.upload(w.blob, lang, cards.map(c => c[lang]).join('、'), V.CONST.TV28_BUDGET_MS - (performance.now() - t0));
    if (tok !== PS.tok || i !== PS.i) return; if (!res.ok) { PS.state = res.err === 'timeout' ? 'timeout' : 'err'; PS.small = true; PS.sig = ''; return; }
    PS.text = res.text; PS.kana = res.kana; PS.heard = TE.maskNG(res.text, res.kana, lang, TD());
    if (t.st === 'check') { const yn = TE.yesNo(res.text, res.kana, lang, TD()); PS.m = yn === 'yes' ? 0 : yn === 'no' ? 1 : -1; }
    else { const m = TE.match(res.text, res.kana, cards, lang); PS.m = m.m; PS.sc = m.score; }
    PS.state = 'heard'; PS.sig = ''; sendTv({ op: 'heard', text: res.text, kana: res.kana, l: lang }); C.vibrate && C.vibrate([20, 40, 20]);
  }
  function padClick(ev) {
    const b = ev.target.closest('button'); if (!b || b.disabled) return; const v = padView(), t = v.t; if (!t) return; const k = b.dataset.k;
    if (padClick30(k, b, t)) return;   /*P13*/
    if (k === 'boss') { PS.i = -1; sendTv({ op: 'pick', boss: b.dataset.v }); }
    else if (k === 'topic') sendTv({ op: 'topic', t: +b.dataset.v });
    else if (k === 'back') sendTv({ op: 'back' }); else if (k === 'ok') sendTv({ op: 'ok' });
    else if (k === 'cheer') sendTv({ op: 'cheer', e: b.dataset.v });
    else if (k === 'card') { padEnd(); sendTv({ op: 'say', text: '', kana: '', pick: +b.dataset.v, l: LANGx() }); PS.state = 'sent'; PS.sig = ''; }
    else if (k === 'mic' || k === 'again' || k === 'other') padMic();
    else if (k === 'send') { const m = PS.m, sc = PS.sc; sendTv({ op: 'say', text: PS.text, kana: PS.kana, pick: -1, m, sc, l: LANGx() }); padEnd(); PS.state = 'sent'; PS.sig = ''; }
    else if (k === 'self') { PS.state = 'idle'; PS.small = true; PS.heard = ''; PS.m = -1; PS.sig = ''; }
    else if (k === 'yes' || k === 'no') { padEnd(); sendTv({ op: k }); PS.state = 'sent'; PS.sig = ''; }
    else if (k === 'end') { if (PS.arm && performance.now() - PS.arm < 4000) { sendTv({ op: 'stop' }); PS.arm = 0; } else PS.arm = performance.now(); PS.sig = ''; }
  }
  function padRender() {
    const v = padView(), t = v.t, d = document.getElementById('tv29Pad'); if (!d) return;
    const on = !!(t && t.on && v.mine && C.me && C.me.joined); d.classList.toggle('hide', !on); if (!on) { if (PS.i !== -1) { padEnd(); PS.i = -1; } PS.sig = ''; return; }
    const slot = v.mine[0] | 0, me = t.ui === 'talk' && t.sp === slot;
    if (t.ui !== PS.ui) { PS.ui = t.ui; PS.picT = 0; }
    if (t.ui === 'talk' && t.i !== PS.i) { padEnd(); PS.i = t.i; }
    if (t.ui !== 'talk' && PS.i !== -1) { padEnd(); PS.i = -1; }
    if (PS.state === 'sent' && t.st !== 'ask' && t.st !== 'check') PS.state = 'idle';
    const mic = micOk(v);
    const sig = JSON.stringify([t.ui, t.st, t.i, t.sp, t.list, t.tps, t.rw, t.big, t.hd, me, PS.state, PS.heard, PS.m, PS.small, !!PS.arm, mic, C.lang(), t.bl, t.cards, t.b30, t.gl, t.run || t.ui === 'list' ? t30(v) : 0]); if (sig === PS.sig) return; PS.sig = sig;
    const H = [], nm = t.nm ? Lx(t.nm[0], t.nm[1]) : '';
    if (t.ui === 'list') { H.push(`<h2>💬 ${Lx('だれと おしゃべり する？', '和谁聊天？')}</h2><div class="msg">${esc(Lx(t.bl[0], t.bl[1]))}</div><div class="list">`);
      for (const [k, lv, f, tj, tz, ch, nj, nz, bj, bz] of t.list || []) H.push(`<button data-k="boss" data-v="${k}" class="${f ? '' : 'lock'}"><canvas data-pic="${k}" data-lock="${f ? 0 : 1}" width="104" height="104"></canvas><div>${f ? esc(Lx(bj, bz)) : '？？？'}${nj ? '「' + esc(Lx(nj, nz)) + '」' : ''}<small class="h">${f ? hearts(lv) + (lv >= 5 ? ' 💖' : '') + (ch ? ' 🎁' : '') : '🔒'}</small><small>${f ? (tj ? esc(Lx(tj, tz)) : Lx('すきな はなしを えらぶ', '选喜欢的话题')) : ''}</small></div></button>`);
      H.push('</div>'); padBadges30(t, H, v); H.push(`<button class="btn" data-k="back">◀ ${Lx('もどる', '返回')}</button>`); }
    else if (t.ui === 'topics') { H.push(`<h2>💬 ${Lx('どの はなしに する？', '聊哪个话题？')}</h2><div class="cards">` + (t.tps || []).map((p, i) => `<button data-k="topic" data-v="${i}">${esc(Lx(p[0], p[1]))}${p[2] ? ' ✅' : ''}</button>`).join('') + `</div><button class="btn" data-k="back">◀ ${Lx('もどる', '返回')}</button>`); }
    else if (t.ui === 'reward' && t.rw) { const r = t.rw; H.push(`<h2>💬 ${esc(nm)}</h2>` + (r.big ? `<div class="big1" style="font-size:clamp(20px,8vh,40px)">${esc(Lx(r.big[0], r.big[1]))}</div>` : r.run ? '' : r.complete ? `<div class="big1">♥ ${r.lv0} → ${r.lv1}${r.sp ? ' ✨' : ''}</div>` : `<div class="msg">${Lx('また こんど おはなし しようね', '下次再聊吧')}</div>`)
      + r.lines.map(l => `<div class="msg">${esc(Lx(l[0], l[1]))}</div>`).join('') + `<button class="btn ok" data-k="ok">✅ OK</button>`); }
    else if (t.ui === 'talk') {
      const q = t.q ? `<div class="q">${esc(t.q[0])}<small>${esc(t.q[1])}</small></div>` : '', cards = padCards(t);
      H.push(`<h2>💬 ${esc(nm)}　${t.run ? '' : hearts(t.lv | 0)}　<small style="font-size:.6em">${t.bt ? t.bt + ' / ' + t.of : ''}</small></h2>` + padHead30(v, t));
      if (t.st === 'hud') padHud30(v, t, H, q, cards);   /*P13：そうだんタイム*/
      else if (!me) { H.push(`<div class="msg">📣 ${Lx('おうえん', '加油')}　—　${Lx(`${esc(t.spn || '')} が こたえるよ`, `${esc(t.spn || '')} 来回答`)}</div>${q}<div class="cards off">` + cards.map(c => `<button disabled><i>${esc(c.ic)}</i>${esc(c.ja)}${ZS(c.zh)}</button>`).join('') + `</div><div class="cheers">` + ['👏', '❤️', '😄', '⭐'].map(e => `<button data-k="cheer" data-v="${e}">${e}</button>`).join('') + '</div>'); }
      else if (t.st === 'say' || t.st === 'think' || PS.state === 'sent') { H.push(`<div class="msg">${t.st === 'think' || PS.state === 'sent' ? Lx(`…${esc(nm)} が かんがえちゅう`, `…${esc(nm)} 正在想`) : Lx('👂 きいてね', '👂 请听')}</div>${q}<div class="cards off">` + cards.map(c => `<button disabled><i>${esc(c.ic)}</i>${esc(c.ja)}${ZS(c.zh)}</button>`).join('') + '</div>'); }
      else if (t.st === 'check') { const c = t.chk || ['', '', ''];
        H.push(`<div class="q">${Lx('これで きめる？', '就这样定了吗？')}<small>${esc(c[0])} ${esc(c[1])}／${esc(c[2])}</small></div>`);
        if (PS.state === 'heard') H.push(`<div class="msg">${Lx('きこえた ことば：', '听到的话：')}『${esc(PS.heard)}』</div>`);
        H.push(`<div class="row"><div class="cards xl"><button data-k="yes" class="${PS.m === 0 ? 'glow' : ''}"><i>✅</i>${Lx('うん', '嗯')}</button><button data-k="no" class="${PS.m === 1 ? 'glow' : ''}"><i>↩</i>${Lx('ちがう', '不是')}</button></div>`
          + (mic ? `<button class="mic small ${PS.state === 'rec' ? 'rec' : ''}" data-k="mic"><i>${PS.state === 'rec' ? '⏹' : PS.state === 'up' ? '⏳' : '🎤'}</i>${PS.state === 'rec' ? Lx('おわり', '结束') : Lx('はなす', '说话')}</button>` : '') + '</div>'); }
      else { // ask
        const big = t.big | 0, tapOnly = big === 2 || !mic;
        if (PS.state === 'heard') { H.push(`<div class="msg">${Lx('きこえた ことば：', '听到的话：')}『${esc(PS.heard)}』</div>${q}`);
          H.push(`<div class="cards">` + cards.map((c, i) => `<button data-k="card" data-v="${i}" class="${PS.m === i ? 'glow' : ''}"><i>${esc(c.ic)}</i>${esc(c.ja)}${ZS(c.zh)}</button>`).join('') + '</div>');
          H.push(`<div class="acts"><button class="btn ok" data-k="send">✅ ${Lx('これで いい', '就这个')}</button><button class="btn" data-k="again">🎤 ${Lx('もういちど', '再说一次')}</button><button class="btn" data-k="self">👆 ${Lx('カードで えらぶ', '用卡片选')}</button></div>`); }
        else {
          const hint = PS.state === 'rec' ? Lx('● きいてるよ…（もういちど おすと おわり）', '● 在听…（再按一次结束）') : PS.state === 'up' ? Lx('…かんがえちゅう', '…正在想') : PS.state === 'quiet' ? Lx('こえが ちいさいよ。カードでも いいよ', '声音太小了，也可以点卡片')
            : PS.state === 'timeout' || PS.state === 'err' ? Lx('うまく きこえなかった。タップで えらんでね', '没听清，请点卡片') : PS.state === 'denied' ? Lx('マイクが つかえません。カードを タップしてね', '麦克风不能用，请点卡片')
            : tapOnly ? Lx('カードを タップしてね', '请点卡片') : (big || PS.small) ? Lx('カードを タップしてね（🎤 も つかえるよ）', '请点卡片（也可以用 🎤）') : Lx('カードを タップ するか、🎤 で こたえてね', '点卡片，或者按 🎤 回答');
          H.push(`<div class="msg">${hint}</div>${q}<div class="row"><div class="cards ${big ? 'xl' : ''}">` + cards.map((c, i) => `<button data-k="card" data-v="${i}"${t.gl && t.gl.includes(i) ? ' class="glow"' : ''}><i>${esc(c.ic)}</i>${esc(c.ja)}${ZS(c.zh)}</button>`).join('')
            + (t.open && mic && !tapOnly ? `<button class="other" data-k="other"><i>💭</i>${Lx('ほかの こと（🎤 で いってね）', '别的（按 🎤 说）')}</button>` : '') + '</div>'
            + (!tapOnly ? `<button class="mic ${big || PS.small ? 'small' : ''} ${PS.state === 'rec' ? 'rec' : ''}" data-k="mic"><i>${PS.state === 'rec' ? '⏹' : PS.state === 'up' ? '⏳' : '🎤'}</i>${PS.state === 'rec' ? Lx('おわり', '结束') : Lx('はなす', '说话')}</button>` : '') + '</div>'); } }
      if (me) H.push(`<button class="end ${PS.arm ? 'arm' : ''}" data-k="end">👋 ${PS.arm ? Lx('もういちど おすと おわる', '再按一次结束') : Lx('おわる', '结束')}</button>`);
    }
    if (/canvas/.test(H.join('')) && PS.picT < 3) { PS.picT++; setTimeout(() => { PS.sig = ''; }, 800); }   // 絵が あとから 読みこまれる
    d.innerHTML = H.join(''); d.querySelectorAll('canvas[data-pic]').forEach(c => { const x = c.getContext('2d'); if (C.monPic) x.drawImage(C.monPic(c.dataset.pic, c.width, c.dataset.lock !== '1'), 0, 0, c.width, c.height); });
  }

  /* P13 hooks（v0.30）：TankChat.run（ボスごとの とくべつな おしゃべり）と TankChat.ext（v0.30 の 部品が はめる 小さな フック）
     - ext が 空で run を よばなければ、ここは 何も しない（v0.29 と おなじ うごき）。設計 v030-design.md §2.2・§6
     - run(cfg)：{ boss, sheet, frame, title:[ja,zh], memory, greet, hud:()=>html, big:[ja,zh]|null, kind, huddle:boolean, wait:[{ja,zh}], onStep(step,ctx), onEnd(step,state)->{say,lines,big,next,then,mood} }
     - ext：{ greet(boss,store29), memory(boss), onTurn(step,ctx), huddle(ask,ctx), badges(boss), helpers(list,stage,lap), pages(pages), drawPage(x,st,r,now), wait(boss), pack() }
     - そうだんタイム（§6）：st 'hud' → だれかの スマホの 💬（cmd {a:'tv30', op:'go', i}）で その人が こたえる。じかんの きまりは ない */
  const X = () => api.ext || {}, xOn = () => !!S.run || Object.keys(X()).length > 0;
  const P13_WAIT_MS = 15000, P13_POP_MS = 2200;
  function css30() { if (document.getElementById('tv30Css')) return; const s = document.createElement('style'); s.id = 'tv30Css'; s.textContent = `
#tv29Chat .hd b.t30{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis}#tv29Chat .hd .h30{font-size:2.8vh;color:#ff8aa8;background:rgba(255,255,255,.08);padding:.3vh 1.2vw;border-radius:99px;white-space:nowrap}#tv29Chat .hd .h30 small{font-size:2vh;color:#fff6dc;margin-left:.6vw}
#tv29Chat .hud30{text-align:center;font-size:4vh;font-weight:900;color:#ffd23a;animation:none}#tv29Chat .hud30 small{display:block;font-size:2.6vh;color:#fff6dc;margin-top:.4vh}
#tv29Chat .pt.wait canvas{animation:tv30Sway 3.6s ease-in-out infinite}#tv29Chat .pt .note30{position:absolute;right:-1vh;top:-1vh;font-size:4vh;display:none}#tv29Chat .pt.wait .note30{display:block;animation:tv30Sway 3.6s ease-in-out infinite}
#tv29Chat .pt .wb30{position:absolute;left:50%;top:-7vh;transform:translateX(-50%);white-space:nowrap;background:#fff;color:#1b2a22;border-radius:2vh;padding:.6vh 1.4vh;font-weight:900;font-size:2.6vh;box-shadow:0 .4vh 0 #000}#tv29Chat .pt .wb30 small{display:block;font-size:1.8vh;opacity:.75}
#tv29Chat .pop30{position:absolute;font-weight:900;font-size:4.6vh;white-space:nowrap;animation:tv29Up 2.2s ease-out forwards;pointer-events:none;text-shadow:0 .3vh 0 #000}
#tv29Chat .board30{display:flex;flex-wrap:wrap;gap:.8vh 1vw;justify-content:center}#tv29Chat .board30 span{font-size:2.6vh;font-weight:900;color:#1b2a22;border-radius:99px;padding:.3vh 1.2vw;border:.3vh solid #1b2a22}
#tv29Chat.day30{background:radial-gradient(ellipse at 50% 30%,#5f8f6a,#24402c 75%);transition:background 1.2s}
#tv29Chat .grid button .b30{display:inline-block;margin-top:.6vh;background:#ff6a5f;color:#fff;border-radius:99px;padding:.2vh 1vw;font-size:2.2vh;font-weight:900}
@keyframes tv30Sway{0%,100%{transform:rotate(-4deg)}50%{transform:rotate(4deg)}}
#tv29Pad .go30{min-height:min(40vh,170px);border-radius:24px;border:5px solid #10201a;box-shadow:0 7px 0 #10201a;background:#ffd23a;color:#10201a;font:inherit;font-weight:900;font-size:clamp(24px,9vh,44px)}#tv29Pad .go30 small{display:block;font-size:.5em}
#tv29Pad .g30{text-align:center;color:#ff8aa8;font-weight:900;font-size:clamp(14px,4.4vh,20px)}#tv29Pad .board30{display:flex;flex-wrap:wrap;gap:6px;justify-content:center}#tv29Pad .board30 span{border-radius:99px;padding:2px 10px;color:#1b2a22;font-weight:900;font-size:13px;border:2px solid #10201a}
#tv29Pad .b30s{display:flex;gap:8px;flex-wrap:wrap}#tv29Pad .b30s button{flex:1 1 40%;min-height:44px;border-radius:14px;border:3px solid #10201a;background:#ffd0c8;color:#1b2a22;font:inherit;font-weight:900;font-size:15px}`;
    document.head.appendChild(s); }
  const PCOL30 = slot => (C && C.PCOL && C.PCOL[slot]) || ['#ff5a5a', '#4aa8ff', '#5ad06a', '#ffcf3a'][slot | 0] || '#ffd23a';
  // テレビ：run を はじめる（ロビーか 結果の 画面で、場面が ない 時だけ）
  function run(cfg) {
    const G = C && C.G(); if (!G || !cfg || !cfg.boss || !cfg.sheet) return false;
    if (!(G.ph === 'lobby' || G.ph === 'over') || C.SC().on || S.on || (C.busy && C.busy()) || document.getElementById('tv28Set')) return false;
    if (!C.players().length) return false;
    css30(); S.on = 1; S.picT = 0; S.sig = ''; S.rw = null; S.runNext = null; C.play && C.play('join'); tvPoll(); tvWarm(); runStart(cfg); return true;
  }
  function runStart(cfg) {
    const ps = C.players(), lang = LANGx();
    Object.assign(S, { run: cfg, boss: cfg.boss, ti: 0, ui: 'talk', order: ps.map(p => p.id), lastB: '', hd: '', rec: '', stopArm: 0, ended: null, hsp: '', hb: '', ans: '', waitShown: 0, waitOn: null, hudAt: 0 });
    S.oi = S.store.turn % Math.max(1, S.order.length); S.sp = S.order[S.oi];
    S.talk = S.eng.open({ who: cfg.boss, character: cfg.sheet, topic: 0, frame: cfg.frame, memory: (cfg.memory || []).slice(0, 6), lang, names: ps.map(p => p.name), greet: cfg.greet || null });
    const d = document.getElementById('tv29Chat'); if (d) d.classList.remove('day30');
    if (ttsReady() && voiceOn()) fetch('/tts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ who: cfg.boss, warm: true }) }).catch(() => {});
    const tok = ++S.tok; S.st = 'say'; S.sig = ''; S.talk.start().then(st => { if (tok === S.tok) tvStep(st); });
  }
  // tvStep の はじめ：run では 空の セリフ・おわりの あいさつを のぞく。そうだんタイムの 番を きめる（true＝じゅんばんを うごかさない）
  function p13Pre(st) {
    if (S.run) { st.say = st.say.filter(l => l && l.ja); if (st.done && st.why === 'done' && S.run.onEnd) st.say = st.say.filter(l => !(l.fx && (l.fx[0] === 'bye' || l.fx[0] === 'byeWarm'))); }
    if (S.hsp && (!st.ask || st.ask.b !== S.hb)) { S.sp = S.hsp; S.hsp = ''; S.ans = ''; }
    if (S.run && S.run.glow && st.ask && st.ask.cards) { let g = []; try { g = S.run.glow(st.ask) || []; } catch (e) { g = []; } for (const i of g) if (st.ask.cards[i]) st.ask.cards[i].glow = 1; }
    S.hudNext = !!(st.ask && hudWanted(st.ask)); return S.hudNext;
  }
  function hudWanted(a) {
    if (!a || a.check || a.reask || a.big || a.again || S.hb === a.b) return false;
    if (S.run) return !!a.huddle && S.run.huddle !== false;
    const f = X().huddle; if (!f) return false; try { return !!f(a, { boss: S.boss, kind: 'v29' }); } catch (e) { console.warn('P13：そうだんタイムを きめられませんでした', e); return false; }
  }
  const p13AskSt = st => (st.ask && st.ask.check ? 'check' : S.hudNext ? 'hud' : 'ask');
  // スマホの 💬：さいしょに とどいた 人が こたえる
  function p13Cmd(peer, d) {
    const G = C.G(); if (!G.pl[peer] || !S.on || S.ui !== 'talk') return;
    if (d.op === 'go' && S.st === 'hud' && d.i === S.i) p13Go(peer);
  }
  function p13Go(peer) { const a = S.step && S.step.ask; if (!a) return; S.hsp = S.sp; S.sp = peer; S.ans = peer; S.hb = a.b; S.st = 'ask'; S.sig = ''; C.tone && C.tone(660, 990, .1, 'triangle', .14); }
  // こたえた 後：ext.onTurn（v0.29 の おしゃべりでも）・run.onStep
  function p13Turn(st, spId) {
    if (!xOn()) return; const G = C.G(), p = G.pl[spId], ctx = { boss: S.boss, speaker: p ? { id: spId, name: p.name, slot: p.slot } : { id: spId, name: '', slot: -1 }, kind: S.run ? (S.run.kind || 'run') : 'v29', state: S.talk && S.talk.state };
    try { if (X().onTurn) X().onTurn(st, ctx); } catch (e) { console.warn('P13：onTurn で 失敗しました', e); }
    try { if (S.run && S.run.onStep) S.run.onStep(st, ctx); } catch (e) { console.warn('P13：onStep で 失敗しました', e); }
  }
  // run の おわり：onEnd → （say を 言う）→ then（つぎの 話）か ごほうび
  function runEnd(st) {
    const cfg = S.run, state = S.talk && S.talk.state; S.st = 'think'; S.sig = ''; const tok = S.tok;
    let pr; try { pr = cfg.onEnd ? cfg.onEnd(st, state) : null; } catch (e) { console.warn('P13：onEnd で 失敗しました', e); pr = null; }
    Promise.resolve(pr).catch(e => { console.warn('P13：onEnd で 失敗しました', e); return null; }).then(r => {
      if (tok !== S.tok || S.run !== cfg) return; r = r || {};
      const fin = () => { if (tok !== S.tok || S.run !== cfg) return; if (r.then) { runStart(r.then); return; }
        if (r.visit) { const b = cfg.boss, t = r.ti | 0; S.run = null; S.talk = null; S.ui = 'list'; S.sig = ''; tvStart(b, t, true); if (S.ui !== 'talk') tvClose(); return; }   /*P13：v0.29 の 話へ*/ if (r.skip) { S.rw = { run: 1 }; S.runNext = r.next || null; rwClose(); return; }
        S.rw = { run: 1, complete: false, big: r.big || cfg.big || null, lines: r.lines || [], why: st.why }; S.runNext = r.next || null; S.ui = 'reward'; S.st = 'reward'; S.talk = null; S.sig = ''; if (r.happy) C.play && C.play('powerup'); };
      if (r.mood === 'happy') { const d = document.getElementById('tv29Chat'); if (d && r.day) d.classList.add('day30'); }
      if (r.say && r.say.length) { S.step = Object.assign({}, st, { ask: null }); S.lines = r.say.map(l => Object.assign({ who: cfg.boss, src: 'fixed' }, l)); S.li = -1; S.st = 'say'; S.mood = r.mood || ''; S.sig = ''; audioSay(S.lines, tok, fin); }
      else fin(); });
  }
  function rwClose() {
    if (S.rw && S.rw.run) { const nx = S.runNext; S.runNext = null; tvClose(); if (nx) try { nx(); } catch (e) { console.warn('P13：つぎの 一歩で 失敗しました', e); } return; }
    S.ui = 'list'; S.rw = null; S.sig = '';
  }
  // だれも いなくなった（run）：onEnd に gone を わたして、つぎの 一歩（たたかい など）へ
  function runGone() { const cfg = S.run; let r = null; try { r = cfg.onEnd ? cfg.onEnd({ done: true, why: 'gone', complete: false, say: [] }, S.talk && S.talk.state) : null; } catch (e) { r = null; }
    tvClose(); Promise.resolve(r).then(x => { if (x && x.next) try { x.next(); } catch (e) { console.warn('P13：つぎの 一歩で 失敗しました', e); } }).catch(() => {}); }
  // 毎コマ：こたえる 人が いなくなった → そうだんに もどる。まちの ふきだし（15 びょう、1 回 だけ）
  function p13Tick(now) {
    if (!S.on || S.ui !== 'talk' || !xOn()) return; const G = C.G();
    if ((S.st === 'hud' || S.st === 'ask') && !S.rec && !S.audio.busy) { if (!S.hudAt) S.hudAt = now;
      if (!S.waitShown && now - S.hudAt > P13_WAIT_MS) { const ws = (S.run && S.run.wait) || (X().wait ? X().wait(S.boss) : null); if (ws && ws.length) { S.waitShown = 1; S.waitOn = { i: S.i, l: ws[Math.floor(Math.random() * ws.length)] }; S.sig = ''; } } }
    else S.hudAt = 0;
    if (S.waitOn && S.waitOn.i !== S.i) { S.waitOn = null; S.sig = ''; }
    if (S.pops && S.pops.length) { const n = S.pops.length; S.pops = S.pops.filter(p => now - p.at < P13_POP_MS); if (S.pops.length !== n) S.sig = ''; }
  }
  function p13Back(now) { S.sp = S.hsp; S.hsp = ''; S.ans = ''; S.hb = ''; S.st = 'hud'; S.hudAt = now; S.sig = ''; }
  // ポップ（♥ +2・💗 +1 やさしい！）
  function pop(text, col) { if (!S.on) return; css30(); S.pops = (S.pops || []).concat([{ s: String(text), c: col || '#ff8aa8', at: performance.now(), y: (S.pops || []).length % 3 }]); S.sig = ''; }
  const p13Sig = () => (xOn() ? [S.st, S.waitOn ? 1 : 0, (S.pops || []).length, S.run ? (S.run.hud ? S.run.hud() : '') : '', S.ans, S.rw && S.rw.big ? 1 : 0].join('/') : '');
  const p13Mood = () => (xOn() && (S.st === 'hud' || S.st === 'ask') && !S.rec ? 'wait' : '');
  // v0.30.1：とくべつな おしゃべりに 自分の 題（🆘 おねがい・🤝 やくそく…）が ある 時は、それが「💬 … と おしゃべり」の かわりに なる（2 つ ならべない）
  function p13Head(tt) { if (!S.run) return null; const h = S.run.hud ? S.run.hud() : '', rt = S.run.title, hs = h ? `<span class="h30">${h}</span>` : '';
    if (rt && rt[0]) return `<b class="t30">${esc(Lx(rt[0], rt[1] || rt[0]))}</b>${hs}`;
    return `<b>💬 ${Lx(`${esc(bossName(S.boss))} と おしゃべり`, `和${esc(bossName(S.boss))}聊天`)}</b>${hs}${rt ? '' : `<span>${esc(Lx(tt[0], tt[1]))}</span>`}`; }
  function p13Extra() { if (!xOn()) return '';
    const w = S.waitOn ? `<span class="wb30">${esc(Lx(S.waitOn.l.ja, S.waitOn.l.zh))}${ZS(S.waitOn.l.zh)}</span>` : '';
    const pops = (S.pops || []).map((p, i) => `<span class="pop30" style="left:${6 + (i % 3) * 7}vw;top:${26 + p.y * 7}vh;color:${p.c}">${esc(p.s)}</span>`).join('');
    return { w, pops, note: '<span class="note30">♪</span>' }; }
  function p13HudHtml() { const H = TV30ui(), b = H.banner, dc = H.decide; return `<div class="hud30">🗣 ${esc(Lx(b.ja, b.zh))}<small>${esc(Lx(dc.ja, dc.zh))}（💬）</small></div>`; }
  function TV30ui() { const D = root.TankTalk30Data, u = D && D.ui && D.ui.huddle; return u || { banner: { ja: 'みんなで そうだん！', zh: '大家商量一下！' }, decide: { ja: 'きまったら スマホの 💬 を おしてね', zh: '决定了就按手机上的 💬' }, answerBtn: { ja: 'こたえる', zh: '回答' } }; }
  function p13Pack() { if (!xOn()) return null; const G = C.G(), base = {}; let ex = null; try { ex = X().pack ? X().pack() : null; } catch (e) { ex = null; }
    if (ex && typeof ex === 'object') Object.assign(base, ex);
    base.hud = S.on && S.ui === 'talk' && S.st === 'hud' ? 1 : 0; base.ans = S.ans && G.pl[S.ans] ? G.pl[S.ans].slot : -1; return base; }
  function p13Badges(k) { const f = X().badges; if (!f) return []; try { return (f(k) || []).slice(0, 2); } catch (e) { return []; } }
  /* ---------- スマホ：そうだんタイム（💬 こたえる）・ゲージ・アイデア ボード・🆘 ---------- */
  const t30 = v => (v && v.g && v.g.tv30 && typeof v.g.tv30 === 'object' ? v.g.tv30 : null);
  function padHead30(v, t) { const g = t30(v); if (!t.run || !g) return ''; let s = '';
    if (Array.isArray(g.pv)) { const [h, nd] = g.pv; s += `<div class="g30">${Lx('こころメーター', '心之计')} ${hearts(Math.max(0, Math.min(5, h | 0)))}　<small>${Lx(`あと ♥ ${Math.max(0, nd - h)} つ`, `还差 ${Math.max(0, nd - h)} 颗心`)}</small></div>`; }
    if (Array.isArray(g.board) && g.board.length) s += '<div class="board30">' + g.board.map(([sl, tx]) => `<span style="background:${PCOL30(sl)}">${esc(tx)}</span>`).join('') + '</div>';
    return s; }
  function padHud30(v, t, H, q, cards) { const u = TV30ui(), b = u.banner, ab = u.answerBtn;
    H.push(`<div class="msg">🗣 ${esc(Lx(b.ja, b.zh))}</div>${q}<div class="cards off">` + cards.map(c => `<button disabled><i>${esc(c.ic)}</i>${esc(c.ja)}${ZS(c.zh)}</button>`).join('') + '</div>'
      + `<button class="go30" data-k="go30">💬 ${esc(ab.ja)}${ZS(ab.zh)}</button>`); }
  function padBadges30(t, H, v) { const g = t30(v); if (g && Array.isArray(g.m) && g.m.length >= 3) { const ic = ['💗', '🔥', '😆'];   // こころメーター（§7.1）
      H.push(`<div class="m30">${Lx('かぞくの こころ', '全家的心')}　` + ic.map((c, i) => `<span>${g.m[3] === i ? '✨' : ''}${c} Lv${g.m[i] | 0}</span>`).join('') + '</div>'); }
    if (!t.b30) return; const all = []; for (const k in t.b30) for (const b of t.b30[k]) all.push([k, b]); if (!all.length) return;
    H.push('<div class="b30s">' + all.map(([k, b]) => `<button data-k="b30" data-v="${esc(b[3])}" data-b="${esc(k)}">${esc(b[0])} ${esc(Lx(b[1], b[2]))}</button>`).join('') + '</div>'); }
  function padClick30(k, b, t) {
    if (k === 'go30') { C.room.emit('cmd', { a: 'tv30', op: 'go', i: t.i }).catch(e => console.warn('P13：💬 を 送れませんでした', e)); C.vibrate && C.vibrate(30); PS.sig = ''; return true; }
    if (k === 'b30') { C.room.emit('cmd', { a: 'tv30', op: b.dataset.v, boss: b.dataset.b }).catch(e => console.warn('P13：🆘 を 送れませんでした', e)); C.vibrate && C.vibrate(20); return true; }
    return false; }
  /* P13 hooks: end */
  function p13Sheet(boss) { const f = X().sheet; if (!f) return undefined; try { return f(boss) || undefined; } catch (e) { return undefined; } }
  function p13ExtraLines() { if (!S.run || !S.run.extra || !S.step || !S.step.ask) return {}; try { const ex = S.run.extra(S.step.ask); return Array.isArray(ex) && ex.length ? { extra: ex.slice(0, 3) } : {}; } catch (e) { return {}; } }
  function p13Keep(boss, ti) { const f = X().keep; if (!f) return null; try { const c = f(boss, S.store, ti); return c && c.sheet ? c : null; } catch (e) { console.warn('P13：やくそくの 話を 作れませんでした', e); return null; } }
  function p13Shelf(boss) { const f = X().shelf; if (!f) return ''; try { const v = f(boss); return typeof v === 'string' ? v.slice(0, 4) : ''; } catch (e) { return ''; } }
  function p13Vo(boss, l) { const f = X().vo; if (!f) return ''; try { const v = f(boss, l); return typeof v === 'string' && /^t30_[a-z0-9]+_[a-z0-9]+_\d$/.test(v) ? v : ''; } catch (e) { return ''; } }
  function p13Greet(boss) { const f = X().greet; if (!f) return null; try { return f(boss, S.store) || null; } catch (e) { console.warn('P13：あいさつを 作れませんでした', e); return null; } }
  function p13Mem(boss, lines) { const f = X().memory; if (!f) return lines; let ex = []; try { ex = (f(boss) || []).filter(x => typeof x === 'string').slice(0, 3); } catch (e) { ex = []; } return lines.slice(0, Math.max(0, 6 - ex.length)).concat(ex); }
  function p13Helpers(list, stage, lap) { const f = X().helpers; if (!f) return list; try { const r = f(list, stage, lap); return Array.isArray(r) ? r : list; } catch (e) { console.warn('P13：おてつだいを きめられませんでした', e); return list; } }
  function p13Pages(pages) { const f = X().pages; if (!f) return pages; try { const r = f(pages); return Array.isArray(r) ? r : pages; } catch (e) { console.warn('P13：エンディングの ページを 作れませんでした', e); return pages; } }
  Object.assign(api, { attach, onStage, endingSteps, creditStep, drawCredits, drawSlideArt, drawShelf, drawMatesHearts, _tv: S, _pad: PS, open: b => tvOpen(b), close: () => tvClose(), applyHelp, run, pop, ext: api.ext || {} });
  root.TankChat = api;
})(typeof window !== 'undefined' ? window : globalThis);

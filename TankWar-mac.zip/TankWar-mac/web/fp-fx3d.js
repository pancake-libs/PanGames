/* 共通部品：3D の効果（小さな粒・広がる輪・光のにじみ・画質の自動調整）。タワーディフェンス（td-view.js）の作りをまとめたもの（2026-11-15）。
   Three.js（three-td.js の window.THREE）を使う。

   使い方：
     const sparks = new FPFx3d.Particles(scene, 2600, true, false);  // 火花（光を足す）
     const smoke  = new FPFx3d.Particles(scene, 900, false, true);   // 煙（やわらかい）
     sparks.burst(x, y, z, 20, 0xffa040, 3, .5, .2, .04, 2);          // 数・色・速さ・寿命・大きさ（始め・終わり）・重さ・上向き
     const rings = FPFx3d.Rings(scene); rings.add(x, z, .05, 1.5, 0xffe06a, .6);
     const q = FPFx3d.Quality(st, { quality: 未指定なら自動 });         // st は FPScene3d.create の戻り値
     q.resize(); q.setBloom(.32);
     毎フレーム：sparks.update(dt); smoke.update(dt); rings.update(dt); q.watch(dt); q.render();
   画質：2＝光のにじみ・影 2048・解像度 1920、1＝影 1024・1600、0＝影なし・1280。3 秒の平均が 40 フレーム/秒より遅いと 1 段下げる */
(function () {
  'use strict';
  const T3 = window.THREE;
  if (!T3) { console.error('Three.js が読めていません（three-td.js を先に読む）'); return; }
  const _c = new T3.Color();
  const QUALITY_NAMES = ['低', '中', '高'];

  const P_VERT = `attribute float size; attribute float alpha; attribute vec3 pcolor; varying vec3 vC; varying float vA; uniform float uScale;
    void main(){ vC=pcolor; vA=alpha; vec4 mv=modelViewMatrix*vec4(position,1.); gl_PointSize=size*uScale/max(.1,-mv.z); gl_Position=projectionMatrix*mv; }`;
  const P_FRAG = `varying vec3 vC; varying float vA; uniform float uSoft;
    void main(){ vec2 c=gl_PointCoord-.5; float d=length(c); if(d>.5) discard; float a=mix(1.-smoothstep(.35,.5,d), 1.-smoothstep(0.,.5,d), uSoft)*vA; gl_FragColor=vec4(vC,a);
    #include <colorspace_fragment>
    }`;

  class Particles {
    constructor(scene, max, additive, soft) {
      this.max = max; this.n = 0;
      this.p = new Float32Array(max * 3); this.v = new Float32Array(max * 3); this.c = new Float32Array(max * 3);
      this.size = new Float32Array(max); this.alpha = new Float32Array(max); this.life = new Float32Array(max); this.maxLife = new Float32Array(max);
      this.s0 = new Float32Array(max); this.s1 = new Float32Array(max); this.grav = new Float32Array(max); this.drag = new Float32Array(max);
      const geo = new T3.BufferGeometry();
      this.aP = new T3.BufferAttribute(this.p, 3).setUsage(T3.DynamicDrawUsage);
      this.aC = new T3.BufferAttribute(this.c, 3).setUsage(T3.DynamicDrawUsage);
      this.aS = new T3.BufferAttribute(this.size, 1).setUsage(T3.DynamicDrawUsage);
      this.aA = new T3.BufferAttribute(this.alpha, 1).setUsage(T3.DynamicDrawUsage);
      geo.setAttribute('position', this.aP); geo.setAttribute('pcolor', this.aC); geo.setAttribute('size', this.aS); geo.setAttribute('alpha', this.aA);
      geo.boundingSphere = new T3.Sphere(new T3.Vector3(), 1e4);
      this.mat = new T3.ShaderMaterial({ vertexShader: P_VERT, fragmentShader: P_FRAG, transparent: true, depthWrite: false,
        blending: additive ? T3.AdditiveBlending : T3.NormalBlending, uniforms: { uScale: { value: 500 }, uSoft: { value: soft ? 1 : .4 } } });
      this.pts = new T3.Points(geo, this.mat); this.pts.frustumCulled = false; this.pts.renderOrder = additive ? 20 : 15;
      scene.add(this.pts);
    }
    emit(x, y, z, vx, vy, vz, color, life, s0, s1, grav, drag) {
      const i = this.n < this.max ? this.n++ : Math.floor(Math.random() * this.max);
      this.p[i * 3] = x; this.p[i * 3 + 1] = y; this.p[i * 3 + 2] = z;
      this.v[i * 3] = vx; this.v[i * 3 + 1] = vy; this.v[i * 3 + 2] = vz;
      _c.set(color); this.c[i * 3] = _c.r; this.c[i * 3 + 1] = _c.g; this.c[i * 3 + 2] = _c.b;
      this.life[i] = life; this.maxLife[i] = life; this.s0[i] = s0; this.s1[i] = s1 === undefined ? s0 : s1; this.grav[i] = grav || 0; this.drag[i] = drag || 0;
    }
    burst(x, y, z, n, color, speed, life, s0, s1, grav, up) {
      for (let k = 0; k < n; k++) {
        const a = Math.random() * Math.PI * 2, el = Math.random() * Math.PI * .5, sp = speed * (.4 + Math.random() * .6);
        this.emit(x, y, z, Math.cos(a) * Math.cos(el) * sp, Math.sin(el) * sp + (up || 0), Math.sin(a) * Math.cos(el) * sp, color, life * (.6 + Math.random() * .6), s0, s1, grav, 1.5);
      }
    }
    // 画面の高さ（ピクセル）とカメラの画角から、粒の大きさの倍率を決める。resize の時に呼ぶ
    setViewport(heightPx, fovDeg) { this.mat.uniforms.uScale.value = heightPx / (2 * Math.tan(fovDeg * Math.PI / 360)); }
    update(dt) {
      for (let i = 0; i < this.n; i++) {
        this.life[i] -= dt;
        if (this.life[i] <= 0) {
          const j = --this.n; if (i !== j) {
            for (let k = 0; k < 3; k++) { this.p[i * 3 + k] = this.p[j * 3 + k]; this.v[i * 3 + k] = this.v[j * 3 + k]; this.c[i * 3 + k] = this.c[j * 3 + k]; }
            this.life[i] = this.life[j]; this.maxLife[i] = this.maxLife[j]; this.s0[i] = this.s0[j]; this.s1[i] = this.s1[j]; this.grav[i] = this.grav[j]; this.drag[i] = this.drag[j];
          }
          i--; continue;
        }
        const d = Math.max(0, 1 - this.drag[i] * dt);
        this.v[i * 3] *= d; this.v[i * 3 + 1] = this.v[i * 3 + 1] * d - this.grav[i] * dt; this.v[i * 3 + 2] *= d;
        this.p[i * 3] += this.v[i * 3] * dt; this.p[i * 3 + 1] += this.v[i * 3 + 1] * dt; this.p[i * 3 + 2] += this.v[i * 3 + 2] * dt;
        const t = 1 - this.life[i] / this.maxLife[i];
        this.size[i] = this.s0[i] + (this.s1[i] - this.s0[i]) * t;
        this.alpha[i] = t < .1 ? t * 10 : 1 - Math.pow((t - .1) / .9, 1.6);
      }
      this.pts.geometry.setDrawRange(0, this.n);
      this.aP.needsUpdate = this.aC.needsUpdate = this.aS.needsUpdate = this.aA.needsUpdate = true;
    }
  }

  // 地面に広がる輪（建てた・爆発・範囲の印）
  function Rings(scene) {
    const geo = new T3.RingGeometry(.82, 1, 48, 1), list = [];
    return {
      add(x, z, y, r, color, life, opacity) {
        const m = new T3.Mesh(geo, new T3.MeshBasicMaterial({ color, transparent: true, opacity: opacity || .8, depthWrite: false, toneMapped: false, blending: T3.AdditiveBlending, side: T3.DoubleSide }));
        m.rotation.x = -Math.PI / 2; m.position.set(x, y, z); scene.add(m); list.push({ m, life, max: life, r, op: opacity || .8 });
      },
      update(dt) {
        for (let i = list.length - 1; i >= 0; i--) {
          const o = list[i]; o.life -= dt;
          if (o.life <= 0) { scene.remove(o.m); o.m.material.dispose(); list.splice(i, 1); continue; }
          const t = 1 - o.life / o.max, s = o.r * (.2 + .8 * (1 - Math.pow(1 - t, 3)));
          o.m.scale.set(s, s, s); o.m.material.opacity = o.op * (1 - t);
        }
      },
    };
  }

  // 画質：光のにじみ（bloom）・影・解像度を、重さに合わせて切り替える
  function Quality(st, opts) {
    opts = opts || {};
    const { renderer, scene, camera, sun } = st;
    let quality = Math.max(0, Math.min(2, opts.quality === undefined ? 2 : opts.quality)), auto = opts.quality === undefined;
    let composer = null, bloom = null, bloomStrength = opts.bloom === undefined ? .32 : opts.bloom;
    let W = 1, H = 1, PR = 1, acc = 0, n = 0, downAt = -99, t = 0, fps = 60;
    const onResize = opts.onResize || function () {};
    function setup() {
      if (composer) { composer.dispose && composer.dispose(); composer = null; bloom = null; }
      if (quality >= 2) {
        const rt = new T3.WebGLRenderTarget(Math.max(1, W * PR), Math.max(1, H * PR), { type: T3.HalfFloatType, samples: renderer.capabilities.isWebGL2 ? 4 : 0 });
        composer = new T3.EffectComposer(renderer, rt);
        composer.addPass(new T3.RenderPass(scene, camera));
        bloom = new T3.UnrealBloomPass(new T3.Vector2(W * PR / 2, H * PR / 2), bloomStrength, opts.bloomRadius || .5, opts.bloomThreshold || .93);
        composer.addPass(bloom); composer.addPass(new T3.OutputPass());
        composer.setPixelRatio(PR); composer.setSize(W, H);
      }
      renderer.shadowMap.enabled = quality >= 1; sun.castShadow = quality >= 1;
      const sm = quality >= 2 ? 2048 : 1024; sun.shadow.mapSize.set(sm, sm);
      if (sun.shadow.map) { sun.shadow.map.dispose(); sun.shadow.map = null; }
      scene.traverse(o => { if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => { m.needsUpdate = true; }); });
    }
    function resize() {
      const el = renderer.domElement; W = el.clientWidth || innerWidth; H = el.clientHeight || innerHeight;
      const maxW = quality >= 2 ? 1920 : quality >= 1 ? 1600 : 1280;
      PR = Math.min(window.devicePixelRatio || 1, maxW / Math.max(1, W));
      renderer.setPixelRatio(PR); renderer.setSize(W, H, false);
      camera.aspect = W / H; camera.updateProjectionMatrix();
      setup(); onResize({ W, H, PR, heightPx: H * PR, quality });
    }
    function watch(dt) {
      t += dt; acc += dt; n++;
      if (acc >= 3) {
        fps = n / acc; acc = 0; n = 0;
        if (auto && fps < 40 && quality > 0 && t - downAt > 6) { quality--; downAt = t; console.info('重いので画質を下げました：' + QUALITY_NAMES[quality] + '（' + Math.round(fps) + ' フレーム/秒）'); resize(); }
      }
    }
    function render() { if (composer) composer.render(); else renderer.render(scene, camera); }
    function setBloom(v) { bloomStrength = v; if (bloom) bloom.strength = v; }
    return { resize, watch, render, setBloom, get quality() { return quality; }, get fps() { return fps; }, get name() { return QUALITY_NAMES[quality]; } };
  }

  window.FPFx3d = { Particles, Rings, Quality, QUALITY_NAMES };
})();

/* ==================== P11（v0.28）：こえで こたえる（スマホの 🎤 → Mac の whisper → えらぶ札が 光る） ====================
   - 設計：v028-design.md §2.5・2.6・3・5・6・8。サーバーは 中継だけ。ことばの 照らし合わせ（match）は この ファイルの 1 つの 関数で、スマホと テレビの 両方が つかう
   - ことばの表は tank-talkdata.js（window.TankTalkData。tools/v028-gen.mjs が 作る）
   - 声は えらばない：光った札を「✅ これで いい」か 札の タップで えらぶ（いままでの {a:'p3d',op:'vote'} を そのまま 送る）。時間の 決まりは 無い（1 回の 録音が 10 秒まで だけ）
   - スマホ → テレビ：cmd {a:'tv28', op:'rec'|'heard'|'fail'|'clear'|'macrec'|'setup', i, …}。テレビ → スマホ：presence の g.tv28
   - テレビの 記録：'tank-tv28-talk'＝{v:1, cfg:{macMic:0}}
   - node でも 読める（純粋な 関数だけ module.exports）。ブラウザでは window.TankTalkVoice
   ==================== */
(function (root) {
  'use strict';
  const TV28_REC_MAX_S = 10;          // 1 回の 録音の いちばん 長い 秒
  const TV28_SIL_STOP_S = 1.2;        // 話した あと この 秒 しずかなら 止める
  const TV28_SPEECH_DB = -40;         // これより 大きい 音を「話している」とみなす（dBFS、20 ミリ秒ごとの RMS）
  const TV28_QUIET_DB = -38;          // いちばん 大きい 音が これより 小さければ 送らない
  const TV28_MIN_SPEECH_S = 0.25;     // 話した 長さが これより 短ければ 送らない
  const TV28_KEEP_S = 0.15, TV28_PAD_S = 0.3, TV28_MIN_WAV_S = 1.2, TV28_RATE = 16000;
  const TV28_BUDGET_MS = 3500;        // 止めてから 答えを まつ 秒（こえたら 札で えらぶ）
  const TV28_MIC_IDLE_MS = 60000;     // マイクを つかわない まま この 時間で とじる
  const TV28_WS_WAIT_MS = 8000;       // https で つながらない時、もどる 帯を 出すまで
  const TV28_PROBE_MS = 1500;         // https の ping を まつ 時間
  const TV28_DUCK_SAFE_MS = 12000;    // 曲を 小さくする いちばん 長い 時間
  const TV28_POLL_MS = 3000, TV28_TLS_POLL_MS = 10000;
  const TV28_KEY = 'tank-tv28-talk';
  const TV28_HTTP_PORT = 8090;
  const TV28_MM_START_MS = 4000, TV28_MM_WAIT_MS = 9000;   // Mac の マイク：テレビが 録音を はじめるまで・止めてから 答えまで

  /* ---------- ことばの 照らし合わせ（純粋） ---------- */
  const toHira = s => String(s).replace(/[ァ-ヶ]/g, c => String.fromCharCode(c.charCodeAt(0) - 0x60));
  // NFKC・小文字・空白／記号／絵文字を 取る。ja は カタカナ → ひらがな（「ー」は のこす）
  function norm(s, lang) { let t = String(s == null ? '' : s).normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}ー]/gu, ''); if (lang !== 'zh') t = toHira(t); return t; }
  const HALLU0 = ['ご視聴ありがとうございました', 'ご清聴ありがとうございました', 'チャンネル登録', '字幕', '谢谢观看', '请订阅', '字幕由', 'blankaudio', '音楽'];
  // 位置の ことば（0.70）：[ことば, 0 1 ばんめ・1 2 ばんめ・2 さいご, まるごと 同じ時だけ]
  const POS = {
    ja: [['いちばん', 0], ['ひとつめ', 0], ['ひだり', 0], ['一番', 0], ['1番', 0], ['一つ目', 0], ['1つ目', 0], ['左', 0, 1], ['えー', 0, 1], ['a', 0, 1], ['えい', 0, 1],
      ['にばん', 1], ['ふたつめ', 1], ['まんなか', 1], ['二番', 1], ['2番', 1], ['二つ目', 1], ['2つ目', 1], ['真ん中', 1], ['びー', 1, 1], ['b', 1, 1],
      ['さんばん', 2], ['みっつめ', 2], ['みぎ', 2], ['三番', 2], ['3番', 2], ['三つ目', 2], ['3つ目', 2], ['右', 2, 1], ['しー', 2, 1], ['c', 2, 1]],
    zh: [['第一个', 0], ['第一個', 0], ['左边', 0], ['左邊', 0], ['一号', 0], ['一號', 0], ['第二个', 1], ['第二個', 1], ['中间', 1], ['中間', 1], ['二号', 1], ['二號', 1],
      ['第三个', 2], ['第三個', 2], ['右边', 2], ['右邊', 2], ['三号', 2], ['三號', 2]]
  };
  const IDX = new WeakMap();
  function indexOf(data) { if (!data || typeof data !== 'object') return new Map(); let m = IDX.get(data); if (m) return m; m = new Map();
    for (const s of data.sets || []) for (const o of s.opts || []) m.set(norm(o.ja, 'ja'), o); IDX.set(data, m); return m; }
  // 札 1 まいの ことば。札の 文と、空白で わけた 2 文字以上の かたまりも ことばに する
  function words(opt, lang, data) {
    const e = indexOf(data).get(norm(opt.ja, 'ja')), txt = String(opt[lang] || ''), list = [txt];
    for (const c of txt.split(/\s+/)) if ([...norm(c, lang)].length >= 2) list.push(c);
    if (e && e.kw && Array.isArray(e.kw[lang])) list.push(...e.kw[lang]);
    const kw = [...new Set(list.map(k => norm(k, lang)).filter(Boolean))], neg = e && e.neg && Array.isArray(e.neg[lang]) ? e.neg[lang].map(k => norm(k, lang)).filter(Boolean) : [];
    return { kw, neg, id: e ? e.id : '' };
  }
  // ことば w が h の どこかに だいたい ある時の、いちばん 小さい 書きかえの 数（部分の 編集距離）
  function subDist(w, h) { const a = [...w], b = [...h], m = a.length, n = b.length; if (!n) return m; let prev = new Array(n + 1).fill(0), best = m;
    for (let i = 1; i <= m; i++) { const cur = [i]; for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); prev = cur; }
    for (let j = 0; j <= n; j++) best = Math.min(best, prev[j]); return best; }
  function isHallu(h, data) { if (!h) return true; const list = HALLU0.concat(data && Array.isArray(data.hallu) ? data.hallu : []);
    for (const x of list) { const nx = norm(x, 'zh'), nj = norm(x, 'ja'); for (const q of [nx, nj]) if (q && h.includes(q) && h.length - q.length <= 2) return true; } return false; }
  // 点数（札ごと）。opts＝[{ja, zh, off}]
  function scores(H, opts, lang, data) {
    const n = opts.length, K = opts.map(o => words(o, lang, data)), hits = [];
    K.forEach((k, i) => { for (const w of k.kw) H.forEach((h, hi) => { if (w.length === 1) { if (h === w) hits.push({ o: i, h: hi, s: 0, e: 1, len: 1 }); return; }
      for (let p = h.indexOf(w); p >= 0; p = h.indexOf(w, p + 1)) hits.push({ o: i, h: hi, s: p, e: p + w.length, len: w.length }); }); });
    for (const [w0, which, whole] of POS[lang === 'zh' ? 'zh' : 'ja']) { const w = norm(w0, lang), o = which === 2 ? n - 1 : which; if (o >= n || o < 0) continue;
      H.forEach((h, hi) => { if (whole) { if (h === w) hits.push({ o, h: hi, s: 0, e: w.length, len: w.length, pos: 1 }); return; }
        for (let p = h.indexOf(w); p >= 0; p = h.indexOf(w, p + 1)) hits.push({ o, h: hi, s: p, e: p + w.length, len: w.length, pos: 1 }); }); }
    // 重なり：ほかの 札の もっと 長い ことばの 中に すっぽり 入る ことばは 数えない（「哭」と「不哭」）
    const keep = hits.filter(a => !hits.some(b => b.o !== a.o && b.h === a.h && b.len > a.len && b.s <= a.s && b.e >= a.e));
    const sc = new Array(n).fill(0), exact = new Array(n).fill(false), out = K.map(k => k.neg.some(w => H.some(h => h.includes(w))));
    for (const a of keep) { if (out[a.o]) continue; sc[a.o] = Math.max(sc[a.o], a.pos ? 0.70 : 0.70 + 0.05 * Math.min(a.len, 6)); if (!a.pos) exact[a.o] = true; }
    K.forEach((k, i) => { if (out[i] || exact[i]) return; for (const w of k.kw) { const len = [...w].length; if (len < 3) continue;
      for (const h of H) { const sim = 1 - subDist(w, h) / len; if (sim >= 0.67) sc[i] = Math.max(sc[i], 0.40 + 0.20 * sim); } } });
    return sc.map(v => Math.round(v * 1000) / 1000);
  }
  function decide(sc, ok) { const idx = sc.map((v, i) => i).filter(i => ok(i)).sort((a, b) => sc[b] - sc[a]); if (!idx.length) return { m: -1, score: 0, amb: [] };
    const b = sc[idx[0]], s2 = idx.length > 1 ? sc[idx[1]] : 0;
    if (b >= 0.5 && b - s2 >= 0.15) return { m: idx[0], score: b, amb: [] };
    return { m: -1, score: b, amb: b >= 0.5 ? idx.filter(i => sc[i] >= Math.max(0.5, b - 0.15)) : [] }; }
  // 照らし合わせ。text＝whisper の 文、kana＝その 読み（無くても よい）、opts＝[{ja, zh, off}]（off＝いまは えらべない札）
  // 答え：{m, score, amb, sc}。m＝光らせる札（-1＝わからない）。off＝えらべない札に 当たった時の その番号。none＝何も 聞こえなかった
  function match(text, kana, opts, lang, data) {
    lang = lang === 'zh' ? 'zh' : 'ja'; data = data || root.TankTalkData || {}; opts = (opts || []).map(o => Array.isArray(o) ? { ic: o[0], ja: o[1], zh: o[2] } : o);
    const H = [...new Set([norm(text, lang), lang === 'ja' && kana ? norm(kana, 'ja') : ''].filter(Boolean))];
    if (!H.length || isHallu(H[0], data)) return { m: -1, score: 0, amb: [], none: true, off: -1, sc: opts.map(() => 0) };
    const sc = scores(H, opts, lang, data), all = decide(sc, () => true);
    if (all.m >= 0 && opts[all.m].off) return { m: -1, score: all.score, amb: [], off: all.m, sc };
    return Object.assign(decide(sc, i => !opts[i].off), { off: -1, sc });
  }
  // テレビの 字幕：だめな ことばを ★ に。読み（kana）だけに ある時は まるごと「★★★」。40 文字まで
  function maskNG(text, kana, lang, data) {
    data = data || root.TankTalkData || {}; lang = lang === 'zh' ? 'zh' : 'ja'; const ng = data.ng && Array.isArray(data.ng[lang]) ? data.ng[lang] : [];
    const chars = [...String(text || '').slice(0, 160)], cmp = chars.map(c => toHira(c.normalize('NFKC').toLowerCase())), hit = new Array(chars.length).fill(false);
    for (const w of ng) { const wn = [...toHira(String(w).normalize('NFKC').toLowerCase().replace(/\s+/g, ''))]; if (!wn.length) continue;
      for (let i = 0; i + wn.length <= chars.length; i++) if (wn.every((c, j) => cmp[i + j] === c)) for (let j = 0; j < wn.length; j++) hit[i + j] = true; }
    let out = chars.map((c, i) => hit[i] ? '★' : c).join('');
    if (!hit.includes(true)) { const hs = [norm(text, lang)].concat(lang === 'ja' && kana ? [norm(kana, 'ja')] : []);
      if (ng.some(w => { const q = norm(w, lang); return q && hs.some(h => h.includes(q)); })) out = '★★★'; }
    const a = [...out]; return a.length > 40 ? a.slice(0, 40).join('') + '…' : out;
  }

  /* ---------- 音の 道具（純粋） ---------- */
  function analyze(x, rate) {
    const f = Math.max(1, Math.round(rate * 0.02)), thr = Math.pow(10, TV28_SPEECH_DB / 20); let peak = 0, first = -1, last = -1;
    for (let i = 0; i < x.length; i++) { const v = Math.abs(x[i]); if (v > peak) peak = v; }
    for (let s = 0; s < x.length; s += f) { let e = 0; const end = Math.min(x.length, s + f); for (let i = s; i < end; i++) e += x[i] * x[i]; const rms = Math.sqrt(e / Math.max(1, end - s));
      if (rms >= thr) { if (first < 0) first = s; last = end; } }
    return { peakDb: peak > 0 ? 20 * Math.log10(peak) : -120, start: Math.max(0, first), end: first < 0 ? 0 : last, speechSec: first < 0 ? 0 : (last - first) / rate };
  }
  const isQuiet = a => a.peakDb < TV28_QUIET_DB || a.speechSec < TV28_MIN_SPEECH_S;
  function trim(x, rate, a, keep) { const k = Math.round((keep === undefined ? TV28_KEEP_S : keep) * rate); return x.slice(Math.max(0, a.start - k), Math.min(x.length, a.end + k)); }
  // JS の 作り直し（OfflineAudioContext が 無い時）：はこの 平均（ちぢめる時）＋ 直線で つなぐ
  function resample(x, from, to) {
    if (from === to) return Float32Array.from(x); const r = from / to, n = Math.max(1, Math.round(x.length / r)), out = new Float32Array(n);
    let src = x; if (r > 1) { const w = Math.max(1, Math.round(r)); src = new Float32Array(x.length); let acc = 0; for (let i = 0; i < x.length; i++) { acc += x[i]; if (i >= w) acc -= x[i - w]; src[i] = acc / Math.min(i + 1, w); } }
    const sh = r > 1 ? (Math.round(r) - 1) / 2 : 0;
    for (let i = 0; i < n; i++) { const p = Math.min(src.length - 1, i * r + sh), a = Math.floor(p), b = Math.min(src.length - 1, a + 1), t = p - a; out[i] = src[a] * (1 - t) + src[b] * t; }
    return out;
  }
  function padSilence(x, rate, pad, min) { const p = Math.round((pad === undefined ? TV28_PAD_S : pad) * rate), total = Math.max(x.length + p * 2, Math.round((min === undefined ? TV28_MIN_WAV_S : min) * rate));
    const out = new Float32Array(total), off = Math.floor((total - x.length) / 2); out.set(x, off); return out; }
  // 44 バイトの 頭＋PCM 16 ビット 1 チャンネル
  function encodeWav(x, rate) {
    const buf = new ArrayBuffer(44 + x.length * 2), v = new DataView(buf), w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
    w(0, 'RIFF'); v.setUint32(4, 36 + x.length * 2, true); w(8, 'WAVE'); w(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, rate, true); v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, x.length * 2, true);
    for (let i = 0; i < x.length; i++) { const s = Math.max(-1, Math.min(1, x[i])); v.setInt16(44 + i * 2, s < 0 ? Math.round(s * 32768) : Math.round(s * 32767), true); }
    return buf;
  }

  /* ---------- https へ うつる（純粋な 決まり）と、名前の 持ちこし ---------- */
  const isLoopback = h => /^(127\.|localhost$|\[?::1\]?$)/i.test(String(h || ''));
  // ping を 試すか：スマホ・http・この 端末の 中ではない・?nohttps=1 でない・まだ 参加していない
  function probeDecision(o) { return o.role === 'pad' && o.protocol === 'http:' && !isLoopback(o.hostname) && !/[?&]nohttps=1(&|$)/.test(o.search || '') && !o.noHttps && !o.joined; }
  function b64u(bytes) { let s = ''; for (const b of bytes) s += String.fromCharCode(b); return (typeof btoa === 'function' ? btoa(s) : Buffer.from(s, 'binary').toString('base64')).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function encHash(o) { return b64u(new TextEncoder().encode(JSON.stringify({ n: o && o.n ? String(o.n).slice(0, 40) : '', l: o && o.l === 'zh' ? 'zh' : (o && o.l === 'ja' ? 'ja' : '') }))); }
  function decHash(s) { try { s = String(s || '').replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '=';
    const bin = typeof atob === 'function' ? atob(s) : Buffer.from(s, 'base64').toString('binary'), o = JSON.parse(new TextDecoder().decode(Uint8Array.from(bin, c => c.charCodeAt(0))));
    return { n: typeof o.n === 'string' ? o.n.slice(0, 40) : '', l: o.l === 'zh' || o.l === 'ja' ? o.l : '' }; } catch (e) { return null; } }

  const api = { norm, match, maskNG, words, scores, subDist, analyze, isQuiet, trim, resample, padSilence, encodeWav, probeDecision, encHash, decHash, isLoopback,
    HALLU0, POS, KEY: TV28_KEY, CONST: { TV28_REC_MAX_S, TV28_SIL_STOP_S, TV28_QUIET_DB, TV28_MIN_SPEECH_S, TV28_BUDGET_MS, TV28_RATE },
    CREDITS: ['whisper.cpp — MIT（© Georgi Gerganov and contributors）', 'Whisper models — MIT（© OpenAI）', 'whisper-jni — Apache-2.0（© Miguel Álvarez Díez）', 'Kuromoji — Apache-2.0（© Atilika Inc.）・mecab-ipadic（NAIST）'] };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (typeof window === 'undefined' || typeof document === 'undefined') return;

  /* ==================== ここから ブラウザだけ ==================== */
  const ss = { get(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { sessionStorage.setItem(k, v); } catch (e) { /* 使えない時は おぼえない */ } } };
  const ls = { get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* 使えない時は おぼえない */ } } };
  const PAGE_ROLE = location.pathname === '/tank-tv.html' ? 'tv' : 'pad', GAME_PAGE = ['/', '/tank', '/tank.html', '/tank-tv.html', '/td'].includes(location.pathname);

  /* ---------- 録音（TankTalkVoice.Recorder） ---------- */
  class Recorder {
    constructor(o) { this.o = o || {}; this.stream = null; this.ac = null; this.own = false; this.rec = false; this.chunks = []; this.level = 0; this.t = 0; this.usedAt = 0; this.timer = null; }
    static can() { return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia) && window.isSecureContext !== false; }
    get active() { return !!(this.stream && this.stream.getAudioTracks().some(t => t.readyState === 'live')); }
    async open() {
      this.usedAt = Date.now();
      if (this.active && this.ac) { if (this.ac.state === 'suspended') await this.ac.resume().catch(() => {}); return; }
      if (!Recorder.can()) throw Object.assign(new Error('マイクが ありません'), { name: 'NotSupportedError' });
      // iPhone：音の 道は タップの 中で 作って resume する（getUserMedia を まつ 前に）
      let ac = this.o.ac && this.o.ac.state !== 'closed' ? this.o.ac : null; this.own = !ac; if (!ac) ac = new (window.AudioContext || window.webkitAudioContext)();
      const res = ac.resume ? ac.resume().catch(() => {}) : null; this.ac = ac;
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
      await res; this.stream = stream; const src = ac.createMediaStreamSource(stream), zero = ac.createGain(); zero.gain.value = 0; zero.connect(ac.destination);
      if (ac.createScriptProcessor) { const p = ac.createScriptProcessor(4096, 1, 1); p.onaudioprocess = e => this.feed(e.inputBuffer.getChannelData(0)); src.connect(p); p.connect(zero); this.node = p; }
      else { const code = 'class P extends AudioWorkletProcessor{process(i){const c=i[0]&&i[0][0];if(c)this.port.postMessage(c.slice(0));return true;}}registerProcessor("tv28-cap",P);';
        const url = URL.createObjectURL(new Blob([code], { type: 'application/javascript' })); await ac.audioWorklet.addModule(url); URL.revokeObjectURL(url);
        const node = new AudioWorkletNode(ac, 'tv28-cap'); node.port.onmessage = e => this.feed(e.data); src.connect(node); node.connect(zero); this.node = node; }
      this.src = src; this.zero = zero;
      clearInterval(this.timer); this.timer = setInterval(() => { if (!this.rec && Date.now() - this.usedAt > TV28_MIC_IDLE_MS) this.close(); }, 5000);
    }
    start() { this.chunks = []; this.n = 0; this.t = 0; this.speech = 0; this.silent = 0; this.heard = false; this.rec = true; this.usedAt = Date.now(); }
    feed(c) {
      let e = 0; for (let i = 0; i < c.length; i++) e += c[i] * c[i]; const rms = Math.sqrt(e / Math.max(1, c.length)), db = rms > 0 ? 20 * Math.log10(rms) : -120;
      this.level = Math.max(this.level * 0.7, Math.min(1, Math.max(0, (db + 60) / 50)));
      if (!this.rec) return; const dt = c.length / this.ac.sampleRate; this.chunks.push(new Float32Array(c)); this.n += c.length; this.t += dt;
      if (db > TV28_SPEECH_DB) { this.speech += dt; this.silent = 0; if (this.speech >= 0.15) this.heard = true; } else this.silent += dt;
      if (this.t >= TV28_REC_MAX_S) this.auto('max'); else if (this.heard && this.silent >= TV28_SIL_STOP_S) this.auto('silence');
    }
    auto(why) { if (!this.rec) return; const r = this.stop(); if (this.o.onAuto) try { this.o.onAuto(why, r); } catch (e) { console.warn('P11：録音の おわりで 失敗しました', e); } }
    stop() { this.rec = false; this.usedAt = Date.now(); const out = new Float32Array(this.n || 0); let o = 0; for (const c of this.chunks) { out.set(c, o); o += c.length; } this.chunks = [];
      const r = { data: out, rate: this.ac ? this.ac.sampleRate : 48000, sec: this.t }; if (api.testAudio) { const t = api.testAudio; r.data = t.data; r.rate = t.rate; } return r; }
    close() { this.rec = false; clearInterval(this.timer); this.timer = null; try { if (this.stream) this.stream.getTracks().forEach(t => t.stop()); } catch (e) { /* もう 止まっている */ }
      try { if (this.src) this.src.disconnect(); if (this.node) this.node.disconnect(); if (this.zero) this.zero.disconnect(); } catch (e) { /* もう はずれている */ }
      if (this.own && this.ac && this.ac.close) this.ac.close().catch(() => {}); this.stream = null; this.src = this.node = this.zero = null; if (this.own) this.ac = null; this.level = 0; }
  }
  async function to16k(x, rate) {
    if (rate === TV28_RATE) return x;
    try { const OAC = window.OfflineAudioContext || window.webkitOfflineAudioContext, n = Math.max(1, Math.round(x.length * TV28_RATE / rate)), oc = new OAC(1, n, TV28_RATE), b = oc.createBuffer(1, x.length, rate);
      b.copyToChannel ? b.copyToChannel(x, 0) : b.getChannelData(0).set(x); const s = oc.createBufferSource(); s.buffer = b; s.connect(oc.destination); s.start(0);
      const out = await oc.startRendering(); return out.getChannelData(0).slice(); }
    catch (e) { return resample(x, rate, TV28_RATE); }
  }
  // 録音 → 送る WAV（小さすぎる時は quiet）
  async function toWav(r) { const a = analyze(r.data, r.rate); if (isQuiet(a)) return { quiet: true, a };
    let x = trim(r.data, r.rate, a); x = await to16k(x, r.rate); x = padSilence(x, TV28_RATE); return { blob: new Blob([encodeWav(x, TV28_RATE)], { type: 'audio/wav' }), sec: x.length / TV28_RATE, a }; }
  // POST /stt。budget ミリ秒で あきらめる（おそい 答えは すてる）
  async function upload(blob, lang, hint, budget) {
    const ac = new AbortController(), t = setTimeout(() => ac.abort(), Math.max(200, budget || TV28_BUDGET_MS)), h = { 'Content-Type': 'audio/wav' };
    if (api.fakeText) h['X-Fake-Text'] = encodeURIComponent(api.fakeText);
    try { const r = await fetch('/stt?lang=' + (lang === 'zh' ? 'zh' : 'ja') + '&hint=' + encodeURIComponent(String(hint || '').slice(0, 200)), { method: 'POST', headers: h, body: blob, signal: ac.signal, cache: 'no-store' });
      let j = null; try { j = await r.json(); } catch (e) { j = null; }
      if (!r.ok) return { ok: false, err: (j && j.err) || 'http' + r.status, status: r.status };
      return j && j.ok ? { ok: true, text: String(j.text || '').slice(0, 120), kana: String(j.kana || '').slice(0, 120), ms: j.ms | 0 } : { ok: false, err: (j && j.err) || 'bad' }; }
    catch (e) { return { ok: false, err: e && e.name === 'AbortError' ? 'timeout' : 'net' }; }
    finally { clearTimeout(t); }
  }
  // https の ping（この スマホが 証明書を しんじているか）
  async function probe() {
    try { const r = await fetch('/tls/info', { cache: 'no-store' }); if (!r.ok) return null; const info = await r.json(); if (!info || !info.https || typeof info.url !== 'string') return null;
      const ac = new AbortController(), t = setTimeout(() => ac.abort(), TV28_PROBE_MS);
      try { const p = await fetch(info.url + 'tls/ping', { mode: 'cors', cache: 'no-store', signal: ac.signal }); return p.ok ? info.url : null; } finally { clearTimeout(t); } }
    catch (e) { return null; }
  }
  function httpsUrl(base, extra) { const q = new URLSearchParams(location.search); q.delete('nohttps'); if (extra) for (const k in extra) q.set(k, extra[k]); const s = q.toString();
    return base + location.pathname.replace(/^\//, '') + (s ? '?' + s : '') + '#tv28=' + encHash({ n: ls.get('dg-name') || '', l: ls.get('fp-lang') || '' }); }

  /* ---------- 読みこみの 時（ゲームの 前）：名前の 持ちこし・https へ ---------- */
  if (/[?&]nohttps=1(&|$)/.test(location.search)) ss.set('tv28-nohttps', '1');
  if (location.hash.startsWith('#tv28=')) { const o = decHash(location.hash.slice(6)); if (o) { if (o.n) ls.set('dg-name', o.n); if (o.l) ls.set('fp-lang', o.l); }
    try { history.replaceState(null, '', location.pathname + location.search); } catch (e) { /* のこっても こまらない */ } }
  const BOOT = { probe: null, url: null };
  if (GAME_PAGE && probeDecision({ role: PAGE_ROLE, protocol: location.protocol, hostname: location.hostname, search: location.search, noHttps: ss.get('tv28-nohttps') === '1', joined: false })) {
    BOOT.probe = probe().then(url => { BOOT.url = url; const C = api.ctx;
      if (url && !(C && C.me && C.me.joined)) { console.info('P11：https へ うつります'); location.replace(httpsUrl(url)); }
      return url; });
  }

  /* ---------- 見た目 ---------- */
  function css() { if (document.getElementById('tv28Css')) return; const s = document.createElement('style'); s.id = 'tv28Css'; s.textContent = `
#tv28Row{display:flex;gap:12px;width:100%;align-items:stretch}#tv28Row>#p3dCh{flex:1 1 auto;min-width:0;width:auto}
#tv28Mic{flex:0 0 22%;min-width:96px;max-width:200px;display:flex;flex-direction:column;gap:8px;align-items:stretch;justify-content:center}
#tv28Mic.small{flex-basis:76px;min-width:76px}
#tv28Big{position:relative;flex:1 1 auto;min-height:min(50vh,190px);border-radius:24px;border:5px solid #10201a;box-shadow:0 8px 0 #10201a,0 0 0 calc(var(--lv,0)*14px) rgba(255,90,90,.45);background:#fff3b0;color:#10201a;font-weight:900;font-size:clamp(14px,4.6vh,20px);line-height:1.15;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;padding:6px 4px;overflow:hidden}
#tv28Big i{font-style:normal;font-size:clamp(34px,14vh,62px);line-height:1}
#tv28Big b{position:absolute;left:0;bottom:0;height:8px;background:#ff5a5a;width:0}
#tv28Big.rec{background:#ff8a8a;animation:tv28Pulse 1s ease-in-out infinite}#tv28Big.think i{animation:tv28Spin 1s linear infinite}
#tv28Big.wait,#tv28Big.denied{background:#c9cfc9;opacity:.75}#tv28Big:active{transform:translateY(5px);box-shadow:0 3px 0 #10201a}
#tv28Mic.small #tv28Big{min-height:76px;flex:0 0 auto;font-size:12px}#tv28Mic.small #tv28Big i{font-size:30px}#tv28Mic.small #tv28Big span{display:none}
#tv28Act{display:flex;flex-direction:column;gap:6px;flex:1 1 auto;justify-content:center}
#tv28Act button{min-height:min(15vh,56px);border-radius:14px;border:3px solid #10201a;box-shadow:0 4px 0 #10201a;background:#fff;color:#10201a;font-weight:900;font-size:clamp(13px,4vh,17px);line-height:1.1;padding:2px 4px}
#tv28Act button.ok{background:#7fe08f;min-height:min(22vh,80px);font-size:clamp(15px,4.8vh,20px)}#tv28Act button:active{transform:translateY(3px);box-shadow:0 1px 0 #10201a}
#tv28Mic.small #tv28Act button{font-size:12px;min-height:44px}
#tv28Msg{margin:0;font-size:clamp(13px,4vh,17px);line-height:1.3;color:#ffe9a8;font-weight:900;min-height:1.3em}
#tv28Msg button{margin-left:6px;border-radius:99px;border:2px solid #ffe9a8;background:none;color:#ffe9a8;font-weight:900;padding:0 8px}
#p3dCh button.tv28Glow{box-shadow:0 0 0 6px #fff,0 0 22px 10px #ffd23a,0 8px 0 #10201a;animation:tv28Pulse 1s ease-in-out infinite}
#tv28Wait{margin-top:8px;display:flex}#tv28Wait button{flex:1;min-height:46px;box-shadow:0 4px 0 var(--ink,#10201a);border-radius:14px;border:3px solid var(--ink,#10201a);background:#e8ffe0;font:inherit;font-size:16px;font-weight:900;color:var(--ink,#10201a)}
#tv28Back{position:fixed;left:0;right:0;top:0;z-index:99;background:#c0392b;color:#fff;font-weight:900;font-size:16px;padding:10px;text-align:center;border:0;width:100%}
@keyframes tv28Pulse{0%,100%{filter:brightness(1)}50%{filter:brightness(1.18)}}@keyframes tv28Spin{to{transform:rotate(360deg)}}
#tv28Cap{position:absolute;z-index:16;left:50%;transform:translateX(-50%);top:82.4vh;width:min(92vw,162vh);display:flex;flex-direction:column;gap:.3vh;padding:.3vh;border-radius:1.4vh;background:rgba(10,16,12,.96);pointer-events:none}
#tv28Cap div{background:rgba(255,255,255,.04);border:.3vh solid var(--c,#fff);border-radius:1.2vh;padding:.25vh 1.4vh;color:#fff;font-weight:900;font-size:2.3vh;line-height:1.2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#tv28Cap div b{color:var(--c,#fff)}#tv28Cap div.rec{animation:tv28Pulse .9s ease-in-out infinite}#tv28Cap div em{font-style:normal;color:#ffd23a}
#tv28Btn{position:absolute;left:3.5vw;bottom:calc(3vh + 124px);z-index:9;padding:6px 12px;border-radius:99px;background:rgba(232,255,224,.92);border:2px solid #1b2a22;font-size:14px;font-weight:900}
#tv28Set{position:absolute;inset:4vh 4vw;z-index:60;background:#fff6dc;color:#1b2a22;border:6px solid #1b2a22;border-radius:2vh;padding:2.4vh 2.6vw;display:flex;flex-direction:column;gap:1.4vh;font-size:2.3vh;overflow:auto}
#tv28Set h2{margin:0;font-size:3.6vh}#tv28Set .cols{display:flex;gap:2.4vw;flex:1 1 auto;min-height:0}#tv28Set .st{flex:1 1 0;min-width:0;display:flex;flex-direction:column;gap:1vh;overflow-wrap:anywhere}
#tv28Set .st p{margin:0;line-height:1.35}#tv28Set .st code{font-size:1.8vh;word-break:break-all;background:#efe4c4;padding:0 .4vw;border-radius:.6vh}
#tv28Set .qr{flex:0 0 auto;display:flex;gap:1.4vw;justify-content:space-around;align-items:flex-start}#tv28Set .qr figure{margin:0;text-align:center;flex:1 1 0;display:flex;flex-direction:column;gap:.6vh;align-items:center}
#tv28Set .qr img{width:min(13vw,24vh);height:min(13vw,24vh);background:#fff;border:3px solid #1b2a22;border-radius:1vh}#tv28Set .qr figcaption{font-weight:900;font-size:2vh;line-height:1.25}
#tv28Set .btns{display:flex;gap:1vw;flex-wrap:wrap}#tv28Set button{font:inherit;font-weight:900;font-size:2.2vh;padding:.8vh 1.4vw;border-radius:1vh;border:3px solid #1b2a22;background:#fff;color:#1b2a22}
#tv28Set button.on{background:#7fe08f}#tv28Set .ok{color:#22894a}#tv28Set .ng{color:#c0392b}#tv28Set small{opacity:.7;font-size:1.7vh;line-height:1.3}`;
    document.head.appendChild(s); }

  /* ==================== ゲームに つなぐ ==================== */
  let C = null;
  function attach(ctx) { C = api.ctx = ctx; css(); if (ctx.ROLE === 'tv') tvInit(); else padInit(); api.ready = true; }
  const Lx = (ja, zh) => C.L(ja, zh);
  const LANGx = () => (C.lang() === 'zh' ? 'zh' : 'ja');
  const optsOf = st => (st && st.opts ? st.opts.map((o, i) => ({ ic: o.ic, ja: o.ja, zh: o.zh, off: !!(st.off && st.off.includes(i)) })) : []);

  /* ---------- テレビ ---------- */
  const TVS = { on: 0, hs: 0, ss: 'off', status: null, tls: null, stepObj: null, rec: {}, hd: {}, duckAt: 0, mac: null, macPeer: '', macStep: null, macLang: 'ja', capSig: '', btnSig: '', polled: 0, tlsPolled: 0, store: null };
  function cleanStore(v) { v = v && typeof v === 'object' ? v : {}; const c = v.cfg && typeof v.cfg === 'object' ? v.cfg : {}; return { v: 1, cfg: { macMic: c.macMic ? 1 : 0 } }; }
  function tvSave() { C.writeJSON(TV28_KEY, TVS.store); }
  function tvInit() {
    TVS.store = cleanStore(C.readJSON(TV28_KEY));
    const send = C.room.presence; C.room.presence = function (p) { if (p && p.role === 'tv' && p.g) { try { p.g.tv28 = tvPack(); } catch (e) { console.warn('P11：こえの 様子を 作れませんでした', e); } } return send.call(C.room, p); };
    C.room.on('cmd', m => { if (m.data && m.data.a === 'tv28') try { tvCmd(m.peer, m.data); } catch (e) { console.warn('P11：こえの 操作を 処理できませんでした', e); } });
    const cap = document.createElement('div'); cap.id = 'tv28Cap'; cap.className = 'hide'; document.body.appendChild(cap);
    const b = document.createElement('button'); b.id = 'tv28Btn'; b.className = 'hide'; b.onclick = () => { if (C.audioOn) C.audioOn(); tvOpenSetup(); }; document.body.appendChild(b);
    addEventListener('keydown', ev => { if (ev.key === 'Escape' && document.getElementById('tv28Set')) { tvCloseSetup(); ev.preventDefault(); ev.stopImmediatePropagation(); } }, true);
    C.hookAfter(tvAfter); tvPoll(true);
  }
  const ready = () => TVS.on === 1;
  function tvStep() { const SC = C.SC; if (!SC || !SC.on) return null; const st = C.cur(); return st && st.t === 'choice' ? st : null; }
  function tvMicOpen(st) { return !!(st && !C.SC.decided && !(C.voBusy && C.voBusy())); }
  function tvPack() {
    const G = C.G(), st = tvStep(), o = { on: TVS.on, hs: TVS.hs, ss: TVS.ss, mm: TVS.store.cfg.macMic, st: st ? C.SC.i : -1, mic: tvMicOpen(st) ? 1 : 0 };
    const rec = Object.keys(TVS.rec).map(id => G.pl[id] ? G.pl[id].slot : -1).filter(s => s >= 0); if (rec.length) o.rec = rec;
    const hd = {}; for (const id in TVS.hd) { const h = TVS.hd[id]; hd[id] = [h.masked, h.m, h.fails, h.n, h.why]; } if (Object.keys(hd).length) o.hd = hd;
    const S = TVS.status; if (S && S.state === 'downloading') o.dl = [S.done | 0, S.total | 0];
    return o;
  }
  function hdOf(id) { return TVS.hd[id] || (TVS.hd[id] = { text: '', kana: '', masked: '', m: -1, fails: 0, n: 0, why: '' }); }
  function tvHeard(id, st, text, kana, lang) {
    const r = match(text, kana, optsOf(st), lang), h = hdOf(id); h.text = text; h.kana = kana; h.masked = maskNG(text, kana, lang); h.n++; h.lang = lang;
    h.m = r.m; h.why = r.m >= 0 ? '' : r.off >= 0 ? 'off' : r.none ? 'none' : 'miss'; if (r.m < 0) h.fails++; delete TVS.rec[id]; return r;
  }
  function tvFail(id, why) { const h = hdOf(id); h.fails++; h.n++; h.m = -1; h.why = why; h.masked = ''; delete TVS.rec[id]; }
  function tvCmd(peer, d) {
    const G = C.G(); if (!G.pl[peer]) return;
    if (d.op === 'setup') { if (G.ph === 'lobby' && !C.SC.on) tvOpenSetup(); return; }
    const st = tvStep(); if (!st || d.i !== C.SC.i || (st.only && st.only !== peer)) return;
    const lang = d.l === 'zh' ? 'zh' : d.l === 'ja' ? 'ja' : LANGx(), str = v => String(v == null ? '' : v).slice(0, 120);
    if (d.op === 'rec') { if (d.on && !C.SC.decided) TVS.rec[peer] = performance.now(); else delete TVS.rec[peer]; }
    else if (d.op === 'heard') tvHeard(peer, st, str(d.text), str(d.kana), lang);
    else if (d.op === 'fail') tvFail(peer, ['quiet', 'timeout', 'err', 'denied'].includes(d.why) ? d.why : 'err');
    else if (d.op === 'clear') delete TVS.hd[peer];
    else if (d.op === 'macrec' && TVS.store.cfg.macMic) { if (d.on) tvMacStart(peer, st, lang); else tvMacStop(peer); }
  }
  // Mac の マイク（スマホの 🎤 で テレビの 画面が 録音する）
  async function tvMacStart(peer, st, lang) {
    if (TVS.mac && TVS.mac.rec) return; if (!tvMicOpen(st)) return;
    TVS.macPeer = peer; TVS.macStep = st; TVS.macLang = lang;
    try { if (!TVS.mac) TVS.mac = new Recorder({ ac: C.AC() || undefined, onAuto: (why, r) => tvMacDone(r) }); await TVS.mac.open(); }
    catch (e) { console.warn('P11：Mac の マイクが つかえません', e); tvFail(peer, 'denied'); return; }
    if (tvStep() !== st) return; TVS.mac.start(); TVS.rec[peer] = performance.now();
  }
  function tvMacStop(peer) { if (!TVS.mac || !TVS.mac.rec || peer !== TVS.macPeer) return; tvMacDone(TVS.mac.stop()); }
  async function tvMacDone(r) {
    const peer = TVS.macPeer, st = TVS.macStep, lang = TVS.macLang, t0 = performance.now(); delete TVS.rec[peer];
    const w = await toWav(r); if (tvStep() !== st) return; if (w.quiet) { tvFail(peer, 'quiet'); return; }
    const res = await upload(w.blob, lang, st.opts.map(o => lang === 'zh' ? o.zh : o.ja).join('、'), TV28_BUDGET_MS - (performance.now() - t0));
    if (tvStep() !== st) return; if (!res.ok) { tvFail(peer, res.err === 'timeout' ? 'timeout' : 'err'); return; } tvHeard(peer, st, res.text, res.kana, lang);
  }
  function tvAfter(dt, now) {
    const G = C.G(), st = tvStep();
    if (st !== TVS.stepObj) { TVS.stepObj = st; TVS.rec = {}; TVS.hd = {}; if (TVS.mac) { if (TVS.mac.rec) TVS.mac.stop(); if (!st) TVS.mac.close(); } if (TVS.duckAt) tvUnduck(); }
    if (st && C.SC.decided && Object.keys(TVS.rec).length) { TVS.rec = {}; if (TVS.mac && TVS.mac.rec) TVS.mac.stop(); }
    for (const id in TVS.rec) if (!G.pl[id]) delete TVS.rec[id];
    // 録音の 間は 曲を 小さく（毎コマ。p4vAfter の 後に 動く）
    const any = Object.keys(TVS.rec).length > 0;
    if (any) { if (!TVS.duckAt) TVS.duckAt = now; if (now - TVS.duckAt > TV28_DUCK_SAFE_MS) { TVS.rec = {}; tvUnduck(); } else tvDuck(); } else if (TVS.duckAt) tvUnduck();
    tvCaption(st, G);
    const b = document.getElementById('tv28Btn'); if (b) { const show = G.ph === 'lobby' && C.view() === 'lobby' && !C.SC.on; b.classList.toggle('hide', !show); const t = Lx('🎤 こえの じゅんび', '🎤 声音准备') + (ready() ? ' ✓' : ''); if (b.textContent !== t) b.textContent = t; }
    if (document.getElementById('tv28Set') && (G.ph !== 'lobby' || C.SC.on)) tvCloseSetup();
    if (now - TVS.polled > TV28_POLL_MS) tvPoll(false);
  }
  function tvDuck() { const P = C.P4V, AC = C.AC(); if (!P || !P.music || !AC) return; const t = AC.currentTime;
    for (const [g, v] of [[P.music, 0.10], [P.sfx, 0.50]]) { g.gain.cancelScheduledValues(t); g.gain.setValueAtTime(v, t); } }
  function tvUnduck() { TVS.duckAt = 0; const P = C.P4V; if (P && P.music) { P.ducked = true; C.duck(false); } }
  function tvCaption(st, G) {
    const box = document.getElementById('tv28Cap'); if (!box) return; const lines = [];
    if (st) for (const p of C.players()) { const r = TVS.rec[p.id], h = TVS.hd[p.id]; if (!r && !h) continue; const nm = esc(p.name), col = (C.PCOL && C.PCOL[p.slot]) || '#fff';
      if (r) lines.push([col, 'rec', '🎤 ' + Lx(`<b>${nm}</b> が はなしています…`, `<b>${nm}</b> 正在说…`)]);
      else if (h.m >= 0 && st.opts[h.m]) { const o = st.opts[h.m]; lines.push([col, '', `🎤 <b>${nm}</b>　` + Lx('きこえた ことば：', '听到的话：') + `『${esc(h.masked)}』 → <em>${esc(o.ic || '')} ${esc(Lx(o.ja, o.zh))}</em>`]); }
      else if (h.why === 'off') lines.push([col, '', `🎤 <b>${nm}</b>　『${esc(h.masked)}』 ` + Lx('それは いまは えらべないよ', '这个现在不能选')]);
      else if (h.why === 'denied') lines.push([col, '', `🎤 <b>${nm}</b>　` + Lx('マイクが つかえません。カードを タップしてね', '麦克风不能用，请点卡片')]);
      else lines.push([col, '', `🎤 <b>${nm}</b>　` + (h.masked ? `『${esc(h.masked)}』` : '') + Lx('？ もういちど いってね', '？再说一次吧')]); }
    const sig = JSON.stringify(lines.slice(0, 4)); if (sig === TVS.capSig) return; TVS.capSig = sig; box.classList.toggle('hide', !lines.length);
    box.innerHTML = lines.slice(0, 4).map(([c, cls, h]) => `<div class="${cls}" style="--c:${c}">${h}</div>`).join('');
  }
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  async function tvPoll(force) {
    TVS.polled = performance.now();
    try { const r = await fetch('/stt/status', { cache: 'no-store' }); if (r.status === 404) { TVS.status = null; TVS.ss = 'off'; TVS.on = 0; } else if (r.ok) { const s = await r.json(); TVS.status = s; TVS.ss = s && s.on ? String(s.state || 'off') : 'off'; TVS.on = TVS.ss === 'ready' ? 1 : 0; } }
    catch (e) { TVS.on = 0; TVS.ss = 'off'; }
    if (force || performance.now() - TVS.tlsPolled > TV28_TLS_POLL_MS || document.getElementById('tv28Set')) { TVS.tlsPolled = performance.now();
      try { const r = await fetch('/tls/info', { cache: 'no-store' }); TVS.tls = r.ok ? await r.json() : null; } catch (e) { TVS.tls = null; } TVS.hs = TVS.tls && TVS.tls.https ? 1 : 0; }
    if (document.getElementById('tv28Set')) tvFillSetup();
  }
  // テレビ：こえの じゅんび（https・聞きとり・証明書・QR・Mac の マイク）
  function tvOpenSetup() { if (document.getElementById('tv28Set')) return; const d = document.createElement('div'); d.id = 'tv28Set'; document.body.appendChild(d); tvFillSetup(); tvPoll(true); }
  function tvCloseSetup() { const d = document.getElementById('tv28Set'); if (d) d.remove(); }
  function tvFillSetup() {
    const d = document.getElementById('tv28Set'); if (!d) return; const S = TVS.status, T = TVS.tls, mm = TVS.store.cfg.macMic, ss = TVS.ss;
    const stt = !S ? `<span class="ng">✗ ${Lx('きく 部品が ありません（タップで あそべます）', '没有识别组件（可以用点的方式玩）')}</span>`
      : ss === 'ready' ? `<span class="ok">✓ ${Lx('きく じゅんび OK', '识别准备好了')}${S.msBench ? '（' + (S.msBench / 1000).toFixed(1) + Lx(' びょう', ' 秒') + '）' : ''}・${esc(S.model || '')}</span>`
      : ss === 'downloading' ? `⏳ ${Lx('ダウンロード中', '下载中')} ${S.total ? Math.floor(100 * (S.done | 0) / S.total) : 0}%`
      : ss === 'loading' ? `⏳ ${Lx('よみこみ中…', '读取中…')}`
      : ss === 'nomodel' ? `<span class="ng">✗ ${Lx('きく ための データが ありません', '没有识别用的数据')}</span>${S.err ? '<br><small>' + esc(S.err) + '</small>' : ''}${S.url ? `<br><small>${Lx('ブラウザで ダウンロード：', '用浏览器下载：')}</small><code>${esc(S.url)}</code>` : ''}${S.dir ? `<br><small>${Lx('おく ばしょ：', '放到：')}</small><code>${esc(S.dir)}</code>` : ''}`
      : `<span class="ng">✗ ${esc(ss)}${S.err ? '：' + esc(S.err) : ''}</span>`;
    const tls = T && T.https ? `<span class="ok">✓ https ${esc(T.url || '')}</span>` + (T.caName ? `<br><small>${esc(T.caName)}<br>SHA-256 ${esc(T.caSha256 || '')}</small>` : '') : `<span class="ng">✗ ${Lx('https なし（スマホは タップだけ）', '没有 https（手机只能点）')}</span>`;
    const q = (u, n, ja, zh) => `<figure><img alt="" src="/qr.svg?u=${u}&t=${Math.floor(Date.now() / 60000)}"><figcaption>${n} ${Lx(ja, zh)}</figcaption></figure>`;
    d.innerHTML = `<h2>🎤 ${Lx('こえで こたえる じゅんび', '用声音回答的准备')}</h2><div class="cols"><div class="st">
<p><b>${Lx('きく 部品', '识别')}：</b>${stt}</p><p><b>${Lx('あんぜんな つながり', '安全连接')}：</b>${tls}</p>
<p><small>${Lx('スマホ 1 だいずつ：① で しょうめいしょを いれる → ② で ゲームに はいる → ③ で こえの テスト。いれなくても タップで あそべます', '每台手机：用 ① 安装证书 → 用 ② 进游戏 → 用 ③ 测试声音。不装也可以用点的方式玩')}</small></p>
<div class="btns"><button id="tv28MM" class="${mm ? 'on' : ''}">🖥 ${Lx('Mac の マイクで きく：', '用 Mac 的麦克风：')}${mm ? 'ON' : 'OFF'}</button><button id="tv28Test">🧪 ${Lx('Mac で テスト', '在 Mac 上测试')}</button>
${S && S.dir ? `<button id="tv28Dir">📂 ${Lx('フォルダーを ひらく', '打开文件夹')}</button>` : ''}${S && (ss === 'nomodel' || ss === 'error') ? `<button id="tv28Retry">🔁 ${Lx('もういちど ダウンロード', '重新下载')}</button>` : ''}<button id="tv28Close">✖ ${Lx('とじる', '关闭')}</button></div>
<small>${Lx('こえは この Mac の 中だけ。もじに したら すぐ きえます。ネットには おくりません', '声音只在这台 Mac 里，变成文字后马上删除，不会发到网上')}<br>${api.CREDITS.join('<br>')}</small></div>
<div class="qr">${T && T.https ? q('setup', '①', 'しょうめいしょ', '证书') + q('tls', '②', 'ゲーム（https）', '游戏（https）') + q('test', '③', 'こえの テスト', '声音测试') : q('setup', '①', 'こえの じゅんび', '声音准备')}</div></div>`;
    const on = (id, f) => { const b = document.getElementById(id); if (b) b.onclick = f; };
    on('tv28MM', () => { TVS.store.cfg.macMic = mm ? 0 : 1; tvSave(); tvFillSetup(); }); on('tv28Close', tvCloseSetup);
    on('tv28Test', () => { try { window.open('/voice-test', '_blank'); } catch (e) { location.href = '/voice-test'; } });
    const post = body => fetch('/stt/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then(() => tvPoll(true)).catch(e => console.warn('P11：設定を 送れませんでした', e));
    on('tv28Dir', () => post({ openDir: true })); on('tv28Retry', () => post({ retry: true }));
  }

  /* ---------- スマホ ---------- */
  const PS = { step: -1, state: 'idle', fails: 0, m: -1, heard: '', small: false, rec: null, tok: 0, hdN: -1, mmWait: false, help: false, sig: '', waitSig: '', probeUrl: null, probing: false, wsAt: 0 };
  const sendTv = d => { C.room.emit('cmd', Object.assign({ a: 'tv28', i: PS.step }, d)).catch(e => console.warn('P11：こえの 操作を 送れませんでした', e)); };
  function padInit() {
    const ch = document.getElementById('p3dCh'); if (!ch) return; const row = document.createElement('div'); row.id = 'tv28Row'; ch.parentNode.insertBefore(row, ch);
    const mic = document.createElement('div'); mic.id = 'tv28Mic'; mic.className = 'hide';
    const big = document.createElement('button'); big.id = 'tv28Big'; big.innerHTML = '<i>🎤</i><span></span><b></b>'; big.onclick = () => padMicTap();
    const act = document.createElement('div'); act.id = 'tv28Act'; act.className = 'hide';
    for (const [id, cls, f] of [['tv28Ok', 'ok', padOk], ['tv28Again', '', padMicTap], ['tv28Self', '', padSelf]]) { const b = document.createElement('button'); b.id = id; if (cls) b.className = cls; b.onclick = f; act.appendChild(b); }
    mic.append(big, act); row.append(mic, ch);
    const msg = document.createElement('p'); msg.id = 'tv28Msg'; msg.className = 'hide'; row.after(msg);
    const box = document.getElementById('p3dBox'), w = document.createElement('div'); w.id = 'tv28Wait'; w.className = 'hide'; if (box) box.before(w);   // ボスの こえ・クレジットの 上（スマホの 横画面で 見える ところ）
    document.addEventListener('visibilitychange', () => { if (document.hidden) padEndStep(); });
    PS.wsAt = performance.now(); C.hookPad(padRender);
  }
  function padView() {
    const ps = C.room.peers(), host = ps.find(p => p.presence && p.presence.role === 'tv'), self = ps.find(p => p.isMe), g = host && host.presence.g ? host.presence.g : null, mine = g && self && g.pl ? g.pl[self.peer] : null;
    return { g, self, mine, o: g && g.p3d, t: g && g.tv28 && typeof g.tv28 === 'object' ? g.tv28 : null };
  }
  function padEndStep() { PS.tok++; if (PS.rec) { if (PS.rec.rec) { PS.rec.stop(); sendTv({ op: 'rec', on: 0 }); } PS.rec.close(); } if (PS.mmWait && PS.state === 'rec') sendTv({ op: 'macrec', on: 0 });
    PS.state = 'idle'; PS.fails = 0; PS.m = -1; PS.heard = ''; PS.small = false; PS.mmWait = false; PS.help = false; padGlow(-1); }
  function padGlow(i) { const ch = document.getElementById('p3dCh'); if (ch) [...ch.children].forEach((b, k) => b.classList.toggle('tv28Glow', k === i)); }
  function padCards() { const v = padView(); return v.o && Array.isArray(v.o.ch) ? v.o.ch[2].map((q, i) => ({ ic: q[0], ja: q[1], zh: q[2], off: !!(v.o.of && v.o.of.includes(i)) })) : []; }
  function padFail(why) { PS.fails++; PS.state = why === 'quiet' ? 'quiet' : why === 'timeout' ? 'timeout' : why === 'denied' ? 'denied' : 'err'; if (PS.fails >= 2) PS.small = true; sendTv({ op: 'fail', why }); }
  async function padMicTap() {
    const v = padView(), t = v.t; if (!t || PS.state === 'think' || PS.step < 0) return;
    if (PS.state === 'rec') { if (PS.mmWait) { sendTv({ op: 'macrec', on: 0 }); PS.state = 'think'; PS.mmAt = performance.now(); } else if (PS.rec && PS.rec.rec) padGot(PS.rec.stop()); return; }
    if (!t.mic) return; padGlow(-1); PS.m = -1; C.vibrate(20);
    if (t.mm && !(window.isSecureContext && Recorder.can())) { const h = t.hd && self0(v) && t.hd[self0(v)]; PS.hdN = h ? h[3] : -1; PS.mmWait = true; PS.mmSeen = false; PS.mmAt = performance.now(); PS.state = 'rec'; sendTv({ op: 'macrec', on: 1, l: LANGx() }); return; }
    const step = PS.step, tok = ++PS.tok;
    try { if (!PS.rec) PS.rec = new Recorder({ onAuto: (why, r) => padGot(r) }); await PS.rec.open(); }
    catch (e) { console.warn('P11：マイクが つかえません', e); if (tok === PS.tok) padFail('denied'); return; }
    if (tok !== PS.tok || step !== PS.step) return; PS.rec.start(); PS.state = 'rec'; sendTv({ op: 'rec', on: 1 });
  }
  const self0 = v => (v.self ? v.self.peer : '');
  async function padGot(r) {
    const step = PS.step, tok = ++PS.tok, t0 = performance.now(); PS.state = 'think'; sendTv({ op: 'rec', on: 0 });
    let w; try { w = await toWav(r); } catch (e) { console.warn('P11：音を つくれませんでした', e); w = null; }
    if (tok !== PS.tok || step !== PS.step) return; if (!w) { padFail('err'); return; } if (w.quiet) { padFail('quiet'); return; }
    const cards = padCards(), lang = LANGx(), res = await upload(w.blob, lang, cards.map(c => lang === 'zh' ? c.zh : c.ja).join('、'), TV28_BUDGET_MS - (performance.now() - t0));
    if (tok !== PS.tok || step !== PS.step) return;   // おそい 答えは すてる
    if (!res.ok) { padFail(res.err === 'timeout' ? 'timeout' : 'err'); return; }
    const m = match(res.text, res.kana, padCards(), lang); PS.heard = maskNG(res.text, res.kana, lang); sendTv({ op: 'heard', text: res.text, kana: res.kana, l: lang });
    padResult(m.m, m.off >= 0 ? 'off' : m.none ? 'none' : 'miss');
  }
  function padResult(m, why) { if (m >= 0) { PS.state = 'match'; PS.m = m; padGlow(m); C.vibrate([20, 40, 20]); } else { PS.state = why === 'off' ? 'offhit' : why === 'quiet' ? 'quiet' : why === 'timeout' ? 'timeout' : why === 'err' || why === 'denied' ? why : 'nomatch'; PS.fails++; if (PS.fails >= 2) PS.small = true; } }
  function padOk() { const ch = document.getElementById('p3dCh'), b = ch && ch.children[PS.m]; if (b && !b.disabled) b.click(); }
  function padSelf() { PS.state = 'idle'; PS.small = true; PS.m = -1; padGlow(-1); sendTv({ op: 'clear' }); }
  function padRender() {
    const v = padView(), o = v.o, t = v.t, mine = v.mine, sc = o && mine && Array.isArray(o.sc) ? o.sc : null, choice = !!(sc && sc[2] === 1 && Array.isArray(o.ch));
    const step = choice ? sc[0] : -1; if (step !== PS.step) { padEndStep(); PS.step = step; }
    padBack(); padWait(v, sc);
    const slot = mine ? mine[0] | 0 : -1, only = choice && Array.isArray(o.on) ? o.on : null, me1 = !only || only[0] === slot, id = self0(v);
    const voted = choice && ((o.vt && o.vt[id] !== undefined) || !!document.querySelector('#p3dCh button.mine')), dec = choice && o.dc !== undefined;
    const secure = window.isSecureContext && Recorder.can(), avail = choice && me1 && !dec && !voted && t && t.on === 1 && (secure || t.mm === 1) && t.st === sc[0];
    const mic = document.getElementById('tv28Mic'), msg = document.getElementById('tv28Msg'); if (!mic) return;
    if (!avail) { if (PS.state === 'rec' || PS.state === 'think') { PS.tok++; if (PS.rec && PS.rec.rec) { PS.rec.stop(); sendTv({ op: 'rec', on: 0 }); } PS.state = 'idle'; }
      mic.classList.add('hide'); msg.classList.add('hide'); if (choice && (voted || dec)) padGlow(PS.state === 'match' ? PS.m : -1); return; }
    // Mac の マイク：テレビの 答えを まつ
    if (PS.mmWait) { const h = t.hd && t.hd[id], recNow = Array.isArray(t.rec) && t.rec.includes(slot);
      if (recNow) PS.mmSeen = true; if (PS.state === 'rec' && !recNow && (PS.mmSeen || (h && h[3] !== PS.hdN))) PS.state = 'think';
      if (h && h[3] !== PS.hdN && PS.state !== 'rec') { PS.hdN = h[3]; PS.mmWait = false; PS.heard = h[0] || ''; padResult(h[1], h[4]); }
      // テレビが こたえない時（はじまらない・答えが こない）は 札で えらぶ
      else if (PS.mmWait && ((PS.state === 'rec' && !PS.mmSeen && performance.now() - PS.mmAt > TV28_MM_START_MS) || (PS.state === 'think' && performance.now() - PS.mmAt > TV28_MM_WAIT_MS))) {
        if (PS.state === 'rec') sendTv({ op: 'macrec', on: 0 }); PS.mmWait = false; PS.heard = ''; padResult(-1, 'timeout'); } }
    const st = !t.mic && PS.state === 'idle' ? 'wait' : PS.state, big = document.getElementById('tv28Big'), act = document.getElementById('tv28Act');
    mic.classList.remove('hide'); msg.classList.remove('hide'); mic.classList.toggle('small', PS.small && st !== 'rec' && st !== 'think');
    const showAct = st === 'match' || st === 'nomatch' || st === 'offhit' || st === 'quiet' || st === 'timeout' || st === 'err';
    big.classList.toggle('hide', showAct); act.classList.toggle('hide', !showAct);
    if (PS.rec && PS.rec.rec) { big.style.setProperty('--lv', PS.rec.level.toFixed(2)); big.lastChild.style.width = Math.min(100, PS.rec.t / TV28_REC_MAX_S * 100) + '%'; } else if (big.style.getPropertyValue('--lv')) { big.style.removeProperty('--lv'); big.lastChild.style.width = '0'; }
    const sig = [st, PS.small, PS.m, PS.heard, PS.help, C.lang(), PS.fails].join('|'); if (sig === PS.sig) return; PS.sig = sig;
    for (const c of ['rec', 'think', 'wait', 'denied']) big.classList.toggle(c, st === c);
    big.firstChild.textContent = st === 'think' ? '⏳' : st === 'denied' ? '🚫' : st === 'rec' ? '⏹' : '🎤';
    big.children[1].textContent = st === 'rec' ? Lx('おわり', '结束') : st === 'think' ? '' : st === 'denied' ? Lx('つかえない', '不能用') : Lx('はなす', '说话');
    document.getElementById('tv28Ok').textContent = '✅ ' + Lx('これで いい', '就这个'); document.getElementById('tv28Again').textContent = '🎤 ' + Lx('もういちど', '再说一次');
    document.getElementById('tv28Self').textContent = '👆 ' + Lx('じぶんで えらぶ', '自己选'); document.getElementById('tv28Ok').classList.toggle('hide', st !== 'match');
    const q = PS.heard ? `『${PS.heard}』` : '', T = {
      wait: Lx('ボスの おはなしを きいてね…（タップでも OK）', '先听首领说话…（也可以点卡片）'),
      idle: PS.small ? Lx('カードを タップしてね（🎤 も つかえるよ）', '请点卡片（也可以用 🎤）') : Lx('🎤 を おして こたえを いってね。タップでも OK', '按 🎤 说出回答。点卡片也可以'),
      rec: Lx('● きいてるよ…（もういちど おすと おわり）', '● 在听…（再按一次结束）'), think: Lx('…かんがえちゅう', '…正在想'),
      match: Lx('きこえた：', '听到了：') + q, nomatch: PS.small ? q + Lx('？ カードを タップしてね（🎤 も つかえるよ）', '？请点卡片（也可以用 🎤）') : q + Lx('？ もういちど いってね', '？再说一次吧'),
      offhit: q + ' ' + Lx('それは いまは えらべないよ', '这个现在不能选'), quiet: Lx('こえが ちいさいよ', '声音太小了'),
      timeout: Lx('うまく きこえなかった。タップで えらんでね', '没听清，请点卡片'), err: Lx('うまく きこえなかった。タップで えらんでね', '没听清，请点卡片'),
      denied: Lx('マイクが つかえません。カードを タップしてね', '麦克风不能用，请点卡片') }[st] || '';
    msg.textContent = T;
    if (st === 'denied') { const hb = document.createElement('button'); hb.textContent = '？'; hb.onclick = () => { PS.help = !PS.help; PS.sig = ''; }; msg.appendChild(hb);
      if (PS.help) msg.appendChild(document.createTextNode('　' + Lx('iPhone：設定 → アプリ → Safari → マイク → 許可／Android：アドレスバーの 🔒 → 権限 → マイク', 'iPhone：设置 → App → Safari → 麦克风 → 允许／Android：地址栏的 🔒 → 权限 → 麦克风'))); }
  }
  // https で つながらない時：ふつうの モードへ もどる 帯
  function padBack() { if (location.protocol !== 'https:' || PS.backDone) return; if (C.room.connected) { PS.backDone = true; const b = document.getElementById('tv28Back'); if (b) b.remove(); return; }
    if (performance.now() - PS.wsAt < TV28_WS_WAIT_MS || document.getElementById('tv28Back')) return;
    const b = document.createElement('button'); b.id = 'tv28Back'; b.textContent = Lx('つながりません → ふつうの モードに もどる', '连不上 → 回到普通模式');
    b.onclick = () => { location.href = 'http://' + location.hostname + ':' + TV28_HTTP_PORT + '/?nohttps=1&auto=1'; }; document.body.appendChild(b); }
  // 待合室の 1 つの ボタン（こえの じゅんび／じゅんびちゅう／OK）
  function padWait(v, sc) {
    const w = document.getElementById('tv28Wait'); if (!w) return; const t = v.t, g = v.g, secure = window.isSecureContext && Recorder.can();
    let item = null;
    if (C.me.joined && g && v.mine && g.ph === 'lobby' && !sc && t && t.ss && t.ss !== 'off') {
      if (!secure) { if (t.hs) { if (!PS.probing && PS.probeUrl === null) { PS.probing = true; (BOOT.probe || probe()).then(u => { PS.probeUrl = u || ''; PS.probing = false; }); }
        item = PS.probeUrl ? ['go', Lx('🎤 こえで あそぶ（きりかえる）', '🎤 用声音玩（切换）')] : ['setup', Lx('🎤 こえを つかう じゅんび', '🎤 准备使用声音')]; } }
      else if (t.ss === 'ready') item = ['test', Lx('🎤 こえ：OK（テスト）', '🎤 声音：OK（测试）')];
      else if (t.ss === 'downloading') { const p = t.dl && t.dl[1] ? Math.floor(100 * t.dl[0] / t.dl[1]) : 0; item = ['test', Lx(`🎤 こえ：じゅんびちゅう ${p}%`, `🎤 声音：准备中 ${p}%`)]; }
      else item = ['test', Lx('🎤 こえ：じゅんびちゅう', '🎤 声音：准备中')];
    }
    const sig = item ? item.join('|') : ''; if (sig === PS.waitSig) return; PS.waitSig = sig; w.classList.toggle('hide', !item); w.textContent = ''; if (!item) return;
    const b = document.createElement('button'); b.textContent = item[1];
    b.onclick = () => { if (item[0] === 'go') { location.href = httpsUrl(PS.probeUrl, { auto: '1' }); return; }
      if (item[0] === 'setup') { sendTv({ op: 'setup' }); setTimeout(() => { location.href = '/voice-setup'; }, 150); } else location.href = '/voice-test'; };   // テレビにも じゅんびの 画面（QR）を 出す
    w.appendChild(b);
  }

  api.attach = attach; api.Recorder = Recorder; api.toWav = toWav; api.upload = upload; api.probe = probe; api.httpsUrl = httpsUrl; api.boot = BOOT;
  api._tv = TVS; api._pad = PS;   // 確かめ用
  root.TankTalkVoice = api;
})(typeof window !== 'undefined' ? window : globalThis);

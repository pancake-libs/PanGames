/* 戦車のゲームの面（26 × 26 の升。戦車は 2 × 2 升）。
   tk1〜tk15 は TK（https://github.com/sunsharebay-lgtm/TK の 坦克大战、v1.6.14）の面と敵の割合を、作者の許可を得て写したもの（2026-11-14、D-015）。
   grass は自作（TK の 1 面目は 1985 年のファミコンのゲームの 1 面とほぼ同じ形のため使わない。ADR-04）。
   文字：. 地面 B レンガ S 鋼 W 水 T 木 I 氷 D 砂。おうち・出口・味方の出る所は、計算（tank-sim.js）が置く。
   この面のデータは make_stages.py で作った。面を直す時は、ここを直接直してよい */
(function (root) {
  'use strict';
  const MAPS = {
    grass: [
      "..........................",
      "..........................",
      "..TTTT....BBBBBB....TTTT..",
      "..TTTT....BBBBBB....TTTT..",
      "..........................",
      "BBBB..WWWW......WWWW..BBBB",
      "BBBB..WWWW......WWWW..BBBB",
      ".........TT....TT.........",
      "..BB.....TT....TT.....BB..",
      "..BB..BBBB..SS..BBBB..BB..",
      "..BB..BBBB..SS..BBBB..BB..",
      "..........................",
      "TTTT..BB..TTTTTT..BB..TTTT",
      "TTTT..BB..TTTTTT..BB..TTTT",
      "..........................",
      "..SS..BBBBBB..BBBBBB..SS..",
      "..SS..BB..........BB..SS..",
      "......BB..WWWWWW..BB......",
      "..........WWWWWW..........",
      "..........................",
      "..BBBB..TT......TT..BBBB..",
      "..BBBB..TT......TT..BBBB..",
      "..........................",
      "..........................",
      "..........................",
      ".........................."
    ],
    tk1: [
      "..........................",
      "..SS..SS..SS..SS..SS..SS..",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "....BBBB........BBBB......",
      "....BBBB........BBBB......",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..........................",
      "SS......SS......SS......SS",
      "SS......SS......SS......SS",
      "..BBBBBB..BBBB..BBBBBB....",
      "..BBBBBB..BBBB..BBBBBB....",
      "..........................",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..........................",
      "BBBB......BBBBBB......BBBB",
      "BBBB......BBBBBB......BBBB",
      "..........................",
      "..........................",
      "..........................",
      ".........................."
    ],
    tk2: [
      "..........................",
      "..........................",
      "..BB..BBBBBBBBBBBB..BB....",
      "..BB..BBBBBBBBBBBB..BB....",
      "..BB..............BB..BB..",
      "..BB..............BB..BB..",
      "WWWWWW..WWWWWW..WWWWWW....",
      "WWWWWW..WWWWWW..WWWWWW....",
      "..........................",
      "..BBBB..BB..BB..BBBB..BB..",
      "..BBBB..BB..BB..BBBB..BB..",
      "..........................",
      "..WWWW..WWWWWWWW..WWWW....",
      "..WWWW..WWWWWWWW..WWWW....",
      "..........................",
      "BB..BBBB..BBBB..BBBB..BBBB",
      "BB..BBBB..BBBB..BBBB..BBBB",
      "..........................",
      "..SS..............SS......",
      "..SS..............SS......",
      "..BBBBBB......BBBBBB......",
      "..BBBBBB......BBBBBB......",
      "..........................",
      "..........................",
      "..........................",
      ".........................."
    ],
    tk3: [
      "..........................",
      "..TTTT......TTTT......TTTT",
      "..TTTT......TTTT......TTTT",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "TTTT..TTTTTTTTTTTT..TTTTTT",
      "TTTT..TTTTTTTTTTTT..TTTTTT",
      "..BB..............BB......",
      "..BB..............BB......",
      "..BB..BBBBBBBBBB..BB..BB..",
      "..BB..BBBBBBBBBB..BB..BB..",
      "......BB......BB..........",
      "......BB......BB..........",
      "TTTTTTBB......BBTTTTTTTT..",
      "TTTTTTBB......BBTTTTTTTT..",
      "......BBBBBBBBBB..........",
      "......BBBBBBBBBB..........",
      "..BB..............BB..BB..",
      "..BB..............BB..BB..",
      "..TTTT..TTTTTT..TTTT..TT..",
      "..TTTT..TTTTTT..TTTT..TT..",
      "..........................",
      "..BB..BB......BB..BB......",
      "..BB..BB......BB..BB......",
      "..........................",
      ".........................."
    ],
    tk4: [
      "..........................",
      "..IIIIIIIIIIIIIIIIIIIIII..",
      "..II..BB..BB..BB..BB..II..",
      "..II..BB..BB..BB..BB..II..",
      "..II..II..II..II..II..II..",
      "..II..II..II..II..II..II..",
      "SSII..IIIIIIIIIIII..IISS..",
      "SSII..IIIIIIIIIIII..IISS..",
      "..II..II......II..II......",
      "..II..II......II..II......",
      "..IIIIII..BB..IIIIII..BB..",
      "..IIIIII..BB..IIIIII..BB..",
      "..........BB..............",
      "..........BB..............",
      "BBII..IIIIIIIIIIIIII..IIBB",
      "BBII..IIIIIIIIIIIIII..IIBB",
      "..II..............II......",
      "..II..............II......",
      "..IIII..BBBBBB..IIII..BB..",
      "..IIII..BBBBBB..IIII..BB..",
      "..........................",
      "..BB..IIII......IIII..BB..",
      "..BB..IIII......IIII..BB..",
      "..........................",
      "..........................",
      ".........................."
    ],
    tk5: [
      "..........................",
      "..........................",
      "BB....BB..BB..BB..BB....BB",
      "BB..BBBB..BB..BB..BBBB..BB",
      "BB..BB......BB......BB..BB",
      "BB..BB..BBBBBBBBBB..BB..BB",
      "BB..BB..BB......BB..BB..BB",
      "BB..BBBBBB..BB..BB..BB..BB",
      "BB......BB..BB..BB......BB",
      "BBBBBB..BB..BB..BBBBBBBBBB",
      "........BB..BB............",
      "BBBBBB..BB..BBBBBB..BBBBBB",
      "BB..BB..BB......BB..BB..BB",
      "BB..BB..BBBBBB..BB..BB..BB",
      "BB..BB......BB..BB..BB..BB",
      "BB..BBBBBB..BB..BB..BB..BB",
      "BB......BB..BB..BB..BB..BB",
      "BBBBBB..BB..BB..BB..BB..BB",
      "........BB..BB..BB......BB",
      "BBBBBB..BB..BB..BBBBBB..BB",
      "BB..BB..BB..BB......BB..BB",
      "BB..BB..BB..BBBBBB..BB..BB",
      "BB..BB......BB..BB..BB..BB",
      "BB..BBBB..BBBB....BBBB..BB",
      "..........................",
      ".........................."
    ],
    tk6: [
      "..........................",
      "..........................",
      "..SS..BBBBBBBBBBBB..SS....",
      "..SS..BBBBBBBBBBBB..SS....",
      "..SS..BB........BB..SS....",
      "..SS..BB..SSSS..BB..SS....",
      "..SS..BB..SSSS..BB..SS....",
      "..SS..BB........BB..SS....",
      "..SS..BBBBBB..BBBB..SS....",
      "..SS................SS....",
      "..SSSSSS..BBBB..SSSSSS....",
      "..........BBBB............",
      "BBBB..BB..BBBB..BB..BBBB..",
      "BBBB..BB........BB..BBBB..",
      "......BB..SSSS..BB........",
      "..BB..BB..SSSS..BB..BB....",
      "..BB..BBBBBBBBBBBB..BB....",
      "..BB..............BB..BB..",
      "..BBBBBB..BBBB..BBBBBB....",
      "..........BBBB............",
      "SS..BBBB..BBBB..BBBB..SS..",
      "SS..BBBB........BBBB..SS..",
      "..........................",
      "..BB..........BB..........",
      "..........................",
      ".........................."
    ],
    tk7: [
      "..........................",
      "..BB..................BB..",
      "..BB..BBBBBBBBBBBB....BB..",
      "..BB..BB........BB....BB..",
      "..BB..BB..BBBB..BB....BB..",
      "..BB..BB..BBBB..BB....BB..",
      "..BB..BB........BB....BB..",
      "..BB..BBBBBB..BBBB....BB..",
      "..BB..................BB..",
      "..BBBBBBBB..BBBBBBBBBBBB..",
      "..........................",
      "BBBBBB..BBBBBBBBBB..BBBBBB",
      "..........................",
      "..BB..BBBBBB..BBBBBB..BB..",
      "..BB..BB........BB....BB..",
      "..BB..BB..SSSS..BB....BB..",
      "..BB..BB..SSSS..BB....BB..",
      "..BB..BB........BB....BB..",
      "..BB..BBBBBBBBBBBB....BB..",
      "..BB..................BB..",
      "..BBBBBB......BBBBBB..BB..",
      "..........................",
      "..BB..BB......BB..BB......",
      "..BB..BB......BB..BB......",
      "..........................",
      ".........................."
    ],
    tk8: [
      "..........................",
      "..........................",
      "BBBB..BBBB..BBBB..BBBB..BB",
      "BBBB..BBBB..BBBB..BBBB..BB",
      "..........................",
      "WWWWWWWW....WWWWWWWW......",
      "WWWWWWWW....WWWWWWWW......",
      "WWWWWWWW....WWWWWWWW......",
      "..........................",
      "..BB..BBBBBBBBBBBB..BB....",
      "..BB..BB........BB..BB....",
      "..BB..BB..SSSS..BB..BB....",
      "..BB..BB..SSSS..BB..BB....",
      "..BB..BB........BB..BB....",
      "..BB..BBBB..BBBBBB..BB....",
      "..........................",
      "....WWWWWWWW....WWWWWWWW..",
      "....WWWWWWWW....WWWWWWWW..",
      "....WWWWWWWW....WWWWWWWW..",
      "..........................",
      "..BBBB..BBBB..BBBB..BBBB..",
      "..BBBB..BBBB..BBBB..BBBB..",
      "..........................",
      "..BB..............BB......",
      "..........................",
      ".........................."
    ],
    tk9: [
      "..........................",
      "..TT..IIIIIIIIIIII..TT....",
      "..TT..IIIIIIIIIIII..TT....",
      "..TT..II........II..TT....",
      "..TT..II..BBBB..II..TT....",
      "..TT..II..BBBB..II..TT....",
      "..TT..II........II..TT....",
      "..TT..IIIIII..IIII..TT....",
      "..TT..............TT..TT..",
      "IIIIII..BBBBBB..IIIIII....",
      "IIIIII..BBBBBB..IIIIII....",
      "..........................",
      "..BB..TTTT..TTTT..BB..BB..",
      "..BB..TTTT..TTTT..BB..BB..",
      "..BB..............BB..BB..",
      "..BBBBBB..SSSS..BBBBBB....",
      "..........SSSS............",
      "IIII..BB..............BB..",
      "IIII..BB..IIIIIIII..BB....",
      "......BB..IIIIIIII..BB....",
      "..TTTT....IIIIIIII....TTTT",
      "..TTTT................TTTT",
      "..........................",
      "..BB..BB......BB..BB......",
      "..........................",
      ".........................."
    ],
    tk10: [
      "..........................",
      "..SS..SS..SS..SS..SS..SS..",
      "..SS..SS..SS..SS..SS..SS..",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "SSSS..SSSS..SSSS..SSSS..SS",
      "BBBB..BBBB..BBBB..BBBB..BB",
      "..........................",
      "..BBBBBBBB..BBBBBBBB..BB..",
      "..BB....BB..BB....BB..BB..",
      "..BB..SSBB..BBSS..BB..BB..",
      "..BB..SSBB..BBSS..BB..BB..",
      "..BB....BB..BB....BB..BB..",
      "..BBBBBBBB..BBBBBBBB..BB..",
      "..........................",
      "SS..BBBB..SSSSSS..BBBB..SS",
      "SS..BBBB..SSSSSS..BBBB..SS",
      "..........................",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..SS..SS..SS..SS..SS..SS..",
      "..........................",
      "BBBB......BBBBBB......BBBB",
      "..........................",
      "..........................",
      ".........................."
    ],
    tk11: [
      "..........................",
      "..SS..BBBB..SSSS..BBBB..SS",
      "..SS..BBBB..SSSS..BBBB..SS",
      "..........................",
      "WWWW..IIII..BBBB..IIII..WW",
      "WWWW..IIII..BBBB..IIII..WW",
      "..........................",
      "..BBBBBB..TTTTTT..BBBBBB..",
      "..BB..BB..TTTTTT..BB..BB..",
      "..BB..BB..........BB..BB..",
      "..BB..BBBBSSSSBBBBBB..BB..",
      "..BB..BBBBSSSSBBBBBB..BB..",
      "..BB..............BB..BB..",
      "..BBBBBB..BBBB..BBBBBB....",
      "..........BBBB............",
      "IIII..SS..BBBB..SS..IIII..",
      "IIII..SS........SS..IIII..",
      "......SS..BBBB..SS........",
      "..BB..SSSSBBBBSSSS..BB....",
      "..BB..............BB..BB..",
      "..BBBB..TTTT..TTTT..BBBB..",
      "..BBBB..TTTT..TTTT..BBBB..",
      "..........................",
      "..BB..BB......BB..BB......",
      "..........................",
      ".........................."
    ],
    tk12: [
      "..........................",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BBBB....BB..",
      "..BB..BB..BB..BBBB....BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "......BBSSBB..BBSSBB......",
      "......BBSSBB..BBSSBB......",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "....BB..BBBBBBBB..BB......",
      "....BB..BBBBBBBB..BB......",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "....BBBB........BBBB......",
      "....BBBB........BBBB......",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "......SSSS..SSSS..........",
      "......SSSS..SSSS..........",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..........................",
      "..........................",
      ".........................."
    ],
    tk13: [
      "..........................",
      "..WW..WWWWWW..WWWWWW..WW..",
      "..WW..WWWWWW..WWWWWW..WW..",
      "..BB..WWWWWW..WWWWWW..BB..",
      "..BB..WWWWWW..WWWWWW..BB..",
      "..........................",
      "..WW..WWWWWW..WWWWWW..WW..",
      "..WW..WWWWWW..WWWWWW..WW..",
      "..BB..BBBBBB..BBBBBB..BB..",
      "..BB..BBBBBB..BBBBBB..BB..",
      "...........BB.............",
      "...........BB.............",
      "..........................",
      "BB..WWWW..WWWWWW..WWWW..BB",
      "BB..WWWW..WWWWWW..WWWW..BB",
      "..WW..WW..WWWW..WW..WW....",
      "..WW..WW..WWWW..WW..WW....",
      "..BB..BB..BBBB..BB..BB....",
      "..BB..BB..BBBB..BB..BB....",
      "..........................",
      "..SS..SS..SSSS..SS..SS....",
      "..SS..SS..SSSS..SS..SS....",
      "..........................",
      "..BB..BB......BB..BB......",
      "..........................",
      ".........................."
    ],
    tk14: [
      "..........................",
      "..SS..BBBB..SS..BBBB..SS..",
      "..SS..BBBB..SS..BBBB..SS..",
      "..BB..SSSS..BB..SSSS..BB..",
      "..BB..SSSS..BB..SSSS..BB..",
      "..........................",
      "..WW..BBBB..WW..BBBB..WW..",
      "..WW..BBBB..WW..BBBB..WW..",
      "..BB..WWWW..BB..WWWW..BB..",
      "..BB..WWWW..BB..WWWW..BB..",
      "SS..BB..SS..BB..SS..BB..SS",
      "SS..BB..SS..BB..SS..BB..SS",
      "..........................",
      "..BBBB..SS..BBBB..SS......",
      "..BBBB..SS..BBBB..SS......",
      "..SS..BBBB..SS..BBBB......",
      "..SS..BBBB..SS..BBBB......",
      "..........................",
      "..BB..WW..BB..WW..BB..BB..",
      "..BB..WW..BB..WW..BB..BB..",
      "..SS..BB..SS..BB..SS..SS..",
      "..SS..BB..SS..BB..SS..SS..",
      "..........................",
      "..BB..BB..BB..BB..BB..BB..",
      "..........................",
      ".........................."
    ],
    tk15: [
      "..........................",
      "..DD..DD..DD..DD..DD..DD..",
      "..DD..DD..DD..DD..DD..DD..",
      "..DD..DD..DD..DDDD....DD..",
      "..DD..DD..DD..DDDD....DD..",
      "..DD..DD..DD..DD..DD..DD..",
      "..DD..DD..DD..DD..DD..DD..",
      "......DDSSDD..DDSSDD......",
      "......DDSSDD..DDSSDD......",
      "..DD..DD..DD..DD..DD..DD..",
      "..DD..DD..DD..DD..DD..DD..",
      "....DD..DDDDDDDD..DD......",
      "....DD..DDDDDDDD..DD......",
      "..DD..DD..DD..DD..DD..DD..",
      "..DD..DD..DD..DD..DD..DD..",
      "WWWW..DDDD..DDDD..WWWW....",
      "WWWW..DDDD..DDDD..WWWW....",
      "..DD..DD..DD..DD..DD..DD..",
      "..DD..DD..DD..DD..DD..DD..",
      "......SSSS..SSSS..........",
      "......SSSS..SSSS..........",
      "..DD..DD..DD..DD..DD..DD..",
      "..DD..DD..DD..DD..DD..DD..",
      "..........................",
      "..........................",
      ".........................."
    ],
  };
  /* 面ごとの敵の割合（ふつう・はやい・どっしり・かたい）。人数に合わせて数を増やす */
  const MIX = {"grass": [12, 4, 3, 1], "tk1": [10, 4, 4, 2], "tk2": [8, 5, 5, 2], "tk3": [6, 6, 6, 2], "tk4": [8, 4, 6, 2], "tk5": [6, 5, 7, 2], "tk6": [4, 6, 7, 3], "tk7": [5, 5, 7, 3], "tk8": [4, 7, 6, 3], "tk9": [3, 6, 8, 3], "tk10": [2, 7, 8, 3], "tk11": [2, 5, 9, 4], "tk12": [6, 5, 6, 2], "tk13": [4, 6, 7, 3], "tk14": [3, 6, 8, 3], "tk15": [5, 6, 7, 2]};

  /* 面の仕掛け（TK の 12 種と同じ考え）。名前・説明は自作。効き目は tank-sim.js の FX */
  const FX_NAME = {
    none: ['ふつうの戦場', '标准战场'], steel: ['鋼の守り：おうちの囲いがはじめから鋼', '铁壁：小屋围墙开局即钢墙'],
    valley: ['急流：敵が速い', '急流：敌人更快'], jungle: ['森：木の中の戦車はねらわれにくい', '丛林：树中的坦克不易被瞄准'],
    ice: ['氷：氷の上はすべる', '冰面：冰上会滑行'], frenzy: ['弾幕：敵がよく撃つ', '弹幕：敌人射速提高'],
    siege: ['攻城：敵がおうちをねらう', '围城：敌人集中攻打小屋'], rush: ['車列：敵が早く速く来る', '车流：敌人增援更快'],
    snow: ['雪：味方が遅く、氷でよくすべる', '雪原：我方变慢，冰上滑得更远'], blood: ['血戦：敵がかたい', '血战：敌人更耐打'],
    sand: ['砂：味方が遅い', '沙地：我方变慢'], desert: ['砂漠：ときどき砂嵐で見えにくい', '沙漠：不时有沙尘暴，看不清'], lava: ['溶岩：水のそばで止まると熱い（5 秒でやられる）', '熔岩：在岸边停留 5 秒会受伤'],
    snowland: ['雪山：氷の上はよくすべる', '雪山：冰面上滑得很远'], volcano: ['火山：溶岩のそばで止まると熱い（5 秒でやられる）', '火山：在熔岩边停留 5 秒会受伤'],
    fortress: ['機械要塞：動く壁・スイッチ（撃つと壁が入れかわる）・ワープ', '机械要塞：移动墙、开关（射击可切换墙）、传送门'], inferno: ['地獄：溶岩のそばで止まると熱い。敵がとても強い', '地狱：在熔岩边停留会受伤，敌人非常强']
  };
  /* ふつうの 6 面（周回する）。partner は 3〜4 人の時に横へつなぐ面。面の並びと仕掛けは TK の物語の 6 面と同じ（1 面目だけ自作） */
  const CAMPAIGN = [
    { id: 'grass', ja: '草原', zh: '草原', map: 'grass', partner: 'tk1', fx: 'none', music: 'battle1' },
    { id: 'ice', ja: '氷の原っぱ', zh: '冰原', map: 'tk4', partner: 'tk9', fx: 'ice', music: 'battle2' },
    { id: 'sand', ja: '砂の町', zh: '沙漠', map: 'tk15', partner: 'tk12', fx: 'sand', music: 'battle1' },
    { id: 'lava', ja: '溶岩の町', zh: '熔岩', map: 'tk13', partner: 'tk8', fx: 'lava', music: 'battle2' },
    { id: 'jungle', ja: '深い森', zh: '深林', map: 'tk3', partner: 'tk2', fx: 'jungle', music: 'battle1' },
    { id: 'last', ja: '最後の守り', zh: '最终防线', map: 'tk11', partner: 'tk7', fx: 'blood', music: 'boss', boss: 'boss' }
  ];
  /* おまけの 5 面（1 周クリアすると選べる）。TK の残りの面と仕掛け */
  const EXTRA = [
    { id: 'x1', ja: '鉄の柵', zh: '铁栅阵地', map: 'tk1', partner: 'tk7', fx: 'steel', music: 'battle2' },
    { id: 'x2', ja: '谷川', zh: '河谷', map: 'tk2', partner: 'tk8', fx: 'valley', music: 'battle1' },
    { id: 'x3', ja: '十字路', zh: '十字路口', map: 'tk7', partner: 'tk1', fx: 'rush', music: 'battle2' },
    { id: 'x4', ja: '二つの川', zh: '双河', map: 'tk8', partner: 'tk2', fx: 'valley', music: 'battle1' },
    { id: 'x5', ja: '雪の森', zh: '雪林', map: 'tk9', partner: 'tk4', fx: 'snow', music: 'battle2' }
  ];
  /* 地獄の 5 面。どの面にも首領（TK の首領の考え）が出る。最後に超ボス */
  const HELL = [
    { id: 'h1', ja: '地獄・とりで', zh: '地狱·要塞', map: 'tk6', partner: 'tk10', fx: 'siege', music: 'hell' },
    { id: 'h2', ja: '地獄・めいろ', zh: '地狱·迷宫', map: 'tk5', partner: 'tk14', fx: 'frenzy', music: 'hell' },
    { id: 'h3', ja: '地獄・鋼のあらし', zh: '地狱·钢铁风暴', map: 'tk10', partner: 'tk6', fx: 'frenzy', music: 'hell' },
    { id: 'h4', ja: '地獄・地下工場', zh: '地狱·地下工厂', map: 'tk14', partner: 'tk5', fx: 'rush', music: 'hell' },
    { id: 'h5', ja: '地獄・決戦', zh: '地狱·决战', map: 'tk12', partner: 'tk1', fx: 'sand', music: 'hellboss', boss: 'superboss' }
  ];


  /* ================= ぼうけん（v0.11、開発の第 2 歩）：世界 1 草原・世界 2 砂漠 の 48 面。v0.13 で 世界 3 雪山・世界 4 火山 を足して 96 面。v0.14 で 世界 5 機械要塞・地獄 を足して 144 面 =================
     1 つの世界は 24 面。4 面は手作り（上の地図）、残りは「部品」を並べて自動で作る（面の番号が種）。
     部品は 13 × 13 升の小部屋。中を 5 × 5 の「大きな升」（2 × 2 升）で描き、右と下の 2 升・左と上の 1 升は通り道として空ける
     （部屋どうしの間に 3 升の通り道ができる）。左右は鏡に写して同じ形にする（片側だけ不利にならない）。
     文字：. 地面 B レンガ S 鋼 W 水 T 木 D 砂（味方も敵も遅くなる） */
  const ROOM_W1 = [
    ['.....', '.B.B.', '..T..', '.B.B.', '.....'], ['.....', 'BB.BB', '.....', '.S.S.', '.....'], ['.....', '.WWW.', '.....', 'B...B', 'B.T.B'],
    ['TT..T', 'T....', '..B..', '....T', 'T..TT'], ['.BBB.', '.B.B.', '.....', '.S.S.', '.....'], ['..B..', '..B..', 'BB.BB', '..B..', '..T..'],
    ['B....', 'BB...', '.BB..', '..BB.', '...B.'], ['.....', '.S.S.', '.....', '.BTB.', '.....'], ['.....', 'WW.WW', '.....', '.B.B.', '.B.B.'],
    ['.B...', '.B.BB', '.B...', '...B.', 'BB.B.'], ['.....', '..T..', '.TTT.', '..T..', '.....'], ['B.B.B', '.....', 'B.B.B', '.....', 'B.B.B'],
    ['BB...', 'B....', '...SS', '....S', '.T...'], ['.....', 'W...W', 'W.B.W', '..B..', '.....']
  ];
  const ROOM_W2 = [
    ['DD...', 'DDD..', '..B..', '..DDD', '...DD'], ['.B.B.', '.....', '.S.S.', '.....', '.B.B.'], ['..T..', '.WWW.', 'TW.WT', '.WWW.', '.....'],
    ['SS.SS', 'S...S', '..D..', 'S...S', 'SS.SS'], ['.DDD.', 'DDDDD', 'DD.DD', 'DDDDD', '.DDD.'], ['.....', '..B..', '.BBB.', 'BBSBB', '.....'],
    ['B.B.B', 'B.B.B', '.....', '.B.B.', '.B.B.'], ['.....', '.T.T.', '..S..', '.T.T.', '.....'], ['.....', 'BBBB.', '.....', '.BBBB', '.....'],
    ['S...S', '..D..', '.DSD.', '..D..', 'S...S'], ['DDDDD', '.....', '.B.B.', '.....', 'DD.DD'], ['SBBBS', 'B...B', 'B.D.B', '.....', '.....'],
    ['...DD', '..DD.', '.DD..', 'DD...', 'D...B'], ['S.S.S', '.....', '.D.D.', '.....', 'S.S.S']
  ];
  /* 世界 3 雪山（v0.13）：I 氷（よくすべる）・T 雪の木・S 岩・W 凍らない池 */
  const ROOM_W3 = [
    ['.....', '.III.', '.ISI.', '.III.', '.....'], ['T...T', '.B.B.', '..I..', '.B.B.', 'T...T'], ['IIIII', '.....', '.S.S.', '.....', 'IIIII'],
    ['..T..', '.TTT.', 'TTSTT', '.....', '..B..'], ['.....', 'BIIIB', 'B...B', 'BIIIB', '.....'], ['S...S', '.....', '..W..', '.....', 'S...S'],
    ['II...', 'IIB..', '..B..', '..BII', '...II'], ['.....', '.B.B.', 'IIIII', '.B.B.', '.....'], ['.T.T.', '.....', 'BB.BB', '.....', '.T.T.'],
    ['.....', '.WWW.', '.III.', '.....', 'B.S.B'], ['S.I.S', '..I..', 'IIIII', '..I..', 'S.I.S'], ['BBB..', 'B....', 'B.II.', '...II', '..T..'],
    ['.....', 'TT.TT', '.....', 'S...S', 'SB.BS'], ['..S..', '.I.I.', 'S.B.S', '.I.I.', '..S..']
  ];
  /* 世界 4 火山（v0.13）：W 溶岩（通れない。そばで止まると熱い）・S 岩・B レンガ・D 灰（遅くなる）・T 枯れ木 */
  const ROOM_W4 = [
    ['.....', '.WWW.', '.W.W.', '.....', 'S...S'], ['S.B.S', '.....', 'BBSBB', '.....', 'S.B.S'], ['DD.DD', 'D...D', '..W..', 'D...D', 'DD.DD'],
    ['..S..', '.SWS.', '..S..', '.....', 'B...B'], ['W...W', '.B.B.', '.....', '.B.B.', 'W...W'], ['.....', 'SSBSS', '.....', '.T.T.', '.....'],
    ['B..WW', 'B...W', 'BB...', '...BB', 'W...B'], ['.....', '.DDD.', 'BDWDB', '.DDD.', '.....'], ['S...S', 'S.B.S', '..B..', 'S.B.S', 'S...S'],
    ['.WW..', '..W..', '.....', '..BBB', '..B..'], ['T.T.T', '.....', 'SBSBS', '.....', '.....'], ['.....', 'W.S.W', '.....', 'B.B.B', 'B.B.B'],
    ['..D..', '.DSD.', 'DS.SD', '.DSD.', '..D..'], ['BBBBB', '.....', '..W..', '.....', 'S.S.S']
  ];
  /* 世界 5 機械要塞（v0.14）：S 鋼・B レンガ・G／J 動く壁（G と J が交代で開け閉めする。計算が g（開き）に変える）・K スイッチ（味方が撃つと壁が入れかわる） */
  const ROOM_W5 = [
    ['.....', '.SGS.', '.J.J.', '.SGS.', '.....'], ['S...S', '.BBB.', '.BKB.', '.BBB.', 'S...S'], ['GG.JJ', '.....', 'S.K.S', '.....', 'JJ.GG'],
    ['.S.S.', '.S.S.', '.....', 'BBGBB', '.....'], ['B.B.B', '.....', 'SJSGS', '.....', 'B.B.B'], ['.....', '.SSS.', '.....', 'G...J', 'G...J'],
    ['SS..S', 'S....', '..K..', '....S', 'S..SS'], ['.B.B.', 'BB.BB', '..S..', 'BB.BB', '.B.B.'], ['.....', 'JJGGJ', '.....', '.S.S.', '.....'],
    ['S.S.S', '.....', 'S.B.S', '.....', 'S.S.S'], ['..G..', '..G..', 'SS.SS', '..J..', '..J..'], ['BBBBB', '.....', 'S.K.S', '.....', 'BBBBB'],
    ['.....', '.GJG.', '.J.J.', '.GJG.', '.....'], ['S..BB', 'S...B', '..S..', 'B...S', 'BB..S']
  ];
  /* 地獄（v0.14）：W 溶岩・S 岩・B レンガ・D 灰・T 枯れ木 */
  const ROOM_W6 = [
    ['S.W.S', '.....', 'WBSBW', '.....', 'S.W.S'], ['.....', '.WWW.', '.WSW.', '.WWW.', '.....'], ['BB.BB', 'B...B', '..S..', 'B...B', 'BB.BB'],
    ['SS.SS', '.....', '.D.D.', '.....', 'SS.SS'], ['W...W', 'W.B.W', '..B..', 'W.B.W', 'W...W'], ['.T.T.', 'SBSBS', '.....', 'BSBSB', '.T.T.'],
    ['..S..', '.SWS.', 'SW.WS', '.SWS.', '..S..'], ['DDDDD', 'D...D', 'D.S.D', 'D...D', 'DDDDD'], ['B.B.B', 'S.S.S', '.....', 'S.S.S', 'B.B.B'],
    ['.....', 'WW.WW', '.....', '.SBS.', '.....'], ['S...S', '.BBB.', '.BWB.', '.BBB.', 'S...S'], ['.WW..', '.W...', '...SS', '..BBS', '.....'],
    ['T...T', '.S.S.', '..W..', '.S.S.', 'T...T'], ['BBBBB', 'S...S', '..D..', 'S...S', 'BBBBB']
  ];
  /* ボス（ぼうけんで出る 6 体）。name＝名前、enter＝出てくる時、defeat＝倒された時。spk：L・R は ふたご の左右。
     子どもが読めるよう、ひらがなを多めにした。台詞は自動では進まない（全員がスマホの「読んだ」を押すと次へ。JUN の指示） */
  const BOSS_TALK = {
    twin: { name: ['ふたご砲', '双炮坦克'], kana: 'ふたごほう', enter: [{ spk: 'L', ja: 'にいちゃん、みぎだ！', zh: '哥，右边！' }, { spk: 'R', ja: 'いや、ひだりだ！', zh: '不，左边！' }],
      defeat: [{ ja: '…つぎは そうだんしてから きめような', zh: '…下次商量好再决定吧' }] },
    engineer: { name: ['工兵車', '工兵车'], kana: 'こうへいしゃ', enter: [{ ja: 'このかべ、みっか かけて つんだんだ！ こわすなよ！', zh: '这堵墙我砌了三天！别打坏！' }],
      defeat: [{ ja: '…まあいい。また つむのも たのしいしな', zh: '…算了，再砌一遍也挺开心' }] },
    bigtank: { name: ['大型戦車', '大型坦克'], kana: 'おおがたせんしゃ', enter: [{ ja: 'ここは とおさん。…もう まもるものも ないのにな', zh: '此路不通。…明明已经没什么可守了' }],
      defeat: [{ ja: 'いいうでだ。この はらっぱ、おまえたちに まかせる', zh: '好身手。这片草原，交给你们了' }] },
    burrower: { name: ['砂もぐり', '钻沙者'], kana: 'すなもぐり', enter: [{ ja: 'は、はずかしいから みないで！（ズボッ）', zh: '别、别看我，好害羞！（噗）' }],
      defeat: [{ ja: '…でてきて、よかったかも', zh: '…出来一下，好像也不错' }] },
    scorpion: { name: ['さそり戦車', '蝎子坦克'], kana: 'さそりせんしゃ', enter: [{ ja: 'みよ、この しっぽ！ しゃしんは 1まい 100コインだ！', zh: '看我这尾巴！拍照一张 100 金币！' }],
      defeat: [{ ja: 'ポーズを きめるまえに うつな…', zh: '我还没摆好姿势你就开炮…' }] },
    sandship: { name: ['砂上戦艦', '沙上战舰'], kana: 'さじょうせんかん', enter: [{ ja: 'ぜんほうもん、ひらけー！ きょうは なみが たかいぞ！', zh: '全炮门，开火！今天浪很大！' }],
      defeat: [{ ja: '…そうか、うみじゃ なかったのか。いちど、ほんものを みたかったな', zh: '…原来这里不是海。真想看一次真正的海' }] },
    // 世界 3 雪山・世界 4 火山（v0.13。台詞は計画の文書のとおり）
    plow: { name: ['除雪車', '除雪车'], kana: 'じょせつしゃ', enter: [{ ja: 'ゆきも！ いわも！ せんしゃも！ ぜーんぶ かたづけまーす！', zh: '雪也好！石头也好！坦克也好！统统清理干净！' }],
      defeat: [{ ja: 'やすむのも… しごとのうち… ですね', zh: '休息…也是工作的一部分…对吧' }] },
    icegun: { name: ['氷の砲台', '冰之炮台'], kana: 'こおりのほうだい', enter: [{ ja: '…さむい？ しらない。かえって', zh: '…冷？不知道。回去吧' }],
      defeat: [{ ja: '…べ、べつに たのしくなかったわけじゃ ない', zh: '…才、才不是一点都不开心呢' }] },
    snowman: { name: ['雪だるま戦車', '雪人坦克'], kana: 'ゆきだるませんしゃ', enter: [{ ja: 'また あいに きてくれたの？ じゃあ、あそぼう！', zh: '你们又来看我啦？那我们一起玩吧！' }],
      defeat: [{ ja: 'たのしかった。らいねんの ふゆも、また つくってね', zh: '好开心。明年冬天，也要再把我堆起来哦' }] },
    flamer: { name: ['火炎放射車', '火焰喷射车'], kana: 'かえんほうしゃしゃ', enter: [{ ja: 'もえろォォ！ オレの たましいィィ！', zh: '燃烧吧！我的灵魂！' }],
      defeat: [{ ja: '…ちょっと もえすぎた。みず ください', zh: '…烧过头了。给我点水' }] },
    golem: { name: ['溶岩ごれむ', '熔岩魔像'], kana: 'ようがんごれむ', enter: [{ ja: 'ボク… あったかい ところが、すきな だけ…', zh: '我…只是喜欢暖和的地方…' }],
      defeat: [{ ja: 'おふろ… いっしょに… はいる？', zh: '泡澡…要一起…泡吗？' }] },
    dragon: { name: ['火竜戦車', '火龙坦克'], kana: 'かりゅうせんしゃ', enter: [{ ja: 'ひとのこよ、わが ほのおを うけてみよ！', zh: '人之子啊，接下我的火焰吧！' }],
      defeat: [{ ja: 'つばさは なくとも、そらは ちかかった。れいを いう', zh: '纵然没有翅膀，天空也曾那么近。多谢了' }] },
    // 世界 5 機械要塞・地獄（v0.14。台詞は計画の文書のとおり）。双子戦車は 2 台（姉 sisA・妹 sisB）で 1 体のボス。spk：A＝姉、B＝妹
    sisA: { name: ['双子戦車', '双子坦克'], kana: 'ふたごせんしゃ', enter: [{ spk: 'B', ja: 'ねえさん、きょうの おやつ なに？', zh: '姐，今天吃什么零食？' }, { spk: 'A', ja: 'たたかいの さいちゅうでしょ！', zh: '正在打仗呢！' }],
      defeat: [{ ja: '…ふたり いっしょなら、こわくないね', zh: '…只要两个人在一起，就不怕了' }] },
    sisB: { name: null, enter: [], defeat: [] },
    airship: { name: ['空中艇', '飞艇'], kana: 'くうちゅうてい', enter: [{ ja: 'したの みなさま ごきげんよう。おりる？ めんどうですわ', zh: '下面的各位日安。下去？好麻烦哦' }],
      defeat: [{ ja: 'じめんって… いがいと ふかふか ですのね', zh: '地面…原来还挺软的呢' }] },
    core: { name: ['要塞コア', '要塞核心'], kana: 'ようさいこあ', enter: [{ ja: 'しんにゅうしゃを かくにん。…しつもん。わたしは なにを まもって いるのですか', zh: '确认入侵者。…提问：我到底在守护什么？' }],
      defeat: [{ ja: '…わかりました。まもるものは ばしょではなく、だれか だったのですね', zh: '…明白了。要守护的不是地方，是某个人' }] },
    shadow: { name: ['闇の戦車', '暗黑坦克'], kana: 'やみのせんしゃ', enter: [{ ja: 'ひとりは さみしい。だから、ぼくは ぼくを ふやした', zh: '一个人好寂寞。所以，我把自己变多了' }],
      defeat: [{ ja: 'きみたちは よにんで ひとつ なんだね。うらやましいな', zh: '你们四个人是一体的呢。真羡慕' }] },
    superstar: { name: ['超ボス', '超级首领'], kana: 'ちょうぼす', enter: [{ ja: 'おまたせ！ じごくの スーパースター、とうじょうだァ！', zh: '让大家久等了！地狱超级巨星，登场！' }],
      defeat: [{ ja: '…アンコールは、なしで たのむ', zh: '…返场就免了吧' }] },
    king: { name: ['戦車の王', '坦克之王'], kana: 'せんしゃのおう', enter: [{ ja: 'わがこらを こえてきたか。…ならば ちちとして、おうとして、さいごに ためそう', zh: '你们超越了我的孩子们吗。…那么，作为父亲、作为王，最后试你们一次' }],
      defeat: [{ ja: 'つよく なったな。この せかいの あしたは、おまえたちの ものだ', zh: '你们变强了。这个世界的明天，属于你们' }] }
  };
  /* v0.22 P5A 場面（No.52）。1 つのワールドの 24 面が いくつかの場面を旅する。lvl＝場面の むずかしさ（ふるさととの差で s を足し引き）、
     theme＝地面の色・fx＝ふつうの仕掛け・rooms＝自動の地図の部品・music＝曲（面の番号で 2 つを交代）。storm・sand・ice・ash は前の WORLDS と同じ意味 */
  const SCENES = {
    grass: { ja: '草原', zh: '草原', ic: '🌼', lvl: 0, theme: 'grass', fx: 'none', rooms: ROOM_W1, music: ['battle1', 'battle2'] },
    forest: { ja: '森', zh: '森林', ic: '🌲', lvl: 0.5, theme: 'jungle', fx: 'jungle', rooms: ROOM_W1, music: ['battle1', 'battle2'] },
    valley: { ja: '川べり', zh: '河边', ic: '🏞', lvl: 0.5, theme: 'grass', fx: 'valley', rooms: ROOM_W1, music: ['battle1', 'battle2'] },
    sand: { ja: '砂漠', zh: '沙漠', ic: '🏜', lvl: 1, theme: 'sand', fx: 'desert', rooms: ROOM_W2, music: ['battle1', 'battle2'], storm: true, sand: 0.18 },
    snow: { ja: '雪山', zh: '雪山', ic: '⛄', lvl: 2, theme: 'snow', fx: 'snowland', rooms: ROOM_W3, music: ['battle3', 'battle4'], ice: 0.12 },
    lava: { ja: '火山', zh: '火山', ic: '🌋', lvl: 3, theme: 'lava', fx: 'volcano', rooms: ROOM_W4, music: ['battle1', 'battle2'], ash: 0.1 },
    metal: { ja: '機械要塞', zh: '机械要塞', ic: '⚙', lvl: 4, theme: 'metal', fx: 'fortress', rooms: ROOM_W5, music: ['battle3', 'battle4'] },
    hell: { ja: '地獄', zh: '地狱', ic: '🔥', lvl: 5, theme: 'hell', fx: 'inferno', rooms: ROOM_W6, music: ['hell', 'hell'], ash: 0.08 } };
  /* ===== P7 BEGIN（v0.24）：景色がわり（No.56）。場面ごとに 3〜4 の景色。番号 0 は今の見た目（何も足さない）。
     pal・tree＝[色相の足し算(度), 彩度 ×, 明るさ ×]（地面・木の色を HSL で動かす）、amb＝[r,g,b,a]（うすく重ねる色）か null、
     decor＝{ 飾りの名前: 量 }（hot は溶岩・地獄の光る割れ目の量）、hot＝光る色（無ければ今の色）。絵は tank.html が描く ===== */
  const LK = (id, ja, zh, ic, pal, tree, amb, decor, hot) => ({ id, ja, zh, ic, pal, tree, amb, decor, hot: hot || null });
  const LOOKS = {
    grass: [LK('flower', 'はなばたけ', '花田', '🌼', [0, 1, 1], [0, 1, 1], null, { flowers: 1 }),
      LK('sunset', 'ゆうやけの はたけ', '夕阳农田', '🌇', [-32, 0.9, 1.05], [-25, 0.9, 0.95], [255, 150, 60, 0.08], { hay: 1, stubble: 1 }),
      LK('edge', 'もりの いりぐち', '森林入口', '🍄', [8, 0.9, 0.88], [0, 1, 0.9], null, { leaves: 1, mushrooms: 0.6 }),
      LK('river', 'かわべ', '河边', '🦆', [24, 1.0, 1.05], [10, 1, 1], null, { reeds: 1, pebbles: 1.5, puddles: 0.5 })],
    forest: [LK('deep', 'ふかい もり', '密林', '🌲', [0, 1, 1], [0, 1, 1], null, { flowers: 1 }),
      LK('mush', 'きのこの もり', '蘑菇森林', '🍄', [30, 0.8, 0.92], [20, 0.9, 0.95], [150, 110, 255, 0.05], { mushrooms: 2, leaves: 0.5 }),
      LK('autumn', 'あきの もり', '秋天的森林', '🍂', [-45, 0.95, 1.05], [-70, 1.1, 1.05], [255, 170, 80, 0.05], { leaves: 2.5 })],
    valley: [LK('green', 'みどりの かわべり', '绿色河畔', '🏞', [0, 1, 1], [0, 1, 1], null, { flowers: 1 }),
      LK('mist', 'あさもやの かわ', '晨雾小河', '🌫', [15, 0.7, 1.1], [10, 0.8, 1.05], [235, 245, 255, 0.07], { reeds: 1.5, puddles: 1 }),
      LK('stones', 'いしころ がわら', '卵石河滩', '🪨', [5, 0.55, 1.0], [0, 0.9, 1], null, { pebbles: 4, reeds: 0.5 })],
    sand: [LK('noon', 'ひるの さばく', '正午沙漠', '🏜', [0, 1, 1], [0, 1, 1], null, {}),
      LK('dusk', 'ゆうひの さばく', '夕阳沙漠', '🌅', [-14, 1.15, 0.95], [0, 1, 0.95], [255, 120, 70, 0.08], { ripples: 1.5 }),
      LK('oasis', 'オアシス', '绿洲', '🌴', [14, 0.95, 1.0], [15, 1.2, 1.05], null, { palms: 1, flowers: 0.4, puddles: 0.4 }),
      LK('beach', 'しろい すなはま', '白沙滩', '🐚', [6, 0.5, 1.12], [0, 1, 1], null, { shells: 1.5, ripples: 0.5 })],
    snow: [LK('white', 'まっしろ せつげん', '白茫茫雪原', '⛄', [0, 1, 1], [0, 1, 1], null, {}),
      LK('lake', 'こおりの みずうみ', '冰湖', '🧊', [-8, 1.6, 0.94], [0, 1, 1], null, { icecracks: 1.5 }),
      LK('aurora', 'オーロラの よあけ', '极光黎明', '🌌', [40, 1.3, 0.93], [0, 1, 0.95], [120, 255, 200, 0.06], { tracks: 0.5 }),
      LK('thaw', 'ゆきどけ', '融雪', '🌱', [0, 1, 0.97], [0, 1, 1], null, { thaw: 1, puddles: 0.6, tracks: 1 })],
    lava: [LK('black', 'くろい かざん', '黑色火山', '🌋', [0, 1, 1], [0, 1, 1], null, {}),
      LK('red', 'あかい ようがんげん', '赤红熔岩原', '🔥', [-8, 1.5, 1.05], [0, 1, 1], [255, 80, 30, 0.06], { embers: 2, hot: 1.6 }),
      LK('ash', 'はいの はら', '灰烬原', '🌫', [0, 0.3, 1.15], [0, 0.4, 1.1], null, { ashdrift: 2, hot: 0.5 }),
      LK('crystal', 'すいしょうの どうくつ', '水晶洞', '💎', [-110, 1.2, 1.0], [-100, 1, 1], [150, 120, 255, 0.05], { crystals: 1, hot: 0.7 }, [180, 120, 255])],
    metal: [LK('steel', 'はがねの ゆか', '钢铁地板', '⚙', [0, 1, 1], [0, 1, 1], null, {}),
      LK('depot', 'そうこ', '仓库', '📦', [-170, 1.3, 1.05], [0, 1, 1], null, { stripes: 1, plates: 1 }),
      LK('circuit', 'でんしの へや', '电子房间', '💡', [5, 1.8, 0.95], [0, 1, 1], [80, 200, 255, 0.05], { circuits: 1 }),
      LK('rust', 'さびた こうじょう', '生锈工厂', '🔩', [-180, 1.0, 1.0], [0, 1, 0.9], null, { rust: 1.5, plates: 0.6 })],
    hell: [LK('gate', 'じごくの いりぐち', '地狱入口', '🔥', [0, 1, 1], [0, 1, 1], null, {}),
      LK('purple', 'むらさきの やみ', '紫色黑暗', '🔮', [-60, 1.1, 1.0], [-50, 1, 1], [170, 90, 255, 0.06], { runes: 1, hot: 0.8 }, [200, 90, 255]),
      LK('blue', 'あおい ほのお', '蓝色火焰', '💠', [-120, 1.0, 1.0], [-110, 1, 1], null, { embers: 1, hot: 1.2 }, [70, 150, 255])] };
  // ぼうけん：k＝そのワールドで その場面が出る何回目か（0 から）。となりの面（同じ場面が続く時）は必ず違う番号
  function lookOf(scene, world, k) { const L = LOOKS[scene]; return L ? ((k | 0) + (world | 0)) % L.length : 0; }
  const RIVER_LOOK = { grass: 3, valley: 1, sand: 2, snow: 1 };   // 川と橋の面は 水の景色に そろえる
  /* ===== P7 END ===== */
  const SCENE_KEY = { g: 'grass', f: 'forest', v: 'valley', s: 'sand', n: 'snow', l: 'lava', m: 'metal', h: 'hell' };   // scenes の 1 文字 → 場面
  const RAND_BASE = { A: 0.45, C: 0.2, D: 0.2, B: 0.15 };   // ランダムの おうちの置き方の割合
  /* 世界。hand＝手作りの面（面の番号 → 地図の名前・つなぐ面・仕掛け）、boss＝ボスの出る面、easy＝楽な面（10 面ごとに一度）、
     music＝曲（球球王国）。theme＝地面の色（tank.html の THEME）。fx＝世界のふつうの仕掛け
     v0.22 P5A：home＝ふるさとの場面、scenes＝面ごとの場面（1 文字＝1 面、SCENE_KEY）、bases＝おうちの置き方（A 下・B まん中・C 角・D 横・N おうち無し）
     P7 v0.24：gims＝面ごとの仕掛け（1 文字＝1 面、- 無し。GIM_ROOMS の kind）
     P8 v0.25：escortShort＝みじかい護送（縦 26 升・画面が動かない）、cargo＝護送で守る相手（面の番号 → CARGO の kind。無ければ truck） */
  const WORLDS = [
    { id: 'w1', gims: '--c-o---dvoc-rc--c--dpo-', ja: '草原', zh: '草原', theme: 'grass', fx: 'none', music: ['battle1', 'battle2'], rooms: ROOM_W1,
      home: 'grass', scenes: 'ggggsssgnnnnfffgvvvglllg', bases: 'AACAANAABDACAADANBAACADA',   // P8 v0.25：6＝N（みじかい護送）・10＝D
      hand: { 1: ['grass', 'tk1', 'none'], 7: ['tk15', 'tk12', 'desert'], 13: ['tk3', 'tk2', 'jungle'], 19: ['tk2', 'tk8', 'valley'] },
      boss: { 8: ['twin'], 16: ['engineer'], 20: ['twin', 'engineer'], 24: ['bigtank'] }, easy: [10, 22], storm: false, sand: 0,
      flags: [2], survive: { 11: 45 }, night: [15], escort: [6, 17], escortShort: [6], cargo: { 6: 'wagon' } },
    { id: 'w2', gims: '--rodm--v-co--d-p----rm-', ja: '砂漠', zh: '沙漠', theme: 'sand', fx: 'desert', music: ['battle1', 'battle2'], rooms: ROOM_W2,
      home: 'sand', scenes: 'ssssfffsllllnnnsvvvsssss', bases: 'ANCADBAACABDACDAANAANCDA',
      hand: { 1: ['tk15', 'tk12', 'desert'], 7: ['tk3', 'tk2', 'jungle'], 13: ['tk6', 'tk9', 'snowland'], 19: ['tk8', 'tk2', 'valley'] },   // 13 は雪山の場面（設計の tk13 火山から変えた）
      boss: { 8: ['burrower'], 16: ['scorpion'], 20: ['burrower', 'scorpion'], 24: ['sandship'] }, easy: [10, 22], storm: true, sand: 0.18,
      flags: [5, 14], survive: { 11: 60 }, night: [9], escort: [2, 18], escortShort: [2], cargo: { 2: 'wagon' }, breakthrough: [21] },
    // v0.13。type：flags＝占領（旗 3 本）・survive＝生き残り（秒）。night＝夜（まわりが暗い）。blizzard＝吹雪（見た目だけ）
    { id: 'w3', gims: '--domr--v-co--m--d--vpc-', ja: '雪山', zh: '雪山', theme: 'snow', fx: 'snowland', music: ['battle3', 'battle4'], rooms: ROOM_W3,
      home: 'snow', scenes: 'nnnnsssnllllmmmnfffnnnnn', bases: 'ANBCDCAABADCAADANBAACADA',
      hand: { 1: ['tk9', 'tk4', 'snowland'], 7: ['tk12', 'tk15', 'desert'], 13: ['tk7', 'tk1', 'fortress'], 19: ['tk3', 'tk9', 'jungle'] },
      boss: { 8: ['plow'], 16: ['icegun'], 20: ['plow', 'icegun'], 24: ['snowman'] }, easy: [10, 22], storm: false, sand: 0, ice: 0.12,
      flags: [5, 11, 15, 21], survive: { 9: 70 }, night: [18], escort: [2, 17], escortShort: [2], cargo: { 2: 'friend' }, blizzard: [3, 21, 23] },   // v0.23 P6A：旗 4 → 5（4 面はミニボス）
    { id: 'w4', gims: '--dorm--v-co----dm--vpc-', ja: '火山', zh: '火山', theme: 'lava', fx: 'volcano', music: ['battle1', 'battle2'], rooms: ROOM_W4,
      home: 'lava', scenes: 'llllnnnlmmmmssslggglllll', bases: 'AABACDAADABAACNADBAACADA',
      hand: { 1: ['tk13', 'tk8', 'volcano'], 7: ['tk4', 'tk11', 'snowland'], 13: ['tk5', 'tk14', 'desert'], 19: ['tk1', 'tk7', 'none'] },
      boss: { 8: ['flamer'], 16: ['golem'], 20: ['flamer', 'golem'], 24: ['dragon'] }, easy: [10, 22], storm: false, sand: 0, ash: 0.1,
      flags: [6, 17, 23], survive: { 3: 75, 11: 90, 18: 100 }, night: [5, 9, 14, 21, 23], escort: [15], cargo: { 15: 'friend' }, blizzard: [] },
    // v0.14。escort＝護送（トラックを守って上のゴールまで。地図は縦 39 升）・breakthrough＝突破（画面が前へ進む。縦 52 升）。
    // 機械要塞：動く壁・スイッチ・ワープ（fx fortress）。地獄：世界 5 をクリアすると開く。溶岩と夜、全部の種類が出る
    { id: 'w5', gims: '---o-d--m--c--v--d---m--', ja: '機械要塞', zh: '机械要塞', theme: 'metal', fx: 'fortress', music: ['battle3', 'battle4'], rooms: ROOM_W5,
      home: 'metal', scenes: 'mmmmlllmnnnnsssmfffmmmmm', bases: 'AANANDAACANAANBANDAANCNA',
      hand: { 1: ['tk7', 'tk1', 'fortress'], 7: ['tk8', 'tk14', 'volcano'], 13: ['tk12', 'tk5', 'desert'], 19: ['tk3', 'tk2', 'jungle'] },
      boss: { 8: ['sisA', 'sisB'], 16: ['airship'], 20: ['sisA', 'sisB', 'airship'], 24: ['core'] }, easy: [10, 22], storm: false, sand: 0,
      flags: [9], survive: { 18: 90 }, escort: [3, 11, 17, 23], cargo: { 11: 'friend', 23: 'friend' }, breakthrough: [5, 14, 21], night: [6, 15], blizzard: [] },
    { id: 'w6', gims: '---om-v--d-c----dm--v-o-', ja: '地獄', zh: '地狱', theme: 'hell', fx: 'inferno', music: ['hell', 'hell'], bossMusic: 'hellboss', rooms: ROOM_W6,
      home: 'hell', scenes: 'hhhhmmmhllllnnnhssshhhhh', bases: 'AANACNBAACNCAANABDAACNDA',   // v0.23 P6A：3＝N・4＝A・7＝B・11＝N・12＝C
      hand: { 1: ['tk6', 'tk12', 'inferno'], 13: ['tk9', 'tk4', 'snowland'], 19: ['tk15', 'tk12', 'desert'] },   // 7 は自動の地図（v0.22）
      boss: { 8: ['shadow'], 16: ['superstar'], 20: ['shadow', 'superstar'], 24: ['king'] }, easy: [9, 21], storm: false, sand: 0, ash: 0.08,
      flags: [10, 18], survive: { 7: 90, 21: 100 }, escort: [3, 15], cargo: { 3: 'friend' }, breakthrough: [6, 11, 22], night: [5, 17, 23], blizzard: [] }   // v0.23 P6A：4・12 面を ふつうの面に
  ];
  // v0.22 P5A：面の場面（無ければ その世界の ふるさと。クラシックなど world の無い面は草原）
  function sceneOf(st) { return (st && SCENES[st.scene]) || (st && WORLDS[st.world] && SCENES[WORLDS[st.world].home]) || SCENES.grass; }
  const PER_WORLD = 24, ADV_SPECIAL_FROM = { bouncer: 2, miner: 6, mortar: 12, sniper: 18, rammer: 26 };   // 自作の敵が出始める面（0 から数えた通しの番号。v0.22 で早めた。P7 v0.24：迫撃 13・狙撃 19・突進 27 面へ）
  const lerp = (a, b, k) => a + (b - a) * k;
  /* ===== P6A BEGIN（v0.23）：4 面ごとの ミニボス（No.54）・面の間の ミニゲーム（No.13）=====
     st.event＝{ kind: 'miniboss'｜'boss', mini: ミニゲームの種類（無ければ null）, mb: ミニボスの数（miniboss だけ）}。4 面ごと（no % 4 === 0）だけ */
  const MINI_BY_NO = { 4: 'treasure', 8: 'target', 12: 'coins', 16: 'race', 20: 'treasure' }, MINI_24 = ['coins', 'race', 'target', 'coins', 'race', null];
  const MINI_BOSS = [   // 世界ごと。look＝絵と動きを借りる敵の種類。hp＝1 人・4 面目の体力。sec＝時計。spd・cd＝速さ・撃つ間隔に掛ける。guard＝何秒ごとに 1 発ふせぐか（0＝無し）
    { name: ['でかでか戦車', '大块头坦克'], look: 'armor', hp: 8, sec: 60, spd: 1.0, cd: 1.0, guard: 0, ja: 'どすーん！ ここは とおさないぞ！', zh: '咚——！不让你们过去！' },
    { name: ['びゅんびゅん号', '飞毛腿号'], look: 'fast', hp: 10, sec: 60, spd: 0.7, cd: 1.0, guard: 0, ja: 'びゅーん！ おいつけるかな？', zh: '嗖——！追得上我吗？' },
    { name: ['どっかん号', '轰隆号'], look: 'heavy', hp: 12, sec: 60, spd: 0.9, cd: 1.0, guard: 0, ja: 'どっかーん！ ゆきだまより はやいぞ！', zh: '轰——！比雪球还快哦！' },
    { name: ['ぴょんぴょん号', '弹弹号'], look: 'bouncer', hp: 14, sec: 55, spd: 0.9, cd: 0.9, guard: 0, ja: 'ぴょん ぴょん！ たまが はねるよ！', zh: '蹦蹦！炮弹会反弹哦！' },
    { name: ['かちこち隊長', '硬邦邦队长'], look: 'chief', hp: 16, sec: 55, spd: 1.0, cd: 1.0, guard: 6, ja: 'かちこち！ ときどき ガードするぞ！', zh: '硬邦邦！我有时会挡一下！' },
    { name: ['まっくろ隊長', '黑漆漆队长'], look: 'chief', hp: 18, sec: 50, spd: 1.2, cd: 0.9, guard: 5, ja: 'まっくろ隊長、さんじょう！ いそげ いそげ！', zh: '黑漆漆队长，登场！快点快点！' } ];
  // last＝並びの最後の面（w6-24・ランダム 24）。ミニゲームは無し（エンディング・終わりの画面を じゃましない）
  function eventOf(world, no, bosses, last) {
    if (no % 4) return null;
    const mini = last ? null : no === 24 ? MINI_24[world] || null : MINI_BY_NO[no] || null;
    if (bosses) return { kind: 'boss', mini };
    const m = MINI_BOSS[world] || MINI_BOSS[0];
    return { kind: 'miniboss', mini, mb: { w: MINI_BOSS[world] ? world : 0, look: m.look, hp: Math.round(m.hp * (no >= 12 ? 1.25 : 1)), sec: m.sec, spd: m.spd, cd: m.cd, guard: m.guard } };
  }
  /* ===== P6A END ===== */
  /* ===== P7 BEGIN（v0.24）：びっくりイベント（No.57）・さわれる仕掛け（No.58＋18）=====
     SUR＝イベントの表。from＝出始める gi、sec＝長さ（秒）、warn＝予告（秒）、ja・zh＝始まりの文字（g.banner）、
     end＝終わり・に げた時の文字、win＝たおした時の文字、arrive＝着いた時の文字（補給）。動きは tank-sim.js（stepSur） */
  const SUR = {
    supply: { from: 1, sec: 20, warn: 2, ic: '🪂', name: ['ほきゅう パラシュート', '补给降落伞'], ja: '🪂 ほきゅうが とどくよ！', zh: '🪂 补给要到了！', arrive: ['ほきゅうが とどいた！', '补给到了！'] },
    coinrain: { from: 1, sec: 12, warn: 2, ic: '🪙', name: ['コインの あめ', '金币雨'], ja: '🪙 コインの あめだ！ みんなで ひろおう', zh: '🪙 下金币雨啦！大家一起捡' },
    giant: { from: 1, sec: 25, warn: 2, ic: '🎁', name: ['おおきな アイテム', '巨大道具'], ja: '🎁 おおきな アイテム！ とると みんなに きくよ', zh: '🎁 巨大道具！谁拿到全员都有效' },
    plane: { from: 1, sec: 4, warn: 1, ic: '✈', name: ['おたすけ ひこうき', '支援飞机'], ja: '✈ おたすけ ひこうきが きた！', zh: '✈ 支援飞机来了！' },
    freeze: { from: 8, sec: 8, warn: 2, ic: '⛄', name: ['ゆきだるまの おてつだい', '雪人来帮忙'], ja: '⛄ ゆきだるまが てつだいに きた！ てきが カチコチ', zh: '⛄ 雪人来帮忙了！敌人冻住啦' },
    rainbow: { from: 8, sec: 15, warn: 2, ic: '🌈', name: ['にじの ボーナス', '彩虹奖励'], ja: '🌈 にじが でた！ たおすと コイン +1', zh: '🌈 彩虹出来了！打倒敌人金币 +1', end: ['にじが きえた。またね', '彩虹消失了，下次见'] },
    goldtank: { from: 8, sec: 25, warn: 2, ic: '✨', name: ['にげる きんぴか戦車', '逃跑的金坦克'], ja: '✨ きんぴか戦車だ！ つかまえろ', zh: '✨ 金坦克出现！快追', win: ['やった！ ぎんの たからばこ', '太好了！银宝箱'], end: ['またね〜！', '下次见〜！'] },
    pinata: { from: 24, sec: 30, warn: 2, ic: '🎊', name: ['くすだま戦車', '彩球坦克'], ja: '🎊 くすだま戦車だ！ うつと コインが でるよ', zh: '🎊 彩球坦克！打它会掉金币', win: ['パカーン！', '啪——！'], end: ['たのしかった！', '玩得真开心！'] },
    sunshine: { from: 1, sec: 20, warn: 2, ic: '☀', name: ['はれま', '放晴'], ja: '☀ おひさまが でた！', zh: '☀ 太阳出来了！', storm: ['☀ はれた！ よく みえるよ', '☀ 放晴了！看得很清楚'] } };
  const SUR_ORDER = ['supply', 'coinrain', 'giant', 'plane', 'freeze', 'rainbow', 'goldtank', 'pinata'];
  // その面のイベントの候補 [A, B]（計算が A 65%・B 35% で選ぶ）か null。ボス・ミニボス・護送・突破・再会・w1-1 は無し
  function surpriseOf(st) {
    if (st.bosses || (st.event && st.event.kind === 'miniboss') || st.type === 'escort' || st.type === 'breakthrough' || st.reunion || st.gi === 0) return null;
    if (st.gi === 1) return ['supply', 'supply'];   // さいしょの 1 回は いつも補給（おぼえやすい）
    const pool = SUR_ORDER.filter(k => SUR[k].from <= st.gi);
    let a = pool[(st.gi * 5 + 1) % pool.length], b = pool[(st.gi * 3 + 2) % pool.length];
    if (st.night || st.blizzard) a = 'sunshine'; else if (st.storm) b = 'sunshine';
    if (b === a) b = pool[(pool.indexOf(b) + 1) % pool.length];
    return [a, b];
  }
  // ランダムの面のイベント（8 種ぜんぶから。rnd を呼ばない）。k＝並びの番号（0 から）
  function surpriseRand(st, seed, k) {
    if (st.bosses || (st.event && st.event.kind === 'miniboss') || k % 4 === 3 || st.type === 'escort' || st.type === 'breakthrough' || st.reunion) return null;
    const pool = SUR_ORDER, s = seed >>> 0; let a = pool[(s + k * 5) % 8], b = pool[(s + k * 3 + 2) % 8];
    if (st.night || st.blizzard) a = 'sunshine';
    if (b === a) b = pool[(pool.indexOf(b) + 1) % pool.length];
    return [a, b];
  }
  /* 仕掛け（地図の文字。どれも 2 × 2 升で 1 つ）：C 木箱（ひびは c）・O ドカンたる・G＋K スイッチの とびら・V はやい床・W＋R 川と橋・P ワープ・M おせる岩。
     GIM_FROM＝これより前の gi には置かない。gimKind＝その面で本当に置く種類（置けない時は木箱に落とす。計算と genRows の両方が呼ぶ） */
  const GIM_FROM = { c: 2, o: 4, d: 8, v: 9, r: 13, p: 21, m: 26 };
  const RIVER_OK = { grass: 1, forest: 1, valley: 1, sand: 1, snow: 1 };
  function gimKind(st, layout) {
    const g = st && st.gim, L = layout || 'A'; if (!g || !st.gen || (st.rows || 26) !== 26 || st.type === 'escort' || st.bosses || st.reunion || st.mini || st.p3dBonus != null || st.p3dDuel || st.p4b) return null;   // ひみつ・決闘・ボスちょうせんにも無し
    let k = g.kind;
    if (k === 'r' && !((L === 'A' || L === 'C') && RIVER_OK[st.scene] && st.type !== 'flags')) k = 'c';
    if (k === 'p' && !(L === 'A' && st.scene !== 'metal' && !st.type)) k = 'c';
    if (k === 'd' && st.scene === 'metal') k = 'c';
    if (st.event && st.event.kind === 'miniboss' && k !== 'c' && k !== 'o') k = 'c';
    if ((GIM_FROM[k] ?? 999) > 900) k = 'c';   // 止めた仕掛け（GIM_FROM 999）は木箱に
    return k;
  }
  const GIM_ROOMS = {   // 今の部品と同じ 5 × 5 の大きな升（1 文字＝2 × 2 升）
    c: [['.....', '.C.C.', '.....', '.C.C.', '.....'], ['.....', '.BCB.', '.C.C.', '.BCB.', '.....'], ['C...C', '.....', '..T..', '.....', 'C...C']],
    o: [['.....', '.B.B.', '..O..', '.B.B.', '.....'], ['.....', '.O.O.', '.....', 'BB.BB', '.....'], ['O...O', '.....', '..B..', '.....', 'O...O']],
    d: [['SSS..', 'SCG..', 'SSS..', '.....', '...K.'], ['.....', '.SSS.', '.SCS.', '.SGS.', 'K....']],
    v: [['.....', 'VVVVV', '.....', '.B.B.', '.....'], ['..V..', '..V..', '..V..', '..V..', '..V..'], ['VV...', '.VV..', '..VV.', '...VV', '.....']],
    m: [['.....', '.M...', '.....', '...M.', '.....'], ['.....', '.B.B.', '..M..', '.B.B.', '.....']] };
  // 仕掛けの名前・はじめて出た面の 1 行（画面が出す。台詞ではない）
  const GIM_INFO = {
    c: { ic: '📦', name: ['きばこ', '木箱'], first: ['📦 きばこを うつと なにか でるよ', '📦 打木箱会掉东西哦'] },
    o: { ic: '🛢', name: ['ドカンたる', '爆炸桶'], first: ['🛢 たるを うつと ドカン！ てきを まきこもう', '🛢 打爆炸桶会轰的一声！把敌人卷进去'] },
    d: { ic: '🔘', name: ['スイッチの とびら', '开关门'], first: ['🔘 スイッチを うつと とびらが ひらくよ', '🔘 打开关，门就会打开'] },
    v: { ic: '⏩', name: ['はやい ゆか', '加速地板'], first: ['⏩ ひかる ゆかは はやく はしれるよ', '⏩ 发光的地板可以跑得更快'] },
    r: { ic: '🌉', name: ['かわと はし', '河与桥'], first: ['🌉 かわは はしを わたろう。てきも はしから くるよ', '🌉 过河要走桥，敌人也从桥上来'] },
    p: { ic: '🌀', name: ['ワープの あな', '传送洞'], first: ['🌀 あなに はいると はんたいがわへ ワープ！', '🌀 进洞就传送到另一边！'] },
    m: { ic: '🪨', name: ['おせる いわ', '可推的石块'], first: ['🪨 いわは おすと うごくよ。うっても こわせる', '🪨 石块可以推着走，也能打碎'] } };
  /* ===== P7 END ===== */
  /* ===== P8 BEGIN（v0.25）：護送で守る相手（No.20）。hp＝1 人の体力（人数ごとに +4）、sp＝速さ（升/秒）、r＝味方がこの距離に いる時だけ進む、
     heal＝味方が 2.5 升以内に いる間 何秒ごとに +1（0＝なおらない）、ic＝画面の絵文字、tail＝面の名前の しっぽ [日, 中]。動きは tank-sim.js（stepTruck） ===== */
  const CARGO = {
    truck:  { hp: 10, sp: 1.0,  r: 7.5, heal: 0, ic: '🚚', ja: 'トラック', zh: '卡车', tail: ['：トラックを まもれ', '：护送卡车'] },
    wagon:  { hp: 12, sp: 0.85, r: 9,   heal: 0, ic: '🥕', ja: 'やさいの にぐるま', zh: '蔬菜货车', tail: ['：にぐるまを まもれ', '：护送蔬菜货车'] },
    friend: { hp: 9,  sp: 1.1,  r: 7.5, heal: 6, ic: '🚑', ja: 'なかまの戦車', zh: '友军坦克', tail: ['：なかまを たすけろ', '：护送受伤的伙伴'] } };
  const CARGO_HEAL_R = 2.5;
  // 種つきの乱数（makeRandom・climbFloor・invTick で使い回す。v0.24 までの makeRandom の中の rnd と同じ作り）
  function makeRnd(seed) { let a = (seed >>> 0) || 1; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  /* ===== P8 END ===== */
  /* 48 面の決まり。gi＝通しの番号（0〜47）。s＝難しさ（tank-sim.js の diff の s。今のふつうの 6 面が 0〜5）、em＝敵の数に掛ける値 */
  function makeAdv() {
    const out = [], seenGim = {};   // P7：はじめて出る仕掛け（並び全体で）
    WORLDS.forEach((w, wi) => {
      const seen = {};   // P7：そのワールドで その場面が出た回数（景色）
      for (let no = 1; no <= PER_WORLD; no++) {
        // 草原・砂漠（0〜47）は v0.22 で 1 面から少しむずかしく（s 0.8〜）。雪山・火山（48〜95）は、そこから少しずつ上げる（上がり方はゆるめ）
        const gi = wi * PER_WORLD + no - 1, k = Math.min(1, gi / (2 * PER_WORLD - 1)), k2 = Math.max(0, (gi - 2 * PER_WORLD) / (2 * PER_WORLD - 1)), hand = w.hand[no], bosses = w.boss[no] || null, easy = w.easy.includes(no);
        const specials = Object.keys(ADV_SPECIAL_FROM).filter(n => ADV_SPECIAL_FROM[n] <= gi);
        const km = Math.min(1.2, k2), mix = [Math.round(lerp(12, 6, k) - km * 2), Math.round(lerp(4, 5, k)), Math.round(lerp(3, 5, k) + km), Math.round(lerp(1, 3, k) + km * 2)];   // v0.22：1〜5 面も割合が動く
        const type = bosses ? null : (w.flags || []).includes(no) ? 'flags' : (w.survive || {})[no] ? 'survive' : (w.escort || []).includes(no) ? 'escort' : (w.breakthrough || []).includes(no) ? 'breakthrough' : null;
        const short = type === 'escort' && (w.escortShort || []).includes(no);   // P8 v0.25：みじかい護送
        // v0.22 P5A：その面の場面（scene）・おうちの置き方（base）。sceneNew＝場面がわりの最初の面
        const scene = SCENE_KEY[w.scenes[no - 1]], sc = SCENES[scene], home = SCENES[w.home], prev = no > 1 ? SCENE_KEY[w.scenes[no - 2]] : null, bc = w.bases[no - 1];
        const lvl = Math.max(-0.4, Math.min(0.6, 0.2 * (sc.lvl - home.lvl)));   // 場面の差（ふるさとより きびしい場面は 少し むずかしく）
        const sub = scene !== w.home ? { ja: '（' + sc.ja + '）', zh: '（' + sc.zh + '）' } : { ja: '', zh: '' };
        const st = { id: w.id + '-' + no, world: wi, no, gi, adv: true, theme: sc.theme, storm: !!sc.storm && !bosses && no % 3 !== 1,
          scene, sceneNew: no > 1 && scene !== prev, base: bc === 'N' ? 'A' : bc, baseSide: gi % 2 ? 'R' : 'L', event: null,
          ja: w.ja + ' ' + no + sub.ja, zh: w.zh + ' ' + no + sub.zh, music: bosses ? (w.bossMusic || 'boss') : sc.music[no % 2], rows: type === 'escort' ? (short ? 26 : 39) : type === 'breakthrough' ? 52 : 26, short,
          cargo: type === 'escort' ? ((w.cargo || {})[no] || 'truck') : null,
          s: Math.max(0, (gi < 48 ? 0.8 + gi * 0.105 : gi < 96 ? 5.5 + (gi - 48) * 0.055 : 8.14 + (gi - 96) * 0.03) + lvl - (easy ? 1.2 : 0)), em: (gi < 48 ? 0.85 + gi * 0.006 : gi < 96 ? 1.1 + (gi - 48) * 0.003 : 1.24 + (gi - 96) * 0.0015) * (easy ? 0.7 : 1), easy,
          type, survive: type === 'survive' ? w.survive[no] : 0, night: (w.night || []).includes(no), blizzard: scene === 'snow' && (w.blizzard || []).includes(no),
          mix, specials, share: specials.length ? lerp(0.12, 0.25, Math.min(1, gi / 30)) : 0,
          captains: wi === 0 ? (no > 4 && !easy && !bosses ? 1 : 0) : !bosses ? (easy ? 0 : 1 + (no > 12 ? 1 : 0) + (no > 18 ? 1 : 0)) : 0,   // v0.22：世界 1 も 9 面から 1 台。P7 v0.24：5 面から
          bosses, seed: (wi + 1) * 1000 + no * 37 };
        st.event = eventOf(wi, no, bosses, gi === WORLDS.length * PER_WORLD - 1);   // v0.23 P6A
        if (st.event && st.event.kind === 'miniboss') st.captains = 0;   // ミニボスの面は 大きい敵は 1 台だけ
        if (short) { st.storm = false; st.night = false; st.blizzard = false; }   // P8：みじかい護送は はじめてでも見やすく
        if (hand) Object.assign(st, { map: hand[0], partner: hand[1], fx: hand[2], hand: true });   // 手作りの fx は場面の fx と同じにしてある（v022-check で確かめる）
        else Object.assign(st, { gen: true, fx: sc.fx });
        // P7 v0.24：仕掛け・はじめての敵・景色（川の面は水の景色に）
        const gc = (w.gims || '')[no - 1] || '-';
        st.gim = gc === '-' ? null : { kind: gc, n: gi < 48 ? 1 : 2 };
        st.gimNew = !!st.gim && !seenGim[st.gim.kind]; if (st.gim) seenGim[st.gim.kind] = 1;
        st.newKind = Object.keys(ADV_SPECIAL_FROM).find(k => ADV_SPECIAL_FROM[k] === gi) || null;
        st.look = lookOf(scene, wi, seen[scene] = (seen[scene] ?? -1) + 1);
        if (gimKind(st, st.base) === 'r' && RIVER_LOOK[scene] !== undefined) { st.look = RIVER_LOOK[scene]; st._river = true; }
        st.surprise = null;   // 再会を付けた後で surpriseOf が入れる
        if (type === 'flags') { st.ja += '：旗をとれ'; st.zh += '：夺旗'; } else if (type === 'survive') { st.ja += '：まもりぬけ'; st.zh += '：坚守'; }
        else if (type === 'escort') { const t = CARGO[st.cargo].tail; st.ja += t[0]; st.zh += t[1]; }   // P8：守る相手の名前 else if (type === 'breakthrough') { st.ja += '：とっぱせよ'; st.zh += '：突破'; }
        if (bosses) { const nm = bosses.map(b => BOSS_TALK[b].name).filter(Boolean); st.ja = w.ja + ' ' + no + sub.ja + '：' + nm.map(n => n[0]).join('と'); st.zh = w.zh + ' ' + no + sub.zh + '：' + nm.map(n => n[1]).join('和'); }
        out.push(st);
      }
      // P7：川の面が景色を上書きして となりの面（同じ場面）と同じになったら、となりの方を 両どなりと違う番号に
      const ws = out.slice(-PER_WORLD);
      ws.forEach((st, i) => { const p = ws[i - 1], q = ws[i + 1], sp = p && p.scene === st.scene, sq = q && q.scene === st.scene;
        if (st._river || !((sp && p.look === st.look) || (sq && q.look === st.look))) return;
        for (let j = 0; j < LOOKS[st.scene].length; j++) if (!(sp && p.look === j) && !(sq && q.look === j)) { st.look = j; break; } });
      for (const st of ws) delete st._river;
    });
    return out;
  }
  const ADV = makeAdv();
  /* ===== P2-22 BEGIN：ボスとの再会（アイデア No.22）。たおしたボスが、あとの世界の「楽な面」に 1 回だけ もどってくる。
     role：'help'＝なかまとして 1 回だけ てつだう（gift：futon＝おうちの守り +1、freeze＝敵が 8 秒 とまる、shield＝みんなに 12 秒の盾）
           'rival'＝「また おまえか！」と もう一度 しょうぶ（体力は hp 倍の 弱いボス）。meet＝会った時の台詞、after＝てつだった後／たおされた後の台詞。
     {name}＝参加者の名前（計算の側で入れる）。台詞は ほかと同じで、自動では進まない（全員が「読んだ」を押す） ===== */
  const REUNION = [
    { world: 1, no: 10, kind: 'bigtank', role: 'help', gift: 'futon', at: 6,
      meet: [{ ja: '{name}！ ひさしぶりだな。はらっぱは げんきか？', zh: '{name}！好久不见。草原还好吗？' }, { ja: 'まもるものが できた。…きょうは おまえたちの おうちだ', zh: '我有想守护的东西了。…今天，就是你们的小屋' }],
      after: [{ ja: 'おうちに かべを 1まい たしておいた。あとは まかせたぞ！', zh: '给小屋加了一层保护。接下来交给你们了！' }] },
    { world: 2, no: 10, kind: 'scorpion', role: 'rival', hp: 0.4, at: 8,
      meet: [{ ja: 'また あったな、{name}！ こんどは ポーズを きめてから きたぞ！', zh: '又见面了，{name}！这次我可是摆好姿势才来的！' }, { ja: 'ゆきの うえの しっぽも かっこいいだろう？ もういちど しょうぶだ！', zh: '雪地上的尾巴也很帅吧？再来比一次！' }],
      after: [{ ja: 'ま、また まけた… でも たのしかった。{name}、しゃしんは タダで いいぞ', zh: '又、又输了…不过很开心。{name}，照片免费送你们' }] },
    { world: 3, no: 10, kind: 'snowman', role: 'help', gift: 'freeze', at: 14,
      meet: [{ ja: '{name}！ ふゆじゃ ないけど、あいに きたよ！', zh: '{name}！虽然不是冬天，我还是来看你们啦！' }, { ja: 'ここ あついね… とけちゃう まえに、えいっ！', zh: '这里好热…趁我还没融化，嘿！' }],
      after: [{ ja: 'てきを カチコチに したよ。いまの うちに！ またね！', zh: '我把敌人冻住了。趁现在！下次见！' }] },
    { world: 4, no: 10, kind: 'flamer', role: 'rival', hp: 0.4, at: 8,
      meet: [{ ja: '{name}ァァ！ みずを のんで ふっかつだァ！', zh: '{name}——！我喝完水复活啦！' }, { ja: 'オレの たましいは まだ きえてないィィ！ もういっかい だ！', zh: '我的灵魂还没熄灭！再来一次！' }],
      after: [{ ja: '…いい ひばなだった。つぎは {name}の みかたで もえるぜ', zh: '…漂亮的火花。下次我为{name}燃烧' }] },
    { world: 5, no: 9, kind: 'core', role: 'help', gift: 'shield', at: 6,
      meet: [{ ja: '{name} を かくにん。…しつもんの こたえが わかりました', zh: '确认到{name}。…那个问题，我找到答案了' }, { ja: 'わたしが まもりたいのは、あなたたち です', zh: '我想守护的，就是你们' }],
      after: [{ ja: 'ぜんいんに たてを はりました。きを つけて', zh: '已为全员展开护盾。请多保重' }] }
  ];
  for (const r of REUNION) { const st = ADV[r.world * PER_WORLD + r.no - 1]; if (st && !st.bosses && !st.type) st.reunion = r; }
  for (const st of ADV) st.surprise = surpriseOf(st);   // P7 v0.24：びっくりイベントの候補
  /* ===== P2-22 END ===== */
  /* ランダム（v0.15、JUN さん「同じ場面ではなく ランダムな場面」）：24 面。面ごとに、遊べる世界からランダムに場面（世界・面の種類・夜など）を選ぶ。
     難しさは面の番号で上がる（ぼうけんの開いている所まで）。8・16・24 面目はボス。seed＝種（同じ種なら同じ並び）、open＝ぼうけんの開いた面の数 */
  function makeRandom(seed, open) {
    const rnd = makeRnd(seed);   // P8：関数に出した（同じ数が出る）
    const maxGi = Math.max(0, Math.min(ADV.length - 1, (open | 0) - 1)), worlds = Math.max(1, Math.min(WORLDS.length, Math.floor(maxGi / PER_WORLD) + 1)), out = [];
    for (let k = 0; k < PER_WORLD; k++) {
      const boss = (k + 1) % 8 === 0, w = Math.floor(rnd() * worlds), giD = Math.round(Math.min(maxGi, k / (PER_WORLD - 1) * maxGi));
      const mbNo = !boss && k % 4 === 3;   // v0.23 P6A：4・12・20 面目は ミニボス（種類の無い面から。rnd を呼ぶ回数は同じ）
      const pool = ADV.filter(st => st.world === w && !!st.bosses === boss && (boss || !st.hand) && st.gi <= Math.max(maxGi, w * PER_WORLD + 7) && (!mbNo || !st.type));
      const src = pool[Math.floor(rnd() * pool.length)] || ADV[giD], dif = ADV[giD];
      const st = Object.assign({}, src, { id: 'r-' + (k + 1), no: k + 1, gi: giD, rand: true, s: dif.s, em: dif.em, mix: dif.mix, specials: dif.specials, share: dif.share,
        captains: src.bosses ? 0 : dif.captains, easy: false, seed: (seed % 100000) * 13 + k * 101 + 7 });
      const sc = sceneOf(src), tail = src.ja.indexOf('：') >= 0 ? src.ja.slice(src.ja.indexOf('：')) : '', tailZh = src.zh.indexOf('：') >= 0 ? src.zh.slice(src.zh.indexOf('：')) : '';
      st.ja = 'ランダム ' + (k + 1) + '（' + sc.ja + '）' + tail; st.zh = '随机 ' + (k + 1) + '（' + sc.zh + '）' + tailZh;   // v0.22：名前は場面（世界ではなく）
      out.push(st);
    }
    // v0.22 P5A：おうちの置き方も同じ rnd で（面の並びを決めた後に引く。面の引き方は v0.21 と同じ）。ボス・護送・突破は A。
    // 前の 2 面と同じ置き方は引き直す（A も数える。護送・突破は数えない）。つぎに数える面が ボス（A）なら A・A・A にしない
    const skip = st => st.type === 'escort' || st.type === 'breakthrough', hist = [];
    out.forEach((st, k) => {
      let base = 'A';
      if (!st.bosses && !skip(st)) {
        const nx = out.slice(k + 1).find(o => !skip(o)), nextA = !!(nx && nx.bosses), last = hist[hist.length - 1];
        const bad = b => (hist.length >= 2 && last === b && hist[hist.length - 2] === b) || (nextA && b === 'A' && last === 'A');
        for (let tr = 0; tr < 8; tr++) {
          const r = rnd(); base = r < RAND_BASE.A ? 'A' : r < RAND_BASE.A + RAND_BASE.C ? 'C' : r < RAND_BASE.A + RAND_BASE.C + RAND_BASE.D ? 'D' : 'B';
          if (base === 'B' && st.type === 'flags') base = 'D';   // 旗の面に まん中は無い
          if (!bad(base)) break;
        }
        if (bad(base)) base = ['C', 'D', 'A'].find(b => !bad(b));   // 8 回 引いても だめな時（まず無い）
      }
      if (!skip(st)) hist.push(base);
      Object.assign(st, { sceneNew: k > 0 && st.scene !== out[k - 1].scene, base, baseSide: rnd() < 0.5 ? 'L' : 'R', event: eventOf(st.world, k + 1, st.bosses, k === PER_WORLD - 1) });   // v0.23 P6A
      if (st.event && st.event.kind === 'miniboss') st.captains = 0;
      // P7 v0.24：景色・イベント（rnd を呼ばない＝並びは v0.23 と同じ）。仕掛けは元の面の物を受けつぐ（合わない時は gimKind が木箱に）
      const L = LOOKS[st.scene] || LOOKS.grass; st.look = ((seed >>> 0) + k * 7) % L.length;
      if (gimKind(st, st.base) === 'r' && RIVER_LOOK[st.scene] !== undefined) st.look = RIVER_LOOK[st.scene];
      Object.assign(st, { surprise: surpriseRand(st, seed, k), newKind: null, gimNew: false });
    });
    return out;
  }
  /* ===== P8 BEGIN（v0.25）：むげんの塔（No.16）。新しい mode は作らない＝mode 'rand' ＋ g.climb で 5 階ずつ遊ぶ（tank-sim.js の startRun）。
     1 階＝1 面、10 階ごとにボス（18 体が順番に）、5 階ごとに休み（画面）。30 階で 1 つの世界、180 階で 1 周、そこから先は climbUp で強くなる ===== */
  const CLIMB = { PER: 5, TOP: 180, RETRY: 3, UP: 0.25, UP_CAP: 3, BASES: ['A', 'C', 'A', 'D', 'A', 'B'] };
  function climbFloor(n, seed) {                       // n＝1 から
    n = Math.max(1, Math.floor(Number(n)) || 1); seed = seed >>> 0;
    const cyc = Math.floor((n - 1) / CLIMB.TOP), m = (n - 1) % CLIMB.TOP + 1, boss = m % 10 === 0;
    const giD = Math.min(ADV.length - 1, Math.floor((m - 1) * 0.8)), dif = ADV[giD];   // ボスの階は giD＝8k−1＝その世界の 8・16・24 面
    const rnd = makeRnd(seed * 31 + n * 131 + 5);
    const pool = ADV.filter(s => s.gen && !s.bosses && !s.type && !s.reunion && !(s.event && s.event.kind === 'miniboss') && s.world <= dif.world);
    const src = boss ? dif : pool[Math.floor(rnd() * pool.length)];
    const st = Object.assign({}, src, { id: 'c-' + n, no: n, gi: giD, rand: true, climb: n, climbUp: Math.min(CLIMB.UP_CAP, 1 + CLIMB.UP * cyc),
      s: dif.s, em: dif.em, mix: dif.mix, specials: dif.specials, share: dif.share, captains: boss ? 0 : dif.captains, easy: false,
      event: null, newKind: null, gimNew: false, sceneNew: false, reunion: null, p3dSec: null, short: false, cargo: null, night: !!src.night && m > 30, seed: boss ? src.seed : (seed % 100000) * 17 + n * 131 + 5 });   // ボスの階は その面の地図のまま（種も同じ）
    st.base = boss || st.type === 'flags' ? 'A' : CLIMB.BASES[(n + seed) % 6]; st.baseSide = rnd() < 0.5 ? 'L' : 'R';
    const L = LOOKS[st.scene] || LOOKS.grass; st.look = (seed + n * 7) % L.length;
    if (gimKind(st, st.base) === 'r' && RIVER_LOOK[st.scene] !== undefined) st.look = RIVER_LOOK[st.scene];   // 川の面は水の景色（makeRandom と同じ）
    if (boss) st.surprise = null;
    else { let a = SUR_ORDER[(seed + n * 5) % 8], b = SUR_ORDER[(seed + n * 3 + 2) % 8]; if (st.night || st.blizzard) a = 'sunshine'; if (b === a) b = SUR_ORDER[(SUR_ORDER.indexOf(b) + 1) % 8]; st.surprise = [a, b]; }
    const sc = sceneOf(src), bt = boss && src.ja.indexOf('：') >= 0;   // ボスの名前の しっぽは今の面の物
    st.ja = '塔 ' + n + ' かい（' + sc.ja + '）' + (bt ? src.ja.slice(src.ja.indexOf('：')) : ''); st.zh = '塔 第 ' + n + ' 层（' + sc.zh + '）' + (bt ? src.zh.slice(src.zh.indexOf('：')) : '');
    return st;
  }
  // 1 回の走り＝5 階（from＝5k+1）
  function makeClimb(seed, from, count) { const out = []; for (let i = 0; i < (count || CLIMB.PER); i++) out.push(climbFloor(from + i, seed)); return out; }
  // 「{h} かいから」の h（家族の最高記録の半分より下の 5k+1）
  function climbStart(best) { return 5 * Math.floor(Math.floor(Math.max(0, best | 0) / 2) / 5) + 1; }
  /* ごほうび（はじめて着いた階だけ。家族で 1 回。一人ずつ配る）。f＝休みの階（5 の倍数）。2 周目から 10 階ごとに銀・30 階ごとに金 */
  const CLIMB_REWARD = { w5: { wood: 1 }, w10: { silver: 1, coins: 50 }, w30: { gold: 1, coins: 100, charm: 1 }, top: { gold: 1, coins: 300, charm: 2, top: true },
    again10: { silver: 1, coins: 50 }, again30: { gold: 1, coins: 100 } };
  function climbReward(f) {
    f = Math.floor(Number(f)) || 0; if (f < 1 || f % 5) return null;
    const m = (f - 1) % CLIMB.TOP + 1, R = CLIMB_REWARD, pick = f > CLIMB.TOP ? (m % 30 === 0 ? R.again30 : m % 10 === 0 ? R.again10 : null) : f === CLIMB.TOP ? R.top : f % 30 === 0 ? R.w30 : f % 10 === 0 ? R.w10 : R.w5;
    return pick ? Object.assign({ wood: 0, silver: 0, gold: 0, coins: 0, charm: 0, top: false }, pick) : null;
  }
  // 記録 tank-v25-climb。こわれた入力でも 決まった形を返す。2 回かけても同じ
  const CLIMB_MAX_F = 1e6, CLIMB_RETRY_MAX = 4;
  function cleanClimb(o) {
    const src = o && typeof o === 'object' && !Array.isArray(o) ? o : {}, obj = v => (v && typeof v === 'object' && !Array.isArray(v) ? v : {});
    const num = (v, mx, mn) => { const n = Math.floor(Number(v)); return Number.isFinite(n) && n >= (mn || 0) ? Math.min(n, mx) : (mn || 0); };
    const name = v => (typeof v === 'string' ? v.slice(0, 12) : '');
    const names = v => (Array.isArray(v) ? v.map(name).filter(Boolean).slice(0, 4) : []);
    const bb = obj(src.bestBy), bestBy = { 1: num(bb[1], CLIMB_MAX_F), 2: num(bb[2], CLIMB_MAX_F), 3: num(bb[3], CLIMB_MAX_F), 4: num(bb[4], CLIMB_MAX_F) };
    const top = (Array.isArray(src.top) ? src.top : []).map(r => obj(r)).filter(r => num(r.f, CLIMB_MAX_F) >= 1)
      .map(r => ({ f: num(r.f, CLIMB_MAX_F), n: Math.max(1, num(r.n, 4)), names: names(r.names), at: num(r.at, 4e9), seed: num(r.seed, 2e9) }))
      .sort((a, b) => b.f - a.f || a.at - b.at).slice(0, 5);
    const w = obj(src.who), who = {}; Object.keys(w).map(k => [name(k), num(w[k], CLIMB_MAX_F)]).filter(([k, f]) => k && f >= 1).sort((a, b) => b[1] - a[1]).slice(0, 20).forEach(([k, f]) => { who[k] = Math.max(who[k] || 0, f); });
    let best = num(src.best, CLIMB_MAX_F); for (const k in bestBy) best = Math.max(best, bestBy[k]); for (const r of top) best = Math.max(best, r.f);
    let run = null; const r = src.run;
    if (r && typeof r === 'object' && !Array.isArray(r)) {
      const from = num(r.from, CLIMB_MAX_F), seed = num(r.seed, 2e9);
      if (from >= 1 && (from - 1) % 5 === 0 && seed >= 1) {
        const cp = obj(r.cp), pl = {}; for (const k of Object.keys(obj(cp.pl))) if (/^[0-3]$/.test(k)) { const q = obj(cp.pl[k]); pl[k] = { power: num(q.power, 99), twin: num(q.twin, 99), armor: num(q.armor, 99), lives: num(q.lives, 99), sp: num(q.sp, 999) }; }
        run = { seed, from, retry: num(r.retry, CLIMB_RETRY_MAX), top: Math.min(num(r.top, CLIMB_MAX_F), Math.max(0, from - 1) + CLIMB.PER), n: Math.max(1, num(r.n, 4)), names: names(r.names),
          cp: { loop: 0, futon: num(cp.futon, 99), tower: num(cp.tower, 99), slow: num(cp.slow, 99), pl } };
      }
    }
    return { v: 1, best, bestBy, claimed: Math.min(num(src.claimed, CLIMB_MAX_F), best), plays: num(src.plays, 1e7), top, who, run };
  }
  /* 階をクリアした時の記録（画面が呼ぶ。o＝cleanClimb の形を書きかえる）。f＝クリアした階、names＝その場の名前、seed＝ちょうせんの種。
     返す物＝{ best：家族の新記録, rank：top の順位（0 から。入らなければ -1） }。top は同じ seed の行を上書き */
  function climbNote(o, f, names, seed, at) {
    f = Math.max(0, Math.min(CLIMB_MAX_F, Math.floor(Number(f)) || 0)); if (!f) return { best: false, rank: -1 };
    const nm = (Array.isArray(names) ? names : []).filter(s => typeof s === 'string' && s).map(s => s.slice(0, 12)).slice(0, 4), n = Math.max(1, Math.min(4, nm.length || 1));
    const nb = f > o.best; if (nb) o.best = f; if (f > (o.bestBy[n] | 0)) o.bestBy[n] = f;
    for (const k of nm) o.who[k] = Math.max(o.who[k] | 0, f);
    const who = {}; Object.keys(o.who).sort((a, b) => o.who[b] - o.who[a]).slice(0, 20).forEach(k => { who[k] = o.who[k]; }); o.who = who;   // 高い順・20 人まで（cleanClimb と同じ形）
    seed = Math.max(0, Math.floor(Number(seed)) || 0); let row = seed ? o.top.find(r => r.seed === seed) : null;
    if (row) { if (f > row.f) Object.assign(row, { f, n, names: nm, at: at | 0 }); } else o.top.push(row = { f, n, names: nm, at: Math.max(0, Math.floor(Number(at)) || 0), seed });
    o.top.sort((a, b) => b.f - a.f || a.at - b.at); o.top = o.top.slice(0, 5);
    return { best: nb, rank: o.top.indexOf(row) };
  }
  /* ===== P8：ワールドマップの しんりゃく（No.48）。クリアした面に ときどき印（2 つまで）。おいはらうと ごほうび。ほうっておいても何も へらない。
     本当の時間は使わない（ぼうけんの面のクリア・塔の休みの階ごとに invTick）。しんりゃくの面は 1 面だけの並び（G.p3dList）で遊ぶ ===== */
  const INV = { MAX: 2, MIN_OPEN: 9, EVERY: [5, 7], AHEAD: 12, HIST: 10, COINS: 40, CHARM_AT: 5, GOLD_AT: 10 };
  function invOk(st) { return !!st && !!st.gen && !st.bosses && !st.type && !st.reunion && !(st.event && st.event.kind === 'miniboss') && st.gi >= 2; }
  // o＝cleanInv の形（書きかえる）。出したら { gi, seed } を返す。出さなければ null。乱数は o.seed を進めて使う
  function invTick(o, open) {
    o.tick++; if (open < INV.MIN_OPEN || o.act.length >= INV.MAX) return null;
    const first = !o.first; if (!first && o.tick < o.next) return null;
    const rnd = makeRnd(o.seed); o.seed = (Math.floor(rnd() * 2e9) | 0) || 7;
    let cand = ADV.filter(s => invOk(s) && s.gi < open - 1 && !o.hist.includes(s.gi) && !o.act.some(a => a.gi === s.gi));
    const far = cand.filter(s => !o.act.some(a => ADV[a.gi].world === s.world)); if (far.length) cand = far;
    if (!cand.length) return null;
    const pick = first ? ADV[2] : cand[Math.floor(rnd() * cand.length)], a = { gi: pick.gi, seed: 1 + Math.floor(rnd() * 1e9) };
    o.first = true; o.act.push(a); o.hist = o.hist.concat(a.gi).slice(-INV.HIST); o.tick = 0; o.next = INV.EVERY[0] + Math.floor(rnd() * (INV.EVERY[1] - INV.EVERY[0] + 1)); return a;
  }
  // しんりゃくの面：景色・地図の作り・強さは元のまま、敵の顔ぶれだけ先の面の物＋隊長 +1。夜・イベント・ミニボス・ひみつは無し
  function invadeStage(gi, seed, open) {
    const src = ADV[gi], L = ADV[Math.min(ADV.length - 1, Math.max(gi, Math.min((open | 0) - 2, gi + INV.AHEAD)))];
    return Object.assign({}, src, { id: 'i-' + gi, inv: true, seed: seed | 0, mix: L.mix, specials: L.specials, share: L.share, captains: Math.min(2, (src.captains | 0) + 1),
      easy: false, night: false, event: null, surprise: null, newKind: null, gimNew: false, sceneNew: false, reunion: null, p3dSec: null, ja: 'しんりゃく！ ' + src.ja, zh: '入侵！' + src.zh });
  }
  // 記録 tank-v25-inv。open（ぼうけんの開いた面の数）を渡すと、まだ開いていない面の印を外す。こわれた入力でも 決まった形を返す。2 回かけても同じ
  function cleanInv(o, open) {
    const src = o && typeof o === 'object' && !Array.isArray(o) ? o : {}, num = (v, mx, d) => { const n = Math.floor(Number(v)); return Number.isFinite(n) && n >= 0 ? Math.min(n, mx) : (d || 0); };
    const opn = open === undefined || open === null ? ADV.length + 1 : Number(open) || 0;
    const okGi = gi => Number.isInteger(gi) && gi >= 0 && gi < ADV.length && invOk(ADV[gi]);
    const act = []; for (const a of Array.isArray(src.act) ? src.act : []) { if (!a || typeof a !== 'object') continue; const gi = Number(a.gi);
      if (okGi(gi) && gi < opn - 1 && !act.some(b => b.gi === gi) && act.length < INV.MAX) act.push({ gi, seed: num(a.seed, 2e9) || 1 }); }
    const hist = (Array.isArray(src.hist) ? src.hist : []).map(Number).filter(gi => Number.isInteger(gi) && gi >= 0 && gi < ADV.length).slice(-INV.HIST);
    const next = num(src.next, INV.EVERY[1], 6);
    return { v: 1, tick: num(src.tick, 1e7), next: next >= INV.EVERY[0] ? next : 6, seed: num(src.seed, 2e9) || 20261116, first: !!src.first, act, hist, won: num(src.won, 1e7), lost: num(src.lost, 1e7) };
  }
  // おいはらった時の ごほうび（一人ずつ）。won＝この勝ちを足した後の 家族の回数
  function invReward(won) { const k = won | 0, gold = k > 0 && k % INV.GOLD_AT === 0; return { coins: INV.COINS, silver: 1, charm: !gold && k > 0 && k % INV.CHARM_AT === 0 ? 1 : 0, gold: gold ? 1 : 0 }; }
  /* ===== P8 END ===== */
  /* 部品から地図を作る。cols＝横の升（13 の倍数：26・39・52）、rows＝縦の升（13 の倍数）、seed＝種。同じ種なら同じ地図 */
  function genRows(st, cols, rows, seed, layout) {
    let a = (seed >>> 0) || 1;
    const rnd = () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    // v0.22 P5A：部品・仕掛け・砂は場面から。layout＝計算の決めた おうちの置き方（無ければ A。A の時だけ おうちの近くの溶岩けし・砂は下 6 行まで）
    const w = sceneOf(st), lib = w.rooms, R = 13, baseA = (layout || 'A') === 'A', nx = Math.max(2, Math.round(cols / R)), ny = Math.max(1, Math.round(rows / R));
    const grid = []; for (let y = 0; y < rows; y++) grid.push(new Array(cols).fill('.'));
    const flipV = r => r.slice().reverse();
    const put = (room, rx, ry) => {
      for (let my = 0; my < 5; my++) for (let mx = 0; mx < 5; mx++) {
        let c = room[my][mx]; if (c === '.') continue;
        if (c === 'B' && st.s > 3 && rnd() < (st.s - 3) * 0.04) c = 'S';           // 難しい面ほど、鋼が少し増える
        if (st.easy && c !== 'W' && rnd() < 0.3) continue;                            // 楽な面は壁を少し減らす
        for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) { const x = rx * R + 1 + mx * 2 + dx, y = ry * R + 1 + my * 2 + dy; if (x < cols && y < rows) grid[y][x] = c; }
      }
    };
    // P7 v0.24：仕掛けの部屋は そのまま書く（鋼に変える・楽な面で けずる を通さない）
    const putG = (room, rx, ry) => { for (let my = 0; my < 5; my++) for (let mx = 0; mx < 5; mx++) { const c = room[my][mx]; if (c === '.') continue;
      for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) { const x = rx * R + 1 + mx * 2 + dx, y = ry * R + 1 + my * 2 + dy; if (x < cols && y < rows) grid[y][x] = c; } } };
    const kind = gimKind(st, layout), later = [];   // kind が有る時だけ 部屋を引き終わってから書く（無い面は v0.23 と 1 升も同じ）
    for (let ry = 0; ry < ny; ry++) {
      const half = Math.floor(nx / 2), picks = [];
      for (let i = 0; i < half; i++) { let r = lib[Math.floor(rnd() * lib.length)]; if (rnd() < 0.5) r = flipV(r); picks.push(r); }
      if (kind) { for (let i = 0; i < half; i++) later.push({ room: picks[i], rx: i, ry, left: true }); } else for (let i = 0; i < half; i++) put(picks[i], i, ry);
      if (nx % 2) { let r = lib[Math.floor(rnd() * lib.length)]; if (rnd() < 0.5) r = flipV(r); if (kind) later.push({ room: r, rx: half, ry }); else put(r, half, ry); }
    }
    if (kind) {
      // 左半分の部屋から st.gim.n 個を 仕掛けの部屋に（とびら・たるは上の段を先に。2 つ目は木箱、kind が c なら たる。川・ワープは部屋を さしかえない）
      const want = []; if (GIM_ROOMS[kind]) want.push(kind); if ((st.gim.n | 0) >= 2) want.push(kind === 'c' ? 'o' : 'c');
      for (const wk of want) {
        const slots = later.filter(o => o.left && !o.gim), top = slots.filter(o => o.ry === 0), pool = (wk === 'd' || wk === 'o') && top.length ? top : slots;
        if (!pool.length) break; const o = pool[Math.floor(rnd() * pool.length)], L = GIM_ROOMS[wk]; o.room = L[Math.floor(rnd() * L.length)]; o.gim = wk;
      }
      for (const o of later) (o.gim ? putG : put)(o.room, o.rx, o.ry);
    }
    // 左半分を右へ鏡に写す（左右でまったく同じ形。片側だけ不利にならない）
    for (let y = 0; y < rows; y++) for (let x = 0; x < Math.floor(cols / 2); x++) grid[y][cols - 1 - x] = grid[y][x];
    // P7 v0.24：川と橋（鏡の後）。y＝11・12 を水、橋（R）は 3 本（52 列は 5 本）。橋の前後（y＝9・10・13・14）は空ける
    if (kind === 'r' && rows > 14) {
      const m = Math.floor((cols - 4) / 2), spans = [[5, 8], [cols - 9, cols - 6], [m, cols - 1 - m]]; if (cols >= 52) spans.push([17, 20], [cols - 21, cols - 18]);
      for (const y of [11, 12]) for (let x = 0; x < cols; x++) grid[y][x] = 'W';
      for (const [a, b] of spans) for (let x = a; x <= b; x++) { grid[11][x] = grid[12][x] = 'R'; for (const y of [9, 10, 13, 14]) grid[y][x] = '.'; }
    }
    // 砂の世界：地面のあちこちに砂を足す（左右同じに）
    // 火山：おうちの近く（守る人が止まる所）には溶岩を置かない（A だけ。A 以外は計算の placeHouse が消す）
    if (baseA && (w.fx === 'volcano' || w.fx === 'inferno')) for (let y = rows - 9; y < rows; y++) for (let x = Math.floor(cols / 2) - 7; x <= Math.floor(cols / 2) + 6; x++) if (grid[y] && grid[y][x] === 'W') grid[y][x] = 'D';
    // 雪山は氷、火山は灰（同じやり方で、左右同じに）
    const over = w.sand ? ['D', w.sand] : w.ice ? ['I', w.ice] : w.ash ? ['D', w.ash] : null;
    if (over) for (let y = 1; y < (baseA ? rows - 6 : rows - 1); y += 2) for (let x = 1; x < cols / 2 - 1; x += 2) if (rnd() < over[1]) for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) {
      const xx = x + dx, yy = y + dy, mx = cols - 1 - xx; if (grid[yy][xx] === '.') { grid[yy][xx] = over[0]; grid[yy][mx] = over[0]; } }
    return grid.map(r => r.join(''));
  }
  /* 星 3 つの「時間内」の秒数。敵の数とボスで決める */
  function parTime(st, enemies) { if (st.type === 'flags') return Math.round(50 + enemies * 2.6); if (st.type === 'escort') return st.short ? 90 : 150; if (st.type === 'breakthrough') return 130; return Math.round(40 + enemies * 4.2 + (st.bosses ? st.bosses.length * 50 : 0)) + (st.event && st.event.kind === 'miniboss' ? 25 : 0); }   // v0.23 P6A：ミニボスの面は +25 秒
  /* 生き残りの面の星 3 つ目：たおす敵の数 */
  function killGoal(st, enemies) { return Math.max(6, Math.round(enemies * 0.9 * (st.survive || 90) / 90)); }

  /* v0.22 P5A 保存の決まり（No.52）。面の番号は変えないので open・stars はそのまま。種類が変わった面（gi）の best（最短時間）だけ消す。
     adv＝tank-progress の adv（{ open, stars, best, ver }）。ver < 22 なら 1 回だけ直して ver = 22（今は ADV_VER まで順に）。同じ物を返す（こわれた物は そのまま返す） */
  const ADV_VER = 25, TYPE_CHANGED = [1, 10, 16, 28, 34, 37, 41, 44, 56, 64];
  // v0.23 P6A：ミニボスの 12 面と 種類が動いた 4 面（52・122・126・130）。ver < 23 なら この best も消す
  const TYPE_CHANGED_23 = [3, 11, 27, 35, 51, 52, 59, 75, 83, 99, 107, 122, 123, 126, 130, 131];
  // P8 v0.25：みじかい護送・護送になった 4 面（w1-6・w2-2・w3-2・w4-15）。ver < 25 なら この best も消す
  const TYPE_CHANGED_25 = [5, 25, 49, 86];
  function migrateAdv(adv) {
    if (!adv || typeof adv !== 'object' || Array.isArray(adv)) return adv;
    const ver = Number(adv.ver) || 0;
    if (ver >= ADV_VER) return adv;
    if (adv.best && typeof adv.best === 'object') {
      if (ver < 22) for (const gi of TYPE_CHANGED) delete adv.best[gi];
      if (ver < 23) for (const gi of TYPE_CHANGED_23) delete adv.best[gi];
      if (ver < 25) for (const gi of TYPE_CHANGED_25) delete adv.best[gi];
    }
    adv.ver = ADV_VER; return adv;
  }

  /* ===== P6A BEGIN（v0.23）：ミニゲームの面・ごほうび・記録 ===== */
  const MINI = { treasure: { sec: 10, ja: 'たからべや', zh: '宝藏房间', ic: '🎁' }, target: { sec: 20, ja: 'まとあて', zh: '打靶', ic: '🎯' },
    coins: { sec: 15, ja: 'コインキャッチ', zh: '接金币', ic: '🪙' }, race: { sec: 20, ja: 'かべぬきレース', zh: '破墙赛跑', ic: '🏁' } };
  const MINI_KINDS = ['treasure', 'target', 'coins', 'race'];
  const MINI_REWARD = { coins: [15, 25, 35], wood: 1 };
  // ミニゲームの面（bonusStage と同じ作り。1 面だけの並び G.p3dList=[面] で遊ぶ）。opt＝{ again：同じ面の 2 回目から, seed }
  function miniStage(kind, world, opt) {
    const M = MINI[kind]; if (!M) return null; opt = opt || {};
    const wi = WORLDS[world] ? world | 0 : 0, w = WORLDS[wi], H = SCENES[w.home];
    return Object.assign({}, ADV[wi * PER_WORLD + 1], { id: 'm-' + kind, mini: { kind, sec: M.sec, again: !!opt.again }, seed: opt.seed | 0, ja: M.ja, zh: M.zh,
      scene: w.home, sceneNew: false, theme: H.theme, fx: 'none', storm: false, blizzard: false, night: false, base: 'A', baseSide: 'L', event: null, type: null, survive: 0,
      bosses: null, reunion: null, p3dSec: null, p3dChests: null, captains: 0, easy: true, rows: 26, gateLegacy: true, look: 0, gim: null, gimNew: false, surprise: null, newKind: null });   // P7：景色・仕掛け・イベントなし
  }
  // 一人ずつの ごほうび。tier＝段 0〜2。たからべやは 取った宝箱の中身だけ（ここでは 0）
  function miniReward(kind, tier, again) {
    if (kind === 'treasure') return { coins: 0, wood: 0 };
    return { coins: MINI_REWARD.coins[Math.max(0, Math.min(2, tier | 0))], wood: again ? 0 : MINI_REWARD.wood };
  }
  // 記録 tank-v23-mini。こわれた入力でも 決まった形を返す。best は人数ごと（まと・コイン＝大きいほど良い、レース＝1 位の秒 × 10・小さいほど良い・0＝まだ）
  function cleanMini(o) {
    const src = o && typeof o === 'object' && !Array.isArray(o) ? o : {}, num = (v, mx) => { const n = Math.floor(Number(v)); return Number.isFinite(n) && n > 0 ? Math.min(n, mx) : 0; };
    const obj = v => (v && typeof v === 'object' && !Array.isArray(v) ? v : {});
    const best = {}; for (const k of ['target', 'coins', 'race']) { const b = obj(obj(src.best)[k]); best[k] = { 1: num(b[1], 99999), 2: num(b[2], 99999), 3: num(b[3], 99999), 4: num(b[4], 99999) }; }
    const plays = {}; for (const k of MINI_KINDS) plays[k] = num(obj(src.plays)[k], 1e7);
    const mb = { win: num(obj(src.mb).win, 1e7), flee: num(obj(src.mb).flee, 1e7) };
    const done = {}; const d = obj(src.done); for (const k of Object.keys(d)) if (/^a\d{1,3}-\d{1,3}$/.test(k) && d[k]) done[k] = 1;
    return { v: 1, best, plays, mb, done };
  }
  /* ===== P6A END ===== */

  const api = { REUNION, MAPS, MIX, FX_NAME, CAMPAIGN, EXTRA, HELL, WORLDS, ADV, makeRandom, BOSS_TALK, PER_WORLD, genRows, parTime, killGoal,
    SCENES, SCENE_KEY, sceneOf, migrateAdv, ADV_VER, TYPE_CHANGED, RAND_BASE,   // v0.22 P5A
    MINI_BOSS, MINI, MINI_KINDS, MINI_REWARD, MINI_BY_NO, MINI_24, eventOf, miniStage, miniReward, cleanMini, TYPE_CHANGED_23,   // v0.23 P6A
    LOOKS, lookOf, RIVER_LOOK, SUR, SUR_ORDER, surpriseOf, surpriseRand, GIM_FROM, GIM_ROOMS, GIM_INFO, gimKind, RIVER_OK, ADV_SPECIAL_FROM,   // P7 v0.24
    CARGO, CARGO_HEAL_R, makeRnd, TYPE_CHANGED_25, CLIMB, climbFloor, makeClimb, climbStart, CLIMB_REWARD, climbReward, cleanClimb, climbNote,
    INV, invOk, invTick, invadeStage, cleanInv, invReward };   // P8 v0.25
  root.TankStages = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);

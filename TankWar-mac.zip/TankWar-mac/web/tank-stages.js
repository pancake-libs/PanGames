/* 戦車のゲームの面（26 × 26 の升。戦車は 2 × 2 升）。
   tk1〜tk15 は TK（https://github.com/sunsharebay-lgtm/TK の 坦克大战、v1.6.14）の面と敵の割合を、作者の許可を得て写したもの（2026-11-14、D-015）。
   grass は自作（TK の 1 面目は 1985 年のファミコンのゲームの 1 面とほぼ同じ形のため使わない。ADR-04）。
   文字：. 地面 B レンガ S 鋼 W 水 T 木 I 氷 D 砂。おうち・出口・味方の出る所は、計算（tank-sim.js）が置く。
   この面のデータは make_stages.py で作った。面を直す時は、ここを直接直してよい */
(function (root) {
  'use strict';
  const MAPS = {
    grass: [
      "..........................",
      "..........................",
      "..TTTT....BBBBBB....TTTT..",
      "..TTTT....BBBBBB....TTTT..",
      "..........................",
      "BBBB..WWWW......WWWW..BBBB",
      "BBBB..WWWW......WWWW..BBBB",
      ".........TT....TT.........",
      "..BB.....TT....TT.....BB..",
      "..BB..BBBB..SS..BBBB..BB..",
      "..BB..BBBB..SS..BBBB..BB..",
      "..........................",
      "TTTT..BB..TTTTTT..BB..TTTT",
      "TTTT..BB..TTTTTT..BB..TTTT",
      "..........................",
      "..SS..BBBBBB..BBBBBB..SS..",
      "..SS..BB..........BB..SS..",
      "......BB..WWWWWW..BB......",
      "..........WWWWWW..........",
      "..........................",
      "..BBBB..TT......TT..BBBB..",
      "..BBBB..TT......TT..BBBB..",
      "..........................",
      "..........................",
      "..........................",
      ".........................."
    ],
    tk1: [
      "..........................",
      "..SS..SS..SS..SS..SS..SS..",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "....BBBB........BBBB......",
      "....BBBB........BBBB......",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..........................",
      "SS......SS......SS......SS",
      "SS......SS......SS......SS",
      "..BBBBBB..BBBB..BBBBBB....",
      "..BBBBBB..BBBB..BBBBBB....",
      "..........................",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..........................",
      "BBBB......BBBBBB......BBBB",
      "BBBB......BBBBBB......BBBB",
      "..........................",
      "..........................",
      "..........................",
      ".........................."
    ],
    tk2: [
      "..........................",
      "..........................",
      "..BB..BBBBBBBBBBBB..BB....",
      "..BB..BBBBBBBBBBBB..BB....",
      "..BB..............BB..BB..",
      "..BB..............BB..BB..",
      "WWWWWW..WWWWWW..WWWWWW....",
      "WWWWWW..WWWWWW..WWWWWW....",
      "..........................",
      "..BBBB..BB..BB..BBBB..BB..",
      "..BBBB..BB..BB..BBBB..BB..",
      "..........................",
      "..WWWW..WWWWWWWW..WWWW....",
      "..WWWW..WWWWWWWW..WWWW....",
      "..........................",
      "BB..BBBB..BBBB..BBBB..BBBB",
      "BB..BBBB..BBBB..BBBB..BBBB",
      "..........................",
      "..SS..............SS......",
      "..SS..............SS......",
      "..BBBBBB......BBBBBB......",
      "..BBBBBB......BBBBBB......",
      "..........................",
      "..........................",
      "..........................",
      ".........................."
    ],
    tk3: [
      "..........................",
      "..TTTT......TTTT......TTTT",
      "..TTTT......TTTT......TTTT",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "TTTT..TTTTTTTTTTTT..TTTTTT",
      "TTTT..TTTTTTTTTTTT..TTTTTT",
      "..BB..............BB......",
      "..BB..............BB......",
      "..BB..BBBBBBBBBB..BB..BB..",
      "..BB..BBBBBBBBBB..BB..BB..",
      "......BB......BB..........",
      "......BB......BB..........",
      "TTTTTTBB......BBTTTTTTTT..",
      "TTTTTTBB......BBTTTTTTTT..",
      "......BBBBBBBBBB..........",
      "......BBBBBBBBBB..........",
      "..BB..............BB..BB..",
      "..BB..............BB..BB..",
      "..TTTT..TTTTTT..TTTT..TT..",
      "..TTTT..TTTTTT..TTTT..TT..",
      "..........................",
      "..BB..BB......BB..BB......",
      "..BB..BB......BB..BB......",
      "..........................",
      ".........................."
    ],
    tk4: [
      "..........................",
      "..IIIIIIIIIIIIIIIIIIIIII..",
      "..II..BB..BB..BB..BB..II..",
      "..II..BB..BB..BB..BB..II..",
      "..II..II..II..II..II..II..",
      "..II..II..II..II..II..II..",
      "SSII..IIIIIIIIIIII..IISS..",
      "SSII..IIIIIIIIIIII..IISS..",
      "..II..II......II..II......",
      "..II..II......II..II......",
      "..IIIIII..BB..IIIIII..BB..",
      "..IIIIII..BB..IIIIII..BB..",
      "..........BB..............",
      "..........BB..............",
      "BBII..IIIIIIIIIIIIII..IIBB",
      "BBII..IIIIIIIIIIIIII..IIBB",
      "..II..............II......",
      "..II..............II......",
      "..IIII..BBBBBB..IIII..BB..",
      "..IIII..BBBBBB..IIII..BB..",
      "..........................",
      "..BB..IIII......IIII..BB..",
      "..BB..IIII......IIII..BB..",
      "..........................",
      "..........................",
      ".........................."
    ],
    tk5: [
      "..........................",
      "..........................",
      "BB....BB..BB..BB..BB....BB",
      "BB..BBBB..BB..BB..BBBB..BB",
      "BB..BB......BB......BB..BB",
      "BB..BB..BBBBBBBBBB..BB..BB",
      "BB..BB..BB......BB..BB..BB",
      "BB..BBBBBB..BB..BB..BB..BB",
      "BB......BB..BB..BB......BB",
      "BBBBBB..BB..BB..BBBBBBBBBB",
      "........BB..BB............",
      "BBBBBB..BB..BBBBBB..BBBBBB",
      "BB..BB..BB......BB..BB..BB",
      "BB..BB..BBBBBB..BB..BB..BB",
      "BB..BB......BB..BB..BB..BB",
      "BB..BBBBBB..BB..BB..BB..BB",
      "BB......BB..BB..BB..BB..BB",
      "BBBBBB..BB..BB..BB..BB..BB",
      "........BB..BB..BB......BB",
      "BBBBBB..BB..BB..BBBBBB..BB",
      "BB..BB..BB..BB......BB..BB",
      "BB..BB..BB..BBBBBB..BB..BB",
      "BB..BB......BB..BB..BB..BB",
      "BB..BBBB..BBBB....BBBB..BB",
      "..........................",
      ".........................."
    ],
    tk6: [
      "..........................",
      "..........................",
      "..SS..BBBBBBBBBBBB..SS....",
      "..SS..BBBBBBBBBBBB..SS....",
      "..SS..BB........BB..SS....",
      "..SS..BB..SSSS..BB..SS....",
      "..SS..BB..SSSS..BB..SS....",
      "..SS..BB........BB..SS....",
      "..SS..BBBBBB..BBBB..SS....",
      "..SS................SS....",
      "..SSSSSS..BBBB..SSSSSS....",
      "..........BBBB............",
      "BBBB..BB..BBBB..BB..BBBB..",
      "BBBB..BB........BB..BBBB..",
      "......BB..SSSS..BB........",
      "..BB..BB..SSSS..BB..BB....",
      "..BB..BBBBBBBBBBBB..BB....",
      "..BB..............BB..BB..",
      "..BBBBBB..BBBB..BBBBBB....",
      "..........BBBB............",
      "SS..BBBB..BBBB..BBBB..SS..",
      "SS..BBBB........BBBB..SS..",
      "..........................",
      "..BB..........BB..........",
      "..........................",
      ".........................."
    ],
    tk7: [
      "..........................",
      "..BB..................BB..",
      "..BB..BBBBBBBBBBBB....BB..",
      "..BB..BB........BB....BB..",
      "..BB..BB..BBBB..BB....BB..",
      "..BB..BB..BBBB..BB....BB..",
      "..BB..BB........BB....BB..",
      "..BB..BBBBBB..BBBB....BB..",
      "..BB..................BB..",
      "..BBBBBBBB..BBBBBBBBBBBB..",
      "..........................",
      "BBBBBB..BBBBBBBBBB..BBBBBB",
      "..........................",
      "..BB..BBBBBB..BBBBBB..BB..",
      "..BB..BB........BB....BB..",
      "..BB..BB..SSSS..BB....BB..",
      "..BB..BB..SSSS..BB....BB..",
      "..BB..BB........BB....BB..",
      "..BB..BBBBBBBBBBBB....BB..",
      "..BB..................BB..",
      "..BBBBBB......BBBBBB..BB..",
      "..........................",
      "..BB..BB......BB..BB......",
      "..BB..BB......BB..BB......",
      "..........................",
      ".........................."
    ],
    tk8: [
      "..........................",
      "..........................",
      "BBBB..BBBB..BBBB..BBBB..BB",
      "BBBB..BBBB..BBBB..BBBB..BB",
      "..........................",
      "WWWWWWWW....WWWWWWWW......",
      "WWWWWWWW....WWWWWWWW......",
      "WWWWWWWW....WWWWWWWW......",
      "..........................",
      "..BB..BBBBBBBBBBBB..BB....",
      "..BB..BB........BB..BB....",
      "..BB..BB..SSSS..BB..BB....",
      "..BB..BB..SSSS..BB..BB....",
      "..BB..BB........BB..BB....",
      "..BB..BBBB..BBBBBB..BB....",
      "..........................",
      "....WWWWWWWW....WWWWWWWW..",
      "....WWWWWWWW....WWWWWWWW..",
      "....WWWWWWWW....WWWWWWWW..",
      "..........................",
      "..BBBB..BBBB..BBBB..BBBB..",
      "..BBBB..BBBB..BBBB..BBBB..",
      "..........................",
      "..BB..............BB......",
      "..........................",
      ".........................."
    ],
    tk9: [
      "..........................",
      "..TT..IIIIIIIIIIII..TT....",
      "..TT..IIIIIIIIIIII..TT....",
      "..TT..II........II..TT....",
      "..TT..II..BBBB..II..TT....",
      "..TT..II..BBBB..II..TT....",
      "..TT..II........II..TT....",
      "..TT..IIIIII..IIII..TT....",
      "..TT..............TT..TT..",
      "IIIIII..BBBBBB..IIIIII....",
      "IIIIII..BBBBBB..IIIIII....",
      "..........................",
      "..BB..TTTT..TTTT..BB..BB..",
      "..BB..TTTT..TTTT..BB..BB..",
      "..BB..............BB..BB..",
      "..BBBBBB..SSSS..BBBBBB....",
      "..........SSSS............",
      "IIII..BB..............BB..",
      "IIII..BB..IIIIIIII..BB....",
      "......BB..IIIIIIII..BB....",
      "..TTTT....IIIIIIII....TTTT",
      "..TTTT................TTTT",
      "..........................",
      "..BB..BB......BB..BB......",
      "..........................",
      ".........................."
    ],
    tk10: [
      "..........................",
      "..SS..SS..SS..SS..SS..SS..",
      "..SS..SS..SS..SS..SS..SS..",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "SSSS..SSSS..SSSS..SSSS..SS",
      "BBBB..BBBB..BBBB..BBBB..BB",
      "..........................",
      "..BBBBBBBB..BBBBBBBB..BB..",
      "..BB....BB..BB....BB..BB..",
      "..BB..SSBB..BBSS..BB..BB..",
      "..BB..SSBB..BBSS..BB..BB..",
      "..BB....BB..BB....BB..BB..",
      "..BBBBBBBB..BBBBBBBB..BB..",
      "..........................",
      "SS..BBBB..SSSSSS..BBBB..SS",
      "SS..BBBB..SSSSSS..BBBB..SS",
      "..........................",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..SS..SS..SS..SS..SS..SS..",
      "..........................",
      "BBBB......BBBBBB......BBBB",
      "..........................",
      "..........................",
      ".........................."
    ],
    tk11: [
      "..........................",
      "..SS..BBBB..SSSS..BBBB..SS",
      "..SS..BBBB..SSSS..BBBB..SS",
      "..........................",
      "WWWW..IIII..BBBB..IIII..WW",
      "WWWW..IIII..BBBB..IIII..WW",
      "..........................",
      "..BBBBBB..TTTTTT..BBBBBB..",
      "..BB..BB..TTTTTT..BB..BB..",
      "..BB..BB..........BB..BB..",
      "..BB..BBBBSSSSBBBBBB..BB..",
      "..BB..BBBBSSSSBBBBBB..BB..",
      "..BB..............BB..BB..",
      "..BBBBBB..BBBB..BBBBBB....",
      "..........BBBB............",
      "IIII..SS..BBBB..SS..IIII..",
      "IIII..SS........SS..IIII..",
      "......SS..BBBB..SS........",
      "..BB..SSSSBBBBSSSS..BB....",
      "..BB..............BB..BB..",
      "..BBBB..TTTT..TTTT..BBBB..",
      "..BBBB..TTTT..TTTT..BBBB..",
      "..........................",
      "..BB..BB......BB..BB......",
      "..........................",
      ".........................."
    ],
    tk12: [
      "..........................",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BBBB....BB..",
      "..BB..BB..BB..BBBB....BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "......BBSSBB..BBSSBB......",
      "......BBSSBB..BBSSBB......",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "....BB..BBBBBBBB..BB......",
      "....BB..BBBBBBBB..BB......",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "....BBBB........BBBB......",
      "....BBBB........BBBB......",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "......SSSS..SSSS..........",
      "......SSSS..SSSS..........",
      "..BB..BB..BB..BB..BB..BB..",
      "..BB..BB..BB..BB..BB..BB..",
      "..........................",
      "..........................",
      ".........................."
    ],
    tk13: [
      "..........................",
      "..WW..WWWWWW..WWWWWW..WW..",
      "..WW..WWWWWW..WWWWWW..WW..",
      "..BB..WWWWWW..WWWWWW..BB..",
      "..BB..WWWWWW..WWWWWW..BB..",
      "..........................",
      "..WW..WWWWWW..WWWWWW..WW..",
      "..WW..WWWWWW..WWWWWW..WW..",
      "..BB..BBBBBB..BBBBBB..BB..",
      "..BB..BBBBBB..BBBBBB..BB..",
      "...........BB.............",
      "...........BB.............",
      "..........................",
      "BB..WWWW..WWWWWW..WWWW..BB",
      "BB..WWWW..WWWWWW..WWWW..BB",
      "..WW..WW..WWWW..WW..WW....",
      "..WW..WW..WWWW..WW..WW....",
      "..BB..BB..BBBB..BB..BB....",
      "..BB..BB..BBBB..BB..BB....",
      "..........................",
      "..SS..SS..SSSS..SS..SS....",
      "..SS..SS..SSSS..SS..SS....",
      "..........................",
      "..BB..BB......BB..BB......",
      "..........................",
      ".........................."
    ],
    tk14: [
      "..........................",
      "..SS..BBBB..SS..BBBB..SS..",
      "..SS..BBBB..SS..BBBB..SS..",
      "..BB..SSSS..BB..SSSS..BB..",
      "..BB..SSSS..BB..SSSS..BB..",
      "..........................",
      "..WW..BBBB..WW..BBBB..WW..",
      "..WW..BBBB..WW..BBBB..WW..",
      "..BB..WWWW..BB..WWWW..BB..",
      "..BB..WWWW..BB..WWWW..BB..",
      "SS..BB..SS..BB..SS..BB..SS",
      "SS..BB..SS..BB..SS..BB..SS",
      "..........................",
      "..BBBB..SS..BBBB..SS......",
      "..BBBB..SS..BBBB..SS......",
      "..SS..BBBB..SS..BBBB......",
      "..SS..BBBB..SS..BBBB......",
      "..........................",
      "..BB..WW..BB..WW..BB..BB..",
      "..BB..WW..BB..WW..BB..BB..",
      "..SS..BB..SS..BB..SS..SS..",
      "..SS..BB..SS..BB..SS..SS..",
      "..........................",
      "..BB..BB..BB..BB..BB..BB..",
      "..........................",
      ".........................."
    ],
    tk15: [
      "..........................",
      "..DD..DD..DD..DD..DD..DD..",
      "..DD..DD..DD..DD..DD..DD..",
      "..DD..DD..DD..DDDD....DD..",
      "..DD..DD..DD..DDDD....DD..",
      "..DD..DD..DD..DD..DD..DD..",
      "..DD..DD..DD..DD..DD..DD..",
      "......DDSSDD..DDSSDD......",
      "......DDSSDD..DDSSDD......",
      "..DD..DD..DD..DD..DD..DD..",
      "..DD..DD..DD..DD..DD..DD..",
      "....DD..DDDDDDDD..DD......",
      "....DD..DDDDDDDD..DD......",
      "..DD..DD..DD..DD..DD..DD..",
      "..DD..DD..DD..DD..DD..DD..",
      "WWWW..DDDD..DDDD..WWWW....",
      "WWWW..DDDD..DDDD..WWWW....",
      "..DD..DD..DD..DD..DD..DD..",
      "..DD..DD..DD..DD..DD..DD..",
      "......SSSS..SSSS..........",
      "......SSSS..SSSS..........",
      "..DD..DD..DD..DD..DD..DD..",
      "..DD..DD..DD..DD..DD..DD..",
      "..........................",
      "..........................",
      ".........................."
    ],
  };
  /* 面ごとの敵の割合（ふつう・はやい・どっしり・かたい）。人数に合わせて数を増やす */
  const MIX = {"grass": [12, 4, 3, 1], "tk1": [10, 4, 4, 2], "tk2": [8, 5, 5, 2], "tk3": [6, 6, 6, 2], "tk4": [8, 4, 6, 2], "tk5": [6, 5, 7, 2], "tk6": [4, 6, 7, 3], "tk7": [5, 5, 7, 3], "tk8": [4, 7, 6, 3], "tk9": [3, 6, 8, 3], "tk10": [2, 7, 8, 3], "tk11": [2, 5, 9, 4], "tk12": [6, 5, 6, 2], "tk13": [4, 6, 7, 3], "tk14": [3, 6, 8, 3], "tk15": [5, 6, 7, 2]};

  /* 面の仕掛け（TK の 12 種と同じ考え）。名前・説明は自作。効き目は tank-sim.js の FX */
  const FX_NAME = {
    none: ['ふつうの戦場', '标准战场'], steel: ['鋼の守り：おうちの囲いがはじめから鋼', '铁壁：小屋围墙开局即钢墙'],
    valley: ['急流：敵が速い', '急流：敌人更快'], jungle: ['森：木の中の戦車はねらわれにくい', '丛林：树中的坦克不易被瞄准'],
    ice: ['氷：氷の上はすべる', '冰面：冰上会滑行'], frenzy: ['弾幕：敵がよく撃つ', '弹幕：敌人射速提高'],
    siege: ['攻城：敵がおうちをねらう', '围城：敌人集中攻打小屋'], rush: ['車列：敵が早く速く来る', '车流：敌人增援更快'],
    snow: ['雪：味方が遅く、氷でよくすべる', '雪原：我方变慢，冰上滑得更远'], blood: ['血戦：敵がかたい', '血战：敌人更耐打'],
    sand: ['砂：味方が遅い', '沙地：我方变慢'], desert: ['砂漠：ときどき砂嵐で見えにくい', '沙漠：不时有沙尘暴，看不清'], lava: ['溶岩：水のそばで止まると熱い（5 秒でやられる）', '熔岩：在岸边停留 5 秒会受伤'],
    snowland: ['雪山：氷の上はよくすべる', '雪山：冰面上滑得很远'], volcano: ['火山：溶岩のそばで止まると熱い（5 秒でやられる）', '火山：在熔岩边停留 5 秒会受伤'],
    fortress: ['機械要塞：動く壁・スイッチ（撃つと壁が入れかわる）・ワープ', '机械要塞：移动墙、开关（射击可切换墙）、传送门'], inferno: ['地獄：溶岩のそばで止まると熱い。敵がとても強い', '地狱：在熔岩边停留会受伤，敌人非常强']
  };
  /* ふつうの 6 面（周回する）。partner は 3〜4 人の時に横へつなぐ面。面の並びと仕掛けは TK の物語の 6 面と同じ（1 面目だけ自作） */
  const CAMPAIGN = [
    { id: 'grass', ja: '草原', zh: '草原', map: 'grass', partner: 'tk1', fx: 'none', music: 'battle1' },
    { id: 'ice', ja: '氷の原っぱ', zh: '冰原', map: 'tk4', partner: 'tk9', fx: 'ice', music: 'battle2' },
    { id: 'sand', ja: '砂の町', zh: '沙漠', map: 'tk15', partner: 'tk12', fx: 'sand', music: 'battle1' },
    { id: 'lava', ja: '溶岩の町', zh: '熔岩', map: 'tk13', partner: 'tk8', fx: 'lava', music: 'battle2' },
    { id: 'jungle', ja: '深い森', zh: '深林', map: 'tk3', partner: 'tk2', fx: 'jungle', music: 'battle1' },
    { id: 'last', ja: '最後の守り', zh: '最终防线', map: 'tk11', partner: 'tk7', fx: 'blood', music: 'boss', boss: 'boss' }
  ];
  /* おまけの 5 面（1 周クリアすると選べる）。TK の残りの面と仕掛け */
  const EXTRA = [
    { id: 'x1', ja: '鉄の柵', zh: '铁栅阵地', map: 'tk1', partner: 'tk7', fx: 'steel', music: 'battle2' },
    { id: 'x2', ja: '谷川', zh: '河谷', map: 'tk2', partner: 'tk8', fx: 'valley', music: 'battle1' },
    { id: 'x3', ja: '十字路', zh: '十字路口', map: 'tk7', partner: 'tk1', fx: 'rush', music: 'battle2' },
    { id: 'x4', ja: '二つの川', zh: '双河', map: 'tk8', partner: 'tk2', fx: 'valley', music: 'battle1' },
    { id: 'x5', ja: '雪の森', zh: '雪林', map: 'tk9', partner: 'tk4', fx: 'snow', music: 'battle2' }
  ];
  /* 地獄の 5 面。どの面にも首領（TK の首領の考え）が出る。最後に超ボス */
  const HELL = [
    { id: 'h1', ja: '地獄・とりで', zh: '地狱·要塞', map: 'tk6', partner: 'tk10', fx: 'siege', music: 'hell' },
    { id: 'h2', ja: '地獄・めいろ', zh: '地狱·迷宫', map: 'tk5', partner: 'tk14', fx: 'frenzy', music: 'hell' },
    { id: 'h3', ja: '地獄・鋼のあらし', zh: '地狱·钢铁风暴', map: 'tk10', partner: 'tk6', fx: 'frenzy', music: 'hell' },
    { id: 'h4', ja: '地獄・地下工場', zh: '地狱·地下工厂', map: 'tk14', partner: 'tk5', fx: 'rush', music: 'hell' },
    { id: 'h5', ja: '地獄・決戦', zh: '地狱·决战', map: 'tk12', partner: 'tk1', fx: 'sand', music: 'hellboss', boss: 'superboss' }
  ];


  /* ================= ぼうけん（v0.11、開発の第 2 歩）：世界 1 草原・世界 2 砂漠 の 48 面。v0.13 で 世界 3 雪山・世界 4 火山 を足して 96 面。v0.14 で 世界 5 機械要塞・地獄 を足して 144 面 =================
     1 つの世界は 24 面。4 面は手作り（上の地図）、残りは「部品」を並べて自動で作る（面の番号が種）。
     部品は 13 × 13 升の小部屋。中を 5 × 5 の「大きな升」（2 × 2 升）で描き、右と下の 2 升・左と上の 1 升は通り道として空ける
     （部屋どうしの間に 3 升の通り道ができる）。左右は鏡に写して同じ形にする（片側だけ不利にならない）。
     文字：. 地面 B レンガ S 鋼 W 水 T 木 D 砂（味方も敵も遅くなる） */
  const ROOM_W1 = [
    ['.....', '.B.B.', '..T..', '.B.B.', '.....'], ['.....', 'BB.BB', '.....', '.S.S.', '.....'], ['.....', '.WWW.', '.....', 'B...B', 'B.T.B'],
    ['TT..T', 'T....', '..B..', '....T', 'T..TT'], ['.BBB.', '.B.B.', '.....', '.S.S.', '.....'], ['..B..', '..B..', 'BB.BB', '..B..', '..T..'],
    ['B....', 'BB...', '.BB..', '..BB.', '...B.'], ['.....', '.S.S.', '.....', '.BTB.', '.....'], ['.....', 'WW.WW', '.....', '.B.B.', '.B.B.'],
    ['.B...', '.B.BB', '.B...', '...B.', 'BB.B.'], ['.....', '..T..', '.TTT.', '..T..', '.....'], ['B.B.B', '.....', 'B.B.B', '.....', 'B.B.B'],
    ['BB...', 'B....', '...SS', '....S', '.T...'], ['.....', 'W...W', 'W.B.W', '..B..', '.....']
  ];
  const ROOM_W2 = [
    ['DD...', 'DDD..', '..B..', '..DDD', '...DD'], ['.B.B.', '.....', '.S.S.', '.....', '.B.B.'], ['..T..', '.WWW.', 'TW.WT', '.WWW.', '.....'],
    ['SS.SS', 'S...S', '..D..', 'S...S', 'SS.SS'], ['.DDD.', 'DDDDD', 'DD.DD', 'DDDDD', '.DDD.'], ['.....', '..B..', '.BBB.', 'BBSBB', '.....'],
    ['B.B.B', 'B.B.B', '.....', '.B.B.', '.B.B.'], ['.....', '.T.T.', '..S..', '.T.T.', '.....'], ['.....', 'BBBB.', '.....', '.BBBB', '.....'],
    ['S...S', '..D..', '.DSD.', '..D..', 'S...S'], ['DDDDD', '.....', '.B.B.', '.....', 'DD.DD'], ['SBBBS', 'B...B', 'B.D.B', '.....', '.....'],
    ['...DD', '..DD.', '.DD..', 'DD...', 'D...B'], ['S.S.S', '.....', '.D.D.', '.....', 'S.S.S']
  ];
  /* 世界 3 雪山（v0.13）：I 氷（よくすべる）・T 雪の木・S 岩・W 凍らない池 */
  const ROOM_W3 = [
    ['.....', '.III.', '.ISI.', '.III.', '.....'], ['T...T', '.B.B.', '..I..', '.B.B.', 'T...T'], ['IIIII', '.....', '.S.S.', '.....', 'IIIII'],
    ['..T..', '.TTT.', 'TTSTT', '.....', '..B..'], ['.....', 'BIIIB', 'B...B', 'BIIIB', '.....'], ['S...S', '.....', '..W..', '.....', 'S...S'],
    ['II...', 'IIB..', '..B..', '..BII', '...II'], ['.....', '.B.B.', 'IIIII', '.B.B.', '.....'], ['.T.T.', '.....', 'BB.BB', '.....', '.T.T.'],
    ['.....', '.WWW.', '.III.', '.....', 'B.S.B'], ['S.I.S', '..I..', 'IIIII', '..I..', 'S.I.S'], ['BBB..', 'B....', 'B.II.', '...II', '..T..'],
    ['.....', 'TT.TT', '.....', 'S...S', 'SB.BS'], ['..S..', '.I.I.', 'S.B.S', '.I.I.', '..S..']
  ];
  /* 世界 4 火山（v0.13）：W 溶岩（通れない。そばで止まると熱い）・S 岩・B レンガ・D 灰（遅くなる）・T 枯れ木 */
  const ROOM_W4 = [
    ['.....', '.WWW.', '.W.W.', '.....', 'S...S'], ['S.B.S', '.....', 'BBSBB', '.....', 'S.B.S'], ['DD.DD', 'D...D', '..W..', 'D...D', 'DD.DD'],
    ['..S..', '.SWS.', '..S..', '.....', 'B...B'], ['W...W', '.B.B.', '.....', '.B.B.', 'W...W'], ['.....', 'SSBSS', '.....', '.T.T.', '.....'],
    ['B..WW', 'B...W', 'BB...', '...BB', 'W...B'], ['.....', '.DDD.', 'BDWDB', '.DDD.', '.....'], ['S...S', 'S.B.S', '..B..', 'S.B.S', 'S...S'],
    ['.WW..', '..W..', '.....', '..BBB', '..B..'], ['T.T.T', '.....', 'SBSBS', '.....', '.....'], ['.....', 'W.S.W', '.....', 'B.B.B', 'B.B.B'],
    ['..D..', '.DSD.', 'DS.SD', '.DSD.', '..D..'], ['BBBBB', '.....', '..W..', '.....', 'S.S.S']
  ];
  /* 世界 5 機械要塞（v0.14）：S 鋼・B レンガ・G／J 動く壁（G と J が交代で開け閉めする。計算が g（開き）に変える）・K スイッチ（味方が撃つと壁が入れかわる） */
  const ROOM_W5 = [
    ['.....', '.SGS.', '.J.J.', '.SGS.', '.....'], ['S...S', '.BBB.', '.BKB.', '.BBB.', 'S...S'], ['GG.JJ', '.....', 'S.K.S', '.....', 'JJ.GG'],
    ['.S.S.', '.S.S.', '.....', 'BBGBB', '.....'], ['B.B.B', '.....', 'SJSGS', '.....', 'B.B.B'], ['.....', '.SSS.', '.....', 'G...J', 'G...J'],
    ['SS..S', 'S....', '..K..', '....S', 'S..SS'], ['.B.B.', 'BB.BB', '..S..', 'BB.BB', '.B.B.'], ['.....', 'JJGGJ', '.....', '.S.S.', '.....'],
    ['S.S.S', '.....', 'S.B.S', '.....', 'S.S.S'], ['..G..', '..G..', 'SS.SS', '..J..', '..J..'], ['BBBBB', '.....', 'S.K.S', '.....', 'BBBBB'],
    ['.....', '.GJG.', '.J.J.', '.GJG.', '.....'], ['S..BB', 'S...B', '..S..', 'B...S', 'BB..S']
  ];
  /* 地獄（v0.14）：W 溶岩・S 岩・B レンガ・D 灰・T 枯れ木 */
  const ROOM_W6 = [
    ['S.W.S', '.....', 'WBSBW', '.....', 'S.W.S'], ['.....', '.WWW.', '.WSW.', '.WWW.', '.....'], ['BB.BB', 'B...B', '..S..', 'B...B', 'BB.BB'],
    ['SS.SS', '.....', '.D.D.', '.....', 'SS.SS'], ['W...W', 'W.B.W', '..B..', 'W.B.W', 'W...W'], ['.T.T.', 'SBSBS', '.....', 'BSBSB', '.T.T.'],
    ['..S..', '.SWS.', 'SW.WS', '.SWS.', '..S..'], ['DDDDD', 'D...D', 'D.S.D', 'D...D', 'DDDDD'], ['B.B.B', 'S.S.S', '.....', 'S.S.S', 'B.B.B'],
    ['.....', 'WW.WW', '.....', '.SBS.', '.....'], ['S...S', '.BBB.', '.BWB.', '.BBB.', 'S...S'], ['.WW..', '.W...', '...SS', '..BBS', '.....'],
    ['T...T', '.S.S.', '..W..', '.S.S.', 'T...T'], ['BBBBB', 'S...S', '..D..', 'S...S', 'BBBBB']
  ];
  /* ボス（ぼうけんで出る 6 体）。name＝名前、enter＝出てくる時、defeat＝倒された時。spk：L・R は ふたご の左右。
     子どもが読めるよう、ひらがなを多めにした。台詞は自動では進まない（全員がスマホの「読んだ」を押すと次へ。JUN の指示） */
  const BOSS_TALK = {
    twin: { name: ['ふたご砲', '双炮坦克'], kana: 'ふたごほう', enter: [{ spk: 'L', ja: 'にいちゃん、みぎだ！', zh: '哥，右边！' }, { spk: 'R', ja: 'いや、ひだりだ！', zh: '不，左边！' }],
      defeat: [{ ja: '…つぎは そうだんしてから きめような', zh: '…下次商量好再决定吧' }] },
    engineer: { name: ['工兵車', '工兵车'], kana: 'こうへいしゃ', enter: [{ ja: 'このかべ、みっか かけて つんだんだ！ こわすなよ！', zh: '这堵墙我砌了三天！别打坏！' }],
      defeat: [{ ja: '…まあいい。また つむのも たのしいしな', zh: '…算了，再砌一遍也挺开心' }] },
    bigtank: { name: ['大型戦車', '大型坦克'], kana: 'おおがたせんしゃ', enter: [{ ja: 'ここは とおさん。…もう まもるものも ないのにな', zh: '此路不通。…明明已经没什么可守了' }],
      defeat: [{ ja: 'いいうでだ。この はらっぱ、おまえたちに まかせる', zh: '好身手。这片草原，交给你们了' }] },
    burrower: { name: ['砂もぐり', '钻沙者'], kana: 'すなもぐり', enter: [{ ja: 'は、はずかしいから みないで！（ズボッ）', zh: '别、别看我，好害羞！（噗）' }],
      defeat: [{ ja: '…でてきて、よかったかも', zh: '…出来一下，好像也不错' }] },
    scorpion: { name: ['さそり戦車', '蝎子坦克'], kana: 'さそりせんしゃ', enter: [{ ja: 'みよ、この しっぽ！ しゃしんは 1まい 100コインだ！', zh: '看我这尾巴！拍照一张 100 金币！' }],
      defeat: [{ ja: 'ポーズを きめるまえに うつな…', zh: '我还没摆好姿势你就开炮…' }] },
    sandship: { name: ['砂上戦艦', '沙上战舰'], kana: 'さじょうせんかん', enter: [{ ja: 'ぜんほうもん、ひらけー！ きょうは なみが たかいぞ！', zh: '全炮门，开火！今天浪很大！' }],
      defeat: [{ ja: '…そうか、うみじゃ なかったのか。いちど、ほんものを みたかったな', zh: '…原来这里不是海。真想看一次真正的海' }] },
    // 世界 3 雪山・世界 4 火山（v0.13。台詞は計画の文書のとおり）
    plow: { name: ['除雪車', '除雪车'], kana: 'じょせつしゃ', enter: [{ ja: 'ゆきも！ いわも！ せんしゃも！ ぜーんぶ かたづけまーす！', zh: '雪也好！石头也好！坦克也好！统统清理干净！' }],
      defeat: [{ ja: 'やすむのも… しごとのうち… ですね', zh: '休息…也是工作的一部分…对吧' }] },
    icegun: { name: ['氷の砲台', '冰之炮台'], kana: 'こおりのほうだい', enter: [{ ja: '…さむい？ しらない。かえって', zh: '…冷？不知道。回去吧' }],
      defeat: [{ ja: '…べ、べつに たのしくなかったわけじゃ ない', zh: '…才、才不是一点都不开心呢' }] },
    snowman: { name: ['雪だるま戦車', '雪人坦克'], kana: 'ゆきだるませんしゃ', enter: [{ ja: 'また あいに きてくれたの？ じゃあ、あそぼう！', zh: '你们又来看我啦？那我们一起玩吧！' }],
      defeat: [{ ja: 'たのしかった。らいねんの ふゆも、また つくってね', zh: '好开心。明年冬天，也要再把我堆起来哦' }] },
    flamer: { name: ['火炎放射車', '火焰喷射车'], kana: 'かえんほうしゃしゃ', enter: [{ ja: 'もえろォォ！ オレの たましいィィ！', zh: '燃烧吧！我的灵魂！' }],
      defeat: [{ ja: '…ちょっと もえすぎた。みず ください', zh: '…烧过头了。给我点水' }] },
    golem: { name: ['溶岩ごれむ', '熔岩魔像'], kana: 'ようがんごれむ', enter: [{ ja: 'ボク… あったかい ところが、すきな だけ…', zh: '我…只是喜欢暖和的地方…' }],
      defeat: [{ ja: 'おふろ… いっしょに… はいる？', zh: '泡澡…要一起…泡吗？' }] },
    dragon: { name: ['火竜戦車', '火龙坦克'], kana: 'かりゅうせんしゃ', enter: [{ ja: 'ひとのこよ、わが ほのおを うけてみよ！', zh: '人之子啊，接下我的火焰吧！' }],
      defeat: [{ ja: 'つばさは なくとも、そらは ちかかった。れいを いう', zh: '纵然没有翅膀，天空也曾那么近。多谢了' }] },
    // 世界 5 機械要塞・地獄（v0.14。台詞は計画の文書のとおり）。双子戦車は 2 台（姉 sisA・妹 sisB）で 1 体のボス。spk：A＝姉、B＝妹
    sisA: { name: ['双子戦車', '双子坦克'], kana: 'ふたごせんしゃ', enter: [{ spk: 'B', ja: 'ねえさん、きょうの おやつ なに？', zh: '姐，今天吃什么零食？' }, { spk: 'A', ja: 'たたかいの さいちゅうでしょ！', zh: '正在打仗呢！' }],
      defeat: [{ ja: '…ふたり いっしょなら、こわくないね', zh: '…只要两个人在一起，就不怕了' }] },
    sisB: { name: null, enter: [], defeat: [] },
    airship: { name: ['空中艇', '飞艇'], kana: 'くうちゅうてい', enter: [{ ja: 'したの みなさま ごきげんよう。おりる？ めんどうですわ', zh: '下面的各位日安。下去？好麻烦哦' }],
      defeat: [{ ja: 'じめんって… いがいと ふかふか ですのね', zh: '地面…原来还挺软的呢' }] },
    core: { name: ['要塞コア', '要塞核心'], kana: 'ようさいこあ', enter: [{ ja: 'しんにゅうしゃを かくにん。…しつもん。わたしは なにを まもって いるのですか', zh: '确认入侵者。…提问：我到底在守护什么？' }],
      defeat: [{ ja: '…わかりました。まもるものは ばしょではなく、だれか だったのですね', zh: '…明白了。要守护的不是地方，是某个人' }] },
    shadow: { name: ['闇の戦車', '暗黑坦克'], kana: 'やみのせんしゃ', enter: [{ ja: 'ひとりは さみしい。だから、ぼくは ぼくを ふやした', zh: '一个人好寂寞。所以，我把自己变多了' }],
      defeat: [{ ja: 'きみたちは よにんで ひとつ なんだね。うらやましいな', zh: '你们四个人是一体的呢。真羡慕' }] },
    superstar: { name: ['超ボス', '超级首领'], kana: 'ちょうぼす', enter: [{ ja: 'おまたせ！ じごくの スーパースター、とうじょうだァ！', zh: '让大家久等了！地狱超级巨星，登场！' }],
      defeat: [{ ja: '…アンコールは、なしで たのむ', zh: '…返场就免了吧' }] },
    king: { name: ['戦車の王', '坦克之王'], kana: 'せんしゃのおう', enter: [{ ja: 'わがこらを こえてきたか。…ならば ちちとして、おうとして、さいごに ためそう', zh: '你们超越了我的孩子们吗。…那么，作为父亲、作为王，最后试你们一次' }],
      defeat: [{ ja: 'つよく なったな。この せかいの あしたは、おまえたちの ものだ', zh: '你们变强了。这个世界的明天，属于你们' }] }
  };
  /* 世界。hand＝手作りの面（面の番号 → 地図の名前・つなぐ面・仕掛け）、boss＝ボスの出る面、easy＝楽な面（10 面ごとに一度）、
     music＝曲（球球王国）。theme＝地面の色（tank.html の THEME）。fx＝世界のふつうの仕掛け */
  const WORLDS = [
    { id: 'w1', ja: '草原', zh: '草原', theme: 'grass', fx: 'none', music: ['battle1', 'battle2'], rooms: ROOM_W1,
      hand: { 1: ['grass', 'tk1', 'none'], 7: ['tk1', 'tk7', 'none'], 13: ['tk3', 'tk2', 'jungle'], 19: ['tk2', 'tk8', 'valley'] },
      boss: { 8: ['twin'], 16: ['engineer'], 20: ['twin', 'engineer'], 24: ['bigtank'] }, easy: [10, 22], storm: false, sand: 0 },
    { id: 'w2', ja: '砂漠', zh: '沙漠', theme: 'sand', fx: 'desert', music: ['battle1', 'battle2'], rooms: ROOM_W2,
      hand: { 1: ['tk15', 'tk12', 'desert'], 7: ['tk12', 'tk1', 'desert'], 13: ['tk5', 'tk14', 'desert'], 19: ['tk14', 'tk5', 'desert'] },
      boss: { 8: ['burrower'], 16: ['scorpion'], 20: ['burrower', 'scorpion'], 24: ['sandship'] }, easy: [10, 22], storm: true, sand: 0.18 },
    // v0.13。type：flags＝占領（旗 3 本）・survive＝生き残り（秒）。night＝夜（まわりが暗い）。blizzard＝吹雪（見た目だけ）
    { id: 'w3', ja: '雪山', zh: '雪山', theme: 'snow', fx: 'snowland', music: ['battle1', 'battle2'], rooms: ROOM_W3,
      hand: { 1: ['tk9', 'tk4', 'snowland'], 7: ['tk4', 'tk11', 'snowland'], 13: ['tk6', 'tk9', 'snowland'], 19: ['tk4', 'tk9', 'snowland'] },
      boss: { 8: ['plow'], 16: ['icegun'], 20: ['plow', 'icegun'], 24: ['snowman'] }, easy: [10, 22], storm: false, sand: 0, ice: 0.12,
      flags: [4, 11, 15, 21], survive: {}, night: [], blizzard: [5, 12, 17, 23] },
    { id: 'w4', ja: '火山', zh: '火山', theme: 'lava', fx: 'volcano', music: ['battle1', 'battle2'], rooms: ROOM_W4,
      hand: { 1: ['tk13', 'tk8', 'volcano'], 7: ['tk8', 'tk14', 'volcano'], 13: ['tk2', 'tk8', 'volcano'], 19: ['tk14', 'tk8', 'volcano'] },
      boss: { 8: ['flamer'], 16: ['golem'], 20: ['flamer', 'golem'], 24: ['dragon'] }, easy: [10, 22], storm: false, sand: 0, ash: 0.1,
      flags: [6, 17, 23], survive: { 3: 75, 11: 90, 18: 100 }, night: [5, 9, 14, 21, 23], blizzard: [] },
    // v0.14。escort＝護送（トラックを守って上のゴールまで。地図は縦 39 升）・breakthrough＝突破（画面が前へ進む。縦 52 升）。
    // 機械要塞：動く壁・スイッチ・ワープ（fx fortress）。地獄：世界 5 をクリアすると開く。溶岩と夜、全部の種類が出る
    { id: 'w5', ja: '機械要塞', zh: '机械要塞', theme: 'metal', fx: 'fortress', music: ['battle1', 'battle2'], rooms: ROOM_W5,
      hand: { 1: ['tk7', 'tk1', 'fortress'], 7: ['tk10', 'tk6', 'fortress'], 13: ['tk6', 'tk14', 'fortress'], 19: ['tk5', 'tk7', 'fortress'] },
      boss: { 8: ['sisA', 'sisB'], 16: ['airship'], 20: ['sisA', 'sisB', 'airship'], 24: ['core'] }, easy: [10, 22], storm: false, sand: 0,
      flags: [9], survive: { 18: 90 }, escort: [3, 11, 17, 23], breakthrough: [5, 14, 21], night: [6, 15], blizzard: [] },
    { id: 'w6', ja: '地獄', zh: '地狱', theme: 'hell', fx: 'inferno', music: ['hell', 'hell'], bossMusic: 'hellboss', rooms: ROOM_W6,
      hand: { 1: ['tk6', 'tk12', 'inferno'], 7: ['tk5', 'tk14', 'inferno'], 13: ['tk10', 'tk6', 'inferno'], 19: ['tk14', 'tk5', 'inferno'] },
      boss: { 8: ['shadow'], 16: ['superstar'], 20: ['shadow', 'superstar'], 24: ['king'] }, easy: [9, 21], storm: false, sand: 0, ash: 0.08,
      flags: [10, 18], survive: { 3: 90, 21: 100 }, escort: [4, 15], breakthrough: [6, 12, 22], night: [5, 11, 17, 23], blizzard: [] }
  ];
  const PER_WORLD = 24, ADV_SPECIAL_FROM = { bouncer: 5, miner: 11, mortar: 26, sniper: 32, rammer: 38 };   // 自作の敵が出始める面（0 から数えた通しの番号）
  const lerp = (a, b, k) => a + (b - a) * k;
  /* 48 面の決まり。gi＝通しの番号（0〜47）。s＝難しさ（tank-sim.js の diff の s。今のふつうの 6 面が 0〜5）、em＝敵の数に掛ける値 */
  function makeAdv() {
    const out = [];
    WORLDS.forEach((w, wi) => {
      for (let no = 1; no <= PER_WORLD; no++) {
        // 草原・砂漠（0〜47）は v0.11 と同じ上がり方。雪山・火山（48〜95）は、そこから少しずつ上げる（上がり方はゆるめ）
        const gi = wi * PER_WORLD + no - 1, k = Math.min(1, gi / (2 * PER_WORLD - 1)), k2 = Math.max(0, (gi - 2 * PER_WORLD) / (2 * PER_WORLD - 1)), hand = w.hand[no], bosses = w.boss[no] || null, easy = w.easy.includes(no);
        const specials = Object.keys(ADV_SPECIAL_FROM).filter(n => ADV_SPECIAL_FROM[n] <= gi);
        const km = Math.min(1.2, k2), mix = [Math.round(lerp(14, 6, k) - km * 2), Math.round(lerp(3, 5, k)), Math.round(lerp(2, 5, k) + km), Math.round(lerp(1, 3, k) + km * 2)];
        const type = bosses ? null : (w.flags || []).includes(no) ? 'flags' : (w.survive || {})[no] ? 'survive' : (w.escort || []).includes(no) ? 'escort' : (w.breakthrough || []).includes(no) ? 'breakthrough' : null;
        const st = { id: w.id + '-' + no, world: wi, no, gi, adv: true, theme: w.theme, storm: w.storm && !bosses && no % 3 !== 1,
          ja: w.ja + ' ' + no, zh: w.zh + ' ' + no, music: bosses ? (w.bossMusic || 'boss') : w.music[no % 2], rows: type === 'escort' ? 39 : type === 'breakthrough' ? 52 : 26,
          s: Math.max(0, (gi < 48 ? gi * 0.12 : gi < 96 ? 5.5 + (gi - 48) * 0.055 : 8.14 + (gi - 96) * 0.03) - (easy ? 1.2 : 0)), em: (gi < 48 ? 0.75 + gi * 0.008 : gi < 96 ? 1.1 + (gi - 48) * 0.003 : 1.24 + (gi - 96) * 0.0015) * (easy ? 0.7 : 1), easy,
          type, survive: type === 'survive' ? w.survive[no] : 0, night: (w.night || []).includes(no), blizzard: (w.blizzard || []).includes(no),
          mix, specials, share: specials.length ? lerp(0.12, 0.25, Math.min(1, gi / 30)) : 0,
          captains: wi >= 1 && !bosses ? (easy ? 0 : 1 + (no > 12 ? 1 : 0) + (no > 18 ? 1 : 0)) : 0,
          bosses, seed: (wi + 1) * 1000 + no * 37 };
        if (hand) Object.assign(st, { map: hand[0], partner: hand[1], fx: hand[2], hand: true });
        else Object.assign(st, { gen: true, fx: w.fx });
        if (type === 'flags') { st.ja += '：旗をとれ'; st.zh += '：夺旗'; } else if (type === 'survive') { st.ja += '：まもりぬけ'; st.zh += '：坚守'; }
        else if (type === 'escort') { st.ja += '：トラックを まもれ'; st.zh += '：护送卡车'; } else if (type === 'breakthrough') { st.ja += '：とっぱせよ'; st.zh += '：突破'; }
        if (bosses) { const nm = bosses.map(b => BOSS_TALK[b].name).filter(Boolean); st.ja = w.ja + ' ' + no + '：' + nm.map(n => n[0]).join('と'); st.zh = w.zh + ' ' + no + '：' + nm.map(n => n[1]).join('和'); }
        out.push(st);
      }
    });
    return out;
  }
  const ADV = makeAdv();
  /* 部品から地図を作る。cols＝横の升（13 の倍数：26・39・52）、rows＝縦の升（13 の倍数）、seed＝種。同じ種なら同じ地図 */
  function genRows(st, cols, rows, seed) {
    let a = (seed >>> 0) || 1;
    const rnd = () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    const w = WORLDS[st.world], lib = w.rooms, R = 13, nx = Math.max(2, Math.round(cols / R)), ny = Math.max(1, Math.round(rows / R));
    const grid = []; for (let y = 0; y < rows; y++) grid.push(new Array(cols).fill('.'));
    const flipV = r => r.slice().reverse();
    const put = (room, rx, ry) => {
      for (let my = 0; my < 5; my++) for (let mx = 0; mx < 5; mx++) {
        let c = room[my][mx]; if (c === '.') continue;
        if (c === 'B' && st.s > 3 && rnd() < (st.s - 3) * 0.04) c = 'S';           // 難しい面ほど、鋼が少し増える
        if (st.easy && c !== 'W' && rnd() < 0.3) continue;                            // 楽な面は壁を少し減らす
        for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) { const x = rx * R + 1 + mx * 2 + dx, y = ry * R + 1 + my * 2 + dy; if (x < cols && y < rows) grid[y][x] = c; }
      }
    };
    for (let ry = 0; ry < ny; ry++) {
      const half = Math.floor(nx / 2), picks = [];
      for (let i = 0; i < half; i++) { let r = lib[Math.floor(rnd() * lib.length)]; if (rnd() < 0.5) r = flipV(r); picks.push(r); }
      for (let i = 0; i < half; i++) put(picks[i], i, ry);
      if (nx % 2) { let r = lib[Math.floor(rnd() * lib.length)]; if (rnd() < 0.5) r = flipV(r); put(r, half, ry); }
    }
    // 左半分を右へ鏡に写す（左右でまったく同じ形。片側だけ不利にならない）
    for (let y = 0; y < rows; y++) for (let x = 0; x < Math.floor(cols / 2); x++) grid[y][cols - 1 - x] = grid[y][x];
    // 砂の世界：地面のあちこちに砂を足す（左右同じに）
    // 火山：おうちの近く（守る人が止まる所）には溶岩を置かない
    if (w.fx === 'volcano' || w.fx === 'inferno') for (let y = rows - 9; y < rows; y++) for (let x = Math.floor(cols / 2) - 7; x <= Math.floor(cols / 2) + 6; x++) if (grid[y] && grid[y][x] === 'W') grid[y][x] = 'D';
    // 雪山は氷、火山は灰（同じやり方で、左右同じに）
    const over = w.sand ? ['D', w.sand] : w.ice ? ['I', w.ice] : w.ash ? ['D', w.ash] : null;
    if (over) for (let y = 1; y < rows - 6; y += 2) for (let x = 1; x < cols / 2 - 1; x += 2) if (rnd() < over[1]) for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) {
      const xx = x + dx, yy = y + dy, mx = cols - 1 - xx; if (grid[yy][xx] === '.') { grid[yy][xx] = over[0]; grid[yy][mx] = over[0]; } }
    return grid.map(r => r.join(''));
  }
  /* 星 3 つの「時間内」の秒数。敵の数とボスで決める */
  function parTime(st, enemies) { if (st.type === 'flags') return Math.round(50 + enemies * 2.6); if (st.type === 'escort') return 150; if (st.type === 'breakthrough') return 130; return Math.round(40 + enemies * 4.2 + (st.bosses ? st.bosses.length * 50 : 0)); }
  /* 生き残りの面の星 3 つ目：たおす敵の数 */
  function killGoal(st, enemies) { return Math.max(6, Math.round(enemies * 0.9 * (st.survive || 90) / 90)); }

  const api = { MAPS, MIX, FX_NAME, CAMPAIGN, EXTRA, HELL, WORLDS, ADV, BOSS_TALK, PER_WORLD, genRows, parTime, killGoal };
  root.TankStages = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);

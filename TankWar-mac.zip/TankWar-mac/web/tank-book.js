/* おうちを守れ！戦車隊：図鑑・実績・称号・家族ランキング・見た目スキン（P2：アイデア No.5・26・14・11）。計算だけ（画面なし。node でも動く）。
   - 実績（40 こ）：一人ずつ（名前ごと）。数は tank-gear.js の記録（pr.rec・pr.stats・pr.driver…）から読む。とれたらコインを少し、物によっては称号・スキン
   - 称号：実績でもらう。スマホで 1 つ選ぶ（最初の 1 つは自動で付く）
   - 家族ランキング：たおした数・星・たすけた数・ボスに当てた数・クリアした面。ずっと／今週（月曜から）。全員に何かのメダル
   - スキン：見た目だけ（強さは変わらない）。実績かコインで手に入る
   - 図鑑：家族みんなで 1 冊（会った敵・ボス、手に入れた装備のセット×色） */
(function (root) {
  'use strict';
  const ST = root.TankStages || (typeof require === 'function' ? require('./tank-stages.js') : null);
  const GR = root.TankGear || (typeof require === 'function' ? require('./tank-gear.js') : null);

  /* ---------- ランキングの 5 つの数（P2-14） ---------- */
  const CATS = [
    { k: 'k', ic: '💥', ja: 'たおした数', zh: '击败数', mja: 'げきつい', mzh: '击坠' },
    { k: 's', ic: '⭐', ja: 'あつめた星', zh: '收集的星', mja: 'ほしあつめ', mzh: '集星' },
    { k: 'r', ic: '🚑', ja: 'たすけた数', zh: '救援数', mja: 'おたすけ', mzh: '救援' },
    { k: 'b', ic: '🎯', ja: 'ボスに当てた数', zh: '命中首领', mja: 'ボスたいじ', mzh: '打首领' },
    { k: 'c', ic: '🚩', ja: 'クリアした面', zh: '通关数', mja: 'クリア', mzh: '通关' }];
  // 週の番号（その土地の月曜 0 時から）。1970-01-01 は木曜なので 3 日ずらす
  function weekId(now) { const d = new Date(now === undefined ? Date.now() : now); return Math.floor((Math.floor((d.getTime() - d.getTimezoneOffset() * 60000) / 86400000) + 3) / 7); }
  function recOf(pr) { if (!pr.rec || typeof pr.rec !== 'object') pr.rec = {}; const r = pr.rec; for (const k of ['all', 'wk', 'boss', 'x']) if (!r[k] || typeof r[k] !== 'object') r[k] = {}; r.wid = r.wid | 0; return r; }
  function rollWeek(pr, now) { const r = recOf(pr), w = weekId(now); if (r.wid !== w) { r.wid = w; r.wk = {}; } return r; }
  const add = (o, k, n) => { n = Math.max(0, Math.floor(Number(n) || 0)); if (n) o[k] = (o[k] || 0) + n; };
  /* 面が終わった時に足す。d：{ kills, rescues, bossHits, sp, deaths, combo, clear, stars(数), bossKills, players, bosses:[種類] } */
  function addStage(pr, d, now) {
    const r = rollWeek(pr, now);
    for (const o of [r.all, r.wk]) { add(o, 'k', d.kills); add(o, 'r', d.rescues); add(o, 'b', d.bossHits); if (d.clear) { add(o, 'c', 1); add(o, 's', d.stars); } }
    add(r.all, 'pl', 1); add(r.all, 'sp', d.sp);
    if ((d.combo | 0) > (r.x.cb | 0)) r.x.cb = d.combo | 0;
    if (d.clear) { add(r.all, 'bk', d.bossKills); if (!d.deaths) add(r.all, 'nd', 1); if (d.players >= 4) add(r.all, 'f4', 1); for (const k of d.bosses || []) add(r.boss, k, 1); }
  }
  // ランキングの行：{ name, all:[5], wk:[5] }（今週でない記録は 0）
  function rankRow(pr, now) { const r = recOf(pr), w = r.wid === weekId(now) ? r.wk : {}; return { name: pr.name, all: CATS.map(c => r.all[c.k] | 0), wk: CATS.map(c => w[c.k] | 0) }; }
  /* 全員に何かのメダル。本当の 1 位は「チャンピオン」、ほかの人は まだもらっていない人の中で一番の物を「めいじん」、数が無い人は「これから賞」。
     返す：{ 名前: { cat: 番号（-1＝これから）, top: 本当の 1 位か } } */
  function medals(rows, per) {
    const out = {}, v = (r, i) => (r[per] || [])[i] | 0, used = {};
    for (let i = 0; i < CATS.length; i++) {   // 本当の 1 位（同じ人が 2 つとる時は、先の物だけ）
      let top = 0; for (const r of rows) top = Math.max(top, v(r, i)); if (!top) continue;
      const w = rows.find(r => !out[r.name] && v(r, i) === top); if (w) { out[w.name] = { cat: i, top: true }; used[i] = 1; }
    }
    const order = CATS.map((_, i) => i).sort((a, b) => (used[a] | 0) - (used[b] | 0));   // まだだれももらっていない物から
    for (const i of order) { let best = null; for (const r of rows) if (!out[r.name] && v(r, i) > 0 && (!best || v(r, i) > v(best, i))) best = r; if (best) out[best.name] = { cat: i, top: false }; }
    for (const r of rows) if (!out[r.name]) { let bi = -1, bv = 0; for (let i = 0; i < CATS.length; i++) if (v(r, i) > bv) { bv = v(r, i); bi = i; } out[r.name] = { cat: bi, top: false, hard: bi >= 0 }; }
    return out;
  }
  function medalText(m, L) {
    if (!m || m.cat < 0) return '🌱 ' + L('これから賞', '新星奖'); const c = CATS[m.cat];
    return m.top ? '👑 ' + L(c.mja + ' チャンピオン', c.mzh + '冠军') : m.hard ? '🎖 ' + L(c.mja + ' がんばり賞', c.mzh + '努力奖') : '🏅 ' + L(c.mja + ' めいじん', c.mzh + '达人');
  }

  /* ---------- 図鑑（P2-5）：家族で 1 冊 ---------- */
  const ENEMIES = [
    { k: 'normal', ja: 'ふつうの戦車', zh: '普通坦克', dja: 'いちばん よく出る。ゆっくり', dzh: '最常见，慢悠悠' },
    { k: 'fast', ja: 'はやい戦車', zh: '快速坦克', dja: '足が とても速い', dzh: '跑得飞快' },
    { k: 'heavy', ja: 'どっしり戦車', zh: '重型坦克', dja: '弾が速い', dzh: '炮弹很快' },
    { k: 'armor', ja: 'かたい戦車', zh: '装甲坦克', dja: '4 回 当てないと たおせない', dzh: '要打中 4 次才能击败' },
    { k: 'chief', ja: '首領', zh: '头目', dja: 'とても かたい。たおすと 点が高い', dzh: '非常硬，击败得分高' },
    { k: 'bouncer', ja: 'はねかえし戦車', zh: '反弹坦克', dja: '弾が かべで はね返る', dzh: '炮弹会在墙上反弹' },
    { k: 'miner', ja: 'じらい戦車', zh: '地雷坦克', dja: '通った所に 地雷を おく', dzh: '在走过的地方埋地雷' },
    { k: 'mortar', ja: 'やまなり砲', zh: '迫击炮坦克', dja: 'かべを こえて 弾を おとす', dzh: '炮弹越过墙落下来' },
    { k: 'sniper', ja: 'ねらいうち戦車', zh: '狙击坦克', dja: '赤い線で ねらってから 撃つ', dzh: '先用红线瞄准再开炮' },
    { k: 'rammer', ja: 'とっしん戦車', zh: '冲撞坦克', dja: 'こちらへ まっすぐ つっこむ', dzh: '直直地冲过来' }];
  // ボス：クラシックの 2 体と、ぼうけんの世界ごとのボス（面の順）。world＝-1 はクラシック・地獄
  const BOSSES = (() => {
    const out = [{ k: 'boss', world: -1, ja: 'ボス', zh: '首领' }, { k: 'superboss', world: -1, ja: '超ボス', zh: '超级首领' }], seen = {};
    if (ST) for (const s of ST.ADV) for (const k of s.bosses || []) { if (seen[k]) continue; seen[k] = 1; const t = ST.BOSS_TALK[k], n = t && t.name ? t.name : k === 'sisA' ? ['双子戦車（姉）', '双子坦克（姐姐）'] : k === 'sisB' ? ['双子戦車（妹）', '双子坦克（妹妹）'] : [k, k]; out.push({ k, world: s.world, ja: n[0], zh: n[1] }); }
    return out;
  })();
  const WORLD_BOSS = (() => { const o = {}; for (const b of BOSSES) if (b.world >= 0) (o[b.world] = o[b.world] || []).push(b.k); return o; })();
  function cleanAlbum(a) {
    const o = { e: {}, b: {}, g: {}, log: [] }; if (!a || typeof a !== 'object') return o;
    for (const en of ENEMIES) if (a.e && a.e[en.k]) o.e[en.k] = 1;
    for (const b of BOSSES) { const v = a.b && a.b[b.k]; if (Array.isArray(v)) o.b[b.k] = [v[0] ? 1 : 0, Math.max(0, Math.min(99999, v[1] | 0))]; }
    if (GR) for (const k in GR.SETS) { const m = a.g && (a.g[k] | 0) & 255; if (m) o.g[k] = m; }
    if (Array.isArray(a.log)) for (const l of a.log.slice(-8)) if (Array.isArray(l) && typeof l[1] === 'string' && ACH_BY[l[2]]) o.log.push([Number(l[0]) || 0, l[1].slice(0, 40), l[2]]);
    return o;
  }
  // 会った（敵・ボス）。変わったら true
  function albumMet(al, kind, boss) {
    if (boss) { if (!BOSSES.some(b => b.k === kind)) return false; const v = al.b[kind] || (al.b[kind] = [0, 0]); if (v[0]) return false; v[0] = 1; return true; }
    if (!ENEMIES.some(e => e.k === kind) || al.e[kind]) return false; al.e[kind] = 1; return true;
  }
  function albumDefeat(al, kind) { if (!BOSSES.some(b => b.k === kind)) return false; const v = al.b[kind] || (al.b[kind] = [0, 0]); v[0] = 1; v[1]++; return true; }
  function albumGear(al, bag) { let ch = false; for (const it of bag || []) { const m = (al.g[it.set] | 0) | (1 << it.r); if (m !== (al.g[it.set] | 0)) { al.g[it.set] = m; ch = true; } } return ch; }
  function albumCount(al) {
    let g = 0, gt = 0; if (GR) for (const k in GR.SETS) { gt += GR.RARITY.length; for (let r = 0; r < GR.RARITY.length; r++) if ((al.g[k] | 0) >> r & 1) g++; }
    return { e: ENEMIES.filter(e => al.e[e.k]).length, et: ENEMIES.length, b: BOSSES.filter(b => al.b[b.k] && al.b[b.k][0]).length, bd: BOSSES.filter(b => al.b[b.k] && al.b[b.k][1]).length, bt: BOSSES.length, g, gt };
  }

  /* ---------- 実績（P2-5）と称号（P2-26）・スキン（P2-11） ----------
     v＝数の名前（vals が返す）、n＝いくつでとれるか、c＝コイン、t＝称号 [ja, zh]、skin＝もらえるスキン */
  const ACH = [
    { id: 'c1', ic: '🎉', v: 'c', n: 1, c: 20, ja: 'はじめての クリア', zh: '第一次过关', t: ['しんまい隊員', '新人队员'] },
    { id: 'c10', ic: '🚩', v: 'c', n: 10, c: 30, ja: '10 面 クリア', zh: '通过 10 关' },
    { id: 'c50', ic: '🏁', v: 'c', n: 50, c: 80, ja: '50 面 クリア', zh: '通过 50 关', t: ['ベテラン隊員', '老练队员'], skin: 'rainbow' },
    { id: 'c100', ic: '🏆', v: 'c', n: 100, c: 150, ja: '100 面 クリア', zh: '通过 100 关', t: ['でんせつの隊長', '传说队长'] },
    { id: 'k10', ic: '💥', v: 'k', n: 10, c: 20, ja: '敵を 10 台 たおす', zh: '击败 10 辆敌人' },
    { id: 'k100', ic: '💣', v: 'k', n: 100, c: 50, ja: '敵を 100 台 たおす', zh: '击败 100 辆敌人', t: ['げきつい王', '击坠王'], skin: 'camo' },
    { id: 'k500', ic: '🎖', v: 'k', n: 500, c: 100, ja: '敵を 500 台 たおす', zh: '击败 500 辆敌人', t: ['むてきのエース', '无敌王牌'] },
    { id: 'r1', ic: '🤝', v: 'r', n: 1, c: 20, ja: 'はじめての おたすけ', zh: '第一次救队友' },
    { id: 'r10', ic: '🚑', v: 'r', n: 10, c: 50, ja: '仲間を 10 回 たすける', zh: '救队友 10 次', t: ['おたすけヒーロー', '救援英雄'], skin: 'heart' },
    { id: 'r30', ic: '👼', v: 'r', n: 30, c: 100, ja: '仲間を 30 回 たすける', zh: '救队友 30 次', t: ['まもりの天使', '守护天使'] },
    { id: 'bk1', ic: '👑', v: 'bk', n: 1, c: 30, ja: 'はじめて ボスを たおす', zh: '第一次打倒首领', t: ['ボスハンター', '首领猎人'] },
    { id: 'bk10', ic: '🐲', v: 'bk', n: 10, c: 80, ja: 'ボスを 10 体 たおす', zh: '打倒 10 个首领', t: ['ボスキラー', '首领杀手'], skin: 'flame' },
    { id: 'b100', ic: '🎯', v: 'b', n: 100, c: 50, ja: 'ボスに 100 発 当てる', zh: '命中首领 100 次' },
    { id: 's10', ic: '⭐', v: 's', n: 10, c: 30, ja: '星を 10 こ あつめる', zh: '收集 10 颗星', skin: 'star' },
    { id: 's50', ic: '🌟', v: 's', n: 50, c: 60, ja: '星を 50 こ あつめる', zh: '收集 50 颗星', t: ['ほしあつめ名人', '集星达人'] },
    { id: 's150', ic: '💫', v: 's', n: 150, c: 150, ja: '星を 150 こ あつめる', zh: '收集 150 颗星', t: ['スターマスター', '星星大师'] },
    { id: 'ch10', ic: '🎁', v: 'ch', n: 10, c: 30, ja: '宝箱を 10 こ ひろう', zh: '捡 10 个宝箱' },
    { id: 'ch50', ic: '🧰', v: 'ch', n: 50, c: 80, ja: '宝箱を 50 こ ひろう', zh: '捡 50 个宝箱', t: ['たからばこハンター', '宝箱猎人'] },
    { id: 'wh10', ic: '🎡', v: 'wh', n: 10, c: 30, ja: 'ルーレットを 10 回 まわす', zh: '转 10 次转盘' },
    { id: 'wh50', ic: '🎰', v: 'wh', n: 50, c: 80, ja: 'ルーレットを 50 回 まわす', zh: '转 50 次转盘', t: ['ルーレット名人', '转盘达人'] },
    { id: 'en10', ic: '🔨', v: 'en', n: 10, c: 30, ja: '強化を 10 回 する', zh: '强化 10 次', t: ['かじやさん', '小铁匠'] },
    { id: 'p10', ic: '🔟', v: 'il', n: 10, c: 150, ja: '装備を +10 にする', zh: '把装备强化到 +10', t: ['強化の神さま', '强化之神'] },
    { id: 'gr6', ic: '🥈', v: 'gr', n: 6, c: 60, ja: '銀の装備を 手に入れる', zh: '获得银色装备', t: ['ぎんいろコレクター', '银色收藏家'] },
    { id: 'gr7', ic: '🥇', v: 'gr', n: 7, c: 120, ja: '金の装備を 手に入れる', zh: '获得金色装备', t: ['きんぴか', '金光闪闪'], skin: 'gold' },
    { id: 's4', ic: '🧩', v: 's4', n: 4, c: 50, ja: '同じセットを 4 つ つける', zh: '装备同一套装 4 件' },
    { id: 'cb5', ic: '🔥', v: 'cb', n: 5, c: 40, ja: '5 れんぞくで たおす', zh: '5 连击', t: ['コンボ名人', '连击达人'] },
    { id: 'sp10', ic: '⚡', v: 'sp', n: 10, c: 30, ja: '必殺技を 10 回 つかう', zh: '使用必杀技 10 次' },
    { id: 'nd5', ic: '🛡', v: 'nd', n: 5, c: 60, ja: 'やられずに 5 回 クリア', zh: '不被击败过关 5 次', t: ['ふじみ', '不死之身'] },
    { id: 'dl10', ic: '🧑‍✈️', v: 'dl', n: 10, c: 50, ja: 'ドライバー Lv 10', zh: '驾驶员 Lv 10', t: ['めいドライバー', '名驾驶员'] },
    { id: 'dl30', ic: '🏅', v: 'dl', n: 30, c: 200, ja: 'ドライバー Lv 30', zh: '驾驶员 Lv 30', t: ['でんせつのドライバー', '传说驾驶员'] },
    { id: 'cl10', ic: '🚙', v: 'cl', n: 10, c: 40, ja: '車を Lv 10 にする', zh: '坦克升到 Lv 10' },
    { id: 'bd', ic: '💞', v: 'bd', n: 30, c: 80, ja: '車と なかよし MAX', zh: '和坦克默契 MAX', t: ['あいぼう', '最佳搭档'] },
    { id: 'f4', ic: '👨‍👩‍👧‍👦', v: 'f4', n: 1, c: 50, ja: '4 人で クリア', zh: '4 个人一起过关', t: ['かぞくのきずな', '家族羁绊'] },
    { id: 'w0', ic: '🌱', v: 'w0', c: 60, ja: '草原の ボスを ぜんぶ たおす', zh: '打倒草原的全部首领', t: ['草原のゆうしゃ', '草原勇者'] },
    { id: 'w1', ic: '🏜', v: 'w1', c: 70, ja: '砂漠の ボスを ぜんぶ たおす', zh: '打倒沙漠的全部首领', t: ['砂漠のゆうしゃ', '沙漠勇者'] },
    { id: 'w2', ic: '❄', v: 'w2', c: 80, ja: '雪山の ボスを ぜんぶ たおす', zh: '打倒雪山的全部首领', t: ['雪山のゆうしゃ', '雪山勇者'] },
    { id: 'w3', ic: '🌋', v: 'w3', c: 90, ja: '火山の ボスを ぜんぶ たおす', zh: '打倒火山的全部首领', t: ['火山のゆうしゃ', '火山勇者'] },
    { id: 'w4', ic: '⚙', v: 'w4', c: 100, ja: '機械要塞の ボスを ぜんぶ たおす', zh: '打倒机械要塞的全部首领', t: ['要塞のゆうしゃ', '要塞勇者'] },
    { id: 'w5', ic: '😈', v: 'w5', c: 200, ja: '地獄の ボスを ぜんぶ たおす', zh: '打倒地狱的全部首领', t: ['地獄をこえた者', '越过地狱的人'] },
    { id: 'de', ic: '📖', v: 'de', n: ENEMIES.length, c: 40, ja: '敵を ぜんぶ 見つける', zh: '遇见全部敌人' }];
  for (const a of ACH) if (a.n === undefined) a.n = (WORLD_BOSS[Number(a.v.slice(1))] || [0]).length;
  const ACH_BY = {}; for (const a of ACH) ACH_BY[a.id] = a;
  // 実績に使う数。fam＝家族の図鑑（無くてもよい）
  function vals(pr, fam) {
    const r = recOf(pr), a = r.all, st = pr.stats || {}, v = { k: a.k | 0, s: a.s | 0, r: a.r | 0, b: a.b | 0, c: a.c | 0, bk: a.bk | 0, sp: a.sp | 0, nd: a.nd | 0, f4: a.f4 | 0, cb: r.x.cb | 0,
      ch: st.chests | 0, wh: st.spins | 0, en: st.enh | 0, dl: pr.driver ? pr.driver.lv : 0, cl: 0, bd: 0, gr: 0, il: 0, s4: 0, de: fam ? ENEMIES.filter(e => fam.e[e.k]).length : 0 };
    for (const k in pr.cars || {}) v.cl = Math.max(v.cl, pr.cars[k].lv | 0);
    if (pr.driver) for (const k in pr.driver.bond) v.bd = Math.max(v.bd, pr.driver.bond[k] | 0);
    for (const it of pr.bag || []) { v.gr = Math.max(v.gr, it.r | 0); v.il = Math.max(v.il, it.lv | 0); }
    if (GR) { const sc = GR.setCounts(pr); for (const k in sc) v.s4 = Math.max(v.s4, sc[k]); }
    for (const w in WORLD_BOSS) v['w' + w] = WORLD_BOSS[w].filter(k => r.boss[k]).length;
    return v;
  }
  // 新しくとれた実績を返す（記録に時刻・コインを入れる。称号がまだ無ければ最初の物を付ける）
  function check(pr, fam, now) {
    const v = vals(pr, fam), got = []; if (!pr.ach || typeof pr.ach !== 'object') pr.ach = {}; const had = titles(pr).length > 0;   // 称号を自動で付けるのは最初の 1 回だけ（自分で「なし」にした人はそのまま）
    for (const a of ACH) { if (pr.ach[a.id] || (v[a.v] | 0) < a.n) continue; pr.ach[a.id] = Math.floor((now === undefined ? Date.now() : now) / 1000) || 1; pr.coins = (pr.coins | 0) + a.c; if (a.t && !pr.title && !had) pr.title = a.id; got.push(a); }
    return got;
  }
  function achCount(pr) { let n = 0; for (const a of ACH) if (pr.ach && pr.ach[a.id]) n++; return n; }
  // 称号
  function titleOf(id, L) { const a = ACH_BY[id]; return a && a.t ? L(a.t[0], a.t[1]) : ''; }
  function titles(pr) { return ACH.filter(a => a.t && pr.ach && pr.ach[a.id]).map(a => a.id); }
  function setTitle(pr, id) { if (id === '') { pr.title = ''; return true; } if (!ACH_BY[id] || !ACH_BY[id].t || !pr.ach || !pr.ach[id]) return false; pr.title = id; return true; }
  function curTitle(pr) { return pr.title && ACH_BY[pr.title] && ACH_BY[pr.title].t && pr.ach && pr.ach[pr.title] ? pr.title : ''; }

  // スキン（見た目だけ）。ach＝この実績でもらえる、coins＝コインで買う
  const SKINS = [
    { id: 'none', ja: 'なし', zh: '无' },
    { id: 'stripe', ja: 'しましま', zh: '条纹', coins: 100 },
    { id: 'dots', ja: 'みずたま', zh: '波点', coins: 100 },
    { id: 'check', ja: 'チェック', zh: '格子', coins: 150 },
    { id: 'bolt', ja: 'いなずま', zh: '闪电', coins: 200 },
    { id: 'star', ja: 'ほし', zh: '星星', ach: 's10' },
    { id: 'camo', ja: 'めいさい', zh: '迷彩', ach: 'k100' },
    { id: 'heart', ja: 'ハート', zh: '爱心', ach: 'r10' },
    { id: 'flame', ja: 'ほのお', zh: '火焰', ach: 'bk10' },
    { id: 'rainbow', ja: 'にじ', zh: '彩虹', ach: 'c50' },
    { id: 'gold', ja: 'きんぴか', zh: '金闪闪', ach: 'gr7' }];
  const SKIN_BY = {}; for (const s of SKINS) SKIN_BY[s.id] = s;
  function skinOwned(pr, id) { const s = SKIN_BY[id]; if (!s) return false; if (id === 'none') return true; if (s.ach) return !!(pr.ach && pr.ach[s.ach]); return Array.isArray(pr.skins) && pr.skins.includes(id); }
  function curSkin(pr) { return pr.skin && pr.skin !== 'none' && skinOwned(pr, pr.skin) ? pr.skin : ''; }
  // スマホからの操作：つける・買う
  function skinAct(pr, a) {
    const s = SKIN_BY[a.id]; if (!s) return { ok: false };
    if (a.op === 'skin') { if (!skinOwned(pr, s.id)) return { ok: false, msg: 'lock' }; pr.skin = s.id === 'none' ? '' : s.id; return { ok: true, msg: 'skin' }; }
    if (a.op === 'buy') { if (!s.coins || skinOwned(pr, s.id)) return { ok: false }; if ((pr.coins | 0) < s.coins) return { ok: false, msg: 'poor' }; pr.coins -= s.coins; if (!Array.isArray(pr.skins)) pr.skins = []; pr.skins.push(s.id); pr.skin = s.id; return { ok: true, msg: 'buy', cost: s.coins }; }
    return { ok: false };
  }

  const api = { CATS, weekId, recOf, rollWeek, addStage, rankRow, medals, medalText, ENEMIES, BOSSES, WORLD_BOSS, cleanAlbum, albumMet, albumDefeat, albumGear, albumCount,
    ACH, ACH_BY, vals, check, achCount, titleOf, titles, setTitle, curTitle, SKINS, SKIN_BY, skinOwned, curSkin, skinAct };
  root.TankBook = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);

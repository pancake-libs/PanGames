/* 戦車のゲーム「おうちを守れ！戦車隊」の計算（v0.11：ぼうけん 48 面・ボス 6 体・隊長・星・台詞を足した）。テレビの画面（tank.html）と、確かめ用の node の両方から読む。
   - 升（タイル）を 1 とした座標。戦車は 2 × 2 升、大ボスは 4 × 4 升。面は tank-stages.js
   - 乱数は種を決めた関数（g.rand）だけを使う。同じ種・同じ操作なら同じ結果になる
   - step(g, dt) は決まった刻み（CFG.fixedDt）で呼ぶ。描画は別（tank.html）
   - 音・震えなどの知らせは g.ev に積む。画面がそれを読んで鳴らす
   仕組み（アイテム 7 つ・火力 5 段と 2 連射・陣地の自衛・陣地の護甲・磁場・面の仕掛け・周回・勲章）と数値は、
   TK（sunsharebay-lgtm/TK の 坦克大战）に合わせた。コードは自作（D-015・D-017） */
(function (root) {
  'use strict';
  const Stages = root.TankStages || (typeof require !== 'undefined' ? require('./tank-stages.js') : null);

  /* TK の「1 フレームに何ピクセル（16px＝1 升、60 フレーム/秒）」を、このゲームの「升/秒」に直す係数（味方の速さ 1.5 → 4.6 升/秒） */
  const K = 4.6 / 1.5;
  /* ============ ここを変えると難しさを変えられます ============ */
  const CFG = {
    fixedDt: 1 / 60,          // 計算の刻み（秒）
    maxPlayers: 4,            // 同時に遊べる人数
    lives: 3,                 // 1 人の戦車の台数
    respawnSec: 2,            // やられてから出直すまで（秒）
    shieldSec: 2.5,           // 出た直後に弾が効かない時間（秒）
    friendlyStunSec: 2,       // 味方の弾が当たった時に動けない時間（秒）
    playerSpeed: 1.5 * K,     // 味方の速さ（升/秒）
    fireCooldown: 0.10,       // 味方が次に撃てるまで（秒。弾の数の上限でも止まる）
    maxPower: 5, maxTwin: 3, maxArmor: 5, maxFuton: 5, maxTower: 5, maxSlow: 5, maxLoop: 5,
    spawnWarnSec: 1,          // 敵が出る前に印を出す時間（秒）
    introSec: 2.6,            // 面の始めに名前を出す時間（秒）
    clearSec: 5,              // 面をクリアした後に、賞を見せる時間（秒）
    loopSec: 6,               // 周回の褒美を見せる時間（秒）
    comboSec: 3,              // この時間内に続けて倒すと「れんぞく」
    itemLifeSec: 15,          // アイテムが消えるまで（秒）
    itemPauseSec: 0.35,       // アイテムを取った時に一拍止める時間（秒）
    shieldItemSec: 10,        // 「たて」で無敵になる時間（秒）
    stopItemSec: 9,           // 「ストップ」で敵が止まる時間（秒）
    wallItemSec: 20,          // 「かべなおし」でおうちの周りが鋼になる時間（秒）
    startFuton: 1,            // ふつうの面の始めに、おうちにかかっている おふとん の枚数（家族向けに足した。地獄は 0）
    alertSec: 2.5,            // おうちがあぶない知らせを出す時間（秒）
    lavaWarnSec: 3, lavaBurnSec: 5,   // 溶岩の面：水のそばで止まっていると、3 秒で知らせ、5 秒で熱い
    medalAcc: 0.7, medalAccBonus: 300, medalCombo: 4, medalComboBonus: 500,   // 勲章（命中 7 割・4 れんぞく）と点
    itemScore: 500, comboScore: 50,
    feel: { freeze: true, shake: true, flash: true }   // 手応え（止める・揺らす・白くする）の ON/OFF
  };
  /* 参加人数で変わる値（家族で遊んで直す）。cols：盤面の横の升。1〜2 人も 39（横長）にして、テレビの横いっぱいに広げる（v0.10.1。前は 26 の正方形で、左右が空いていた） */
  const SCALE = {
    1: { cols: 39, gates: 3, enemies: 16, onField: 4, speed: 1.00, fire: 1.00, house: 0.30, bossHp: 1.0, itemEvery: 4 },
    2: { cols: 39, gates: 3, enemies: 20, onField: 5, speed: 1.00, fire: 1.00, house: 0.35, bossHp: 1.5, itemEvery: 4 },
    3: { cols: 39, gates: 4, enemies: 28, onField: 7, speed: 1.05, fire: 0.92, house: 0.40, bossHp: 2.0, itemEvery: 3 },
    4: { cols: 52, gates: 5, enemies: 36, onField: 9, speed: 1.10, fire: 0.85, house: 0.45, bossHp: 2.5, itemEvery: 3 }
  };
  /* 地獄の難しさ（ふつうの値に掛ける） */
  const HELL = { enemies: 1.5, speed: 1.3, fire: 0.6, itemEvery: 2, shield: 0.5, onField: 1, hp: 1 };
  /* 面の仕掛け。enemySpeed・fire（撃つ回数）・playerSpeed・spawnGap は掛け算、hp は敵の体力に足す */
  const FX = {
    none: {}, steel: { baseSteel: true }, valley: { enemySpeed: 1.15 }, jungle: { jungle: true }, ice: { ice: true },
    frenzy: { fire: 1.25 }, siege: { siege: true, fire: 1.08 }, rush: { enemySpeed: 1.10, spawnGap: 0.75 },
    snow: { ice: true, playerSpeed: 0.90 }, blood: { hp: 1 }, sand: { playerSpeed: 0.82 }, lava: { lava: true },
    desert: { playerSpeed: 0.92, storm: true }   // 砂漠（ぼうけん）：少し遅い。砂嵐は見た目だけ（tank.html）
  };
  /* 敵の種類。normal・fast・heavy・armor・chief は TK の 5 種の数値（速さ・弾の速さ・体力・点）。ほかは自作。
     speed・bullet＝升/秒、cd＝撃つ間隔（秒、幅）、from＝自作の敵が出てくる面（1 から） */
  const ENEMY = {
    normal: { hp: 1, speed: 1.00 * K, bullet: 4.0 * K, cd: [1.0, 2.2], score: 100 },
    fast: { hp: 1, speed: 2.00 * K, bullet: 4.0 * K, cd: [1.0, 2.2], score: 200 },
    heavy: { hp: 1, speed: 1.50 * K, bullet: 6.5 * K, cd: [0.8, 1.8], score: 300 },
    armor: { hp: 4, speed: 1.00 * K, bullet: 4.0 * K, cd: [1.0, 2.0], score: 400 },
    chief: { hp: 10, speed: 0.82 * K, bullet: 6.5 * K, cd: [0.7, 1.4], score: 1500, elite: true },
    bouncer: { hp: 1, speed: 3.2, bullet: 9, cd: [1.2, 2.4], from: 3, special: true, score: 300 },
    miner: { hp: 1, speed: 4.0, bullet: 9, cd: [1.6, 3.0], from: 3, special: true, score: 300 },
    mortar: { hp: 2, speed: 2.6, bullet: 0, cd: [3.0, 4.5], from: 4, special: true, score: 300 },
    sniper: { hp: 1, speed: 3.0, bullet: 24, cd: [3.0, 4.0], from: 4, special: true, score: 300 },
    rammer: { hp: 1, speed: 3.6, bullet: 9, cd: [2.0, 3.5], from: 5, special: true, score: 300 },
    boss: { hp: 24, speed: 2.0, bullet: 9, cd: [2.0, 2.0], boss: true, house: 0.4, score: 3000 },
    superboss: { hp: 72, speed: 2.4, bullet: 10, cd: [1.6, 1.6], boss: true, house: 0.6, score: 10000 },
    // ぼうけん（v0.11）。captain＝隊長（王冠。まわりの敵を強くする）。下の 6 体は世界 1・2 のボス（動きは advBoss）
    captain: { hp: 3, speed: 1.1 * K, bullet: 5.0 * K, cd: [0.9, 1.8], score: 800, captain: true },
    twin: { hp: 22, speed: 2.2, bullet: 9, cd: [1.5, 1.5], boss: true, house: 0.3, score: 3000 },
    engineer: { hp: 24, speed: 2.0, bullet: 8.5, cd: [2.4, 2.4], boss: true, house: 0.35, score: 3000 },
    bigtank: { hp: 32, speed: 2.0, bullet: 9, cd: [2.0, 2.0], boss: true, house: 0.4, score: 5000 },
    burrower: { hp: 18, speed: 2.2, bullet: 9.5, cd: [1.1, 1.1], boss: true, house: 0.3, score: 3500 },
    scorpion: { hp: 26, speed: 2.3, bullet: 9.5, cd: [2.1, 2.1], boss: true, house: 0.3, score: 3500 },
    sandship: { hp: 30, speed: 1.6, bullet: 9, cd: [2.0, 2.0], boss: true, house: 0, score: 6000, partHp: 8 }
  };
  const ADV_BOSS = { twin: 1, engineer: 1, bigtank: 1, burrower: 1, scorpion: 1, sandship: 1 };
  const CAPTAIN_KINDS = ['heal', 'shield', 'haste', 'call'];   // 隊長の力：回復・盾・速く・呼ぶ
  const AURA_R = 5.5;              // 隊長の力が届く距離（升）
  const TALK_CHAR_SEC = 0.06, TALK_MIN_SEC = 0.6;   // 台詞：1 文字が出る時間・出そろうまでの最短。出そろうまでは「読んだ」を受け付けない
  const MIX_KINDS = ['normal', 'fast', 'heavy', 'armor'];
  const SPECIALS = ['bouncer', 'miner', 'mortar', 'sniper', 'rammer'];
  const SPECIAL_SHARE = 0.25;   // 自作の敵が出る面での、自作の敵の割合
  /* アイテム 7 つ（TK の出やすさの重み）。パワー・よろいが最高まで育つと、2 連射・電波に変わる */
  const ITEM_WEIGHTS = [['shield', 1], ['stop', 1], ['wall', 1], ['power', 1.64], ['bomb', 1], ['extra', 1], ['armor', 1.35]];
  const ITEMS = ['shield', 'stop', 'wall', 'power', 'bomb', 'extra', 'armor', 'twin', 'field'];
  const ITEM_NAME = { shield: ['たて', '护盾'], stop: ['ストップ', '冻结'], wall: ['かべなおし', '修墙'], power: ['パワー', '火力'], bomb: ['ドカン', '炸弹'],
    extra: ['ぞうえん', '增援'], armor: ['よろい', '护甲'], twin: ['2 れんしゃ', '双炮'], field: ['のろのろ電波', '减速电波'] };
  /* 周回の褒美（TK の周回の褒美と同じ中身。名前は自作）。power＝火力 +、life＝台数 + */
  const LOOP_REWARD = { 1: { ja: '火力アップ', zh: '火力提升', power: 1, life: 0 }, 2: { ja: '予備の戦車', zh: '备用坦克', power: 0, life: 1 },
    3: { ja: '補給', zh: '补给', power: 1, life: 1 }, 4: { ja: '最後の周へ', zh: '最终周目', power: 1, life: 1 } };
  /* ======================================================================== */
  const ROWS = 26, HALF = 0.96, BOSS_HALF = 1.92, MOVE_STEPS = 4, BULLET_STEPS = 4;
  const DX = [0, 1, 0, -1], DY = [-1, 0, 1, 0];   // 向き：0 上・1 右・2 下・3 左
  const SOLID = { B: 1, b: 1, S: 1, W: 1, H: 1 };   // b＝ひびの入ったレンガ（もう 1 発で壊れる）
  const SPAWN_OFFSETS = [-4, 4, -8, 8];         // 味方の出る所（おうちの中心からの升）
  const GATE_AWAY = 4;                          // 敵の出口を、おうちの中心の列からこれだけ離す（升）
  const MINE_LIFE = 10, MINE_ARM = 0.8, MINE_EVERY = 4, MINE_MAX = 3;
  const MORTAR_RING_RATE = 0.3;   // 迫撃がおうちの囲いをねらう割合（残りは味方をねらう）
  const MORTAR_FLIGHT = 1.4, MORTAR_R = 1.6, RAM_RANGE = 8, RAM_SPEED = 8, RAM_SEC = 3, RAM_R = 1.6;
  const SNIPE_AIM = 1.0, LASER_AIM = 1.2, LASER_SEC = 0.6, MISSILE_SPEED = 6, MISSILE_TURN = 2.6, MISSILE_LIFE = 6;
  const ARMOR_GRACE = 0.6;        // よろいが 1 枚はがれた後、続けて当たらない時間（秒）
  const FIELD_STEP = 3;           // 磁場（のろのろ電波）の届く距離：1 段あたりの升
  const FIELD_DEBUFF = 0.1;       // 磁場の弱め方：1 段あたりの割合
  const INPUT_STALE_MS = 1500;   // スマホの向きがこの時間届かなければ止める（Wi-Fi の一瞬の遅れで止まらないよう、1 秒から延ばした）
  const MAX_LIVES = 9;            // 台数の上限（ぞうえん・周回の褒美でもこれより増えない）

  /* 種を決めた乱数（mulberry32） */
  function makeRand(seed) {
    let a = (seed >>> 0) || 1;
    return function () {
      a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
  // 外から来た値（続きからの引き継ぎ）を整数にして範囲に収める。数でなければ def
  const toInt = (v, a, b, def) => { if (v === null || v === undefined || v === '') return def; const n = Number(v); return Number.isFinite(n) ? clamp(Math.trunc(n), a, b) : def; };

  function newGame(seed) {
    const s = (seed === undefined ? 12345 : seed) >>> 0;
    return { ph: 'lobby', mode: 'camp', stageIdx: 0, stage: null, loop: 0, seed: s, rand: makeRand(s), pl: {}, map: [], cols: 26, rows: ROWS,
      tanks: [], bullets: [], shells: [], beams: [], mines: [], missiles: [], items: [], fx: [], texts: [], pending: [], queue: [],
      ev: [], t: 0, phT: 0, pauseT: 0, shake: 0, win: -1, why: '', awards: [], banner: null, reveal: null, loopReward: null,
      futon: 0, tower: 0, slow: 0, towerCd: 0, stopT: 0, wallT: 0, alertT: 0, alertN: 0, lastAlertT: -99, houseDead: false,
      enemyTotal: 0, spawnT: 0, gateI: 0, spawned: 0, itemDrops: 0, nLoaded: 0, dist: null, distDirty: true, distT: 0, paused: false };
  }
  function playerCount(g) { return Object.keys(g.pl).length; }
  function freeSlot(g) { const used = new Set(Object.values(g.pl).map(p => p.slot)); for (let i = 0; i < CFG.maxPlayers; i++) if (!used.has(i)) return i; return -1; }
  function addPlayer(g, id, name) {
    const slot = freeSlot(g); if (slot < 0) return null;
    const p = g.pl[id] = { id, slot, name, lives: CFG.lives, kills: 0, hits: 0, stuns: 0, power: 0, twin: 0, armor: 0, score: 0, tank: null, respawn: 0,
      in: { d: -1, lastF: 0, at: 0 }, fireQ: 0, combo: 0, lastKillT: -99, bestCombo: 0, shots: 0, landed: 0, houseKills: 0, seen: 0, stunBy: '', lavaT: 0 };
    if (g.ph === 'play' || g.ph === 'intro') rescale(g);
    return p;
  }
  function removePlayer(g, id) { const p = g.pl[id]; if (!p) return; if (p.tank) p.tank.alive = false; delete g.pl[id]; if (g.ph === 'play' || g.ph === 'intro') rescale(g); }
  function fxOf(g) { return FX[(g.stage && g.stage.fx) || 'none'] || FX.none; }
  function stageList(g) { return g.mode === 'adv' ? Stages.ADV : g.mode === 'hell' ? Stages.HELL : g.mode === 'extra' ? Stages.EXTRA : Stages.CAMPAIGN; }
  function mixOf(g) { return (g.stage && g.stage.mix) || Stages.MIX[g.stage.map] || [14, 2, 3, 1]; }

  /* 今の人数・面・周回・地獄で決まる値。s は TK の「面＋周回×6」の進み具合 */
  function diff(g, nOverride) {
    const n = clamp(nOverride || playerCount(g) || 1, 1, 4), sc = SCALE[n], hell = g.mode === 'hell', fx = fxOf(g), adv = g.mode === 'adv' && g.stage;
    const s = adv ? g.stage.s : hell ? 12 + g.stageIdx : g.mode === 'extra' ? 6 + g.stageIdx : g.stageIdx + g.loop * 6;
    const fireTK = clamp(0.85 + s * 0.095, 0.85, 2.8);
    let enemies = Math.round(sc.enemies * (hell ? HELL.enemies : 1));
    if (adv) enemies = Math.round(sc.enemies * g.stage.em * (g.stage.bosses ? 0.55 : 1));
    else if (g.stage && g.stage.boss) enemies = Math.round(enemies * 0.6);
    return {
      n, s, enemies,
      onField: sc.onField + Math.min(4, Math.floor(s / 3)) + (hell ? HELL.onField : 0),
      house: Math.min(0.8, sc.house * (fx.siege ? 1.6 : 1)),
      hunt: clamp(0.18 + s * 0.038, 0.18, 0.68) * (fx.siege ? 0.45 : 1),
      speed: sc.speed * (1 + Math.min(0.22, g.loop * 0.045)) * (fx.enemySpeed || 1) * (hell ? HELL.speed : 1),
      fire: sc.fire / fireTK * 0.85 / (fx.fire || 1) * (hell ? HELL.fire : 1),   // 撃つ間隔に掛ける（小さいほどよく撃つ）
      spawnGap: clamp(3.4 - s * 0.17, 1.05, 3.4) * (fx.spawnGap || 1) * (hell ? 0.7 : 1) / Math.sqrt(n / 2 + 0.5),
      hpBonus: adv ? Math.floor(s / 4.5) + (fx.hp || 0) : Math.min(4, g.loop) + (fx.hp || 0) + (hell ? HELL.hp : 0),
      itemEvery: Math.max(2, Math.round(sc.itemEvery * (hell ? HELL.itemEvery : 1) / Math.max(0.9, 1 - g.loop * 0.02))),
      shield: CFG.shieldSec * (hell ? HELL.shield : 1), bossHp: sc.bossHp
    };
  }
  /* 敵の並び。面の割合（ふつう・はやい・どっしり・かたい）を人数の数に合わせ、自作の敵・周回の追加・地獄の首領を足し、3 つに分けて混ぜる（後ほど強い） */
  function buildQueue(g, d) {
    const mix = mixOf(g), sum = mix.reduce((a, b) => a + b, 0), adv = g.mode === 'adv';
    const stageNo = g.mode === 'camp' ? g.stageIdx + 1 : 99, specials = adv ? g.stage.specials : SPECIALS.filter(k => ENEMY[k].from <= stageNo);
    const nCap = adv ? Math.min(g.stage.captains || 0, Math.max(0, d.enemies - 4)) : 0;
    const nSpecial = specials.length ? Math.round((d.enemies - nCap) * (adv ? g.stage.share : SPECIAL_SHARE)) : 0, nMix = d.enemies - nSpecial - nCap, q = [];
    MIX_KINDS.forEach((k, i) => { for (let j = 0; j < Math.round(nMix * mix[i] / sum); j++) q.push(k); });
    while (q.length < nMix) q.push('normal');
    while (q.length > nMix) { const cnt = {}; for (const k of q) cnt[k] = (cnt[k] || 0) + 1; const most = Object.keys(cnt).sort((a, b) => cnt[b] - cnt[a])[0]; q.splice(q.lastIndexOf(most), 1); }
    for (let i = 0; i < nSpecial; i++) q.push(specials[i % specials.length]);
    if (g.mode === 'camp') for (let i = 0; i < Math.min(12, g.loop * 3); i++) q.push(MIX_KINDS[(i + g.stageIdx + g.loop) % 4]);
    for (let i = 0; i < nCap; i++) q.push('captain');
    if (g.mode === 'hell') { q.push('chief'); for (let i = 0; i < 1 + g.stageIdx; i++) q.push('armor'); for (let i = 0; i < Math.min(3, g.stageIdx); i++) q.push('heavy'); }
    const seg = Math.ceil(q.length / 3), out = [];
    for (let s = 0; s < 3; s++) { const part = q.slice(s * seg, (s + 1) * seg); for (let i = part.length - 1; i > 0; i--) { const j = Math.floor(g.rand() * (i + 1)); [part[i], part[j]] = [part[j], part[i]]; } out.push(...part); }
    return out;
  }
  /* 試合の途中で人数が変わった時は、地図はそのまま、残りの敵の並びの長さだけを合わせ直す */
  function rescale(g) {
    const n = playerCount(g); if (!n || !g.enemyTotal) return;
    const total = diff(g, n).enemies; if (total === g.enemyTotal) return;
    const want = Math.max(0, Math.round(g.queue.length * total / g.enemyTotal));
    const plain = () => g.queue.map((k, i) => MIX_KINDS.includes(k) ? i : -1).filter(i => i >= 0);
    while (g.queue.length > want) { const idx = plain(); if (!idx.length) break; g.queue.splice(idx[Math.floor(g.rand() * idx.length)], 1); }
    const mix = mixOf(g), sum = mix.reduce((a, b) => a + b, 0);
    while (g.queue.length < want) { let r = g.rand() * sum, k = 0; while (k < 3 && r >= mix[k]) { r -= mix[k]; k++; } g.queue.splice(Math.floor(g.rand() * (g.queue.length + 1)), 0, MIX_KINDS[k]); }
    g.enemyTotal = total;
  }

  /* ---------- 面を作る ---------- */
  /* 地図を作る。ぼうけんの自動の面（st.gen）は部品から作り、敵の出口・味方の出る所からおうちまで道があるか確かめる。
     道が無ければ種をずらして作り直す（8 回まで） */
  function buildMap(g, n) {
    const st = g.stage;
    if (!st.gen) { buildMapOnce(g, n, null); return; }
    const cols = SCALE[clamp(n, 1, 4)].cols;
    for (let k = 0; k < 8; k++) {
      buildMapOnce(g, n, Stages.genRows(st, cols, ROWS, st.seed + cols * 101 + k * 7919));
      if (mapOk(g)) return;
    }
  }
  // 敵の出口と味方の出る所から、おうちまで（レンガは撃って通れる扱いで）たどり着けるか
  function mapOk(g) {
    buildDist(g);
    for (const gt of g.gates) if (distAt(g, gt.x, gt.y) < 0) return false;
    for (const sp of g.spawns) if (distAt(g, sp.x, sp.y) < 0) return false;
    for (const bx of g.bossXs || []) if (distAt(g, bx, 3) < 0) return false;
    return true;
  }
  function buildMapOnce(g, n, gen) {
    const st = g.stage, sc = SCALE[clamp(n, 1, 4)];
    let cols = sc.cols, rows = ROWS; const map = [];
    if (gen) { rows = gen.length; cols = gen[0].length; for (const r of gen) map.push([...r]); }
    else {
      const A = Stages.MAPS[st.map], B = Stages.MAPS[st.partner] || A; rows = A.length;
      for (let y = 0; y < rows; y++) { let r = A[y]; if (cols === 39) r += B[y].slice(0, 13); else if (cols === 52) r += B[y]; map.push([...r]); }
    }
    const set = (x, y, c) => { if (x >= 0 && y >= 0 && x < cols && y < rows) map[y][x] = c; };
    const clearBox = (x0, y0, w, h) => { for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) set(x, y, '.'); };
    const baseL = Math.floor(cols / 2) - 1, hx = baseL + 1, wall = fxOf(g).baseSteel ? 'S' : 'B';
    clearBox(baseL - 2, rows - 5, 6, 5);
    const ring = [];
    for (let x = baseL - 1; x <= baseL + 2; x++) { set(x, rows - 3, wall); ring.push([x, rows - 3]); }
    for (const y of [rows - 2, rows - 1]) { set(baseL - 1, y, wall); set(baseL + 2, y, wall); set(baseL, y, 'H'); set(baseL + 1, y, 'H'); ring.push([baseL - 1, y]); ring.push([baseL + 2, y]); }
    // 外側にもう 1 重のレンガ（家族で守りに戻る時間を作るため。2 重の囲い）
    for (let x = baseL - 2; x <= baseL + 3; x++) { set(x, rows - 4, wall); ring.push([x, rows - 4]); }
    for (const y of [rows - 3, rows - 2, rows - 1]) { set(baseL - 2, y, wall); set(baseL + 3, y, wall); ring.push([baseL - 2, y]); ring.push([baseL + 3, y]); }
    // おうちの真上に鋼の屋根（2 升）。遠くから真下へ撃たれても届かない。敵は横から回り込む
    set(baseL, rows - 5, 'S'); set(baseL + 1, rows - 5, 'S');
    const spawns = SPAWN_OFFSETS.map(o => ({ x: hx + o, y: rows - 1 }));
    for (const s of spawns) clearBox(s.x - 1, rows - 2, 2, 2);
    const gates = [];
    for (let i = 0; i < sc.gates; i++) {
      let x = Math.round(1 + i * (cols - 2) / (sc.gates - 1));
      if (Math.abs(x - hx) < GATE_AWAY) x = hx - GATE_AWAY - 1;   // おうちの真上には出口を置かない
      gates.push({ x, y: 1 }); clearBox(x - 1, 0, 2, 2);
    }
    const bossX = [hx + 7, hx - 7, hx + 10, hx - 10].find(x => x >= 2 && x <= cols - 2 && gates.every(gt => Math.abs(gt.x - x) >= 4)) || hx + 7;
    if (st.boss) clearBox(bossX - 2, 0, 4, 4);
    // ぼうけんのボス：1 体なら上の真ん中寄り、2 体なら左右。砂上戦艦は上に横長の海（砂）を空ける
    let bossXs = [];
    if (st.bosses) {
      if (st.bosses.includes('sandship')) { bossXs = [hx]; clearBox(Math.max(1, hx - 11), 0, Math.min(cols - 2, 22), 6); }
      else if (st.bosses.length === 1) { bossXs = [bossX]; clearBox(bossX - 2, 0, 4, 4); }
      else { bossXs = [clamp(hx - 9, 3, cols - 3), clamp(hx + 9, 3, cols - 3)]; for (const x of bossXs) clearBox(x - 2, 0, 4, 4); }
    }
    g.map = map; g.mapVer = (g.mapVer || 0) + 1; g.cols = cols; g.rows = rows; g.baseL = baseL; g.hx = hx; g.hy = rows - 1; g.ring = ring; g.spawns = spawns; g.gates = gates; g.bossX = bossX; g.bossXs = bossXs; g.wallTile = wall;
  }
  function loadStage(g, idx) {
    const list = stageList(g); g.stageIdx = clamp(idx, 0, list.length - 1); g.stage = list[g.stageIdx];
    const n = Math.max(1, playerCount(g)); g.nLoaded = n; buildMap(g, n);
    const d = diff(g);
    Object.assign(g, { tanks: [], bullets: [], shells: [], beams: [], mines: [], missiles: [], items: [], fx: [], texts: [], pending: [],
      t: 0, phT: CFG.introSec, ph: 'intro', pauseT: 0, shake: 0, win: -1, why: '', awards: [], reveal: null, loopReward: null,
      stopT: 0, wallT: 0, alertT: 0, houseDead: false, spawnT: 0.6, gateI: 0, spawned: 0, itemDrops: 0,
      distDirty: true, distT: 0, bossSpawned: false, bossWarned: false, lastAlertT: -99, paused: false,
      bossQ: g.stage.bosses ? g.stage.bosses.slice() : [], talk: null, talkWait: [], houseHits: 0, stars: null, bossKills: 0 });
    g.queue = buildQueue(g, d); g.enemyTotal = d.enemies;
    g.par = g.mode === 'adv' ? Stages.parTime(g.stage, d.enemies) : 0;
    g.banner = { s: g.stage.ja, zh: g.stage.zh, t: CFG.introSec };
    if (g.mode !== 'hell') g.futon = Math.max(g.futon, CFG.startFuton);
    for (const id in g.pl) { const p = g.pl[id]; Object.assign(p, { tank: null, respawn: 0, fireQ: 0, combo: 0, lastKillT: -99, bestCombo: 0, shots: 0, landed: 0, houseKills: 0, kills: 0, lavaT: 0 }); }
    g.ev.push({ k: 'stage', idx: g.stageIdx, mode: g.mode, boss: !!g.stage.boss, loop: g.loop });
  }
  /* 遊びを始める。mode＝'camp'（ふつう）・'extra'（おまけ）・'hell'（地獄）、idx＝始める面（0 から）。
     carry＝続きから遊ぶ時の引き継ぎ（{ loop, futon, tower, slow, pl: { 枠: { power, twin, armor, lives } } }） */
  function startRun(g, mode, idx, carry) {
    if (!playerCount(g)) return false;
    g.mode = mode === 'hell' ? 'hell' : mode === 'extra' ? 'extra' : mode === 'adv' ? 'adv' : 'camp';
    const c = carry || {};
    g.loop = g.mode === 'camp' ? toInt(c.loop, 0, CFG.maxLoop - 1, 0) : 0;
    g.futon = toInt(c.futon, 0, CFG.maxFuton, 0); g.tower = toInt(c.tower, 0, CFG.maxTower, 0); g.slow = toInt(c.slow, 0, CFG.maxSlow, 0);
    for (const id in g.pl) {
      const p = g.pl[id], cp = (c.pl && c.pl[p.slot]) || {};
      Object.assign(p, { lives: toInt(cp.lives, 1, MAX_LIVES, CFG.lives), power: toInt(cp.power, 0, CFG.maxPower, 0), twin: toInt(cp.twin, 0, CFG.maxTwin, 0),
        armor: toInt(cp.armor, 0, CFG.maxArmor, 0), hits: 0, stuns: 0, score: 0 });
    }
    loadStage(g, toInt(idx, 0, 99, 0)); return true;
  }
  /* 負けた面をやり直す（台数は戻す。火力・強化は今のまま） */
  function retryStage(g) { if (!playerCount(g)) return false; for (const id in g.pl) g.pl[id].lives = CFG.lives; loadStage(g, g.stageIdx); return true; }
  /* 続きから遊ぶための引き継ぎ（画面が覚えておく） */
  function carryOf(g) {
    const pl = {}; for (const id in g.pl) { const p = g.pl[id]; pl[p.slot] = { power: p.power, twin: p.twin, armor: p.armor, lives: p.lives }; }
    return { loop: g.loop, futon: g.futon, tower: g.tower, slow: g.slow, pl };
  }
  /* 一時停止（テレビのリモコン）。止めている間は計算を進めない */
  function setPause(g, on) {
    if (on && (g.ph === 'play' || g.ph === 'intro')) { g.paused = true; g.ev.push({ k: 'pause' }); }
    else if (!on && g.paused) { g.paused = false; g.ev.push({ k: 'resume' }); }
  }

  /* ---------- 当たり判定 ---------- */
  function tileAt(g, x, y) { if (x < 0 || y < 0 || x >= g.cols || y >= g.rows) return '#'; return g.map[y][x]; }
  function solidAt(g, x, y) { const c = tileAt(g, x, y); return c === '#' || !!SOLID[c]; }
  function boxHitsWall(g, x, y, h) {
    const x0 = Math.floor(x - h), x1 = Math.floor(x + h - 1e-6), y0 = Math.floor(y - h), y1 = Math.floor(y + h - 1e-6);
    for (let cy = y0; cy <= y1; cy++) for (let cx = x0; cx <= x1; cx++) if (solidAt(g, cx, cy)) return true; return false;
  }
  function boxHasTile(g, x, y, h, ch) {
    const x0 = Math.floor(x - h), x1 = Math.floor(x + h - 1e-6), y0 = Math.floor(y - h), y1 = Math.floor(y + h - 1e-6);
    for (let cy = y0; cy <= y1; cy++) for (let cx = x0; cx <= x1; cx++) if (tileAt(g, cx, cy) === ch) return true; return false;
  }
  // ほかの戦車とぶつかるか。すでに重なっている相手からは、離れる向きなら動ける
  function boxHitsTank(g, t, x, y, h) {
    for (const o of g.tanks) {
      if (o === t || !o.alive || o.under) continue; const m = h + o.half;
      if (Math.abs(o.x - x) < m && Math.abs(o.y - y) < m) {
        if (t && Math.abs(o.x - t.x) < m && Math.abs(o.y - t.y) < m && Math.hypot(o.x - x, o.y - y) >= Math.hypot(o.x - t.x, o.y - t.y)) continue;
        return true;
      }
    }
    return false;
  }
  function placeFree(g, x, y, h) { return !boxHitsWall(g, x, y, h) && !boxHitsTank(g, null, x, y, h); }
  // (x, y) の近く（r 升以内）で戦車を置ける所を、近い順に探す。無ければ null
  function findFree(g, x, y, r) {
    for (let k = 2; k <= r; k++) for (let dy = -k; dy <= k; dy++) for (let dx = -k; dx <= k; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) !== k) continue; const nx = x + dx, ny = y + dy;
      if (nx >= 1 && ny >= 1 && nx < g.cols && ny < g.rows - 4 && placeFree(g, nx, ny, HALF)) return { x: nx, y: ny };
    }
    return null;
  }
  /* 戦車を動かす。直角に曲がる時は、通路に入りやすいよう升の境目にそろえる */
  function moveTank(g, t, d, spd, dt) {
    t.blocked = false; if (d < 0) { t.moving = false; return; }
    if (d !== t.dir) {
      if ((d & 1) !== (t.dir & 1)) {
        const sx = d & 1 ? t.x : Math.round(t.x), sy = d & 1 ? Math.round(t.y) : t.y;
        if (!boxHitsWall(g, sx, sy, t.half) && !boxHitsTank(g, t, sx, sy, t.half)) { t.x = sx; t.y = sy; }
      }
      t.dir = d;
    }
    t.moving = true; const s = spd * dt / MOVE_STEPS;
    for (let i = 0; i < MOVE_STEPS; i++) {
      const nx = t.x + DX[d] * s, ny = t.y + DY[d] * s;
      if (boxHitsWall(g, nx, ny, t.half) || boxHitsTank(g, t, nx, ny, t.half)) { t.blocked = true; break; }
      t.x = nx; t.y = ny;
    }
  }
  function onTile(g, t, ch) { return tileAt(g, Math.floor(t.x), Math.floor(t.y)) === ch; }
  function groundSpeed(g, t) { if (onTile(g, t, 'D')) return 0.6; if (onTile(g, t, 'I')) return fxOf(g).ice ? 1.25 : 1.15; return 1; }
  function inTrees(g, t) { return onTile(g, t, 'T'); }
  function newTank(side, x, y, dir, extra) {
    return Object.assign({ side, x, y, dir, alive: true, half: HALF, cd: 0.3, out: 0, shield: 0, stun: 0, freeze: 0, flash: 0, moving: false, blocked: false, slide: 0 }, extra);
  }

  /* ---------- 敵の道さがし：おうちまでの升の距離（幅優先） ---------- */
  function nodeFree(g, cx, cy) { // 中心が (cx, cy) の戦車が置けるか（レンガは撃って通れるので通れる扱い）
    for (let y = cy - 1; y <= cy; y++) for (let x = cx - 1; x <= cx; x++) { const c = tileAt(g, x, y); if (c === '#' || c === 'S' || c === 'W' || c === 'H') return false; }
    return true;
  }
  function buildDist(g) {
    const W = g.cols + 1, H = g.rows + 1, dist = new Int16Array(W * H).fill(-1), q = [];
    for (let cy = 1; cy < g.rows; cy++) for (let cx = 1; cx < g.cols; cx++) if (Math.abs(cx - g.hx) <= 3 && cy >= g.rows - 4 && nodeFree(g, cx, cy)) { dist[cy * W + cx] = 0; q.push(cx, cy); }
    for (let i = 0; i < q.length; i += 2) {
      const x = q[i], y = q[i + 1], d = dist[y * W + x];
      for (let k = 0; k < 4; k++) {
        const nx = x + DX[k], ny = y + DY[k]; if (nx < 1 || ny < 1 || nx >= g.cols || ny >= g.rows) continue;
        const j = ny * W + nx; if (dist[j] >= 0 || !nodeFree(g, nx, ny)) continue; dist[j] = d + 1; q.push(nx, ny);
      }
    }
    g.dist = dist; g.distW = W; g.distDirty = false;
  }
  function distAt(g, cx, cy) { if (!g.dist || cx < 1 || cy < 1 || cx >= g.cols || cy >= g.rows) return -1; return g.dist[cy * g.distW + cx]; }
  // 近くの味方の戦車。森の面では、木の中にいる戦車はねらいにくい（遠い扱い）
  function nearestPlayerTank(g, x, y, forAim) {
    const jungle = fxOf(g).jungle; let best = null, bd = 1e9;
    for (const t of g.tanks) {
      if (t.side !== 'p' || !t.alive) continue; if (forAim && jungle && inTrees(g, t)) continue;
      let d = Math.hypot(t.x - x, t.y - y); if (jungle && inTrees(g, t)) d += 9;
      if (d < bd) { bd = d; best = t; }
    }
    return best;
  }
  function pickMode(g, t, d) { const r = g.rand(), e = ENEMY[t.kind]; if (e.boss) return r < e.house ? 'house' : 'hunt'; return r < d.house ? 'house' : r < d.house + d.hunt ? 'hunt' : 'wander'; }
  function chooseDir(g, t) {
    const r = g.rand();
    if (t.mode === 'house' && r < 0.85) {
      const cx = Math.round(t.x), cy = Math.round(t.y), here = distAt(g, cx, cy); let best = -1, bd = here < 0 ? 1e9 : here;
      for (let k = 0; k < 4; k++) { const d = distAt(g, cx + DX[k], cy + DY[k]); if (d >= 0 && (d < bd || (d === bd && g.rand() < 0.3))) { bd = d; best = k; } }
      if (best >= 0) return best;
    }
    let tg = null;
    if (t.mode === 'hunt' && r < 0.8) tg = nearestPlayerTank(g, t.x, t.y);
    else if (r < 0.25) tg = { x: g.hx, y: g.hy };
    if (!tg) return g.rand() * 4 | 0;
    const dx = tg.x - t.x, dy = tg.y - t.y; let horiz = Math.abs(dx) > Math.abs(dy); if (g.rand() < 0.25) horiz = !horiz;
    return horiz ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0);
  }

  /* ---------- 磁場（のろのろ電波）：味方の戦車のまわり 3 × 段 升の敵を、10 × 段 % 弱める ---------- */
  function fieldRadius(g) { return g.slow * FIELD_STEP; }
  function inField(g, x, y) { if (g.slow <= 0) return false; const r = fieldRadius(g); for (const p of g.tanks) if (p.side === 'p' && p.alive && Math.hypot(p.x - x, p.y - y) < r) return true; return false; }
  function fieldMul(g, t) { return inField(g, t.x, t.y) ? 1 - g.slow * FIELD_DEBUFF : 1; }

  /* ---------- 味方の火力（TK の段と同じ考え） ---------- */
  function playerBulletSpeed(p) { let v = p.power >= 4 ? 8.0 : p.power >= 1 ? 6.5 : 4.0; if (p.twin > 0) v = Math.max(v, 6.5); return v * K; }
  function playerMaxOut(p) { const base = p.power >= 2 ? 2 : 1; return p.twin > 0 ? Math.max(2, base) * 2 + (p.twin - 1) * 2 : base; }
  function playerDamage(p) { return (p.power >= 5 ? 3 : 1) * (p.twin >= 3 ? 2 : p.twin >= 2 ? 1.5 : 1); }
  function playerCooldown(p) { return p.twin > 0 ? Math.max(0.06, CFG.fireCooldown - (p.twin - 1) * 0.02) : CFG.fireCooldown; }

  /* ---------- 弾・爆発 ---------- */
  function addBullet(g, b) { g.bullets.push(Object.assign({ r: 0.2, pierce: 1, steel: false, bounces: 0, dmg: 1, through: false }, b)); }
  function fire(g, t, p) {
    if (t.cd > 0 || t.stun > 0 || t.freeze > 0) return false;
    if (t.side === 'p') {
      if (t.out >= playerMaxOut(p)) return false;
      t.cd = playerCooldown(p); const sp = playerBulletSpeed(p), dmg = playerDamage(p), ox = t.x + DX[t.dir] * 1.0, oy = t.y + DY[t.dir] * 1.0;
      const offs = p.twin > 0 ? [-0.45, 0.45] : [0];
      for (const o of offs) { t.out++; p.shots++; addBullet(g, { x: ox + (t.dir & 1 ? 0 : o), y: oy + (t.dir & 1 ? o : 0), vx: DX[t.dir] * sp, vy: DY[t.dir] * sp, side: 'p', owner: t, pid: t.pid, steel: p.power >= 3, dmg, r: p.power >= 3 ? 0.26 : 0.2 }); }
      g.ev.push({ k: 'fire', big: p.power >= 3 }); return true;
    }
    const e = ENEMY[t.kind]; if (t.out >= (e.elite ? 2 : 1)) return false;
    t.cd = (e.cd[0] + g.rand() * (e.cd[1] - e.cd[0])) * t.fireMul; t.out++;
    const sp = e.bullet * Math.sqrt(t.speedMul) * fieldMul(g, t), ox = t.x + DX[t.dir] * t.half, oy = t.y + DY[t.dir] * t.half;
    addBullet(g, { x: ox, y: oy, vx: DX[t.dir] * sp, vy: DY[t.dir] * sp, side: 'e', owner: t, r: t.kind === 'heavy' || e.elite ? 0.26 : 0.2, bounces: t.kind === 'bouncer' ? 1 : 0, kind: t.kind });
    g.ev.push({ k: 'efire' }); return true;
  }
  // 角度のある弾（ボス）。ang は向きからの角度（ラジアン）
  function fireAngle(g, t, ang, speed, extra) {
    const base = Math.atan2(DY[t.dir], DX[t.dir]) + ang;
    addBullet(g, Object.assign({ x: t.x + Math.cos(base) * t.half, y: t.y + Math.sin(base) * t.half, vx: Math.cos(base) * speed, vy: Math.sin(base) * speed, side: 'e', owner: null, r: 0.3, kind: 'boss' }, extra));
  }
  function alert(g) { g.alertT = CFG.alertSec; if (g.t - g.lastAlertT > 3) { g.lastAlertT = g.t; g.alertN++; g.ev.push({ k: 'danger' }); } }
  function isRing(g, x, y) { return g.ring.some(r => r[0] === x && r[1] === y); }
  // 升を壊す。レンガは 2 発で壊れる（1 発目でひび）。full＝1 発で壊す（体当たり・レーザー）。steel＝鋼も壊す
  function breakTile(g, x, y, steel, byEnemy, full) {
    const c = tileAt(g, x, y);
    if (c === 'B' && !full && !steel) { g.map[y][x] = 'b'; g.mapVer++; g.fx.push({ k: 'dust', x: x + 0.5, y: y + 0.5, t: 0.25, T: 0.25 }); if (byEnemy && isRing(g, x, y)) alert(g); return true; }
    if (c === 'B' || c === 'b' || (c === 'S' && steel)) {
      g.map[y][x] = '.'; g.distDirty = true; g.mapVer++; g.fx.push({ k: 'dust', x: x + 0.5, y: y + 0.5, t: 0.35, T: 0.35 });
      if (byEnemy && isRing(g, x, y)) alert(g); return true;
    }
    return false;
  }
  function hitHouse(g) {
    if (g.houseDead || g.ph !== 'play') return;
    g.houseHits = (g.houseHits || 0) + 1;   // 星「おうち無傷」：おふとんで守っても 1 回に数える
    if (g.futon > 0) { g.futon--; alert(g); g.ev.push({ k: 'shield' }); g.texts.push({ x: g.hx, y: g.hy - 2.5, s: 'おふとんが守った！', zh: '被子挡住了！', t: 1.2, col: '#9fe0ff' }); return; }
    g.houseDead = true; for (let y = g.rows - 2; y < g.rows; y++) for (let x = g.baseL; x <= g.baseL + 1; x++) g.map[y][x] = 'h'; g.mapVer++;
    g.fx.push({ k: 'boom', x: g.hx, y: g.hy - 0.5, r: 2.5, t: 1, T: 1 }); g.shake = 0.6; g.ev.push({ k: 'bigboom' });
    endGame(g, 0, 'house');
  }
  // 味方の戦車に当てる。たて（無敵）の間は効かない。よろいがあれば 1 枚はがれて助かる
  function killPlayer(g, t, cause) {
    if (!t.alive || t.shield > 0) return false;
    const p = g.pl[t.pid];
    if (p && p.armor > 0) { p.armor--; t.shield = ARMOR_GRACE; t.flash = 0.14; g.ev.push({ k: 'armor', pid: t.pid }); g.texts.push({ x: t.x, y: t.y - 1.4, s: 'よろいが守った！', zh: '护甲挡住了！', t: 1, col: '#9fe0ff' }); return false; }
    t.alive = false; g.fx.push({ k: 'boom', x: t.x, y: t.y, r: 1.4, t: 0.6, T: 0.6 }); g.shake = Math.max(g.shake, 0.3); g.ev.push({ k: 'hurt', pid: t.pid });
    if (p) { p.tank = null; p.lives--; p.hits++; p.power = Math.max(0, p.power - 1); p.respawn = CFG.respawnSec; p.combo = 0; p.fireQ = 0; p.lavaT = 0; }
    return true;
  }
  // 敵に当てる。noAim＝命中の数に入れない（ドカン）
  function damageEnemy(g, t, dmg, pid, noAim, hitX) {
    if (!t.alive || t.under) return;
    const p = pid && g.pl[pid]; if (p && !noAim) p.landed++;
    if (t.guard > 0) { t.guard = 0; t.flash = 0.1; g.texts.push({ x: t.x, y: t.y - 1.3, s: 'ガード！', zh: '挡住了！', t: 0.8, col: '#9fe0ff' }); g.ev.push({ k: 'steel' }); return; }
    // 砂上戦艦：砲塔が残っている間は砲塔にだけ当たる（体は効かない）
    if (t.parts && t.parts.some(q => q.hp > 0)) {
      let part = null;
      if (hitX === undefined) part = t.parts.find(q => q.hp > 0);
      else { let bd = 1.4; for (const q of t.parts) if (q.hp > 0 && Math.abs(hitX - (t.x + q.ox)) < bd) { bd = Math.abs(hitX - (t.x + q.ox)); part = q; } }
      if (!part) { g.ev.push({ k: 'steelhit' }); g.fx.push({ k: 'spark', x: hitX === undefined ? t.x : hitX, y: t.y, t: 0.2, T: 0.2 }); return; }
      part.hp -= dmg; part.flash = 0.1; g.ev.push({ k: 'steel' });
      if (part.hp <= 0) {
        g.fx.push({ k: 'boom', x: t.x + part.ox, y: t.y, r: 1.6, t: 0.8, T: 0.8 }); g.shake = Math.max(g.shake, 0.4); g.ev.push({ k: 'bigboom' });
        if (p) p.score += 800;
        if (!t.parts.some(q => q.hp > 0)) { t.phase = 2; g.banner = { s: '砲塔を ぜんぶ こわした！', zh: '炮塔全部摧毁了！', t: 1.8 }; g.ev.push({ k: 'bossphase' }); }
      }
      return;
    }
    t.hp -= dmg; t.flash = 0.08;
    if (t.hp > 0) { if (CFG.feel.freeze && !t.boss) t.freeze = 0.1; g.ev.push({ k: 'steel' }); return; }
    t.alive = false; const big = !!t.boss || !!ENEMY[t.kind].elite;
    g.fx.push({ k: 'boom', x: t.x, y: t.y, r: t.boss ? 3 : big ? 2 : 1.3, t: big ? 1.2 : 0.5, T: big ? 1.2 : 0.5 });
    g.shake = Math.max(g.shake, t.boss ? 0.7 : big ? 0.4 : 0.18); g.ev.push({ k: big ? 'bigboom' : 'boom' });
    if (t.glow) spawnItem(g);
    if (p) {
      p.kills++; p.score += ENEMY[t.kind].score; if (Math.hypot(t.x - g.hx, t.y - g.hy) < 7) p.houseKills++;
      p.combo = g.t - p.lastKillT <= CFG.comboSec ? p.combo + 1 : 1; p.lastKillT = g.t; p.bestCombo = Math.max(p.bestCombo, p.combo);
      if (p.combo >= 2) { p.score += p.combo * CFG.comboScore; g.texts.push({ x: t.x, y: t.y - 1, s: p.combo + ' れんぞく！ +' + p.combo * CFG.comboScore, zh: p.combo + ' 连击！+' + p.combo * CFG.comboScore, t: 1.1, col: p.combo >= 5 ? '#ff6a5f' : p.combo >= 3 ? '#ffb347' : '#7fe0ff', big: p.combo }); g.ev.push({ k: 'combo', n: p.combo }); }
    }
    if (t.boss) { g.banner = { s: 'ボスをたおした！', zh: '打倒了首领！', t: 2 }; g.bossKills = (g.bossKills || 0) + 1; if (ADV_BOSS[t.kind] && Stages.BOSS_TALK[t.kind]) g.talkWait.push({ t: 1.4, kinds: [t.kind], which: 'defeat' }); }
    else if (ENEMY[t.kind].elite) g.texts.push({ x: t.x, y: t.y - 1.6, s: '首領をたおした！', zh: '击破首领！', t: 1.5, col: '#ffd96a' });
  }
  // 爆発。full＝レンガを 1 発で壊す（体当たり）。迫撃・地雷はひびを入れるだけで、おうちに直接は届かない
  function explode(g, x, y, r, side, full) {
    g.fx.push({ k: 'boom', x, y, r, t: 0.5, T: 0.5 }); g.shake = Math.max(g.shake, 0.25); g.ev.push({ k: 'boom' });
    let house = false;
    for (let ty = Math.floor(y - r); ty <= Math.floor(y + r); ty++) for (let tx = Math.floor(x - r); tx <= Math.floor(x + r); tx++) {
      if (Math.hypot(tx + 0.5 - x, ty + 0.5 - y) > r + 0.3) continue;
      const c = tileAt(g, tx, ty); if (c === 'H') house = true; else breakTile(g, tx, ty, false, side === 'e', !!full);
    }
    if (side === 'e') { if (house && full) hitHouse(g); for (const t of g.tanks) if (t.side === 'p' && Math.hypot(t.x - x, t.y - y) < r + 0.6) killPlayer(g, t, 'boom'); }
  }
  /* 弾が升に当たったか。軸に沿う弾は 2 升の幅で調べる（戦車と同じ幅の穴が開く） */
  function bulletTiles(b) {
    const cx = Math.floor(b.x), cy = Math.floor(b.y), ax = Math.abs(b.vx) < 1e-6, ay = Math.abs(b.vy) < 1e-6;
    if (!ay && ax) return [[Math.floor(b.x - 0.5), cy], [Math.floor(b.x + 0.49), cy]];
    if (!ax && ay) return [[cx, Math.floor(b.y - 0.5)], [cx, Math.floor(b.y + 0.49)]];
    return [[cx, cy]];
  }
  function stepBullet(g, b, dt) {
    const s = dt / BULLET_STEPS;
    for (let i = 0; i < BULLET_STEPS && !b.dead; i++) {
      b.x += b.vx * s; b.y += b.vy * s;
      if (b.x < 0 || b.y < 0 || b.x >= g.cols || b.y >= g.rows) {
        if (b.bounces > 0) { b.bounces--; if (b.x < 0 || b.x >= g.cols) b.vx = -b.vx; else b.vy = -b.vy; b.x = clamp(b.x, 0.01, g.cols - 0.01); b.y = clamp(b.y, 0.01, g.rows - 0.01); continue; }
        b.dead = true; break;
      }
      for (const t of g.tanks) {
        if (!t.alive || t === b.owner || t.under) continue; const m = t.half + b.r * 0.5;
        if (Math.abs(b.x - t.x) >= m || Math.abs(b.y - t.y) >= m) continue;
        if (b.side === 'e' && t.side === 'e') continue;
        if (b.side === 'h' && t.side === 'p') continue;   // 陣地の自衛の弾は味方をすり抜ける
        if (b.side === 'p' && t.side === 'p') { // 味方の弾が味方に当たった：しばらく動けない
          b.dead = true; if (t.shield <= 0 && t.stun <= 0) {
            t.stun = CFG.friendlyStunSec; const vp = g.pl[t.pid], sp = g.pl[b.pid]; if (vp) { vp.stuns++; vp.stunBy = sp ? sp.name : ''; vp.fireQ = 0; }
            g.texts.push({ x: t.x, y: t.y - 1.4, s: (sp ? sp.name + ' の弾！' : '') + 'しびれた', zh: (sp ? sp.name + ' 的炮弹！' : '') + '麻痹了', t: 1.4, col: '#c9a8ff' }); g.ev.push({ k: 'stun', pid: t.pid });
          }
          break;
        }
        b.dead = true;
        if (t.side === 'p') killPlayer(g, t, 'bullet'); else damageEnemy(g, t, b.dmg, b.pid, false, b.x);
        break;
      }
      if (b.dead) break;
      if (b.side !== 'e') {   // ミサイル・地雷は味方の弾で壊せる
        for (const m of g.missiles) if (!m.dead && Math.hypot(m.x - b.x, m.y - b.y) < 0.6) { m.dead = true; b.dead = true; g.fx.push({ k: 'boom', x: m.x, y: m.y, r: 0.8, t: 0.3, T: 0.3 }); g.ev.push({ k: 'boom' }); break; }
        if (b.dead) break;
        for (const m of g.mines) if (!m.dead && Math.hypot(m.x - b.x, m.y - b.y) < 0.6) { m.dead = true; b.dead = true; g.fx.push({ k: 'boom', x: m.x, y: m.y, r: 0.7, t: 0.3, T: 0.3 }); break; }
        if (b.dead) break;
      }
      for (const o of g.bullets) { if (o === b || o.dead || (o.side === 'e') === (b.side === 'e')) continue; if (Math.abs(o.x - b.x) < 0.45 && Math.abs(o.y - b.y) < 0.45) { o.dead = b.dead = true; break; } }
      if (b.dead || b.through) continue;
      let stop = false, broke = false, bounce = false, house = false;
      for (const [tx, ty] of bulletTiles(b)) {
        const c = tileAt(g, tx, ty);
        if (c === 'B' || c === 'b') { breakTile(g, tx, ty, b.steel, b.side === 'e', false); broke = true; }
        else if (c === 'S') { if (b.steel) { breakTile(g, tx, ty, true, false); broke = true; } else if (b.bounces > 0) bounce = true; else stop = true; }
        else if (c === 'H') { house = true; stop = true; }
        else if (c === '#') stop = true;
      }
      if (house && b.side === 'e' && !b.hitHouse) { b.hitHouse = true; hitHouse(g); }
      if (bounce && !broke) { b.bounces--; b.vx = -b.vx; b.vy = -b.vy; b.x += b.vx * s * 2; b.y += b.vy * s * 2; continue; }
      if (broke) { g.ev.push({ k: 'brick' }); if (--b.pierce <= 0) { b.dead = true; break; } b.x += b.vx * s * 2; b.y += b.vy * s * 2; continue; }
      if (stop) { b.dead = true; g.fx.push({ k: 'spark', x: b.x, y: b.y, t: 0.2, T: 0.2 }); g.ev.push({ k: 'steelhit' }); break; }
    }
  }

  /* ---------- アイテム（TK と同じ：場に 1 つまで。面の最初の 1 つは、よろいが要る人がいれば よろい） ---------- */
  function itemNeeds(g) {
    const ps = Object.values(g.pl);
    return { power: ps.some(p => p.power < CFG.maxPower) || g.tower < CFG.maxTower, armor: ps.some(p => p.armor < CFG.maxArmor) || g.futon < CFG.maxFuton,
      twin: ps.some(p => p.twin < CFG.maxTwin), field: g.slow < CFG.maxSlow };
  }
  function chooseItem(g) {
    const need = itemNeeds(g);
    const list = ITEM_WEIGHTS.map(([k, w]) => [k === 'power' && !need.power ? 'twin' : k === 'armor' && !need.armor ? 'field' : k, w])
      .filter(([k]) => (k !== 'twin' || need.twin) && (k !== 'field' || need.field));
    if (!list.length) return null;
    if (g.itemDrops === 0 && need.armor) return 'armor';
    let roll = g.rand() * list.reduce((a, [, w]) => a + w, 0);
    for (const [k, w] of list) { roll -= w; if (roll <= 0) return k; }
    return list[list.length - 1][0];
  }
  function spawnItem(g) {
    if (g.items.some(it => !it.dead)) return;
    const kind = chooseItem(g); if (!kind) return;
    for (let i = 0; i < 60; i++) {
      const x = 2 + Math.floor(g.rand() * (g.cols - 4)), y = 3 + Math.floor(g.rand() * (g.rows - 9));
      if (Math.abs(x - g.hx) < 4 && y > g.rows - 6) continue;
      let ok = true; for (let yy = y - 1; yy <= y; yy++) for (let xx = x - 1; xx <= x; xx++) { const c = tileAt(g, xx, yy); if (c === 'S' || c === 'W' || c === 'H' || c === '#') ok = false; }
      if (!ok) continue;
      g.itemDrops++; g.items.push({ x, y, kind, t: CFG.itemLifeSec }); g.ev.push({ k: 'item_appear', kind }); return;
    }
  }
  function setRing(g, ch) {
    for (const [x, y] of g.ring) if (!g.tanks.some(o => o.alive && Math.abs(o.x - (x + 0.5)) < o.half + 0.5 && Math.abs(o.y - (y + 0.5)) < o.half + 0.5)) g.map[y][x] = ch;
    g.distDirty = true; g.mapVer++;
  }
  function pickItem(g, p, it) {
    const t = p.tank; let note = '';
    p.score += CFG.itemScore;
    if (it.kind === 'shield') t.shield = Math.max(t.shield, CFG.shieldItemSec);
    else if (it.kind === 'stop') g.stopT = CFG.stopItemSec;
    else if (it.kind === 'wall') { g.wallT = CFG.wallItemSec; setRing(g, 'S'); }
    else if (it.kind === 'power') {
      if (p.power < CFG.maxPower) { p.power++; note = 'power'; }
      else if (g.tower < CFG.maxTower) { g.tower++; note = 'tower'; }
    } else if (it.kind === 'armor') {
      if (p.armor < CFG.maxArmor) { p.armor++; note = 'armor'; }
      else if (g.futon < CFG.maxFuton) { g.futon++; note = 'futon'; }
    } else if (it.kind === 'twin') { p.twin = Math.min(CFG.maxTwin, p.twin + 1); note = 'twin'; }
    else if (it.kind === 'field') { g.slow = Math.min(CFG.maxSlow, g.slow + 1); note = 'slow'; }
    else if (it.kind === 'extra') { p.lives = Math.min(MAX_LIVES, p.lives + 1); note = 'life'; }
    else if (it.kind === 'bomb') {
      for (const e of g.tanks) if (e.side === 'e' && e.alive) damageEnemy(g, e, e.boss ? 5 : 99, p.id, true);
      g.shake = 0.6; g.ev.push({ k: 'bigboom' });
    }
    g.pauseT = CFG.itemPauseSec; g.reveal = { kind: it.kind, note, name: p.name, slot: p.slot, t: 1.2, lv: { power: p.power, armor: p.armor, twin: p.twin, tower: g.tower, futon: g.futon, slow: g.slow } };
    g.ev.push({ k: 'item_get', kind: it.kind, note, pid: p.id });
  }

  /* ---------- 敵 ---------- */
  function spawnEnemy(g, kind, x, y, d, extra) {
    const e = ENEMY[kind], bonus = e.boss ? 0 : d.hpBonus;
    const t = newTank('e', x, y, 2, Object.assign({ kind, hp: e.hp + bonus, maxHp: e.hp + bonus, ai: 0, want: 2, mode: 'wander', modeT: 8, speedMul: d.speed, fireMul: d.fire, mineCd: MINE_EVERY, charge: 0, aim: 0, fieldApplied: 0 }, extra));
    t.mode = pickMode(g, t, d);
    if (e.boss) { t.boss = true; t.half = BOSS_HALF; t.hp = t.maxHp = Math.round(e.hp * d.bossHp); t.mode = 'hunt'; t.spreadCd = 2; t.missileCd = 5; t.laserCd = 8; t.summonCd = 10; t.snipeCd = 12;
      t.phase = 1; t.atkCd = 2; t.sideCd = 1.5; t.buildCd = 3; t.built = 0; t.st = 'surf'; t.stT = 4; t.lzCd = 5; t.talkT = 4 + g.rand() * 3;
      if (kind === 'sandship') { const ph = Math.max(2, Math.round(e.partHp * d.bossHp)); t.parts = [-1.7, 0, 1.7].map((ox, i) => ({ ox, hp: ph, maxHp: ph, cd: 1.5 + i * 0.6, ang: Math.PI / 2, flash: 0 })); t.dir = 3; t.mode = 'ship'; } }
    if (e.captain) { t.aura = CAPTAIN_KINDS[Math.floor(g.rand() * CAPTAIN_KINDS.length)]; t.auraT = 2; t.captain = true; }
    if (e.elite) { t.hp = t.maxHp = Math.round((e.hp + bonus) * d.bossHp); t.glow = true; }
    g.tanks.push(t); return t;
  }
  function enemyThink(g, t, dt, d) {
    const e = ENEMY[t.kind];
    if (g.stopT > 0 || t.freeze > 0) return;
    // 磁場の中では、速さ・撃つ回数・体力が下がる（体力は 1 段ごとに 1 回だけ）
    const fm = fieldMul(g, t);
    if (fm < 1 && !t.boss) { const want = g.slow * FIELD_DEBUFF; if (want > t.fieldApplied) { const base = t.baseHp || (t.baseHp = t.maxHp); const mx = Math.max(1, base - Math.floor(base * want + 1e-9)); t.hp = Math.max(1, t.hp - (t.maxHp - mx)); t.maxHp = mx; t.fieldApplied = want; } }
    t.cd -= dt * fm; t.modeT -= dt;
    if (t.modeT <= 0) { t.mode = pickMode(g, t, d); t.modeT = 8; }
    let spd = e.speed * t.speedMul * fm * groundSpeed(g, t);
    if (t.kind === 'sniper' && t.aim > 0) { t.aim -= dt; if (t.aim <= 0) { t.dir = t.aimDir; t.cd = 0; t.out = 0; fire(g, t); } return; }
    if (t.kind === 'sniper' && t.cd <= 0) {
      const tgts = [{ x: g.hx, y: g.hy }].concat(g.tanks.filter(o => o.side === 'p' && o.alive && !(fxOf(g).jungle && inTrees(g, o))));
      for (const o of tgts) {
        if (Math.abs(o.x - t.x) < 0.6 && Math.abs(o.y - t.y) < 16) { t.aim = SNIPE_AIM; t.aimDir = o.y > t.y ? 2 : 0; break; }
        if (Math.abs(o.y - t.y) < 0.6 && Math.abs(o.x - t.x) < 16) { t.aim = SNIPE_AIM; t.aimDir = o.x > t.x ? 1 : 3; break; }
      }
      if (t.aim > 0) { t.dir = t.aimDir; g.ev.push({ k: 'aim' }); return; }
    }
    if (t.kind === 'rammer') {
      const tg = nearestPlayerTank(g, t.x, t.y, true);
      if (t.charge <= 0 && tg && Math.hypot(tg.x - t.x, tg.y - t.y) < RAM_RANGE) { t.charge = RAM_SEC; g.texts.push({ x: t.x, y: t.y - 1.4, s: 'とっしん！', zh: '冲撞！', t: 0.9, col: '#ff7a7a' }); }
      if (t.charge > 0) {
        t.charge -= dt;
        if (tg) { const dx = tg.x - t.x, dy = tg.y - t.y; t.want = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0); }
        moveTank(g, t, t.want, RAM_SPEED * t.speedMul * fm, dt);
        if ((tg && Math.hypot(tg.x - t.x, tg.y - t.y) < 2.1) || t.charge <= 0 || t.blocked) { t.alive = false; explode(g, t.x, t.y, RAM_R, 'e', true); }
        return;
      }
    }
    if (t.kind === 'miner') {
      t.mineCd -= dt;
      if (t.mineCd <= 0) { t.mineCd = MINE_EVERY; if (g.mines.filter(m => m.owner === t && !m.dead).length < MINE_MAX) { g.mines.push({ x: t.x, y: t.y, t: MINE_LIFE, arm: MINE_ARM, owner: t }); g.ev.push({ k: 'mine' }); } }
    }
    if (t.kind === 'mortar' && t.cd <= 0) {
      t.cd = (e.cd[0] + g.rand() * (e.cd[1] - e.cd[0])) * t.fireMul;
      let tx, ty; const live = g.tanks.filter(o => o.side === 'p' && o.alive);
      if (g.rand() < MORTAR_RING_RATE || !live.length) { const r = g.ring[Math.floor(g.rand() * g.ring.length)]; tx = r[0] + 0.5; ty = r[1] + 0.5; }
      else { const o = live[Math.floor(g.rand() * live.length)]; tx = o.x; ty = o.y; }
      g.shells.push({ x: tx, y: ty, fx: t.x, fy: t.y, t: MORTAR_FLIGHT, T: MORTAR_FLIGHT, r: MORTAR_R }); g.ev.push({ k: 'mortar' });
    }
    if (t.boss) { if (ADV_BOSS[t.kind]) { if (advBoss(g, t, dt, d)) return; } else bossThink(g, t, dt, d); }
    if (!t.boss && g.hasteCaps && g.hasteCaps.length) for (const c of g.hasteCaps) if (c !== t && Math.hypot(c.x - t.x, c.y - t.y) < AURA_R) { spd *= 1.3; break; }
    t.ai -= dt;
    const aligned = Math.abs(t.x - Math.round(t.x)) < 0.08 && Math.abs(t.y - Math.round(t.y)) < 0.08;
    if (t.blocked && t.cd <= 0 && g.rand() < 0.6 && t.kind !== 'mortar') fire(g, t);
    if (t.blocked || t.ai <= 0 || (aligned && t.mode === 'house' && g.rand() < 0.08)) { t.want = chooseDir(g, t); t.ai = 0.8 + g.rand() * 1.8; }
    if (t.boss && t.laserAim > 0) return;
    if (t.boss && t.hp < t.maxHp / 2) spd *= 1.5;
    if (t.kind === 'superboss') spd *= 1 + (1 - t.hp / t.maxHp) * 0.6;
    moveTank(g, t, t.want, spd, dt);
    if (!t.boss && t.kind !== 'mortar' && t.kind !== 'sniper' && t.cd <= 0) fire(g, t);
  }
  function bossThink(g, t, dt, d) {
    const rate = t.kind === 'superboss' ? 0.5 + 0.5 * (t.hp / t.maxHp) : 1;
    const tick = cd => cd - dt / rate;
    t.spreadCd = tick(t.spreadCd);
    if (t.spreadCd <= 0) {
      const angs = t.kind === 'superboss' ? [-0.7, -0.35, 0, 0.35, 0.7] : [-0.44, 0, 0.44];
      for (const a of angs) fireAngle(g, t, a, ENEMY[t.kind].bullet); t.spreadCd = ENEMY[t.kind].cd[0]; g.ev.push({ k: 'efire' });
    }
    t.summonCd = tick(t.summonCd);
    const minions = g.tanks.filter(o => o.alive && o.minion).length, maxM = t.kind === 'superboss' ? 3 : 2;
    if (t.summonCd <= 0 && (t.kind === 'superboss' || t.hp < t.maxHp / 2)) {
      t.summonCd = t.kind === 'superboss' ? 10 : 12;
      let made = 0;
      while (made < 2 && minions + made < maxM) {
        const sp = findFree(g, Math.round(t.x), Math.round(t.y), 7) || g.gates.find(gt => placeFree(g, gt.x, gt.y, HALF)); if (!sp) break;
        spawnEnemy(g, g.rand() < 0.5 ? 'fast' : 'normal', sp.x, sp.y, d, { minion: true }); made++;
      }
    }
    if (t.kind !== 'superboss') return;
    t.missileCd = tick(t.missileCd);
    if (t.missileCd <= 0) { t.missileCd = 5; for (const a of [-1.2, 1.2]) { const base = Math.atan2(DY[t.dir], DX[t.dir]) + a; g.missiles.push({ x: t.x, y: t.y, ang: base, t: MISSILE_LIFE }); } g.ev.push({ k: 'missile' }); }
    if (t.laserAim > 0) { t.laserAim -= dt; if (t.laserAim <= 0) { g.beams.push({ x: t.x, y: t.y, dir: t.dir, t: LASER_SEC, owner: t }); g.ev.push({ k: 'laser' }); g.shake = Math.max(g.shake, 0.3); } }
    else { t.laserCd = tick(t.laserCd); if (t.laserCd <= 0) { t.laserCd = 9; t.laserAim = LASER_AIM; } }
    t.snipeCd = tick(t.snipeCd);
    if (t.snipeCd <= 0) {
      if (Math.abs(t.x - g.hx) < 1.2) { t.snipeCd = 12; t.dir = 2; fireAngle(g, t, 0, 22, { r: 0.4, pierce: 3 }); g.ev.push({ k: 'efire' }); g.texts.push({ x: t.x, y: t.y - 2.5, s: 'おうちをねらってる！', zh: '瞄准小屋了！', t: 1.4, col: '#ff7a7a' }); }
      else { t.want = g.hx > t.x ? 1 : 3; t.ai = 1; }
    }
  }
  /* ---------- ぼうけんのボス 6 体（v0.11）。どれも体力が減ると技が変わる（段階）。大きな技の前には必ず予告を出す。
     戻り値 true＝この刻みはふつうの動き（道さがし）をしない ---------- */
  function fireAt(g, t, ang, speed, extra, ox, oy) {
    const x = (ox === undefined ? t.x : ox) + Math.cos(ang) * t.half * 0.9, y = (oy === undefined ? t.y : oy) + Math.sin(ang) * t.half * 0.9;
    addBullet(g, Object.assign({ x, y, vx: Math.cos(ang) * speed, vy: Math.sin(ang) * speed, side: 'e', owner: null, r: 0.3, kind: 'boss' }, extra));
  }
  function summon(g, t, d, n, max) {
    const live = g.tanks.filter(o => o.alive && o.minion).length; let made = 0;
    while (made < n && live + made < max) {
      const sp = findFree(g, Math.round(t.x), Math.round(t.y), 7) || g.gates.find(gt => placeFree(g, gt.x, gt.y, HALF)); if (!sp) break;
      spawnEnemy(g, g.rand() < 0.5 ? 'fast' : 'normal', sp.x, sp.y, d, { minion: true }); made++;
    }
    if (made) g.texts.push({ x: t.x, y: t.y - 2.4, s: 'なかまを よんだ！', zh: '叫来了同伴！', t: 1.1, col: '#ffb347' });
  }
  function phaseUp(g, t, ph, ja, zh) { if (t.phase >= ph) return; t.phase = ph; g.shake = Math.max(g.shake, 0.35); g.texts.push({ x: t.x, y: t.y - 2.6, s: ja, zh, t: 1.6, col: '#ff7a5c', big: 2 }); g.ev.push({ k: 'bossphase' }); }
  function axisDirTo(t, o) { const dx = o.x - t.x, dy = o.y - t.y; return Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0); }
  function findFreeBig(g, x, y, r, h) {
    for (let k = 0; k <= r; k++) for (let dy = -k; dy <= k; dy++) for (let dx = -k; dx <= k; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) !== k) continue; const nx = Math.round(x) + dx, ny = Math.round(y) + dy;
      if (nx >= 2 && ny >= 2 && nx <= g.cols - 2 && ny <= g.rows - 7 && placeFree(g, nx, ny, h)) return { x: nx, y: ny };
    }
    return null;
  }
  // 工兵車：味方の前（味方と自分の間）に 2 × 2 のレンガを積む。おうちのまわり・出口・戦車の上には積まない
  function canBuild(g, cx, cy) {
    if (cy < 3 || cy > g.rows - 7 || cx < 2 || cx > g.cols - 2) return false;
    for (let y = cy - 1; y <= cy; y++) for (let x = cx - 1; x <= cx; x++) { const c = tileAt(g, x, y); if (c !== '.' && c !== 'D') return false; }
    if (g.gates.some(gt => Math.abs(gt.x - cx) < 3 && cy < 5)) return false;
    if (Math.abs(cx - g.hx) < 5 && cy > g.rows - 9) return false;
    for (const o of g.tanks) if (o.alive && Math.abs(o.x - cx) < o.half + 1.1 && Math.abs(o.y - cy) < o.half + 1.1) return false;
    for (const it of g.items) if (Math.abs(it.x - cx) < 2 && Math.abs(it.y - cy) < 2) return false;
    return true;
  }
  function buildWall(g, t) {
    const tg = nearestPlayerTank(g, t.x, t.y) || { x: g.hx, y: g.rows - 8 };
    for (let k = 0; k < 16; k++) {
      const r = 2.6 + g.rand() * 3, a = Math.atan2(t.y - tg.y, t.x - tg.x) + (g.rand() - 0.5) * 1.4;
      const cx = Math.round(tg.x + Math.cos(a) * r), cy = Math.round(tg.y + Math.sin(a) * r);
      if (!canBuild(g, cx, cy)) continue;
      for (let y = cy - 1; y <= cy; y++) for (let x = cx - 1; x <= cx; x++) g.map[y][x] = 'B';
      g.mapVer++; g.distDirty = true; t.built++; g.fx.push({ k: 'dust', x: cx, y: cy, t: 0.35, T: 0.35 }); g.ev.push({ k: 'brick' });
      if (g.rand() < 0.35) g.texts.push({ x: cx, y: cy - 1.2, s: 'かべ、できた！', zh: '墙砌好了！', t: 1, col: '#ffd27a' });
      return true;
    }
    return false;
  }
  function advBoss(g, t, dt, d) {
    const f = t.hp / t.maxHp, e = ENEMY[t.kind], near = nearestPlayerTank(g, t.x, t.y, true), base = Math.atan2(DY[t.dir], DX[t.dir]);
    if (t.kind === 'twin') {
      if (f < 0.5) phaseUp(g, t, 2, 'ふたりで本気だ！', '兄弟认真了！');
      t.sideCd -= dt; t.atkCd -= dt; t.talkT -= dt; t.summonCd -= dt;
      if (t.sideCd <= 0) {   // 左右の砲塔：1 段目は片側ずつ、2 段目は両側と斜め
        t.sideN = (t.sideN || 0) + 1; const side = t.sideN % 2 ? 1 : -1;
        const angs = t.phase >= 2 ? [base + Math.PI / 2, base - Math.PI / 2, base + Math.PI / 2 + 0.35, base - Math.PI / 2 - 0.35] : [base + side * Math.PI / 2, base + side * (Math.PI / 2 + 0.3)];
        for (const a of angs) fireAt(g, t, a, e.bullet); t.sideCd = t.phase >= 2 ? 1.25 : 1.5; g.ev.push({ k: 'efire' });
      }
      if (t.atkCd <= 0) { for (const a of t.phase >= 2 ? [-0.3, 0, 0.3] : [0]) fireAt(g, t, base + a, e.bullet); t.atkCd = 2.1; }
      if (t.phase >= 2 && t.summonCd <= 0) { t.summonCd = 12; summon(g, t, d, 2, 2); }
      if (t.talkT <= 0) { t.talkT = 6 + g.rand() * 4; const L = g.rand() < 0.5; g.texts.push({ x: t.x + (L ? -1.6 : 1.6), y: t.y - 2.2, s: L ? 'みぎだ！' : 'ひだりだ！', zh: L ? '右边！' : '左边！', t: 1.2, col: '#ffe08a' }); }
      return false;
    }
    if (t.kind === 'engineer') {
      if (f < 0.5) phaseUp(g, t, 2, 'もっと つむぞ！', '再多砌点！');
      t.buildCd -= dt; t.atkCd -= dt; t.summonCd -= dt;
      if (t.buildCd <= 0 && t.built < (t.phase >= 2 ? 30 : 20)) { buildWall(g, t); t.buildCd = t.phase >= 2 ? 2.8 : 4.5; }
      if (t.atkCd <= 0) { const a = near ? Math.atan2(near.y - t.y, near.x - t.x) : base; for (const o of [-0.35, 0, 0.35]) fireAt(g, t, a + o, e.bullet); t.atkCd = t.phase >= 2 ? 2.0 : 2.4; g.ev.push({ k: 'efire' }); }
      if (t.phase >= 2 && t.summonCd <= 0) { t.summonCd = 12; summon(g, t, d, 2, 2); }
      return false;
    }
    if (t.kind === 'bigtank') {   // 大型戦車：3 段階（今のボスを作り直した）
      if (f < 0.66) phaseUp(g, t, 2, 'まだまだ！', '还没完！');
      if (f < 0.33) phaseUp(g, t, 3, '本気を見せよう', '让你们见识真本事');
      t.atkCd -= dt; t.summonCd -= dt; t.missileCd -= dt; t.snipeCd -= dt;
      if (t.atkCd <= 0) { const angs = t.phase >= 2 ? [-0.7, -0.35, 0, 0.35, 0.7] : [-0.44, 0, 0.44]; for (const a of angs) fireAt(g, t, base + a, e.bullet); t.atkCd = t.phase >= 2 ? 1.7 : 2.0; g.ev.push({ k: 'efire' }); }
      if (t.phase >= 2 && t.summonCd <= 0) { t.summonCd = 11; summon(g, t, d, 2, 3); }
      if (t.phase >= 3) {
        if (t.missileCd <= 0) { t.missileCd = 6; for (const a of [-1.2, 1.2]) g.missiles.push({ x: t.x, y: t.y, ang: base + a, t: MISSILE_LIFE }); g.ev.push({ k: 'missile' }); }
        if (t.snipeCd <= 0) {
          if (Math.abs(t.x - g.hx) < 1.2 && t.y < g.hy - 6) { t.snipeCd = 10; t.dir = 2; fireAt(g, t, Math.PI / 2, 20, { r: 0.4, pierce: 3 }); g.ev.push({ k: 'efire' }); g.texts.push({ x: t.x, y: t.y - 2.5, s: 'おうちを ねらってる！', zh: '瞄准小屋了！', t: 1.4, col: '#ff7a7a' }); }
          else { t.want = g.hx > t.x ? 1 : 3; t.ai = 1; }
        }
      }
      return false;
    }
    if (t.kind === 'burrower') {   // 砂もぐり：もぐる → 予告の印 → 出てきて輪の弾
      if (f < 0.5) phaseUp(g, t, 2, 'もう かくれない…！', '不躲了…！');
      t.stT -= dt;
      if (t.st === 'surf') {
        t.atkCd -= dt; if (t.atkCd <= 0 && near) { fireAt(g, t, Math.atan2(near.y - t.y, near.x - t.x), e.bullet); t.atkCd = t.phase >= 2 ? 0.9 : 1.2; g.ev.push({ k: 'efire' }); }
        if (t.stT <= 0) { t.st = 'dig'; t.stT = 0.7; g.texts.push({ x: t.x, y: t.y - 2, s: 'ズボッ', zh: '噗', t: 0.8, col: '#e9d3a0' }); g.fx.push({ k: 'dust', x: t.x, y: t.y + 1, t: 0.5, T: 0.5 }); }
        return false;
      }
      if (t.st === 'dig') { if (t.stT <= 0) { t.st = 'under'; t.under = true; t.stT = t.phase >= 2 ? 1.3 : 1.8; const live = g.tanks.filter(o => o.side === 'p' && o.alive);
          const tg = live.length && g.rand() < 0.7 ? live[Math.floor(g.rand() * live.length)] : { x: g.hx + (g.rand() < 0.5 ? -7 : 7), y: g.rows - 9 };
          const a = g.rand() * Math.PI * 2, r = 4 + g.rand() * 2; t.tx = clamp(tg.x + Math.cos(a) * r, 3, g.cols - 3); t.ty = clamp(tg.y + Math.sin(a) * r, 3, g.rows - 8); } return true; }
      if (t.st === 'under') {
        if (t.stT > 0) return true;
        const sp = findFreeBig(g, t.tx, t.ty, 6, BOSS_HALF); if (!sp) { t.stT = 0.3; t.tx = g.cols / 2; t.ty = 6; return true; }
        t.x = sp.x; t.y = sp.y; t.under = false; t.st = 'surf'; t.stT = t.phase >= 2 ? 3 : 4.5; t.atkCd = 0.8;
        const nRing = t.phase >= 2 ? 12 : 8; for (let i = 0; i < nRing; i++) fireAt(g, t, i * Math.PI * 2 / nRing, e.bullet * 0.8);
        g.shake = Math.max(g.shake, 0.4); g.fx.push({ k: 'boom', x: t.x, y: t.y, r: 1.8, t: 0.5, T: 0.5 }); g.ev.push({ k: 'bigboom' });
        return true;
      }
      return false;
    }
    if (t.kind === 'scorpion') {   // さそり戦車：はさみの弾と、予告してから しっぽのレーザー
      if (f < 0.5) phaseUp(g, t, 2, 'しっぽが うなるぞ！', '尾巴要发威了！');
      t.atkCd -= dt;
      if (t.laserAim > 0) { t.laserAim -= dt; if (t.laserAim <= 0) { g.beams.push({ x: t.x, y: t.y, dir: t.dir, t: LASER_SEC, owner: t }); g.ev.push({ k: 'laser' }); g.shake = Math.max(g.shake, 0.3); } return true; }
      t.lzCd -= dt;
      if (t.lzCd <= 0 && near) { t.dir = axisDirTo(t, near); t.laserAim = 1.3; t.lzCd = t.phase >= 2 ? 4.5 : 7; g.texts.push({ x: t.x, y: t.y - 2.4, s: 'しっぽビーム！', zh: '尾巴光束！', t: 1.2, col: '#ff7a7a' }); g.ev.push({ k: 'aim' }); return true; }
      if (t.atkCd <= 0) { const angs = t.phase >= 2 ? [-1.2, -0.45, 0.45, 1.2] : [-0.45, 0.45]; for (const a of angs) fireAt(g, t, base + a, e.bullet); t.atkCd = t.phase >= 2 ? 1.5 : 2.1; g.ev.push({ k: 'efire' }); }
      return false;
    }
    if (t.kind === 'sandship') {   // 砂上戦艦：横に行き来する。砲塔 3 つを壊すと体に当たるようになる
      const armored = t.parts.some(q => q.hp > 0), spd = (armored ? 1.6 : 2.6) * t.speedMul * dt;
      const L = Math.max(3, g.hx - 8), R = Math.min(g.cols - 3, g.hx + 8);
      let dir = t.dir === 1 ? 1 : -1; const nx = t.x + dir * spd;
      if (nx < L || nx > R || boxHitsWall(g, nx, t.y, t.half) || boxHitsTank(g, t, nx, t.y, t.half)) { dir = -dir; t.dir = dir > 0 ? 1 : 3; } else t.x = nx;
      t.moving = true;
      for (const q of t.parts) {
        if (q.flash > 0) q.flash -= dt; if (q.hp <= 0) continue;
        const qx = t.x + q.ox, tg = nearestPlayerTank(g, qx, t.y, true); if (tg) q.ang = Math.atan2(tg.y - t.y, tg.x - qx);
        q.cd -= dt; if (q.cd <= 0 && tg) { q.cd = 2.4 + g.rand() * 0.6; addBullet(g, { x: qx + Math.cos(q.ang) * 0.9, y: t.y + Math.sin(q.ang) * 0.9, vx: Math.cos(q.ang) * e.bullet, vy: Math.sin(q.ang) * e.bullet, side: 'e', owner: null, r: 0.3, kind: 'boss' }); g.ev.push({ k: 'efire' }); }
      }
      if (!armored) {
        t.atkCd -= dt; t.summonCd -= dt;
        if (t.atkCd <= 0) { for (const a of [-0.6, -0.3, 0, 0.3, 0.6]) fireAt(g, t, Math.PI / 2 + a, e.bullet); t.atkCd = 2; g.ev.push({ k: 'efire' }); }
        if (t.summonCd <= 0) { t.summonCd = 10; summon(g, t, d, 2, 3); }
      }
      return true;
    }
    return false;
  }
  /* 隊長：まわりの敵を強くする（回復・盾・速く・呼ぶ）。速くは enemyThink で効かせる */
  function stepCaptains(g, dt, d) {
    g.hasteCaps = [];
    for (const c of g.tanks) {
      if (!c.alive || !c.captain) continue;
      if (c.aura === 'haste') { g.hasteCaps.push(c); continue; }
      c.auraT -= dt; if (c.auraT > 0) continue;
      const near = g.tanks.filter(o => o.alive && o.side === 'e' && !o.boss && Math.hypot(o.x - c.x, o.y - c.y) < AURA_R);
      if (c.aura === 'heal') { c.auraT = 3; for (const o of near) if (o.hp < o.maxHp) { o.hp++; g.texts.push({ x: o.x, y: o.y - 1.2, s: '+1', zh: '+1', t: 0.7, col: '#7fe08f' }); } }
      else if (c.aura === 'shield') { c.auraT = 6; for (const o of near) o.guard = 1; }
      else if (c.aura === 'call') {
        c.auraT = 9; const mine = g.tanks.filter(o => o.alive && o.callBy === c).length;
        if (mine < 2) { const sp = findFree(g, Math.round(c.x), Math.round(c.y), 6); if (sp) { spawnEnemy(g, 'normal', sp.x, sp.y, d, { callBy: c }); g.texts.push({ x: c.x, y: c.y - 1.4, s: 'こっちだ！', zh: '这边！', t: 0.9, col: '#c9a8ff' }); } }
      }
    }
  }
  /* ---------- 台詞（ボスが出た時・倒れた時）。自動では進まず、飛ばせない。全員がスマホの「読んだ」を押すと次へ（JUN の指示） ---------- */
  function startTalk(g, kinds, which) {
    const lines = []; for (const k of kinds) { const tk = Stages.BOSS_TALK[k]; if (tk) for (const l of tk[which]) lines.push(Object.assign({ kind: k }, l)); }
    if (!lines.length) return; g.talk = { lines, i: 0, t: 0, read: {}, which }; g.ev.push({ k: 'talk' });
  }
  function talkReady(g) { const tk = g.talk; if (!tk) return false; const l = tk.lines[tk.i]; return tk.t >= TALK_MIN_SEC + [...l.ja].length * TALK_CHAR_SEC; }
  function nextLine(g) { const tk = g.talk; tk.i++; tk.t = 0; tk.read = {}; if (tk.i >= tk.lines.length) { g.talk = null; g.ev.push({ k: 'talkend' }); } else g.ev.push({ k: 'talk' }); }
  function stepTalk(g, dt) {
    g.talk.t += dt; if (!talkReady(g)) return;
    const ids = Object.keys(g.pl); if (!ids.length || ids.every(id => g.talk.read[id])) nextLine(g);
  }
  // スマホの「読んだ」。i＝今の台詞の番号（古い押しを数えない）
  function readTalk(g, pid, i) {
    if (!g.talk || g.talk.i !== i || !g.pl[pid] || !talkReady(g)) return false;
    g.talk.read[pid] = 1; g.ev.push({ k: 'read', pid }); return true;
  }
  function stepBeams(g, dt) {
    for (const bm of g.beams) {
      bm.t -= dt; if (bm.owner && bm.owner.alive) { bm.x = bm.owner.x; bm.y = bm.owner.y; bm.dir = bm.owner.dir; }
      const len = Math.max(g.cols, g.rows); let end = len;
      for (let i = 2; i < len; i++) {
        const px = bm.x + DX[bm.dir] * i, py = bm.y + DY[bm.dir] * i; let stop = false;
        for (const o of [-0.5, 0.49]) {
          const tx = Math.floor(px + (bm.dir & 1 ? 0 : o)), ty = Math.floor(py + (bm.dir & 1 ? o : 0)), c = tileAt(g, tx, ty);
          if (c === 'S' || c === '#') stop = true; else if (c === 'B' || c === 'b') breakTile(g, tx, ty, false, true, true); else if (c === 'H' && !bm.hitHouse) { bm.hitHouse = true; hitHouse(g); }
        }
        if (stop) { end = i; break; }
      }
      bm.len = end;
      for (const t of g.tanks) {
        if (t.side !== 'p' || !t.alive) continue;
        const along = (t.x - bm.x) * DX[bm.dir] + (t.y - bm.y) * DY[bm.dir], across = Math.abs((t.x - bm.x) * DY[bm.dir] - (t.y - bm.y) * DX[bm.dir]);
        if (along > 0 && along < end + 1 && across < 1.8) { bm.hit = bm.hit || []; if (!bm.hit.includes(t)) { bm.hit.push(t); killPlayer(g, t, 'laser'); } }
      }
    }
    g.beams = g.beams.filter(b => b.t > 0);
  }
  function stepMissiles(g, dt) {
    for (const m of g.missiles) {
      if (m.dead) continue; m.t -= dt; if (m.t <= 0) { m.dead = true; continue; }
      if (g.stopT > 0) continue;
      const tg = nearestPlayerTank(g, m.x, m.y);
      if (tg) { const want = Math.atan2(tg.y - m.y, tg.x - m.x); let da = want - m.ang; while (da > Math.PI) da -= 2 * Math.PI; while (da < -Math.PI) da += 2 * Math.PI; m.ang += clamp(da, -MISSILE_TURN * dt, MISSILE_TURN * dt); }
      m.x += Math.cos(m.ang) * MISSILE_SPEED * dt; m.y += Math.sin(m.ang) * MISSILE_SPEED * dt;
      if (tg && Math.hypot(tg.x - m.x, tg.y - m.y) < 1.1) { m.dead = true; g.fx.push({ k: 'boom', x: m.x, y: m.y, r: 1, t: 0.4, T: 0.4 }); killPlayer(g, tg, 'missile'); g.ev.push({ k: 'boom' }); }
      if (m.x < -1 || m.y < -1 || m.x > g.cols + 1 || m.y > g.rows + 1) m.dead = true;
    }
    g.missiles = g.missiles.filter(m => !m.dead);
  }
  /* 陣地の自衛（おうちが近くの敵を撃つ）。届く距離 6＋2×段 升、間隔 1.7−0.26×段 秒（TK と同じ）。3 段から鋼を抜け、5 段で 3 倍 */
  function stepTower(g, dt) {
    if (g.tower <= 0 || g.houseDead) return;
    g.towerCd -= dt; if (g.towerCd > 0) return;
    const L = g.tower, range = 6 + L * 2, hy = g.hy - 0.5; let best = null, bd = range;
    for (const e of g.tanks) if (e.side === 'e' && e.alive) { const dd = Math.abs(e.x - g.hx) + Math.abs(e.y - hy); if (dd < bd) { bd = dd; best = e; } }
    if (!best) { g.towerCd = 0; return; }
    const a = Math.atan2(best.y - hy, best.x - g.hx), sp = (5 + L * 0.5) * K;
    addBullet(g, { x: g.hx, y: hy, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, side: 'h', owner: null, through: true, r: 0.25, dmg: L >= 5 ? 3 : 1 });
    g.towerCd = 1.7 - L * 0.26; g.ev.push({ k: 'fire', big: L >= 3 });
  }
  /* 溶岩の面：水のそばで止まっていると熱い（TK と同じ：3 秒で知らせ、5 秒でたて→よろい→やられる） */
  function stepLava(g, p, t, dt) {
    if (!fxOf(g).lava) return;
    const near = boxHasTile(g, t.x, t.y, t.half + 0.6, 'W');
    if (!near || t.moving) { p.lavaT = 0; return; }
    const before = p.lavaT; p.lavaT += dt;
    if (before < CFG.lavaWarnSec && p.lavaT >= CFG.lavaWarnSec) { g.texts.push({ x: t.x, y: t.y - 1.4, s: 'あつい！ 動いて！', zh: '好烫！快移动！', t: 1.2, col: '#ff9a5c' }); g.ev.push({ k: 'lavawarn', pid: p.id }); }
    if (p.lavaT >= CFG.lavaBurnSec) {
      p.lavaT = 0; g.fx.push({ k: 'boom', x: t.x, y: t.y, r: 1, t: 0.4, T: 0.4 });
      if (t.shield > 0) t.shield = 0; else killPlayer(g, t, 'lava');
    }
  }
  function enemiesOnField(g) { return g.tanks.filter(t => t.side === 'e' && t.alive).length; }
  function enemiesRemaining(g) { return g.queue.length + g.pending.length + enemiesOnField(g) + (g.stage && g.stage.boss && !g.bossSpawned ? 1 : 0) + (g.bossQ ? g.bossQ.length : 0); }
  function bossOf(g) { return g.tanks.find(t => t.boss && t.alive) || null; }
  function bossesOf(g) { return g.tanks.filter(t => t.boss && t.alive); }
  function endGame(g, win, why) { if (g.ph !== 'play') return; g.ph = 'over'; g.win = win; g.why = why; g.ev.push({ k: win ? 'win' : 'lose', why }); }
  /* 面のクリア。勲章と点を決め、1 台もどす */
  function finishStage(g) {
    g.ph = 'clear'; g.phT = CFG.clearSec; g.clearTime = g.t; g.awards = makeAwards(g);
    // 星 3 つ（ぼうけん）：クリア・おうち無傷（1 回も当たらない）・時間内
    g.stars = g.mode === 'adv' ? [1, g.houseHits ? 0 : 1, g.t <= g.par ? 1 : 0] : null;
    for (const a of g.awards) if (a.bonus) for (const id in g.pl) g.pl[id].score += a.bonus;
    for (const id in g.pl) { const p = g.pl[id]; if (p.lives < CFG.lives) p.lives++; }
    const list = stageList(g);
    g.ev.push({ k: 'clear', idx: g.stageIdx, mode: g.mode, loop: g.loop, last: g.stageIdx >= list.length - 1, time: g.t, stars: g.stars });
  }
  /* 賞。命中 7 割（みんなの合計）と 4 れんぞくは TK の勲章（点つき）。げきつい王・まもり神は自作 */
  function makeAwards(g) {
    const ps = Object.values(g.pl), a = [];
    const top = (f, min) => { let best = null; for (const p of ps) if (f(p) >= min && (!best || f(p) > f(best))) best = p; return best; };
    const shots = ps.reduce((s, p) => s + p.shots, 0), landed = ps.reduce((s, p) => s + p.landed, 0);
    if (shots >= 8 && landed / shots >= CFG.medalAcc) a.push({ key: 'meijin', v: Math.min(100, Math.round(landed / shots * 100)), bonus: CFG.medalAccBonus });
    const c = top(p => p.bestCombo, CFG.medalCombo); if (c) a.push({ key: 'renzoku', pid: c.id, v: c.bestCombo, bonus: CFG.medalComboBonus });
    const k = top(p => p.kills, 1); if (k) a.push({ key: 'gekitsui', pid: k.id, v: k.kills });
    const m = top(p => p.houseKills, 1); if (m) a.push({ key: 'mamori', pid: m.id, v: m.houseKills });
    return a;
  }
  /* 面のクリアの後：次の面・周回・全部クリア */
  function afterClear(g) {
    const list = stageList(g);
    // ぼうけん：1 面ごとに結果の画面へ（次の面・ワールドマップは画面が選ぶ）
    if (g.mode === 'adv') { g.ph = 'over'; g.win = 1; g.why = g.stageIdx >= list.length - 1 ? 'complete' : 'stage'; g.ev.push({ k: 'advdone', idx: g.stageIdx, last: g.why === 'complete' }); return; }
    if (g.stageIdx < list.length - 1) { loadStage(g, g.stageIdx + 1); return; }
    if (g.mode === 'camp' && g.loop < CFG.maxLoop - 1) {
      const r = LOOP_REWARD[Math.min(4, g.loop + 1)];
      g.ph = 'loop'; g.phT = CFG.loopSec; g.loopReward = Object.assign({ loop: g.loop + 2 }, r);
      g.ev.push({ k: 'loop', loop: g.loop + 1 }); return;
    }
    g.ph = 'over'; g.win = 1; g.why = 'complete'; g.ev.push({ k: 'win', why: 'complete', mode: g.mode });
  }
  function nextLoop(g) {
    const r = g.loopReward || {}; g.loop++;
    for (const id in g.pl) { const p = g.pl[id]; p.power = Math.min(CFG.maxPower, p.power + (r.power || 0)); p.lives = Math.min(MAX_LIVES, p.lives + (r.life || 0)); }
    loadStage(g, 0);
  }

  /* ---------- 1 刻み ---------- */
  function step(g, dt, now) {
    if (g.paused) return;
    if (g.ph === 'intro') { g.phT -= dt; if (g.banner) g.banner.t -= dt; if (g.phT <= 0) { g.ph = 'play'; g.banner = null; g.ev.push({ k: 'go' }); } return; }
    if (g.ph === 'clear') { g.phT -= dt; if (g.phT <= 0) afterClear(g); return; }
    if (g.ph === 'loop') { g.phT -= dt; if (g.phT <= 0) nextLoop(g); return; }
    if (g.ph !== 'play') return;
    if (g.talk) { stepTalk(g, dt); return; }   // 台詞の間は戦いを止める
    if (g.reveal) { g.reveal.t -= dt; if (g.reveal.t <= 0) g.reveal = null; }
    if (g.banner) { g.banner.t -= dt; if (g.banner.t <= 0) g.banner = null; }
    if (g.pauseT > 0) { g.pauseT -= dt; return; }   // アイテムを取った時の一拍
    g.t += dt; const d = diff(g), n = playerCount(g), fx = fxOf(g);
    if (g.shake > 0) g.shake = Math.max(0, g.shake - dt);
    if (g.alertT > 0) g.alertT -= dt;
    if (g.stopT > 0) g.stopT -= dt;
    if (g.wallT > 0) { g.wallT -= dt; if (g.wallT <= 0) setRing(g, g.wallTile); }
    g.distT -= dt; if (g.distDirty && g.distT <= 0) { buildDist(g); g.distT = 0.5; }
    // 味方
    for (const id in g.pl) {
      const p = g.pl[id];
      if (now - p.in.at > INPUT_STALE_MS) p.in.d = -1;
      if (!p.tank && p.lives > 0) {
        p.respawn -= dt; const sp = g.spawns[p.slot];
        if (p.respawn <= 0 && placeFree(g, sp.x, sp.y, HALF)) { p.tank = newTank('p', sp.x, sp.y, 0, { pid: id, slot: p.slot, shield: d.shield }); g.tanks.push(p.tank); }
      }
      const t = p.tank; if (!t) continue;
      if (t.shield > 0) t.shield -= dt; if (t.flash > 0) t.flash -= dt;
      if (t.stun > 0) { t.stun -= dt; t.moving = false; continue; }
      t.cd -= dt;
      const onIce = onTile(g, t, 'I');
      let dir = p.in.d;
      if (dir >= 0) t.slide = onIce ? (fx.ice ? 0.7 : 0.4) : 0; else if (t.slide > 0) { t.slide -= dt; dir = t.dir; }
      moveTank(g, t, dir, CFG.playerSpeed * (fx.playerSpeed || 1) * groundSpeed(g, t), dt);
      if (p.fireQ > 0) { if (fire(g, t, p)) p.fireQ = 0; else p.fireQ -= dt; }
      for (const it of g.items) if (!it.dead && Math.hypot(it.x - t.x, it.y - t.y) < 1.4) { it.dead = true; pickItem(g, p, it); }
      for (const m of g.mines) if (!m.dead && m.arm <= 0 && Math.hypot(m.x - t.x, m.y - t.y) < 1.1) { m.dead = true; explode(g, m.x, m.y, 1.4, 'e'); }
      if (t.alive) stepLava(g, p, t, dt);
    }
    g.items = g.items.filter(it => !it.dead && (it.t -= dt) > 0);
    // 敵を出す
    if (g.stage.boss && !g.bossSpawned && g.t > 3) {
      if (!g.bossWarned) { g.bossWarned = true; g.banner = { s: g.mode === 'hell' ? '超ボスがくる！' : 'ボスがくる！', zh: g.mode === 'hell' ? '超级首领来了！' : '首领来了！', t: 2 }; g.ev.push({ k: 'bosswarn' }); }
      if (g.t > 5 && placeFree(g, g.bossX, 2, BOSS_HALF)) { g.bossSpawned = true; spawnEnemy(g, g.stage.boss, g.bossX, 2, d); }
    }
    // ぼうけんのボス（1〜2 体）。出たら台詞
    if (g.bossQ && g.bossQ.length && g.t > 3) {
      if (!g.bossWarned) { g.bossWarned = true; g.banner = { s: 'ボスがくる！', zh: '首领来了！', t: 2 }; g.ev.push({ k: 'bosswarn' }); }
      if (g.t > 5) {
        const came = [];
        for (let i = 0; i < g.bossQ.length; i++) {
          const kind = g.bossQ[i], bx = g.bossXs[Math.min(g.stage.bosses.indexOf(kind), g.bossXs.length - 1)] || g.bossX, by = kind === 'sandship' ? 3 : 2;
          if (!placeFree(g, bx, by, BOSS_HALF)) continue;
          spawnEnemy(g, kind, bx, by, d); came.push(kind); g.bossQ.splice(i, 1); i--;
        }
        if (came.length) { g.bossSpawned = true; startTalk(g, came, 'enter'); if (g.talk) return; }
      }
    }
    if (g.talkWait && g.talkWait.length) { for (const w of g.talkWait) w.t -= dt; const w = g.talkWait.find(x => x.t <= 0); if (w) { g.talkWait.splice(g.talkWait.indexOf(w), 1); startTalk(g, w.kinds, w.which); if (g.talk) return; } }
    if (g.mode === 'adv') stepCaptains(g, dt, d);
    g.spawnT -= dt;
    if (g.spawnT <= 0 && g.queue.length && enemiesOnField(g) + g.pending.length < d.onField) {
      const gt = g.gates[g.gateI++ % g.gates.length]; g.pending.push({ x: gt.x, y: gt.y, t: CFG.spawnWarnSec, kind: g.queue.shift() });
      g.spawnT = d.spawnGap;
    }
    for (const s of g.pending) {
      s.t -= dt;
      // 出口に戦車がいて出られない時：3 秒待ったら、空いている別の出口（無ければ出口の近く）から出す
      if (s.t <= -3 && !placeFree(g, s.x, s.y, HALF)) {
        const alt = g.gates.find(gt => placeFree(g, gt.x, gt.y, HALF)) || findFree(g, s.x, s.y + 2, 5);
        if (alt) { s.x = alt.x; s.y = alt.y; s.t = Math.min(s.t, 0); }
      }
      if (s.t <= 0 && placeFree(g, s.x, s.y, HALF)) {
        g.spawned++; const t = spawnEnemy(g, s.kind, s.x, s.y, d, { glow: g.spawned % d.itemEvery === 0 }); t.cd = 0.8; s.done = true;
        if (ENEMY[s.kind].elite) g.ev.push({ k: 'bosswarn' });
      }
    }
    g.pending = g.pending.filter(s => !s.done);
    for (const t of g.tanks) { if (!t.alive || t.side !== 'e') continue; if (t.flash > 0) t.flash -= dt; if (t.freeze > 0) t.freeze -= dt; enemyThink(g, t, dt, d); }
    stepTower(g, dt);
    for (const b of g.bullets) if (!b.dead) stepBullet(g, b, dt);
    for (const b of g.bullets) if (b.dead && !b.counted) { b.counted = true; if (b.owner) b.owner.out = Math.max(0, b.owner.out - 1); }
    g.bullets = g.bullets.filter(b => !b.dead);
    for (const s of g.shells) { if (g.stopT > 0) continue; s.t -= dt; if (s.t <= 0) { s.dead = true; explode(g, s.x, s.y, s.r, 'e'); } }
    g.shells = g.shells.filter(s => !s.dead);
    for (const m of g.mines) { if (m.arm > 0) m.arm -= dt; m.t -= dt; if (m.t <= 0) m.dead = true; }
    g.mines = g.mines.filter(m => !m.dead);
    stepMissiles(g, dt); stepBeams(g, dt);
    g.tanks = g.tanks.filter(t => t.alive);
    for (const f of g.fx) f.t -= dt; g.fx = g.fx.filter(f => f.t > 0);
    for (const x of g.texts) { x.t -= dt; x.y -= dt * 0.8; } g.texts = g.texts.filter(x => x.t > 0);
    if (g.ph !== 'play') return;
    if (n && Object.values(g.pl).every(p => p.lives <= 0 && !p.tank)) { endGame(g, 0, 'out'); return; }
    if (enemiesRemaining(g) === 0 && !g.talk && !(g.talkWait && g.talkWait.length)) finishStage(g);
  }

  /* 確かめ・画面の上の表示に使う、状態のまとめ */
  function summary(g) {
    const b = bossOf(g);
    return { ph: g.ph, mode: g.mode, stage: g.stageIdx, loop: g.loop, fx: g.stage ? g.stage.fx : '', cols: g.cols, players: playerCount(g), left: g.ph === 'play' ? enemiesRemaining(g) : 0,
      enemyTotal: g.enemyTotal, onField: enemiesOnField(g), futon: g.futon, tower: g.tower, slow: g.slow, paused: g.paused,
      boss: b ? { hp: b.hp, max: b.maxHp, kind: b.kind } : null, win: g.win, why: g.why, t: Math.round(g.t * 10) / 10,
      talk: g.talk ? { i: g.talk.i, n: g.talk.lines.length, ready: talkReady(g) } : null, stars: g.stars, par: g.par, houseHits: g.houseHits, bosses: bossesOf(g).map(t => t.kind),
      pl: Object.values(g.pl).map(p => ({ slot: p.slot, lives: p.lives, power: p.power, twin: p.twin, armor: p.armor, score: p.score, kills: p.kills, stuns: p.stuns, alive: !!p.tank })) };
  }

  const api = { CFG, SCALE, HELL, FX, ENEMY, ITEMS, ITEM_WEIGHTS, ITEM_NAME, LOOP_REWARD, K, DX, DY, newGame, addPlayer, removePlayer, playerCount, startRun, retryStage, loadStage, step, diff,
    enemiesRemaining, enemiesOnField, bossOf, summary, stageList, spawnEnemy, spawnItem, chooseItem, pickItem, killPlayer, newTank, makeAwards, buildDist, distAt, tileAt,
    carryOf, setPause, fieldRadius, MAX_LIVES, buildQueue, playerBulletSpeed, playerMaxOut, playerDamage, afterClear, nextLoop,
    bossesOf, readTalk, talkReady, startTalk, ADV_BOSS, AURA_R, TALK_CHAR_SEC, TALK_MIN_SEC, mapOk };
  root.TankSim = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);

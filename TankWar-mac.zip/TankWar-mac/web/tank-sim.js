/* 戦車のゲーム「おうちを守れ！戦車隊」の計算（v0.12：装備の強さ・必殺技・宝箱を足した。v0.11：ぼうけん 48 面・ボス 6 体・隊長・星・台詞）。テレビの画面（tank.html）と、確かめ用の node の両方から読む。
   - 升（タイル）を 1 とした座標。戦車は 2 × 2 升、大ボスは 4 × 4 升。面は tank-stages.js
   - 乱数は種を決めた関数（g.rand）だけを使う。同じ種・同じ操作なら同じ結果になる
   - step(g, dt) は決まった刻み（CFG.fixedDt）で呼ぶ。描画は別（tank.html）
   - 音・震えなどの知らせは g.ev に積む。画面がそれを読んで鳴らす
   仕組み（アイテム 7 つ・火力 5 段と 2 連射・陣地の自衛・陣地の護甲・磁場・面の仕掛け・周回・勲章）と数値は、
   TK（sunsharebay-lgtm/TK の 坦克大战）に合わせた。コードは自作（D-015・D-017） */
(function (root) {
  'use strict';
  const Stages = root.TankStages || (typeof require !== 'undefined' ? require('./tank-stages.js') : null);

  /* TK の「1 フレームに何ピクセル（16px＝1 升、60 フレーム/秒）」を、このゲームの「升/秒」に直す係数（味方の速さ 1.5 → 4.6 升/秒） */
  const K = 4.6 / 1.5;
  /* ============ ここを変えると難しさを変えられます ============ */
  const CFG = {
    fixedDt: 1 / 60,          // 計算の刻み（秒）
    maxPlayers: 4,            // 同時に遊べる人数
    lives: 3,                 // 1 人の戦車の台数
    respawnSec: 2,            // やられてから出直すまで（秒）
    shieldSec: 2.5,           // 出た直後に弾が効かない時間（秒）
    friendlyStunSec: 2,       // 味方の弾が当たった時に動けない時間（秒）
    playerSpeed: 1.5 * K,     // 味方の速さ（升/秒）
    fireCooldown: 0.10,       // 味方が次に撃てるまで（秒。弾の数の上限でも止まる）
    maxPower: 5, maxTwin: 3, maxArmor: 5, maxFuton: 5, maxTower: 5, maxSlow: 5, maxLoop: 5,
    spawnWarnSec: 1,          // 敵が出る前に印を出す時間（秒）
    introSec: 2.6,            // 面の始めに名前を出す時間（秒）
    clearSec: 5,              // 面をクリアした後に、賞を見せる時間（秒）
    loopSec: 6,               // 周回の褒美を見せる時間（秒）
    comboSec: 3,              // この時間内に続けて倒すと「れんぞく」
    itemLifeSec: 15,          // アイテムが消えるまで（秒）
    itemPauseSec: 0.35,       // アイテムを取った時に一拍止める時間（秒）
    shieldItemSec: 10,        // 「たて」で無敵になる時間（秒）
    stopItemSec: 9,           // 「ストップ」で敵が止まる時間（秒）
    wallItemSec: 20,          // 「かべなおし」でおうちの周りが鋼になる時間（秒）
    startFuton: 1,            // ふつうの面の始めに、おうちにかかっている おふとん の枚数（家族向けに足した。地獄は 0）
    alertSec: 2.5,            // おうちがあぶない知らせを出す時間（秒）
    lavaWarnSec: 3, lavaBurnSec: 5,   // 溶岩の面：水のそばで止まっていると、3 秒で知らせ、5 秒で熱い
    medalAcc: 0.7, medalAccBonus: 300, medalCombo: 4, medalComboBonus: 500,   // 勲章（命中 7 割・4 れんぞく）と点
    itemScore: 500, comboScore: 50,
    feel: { freeze: true, shake: true, flash: true }   // 手応え（止める・揺らす・白くする）の ON/OFF
  };
  /* 参加人数で変わる値（家族で遊んで直す）。cols：盤面の横の升。1〜2 人も 39（横長）にして、テレビの横いっぱいに広げる（v0.10.1。前は 26 の正方形で、左右が空いていた） */
  const SCALE = {
    1: { cols: 39, gates: 3, enemies: 16, onField: 4, speed: 1.00, fire: 1.00, house: 0.30, bossHp: 1.0, itemEvery: 4 },
    2: { cols: 39, gates: 3, enemies: 20, onField: 5, speed: 1.00, fire: 1.00, house: 0.35, bossHp: 1.5, itemEvery: 4 },
    3: { cols: 39, gates: 4, enemies: 28, onField: 7, speed: 1.05, fire: 0.92, house: 0.40, bossHp: 2.0, itemEvery: 3 },
    4: { cols: 52, gates: 5, enemies: 36, onField: 9, speed: 1.10, fire: 0.85, house: 0.45, bossHp: 2.5, itemEvery: 3 }
  };
  /* 地獄の難しさ（ふつうの値に掛ける） */
  const HELL = { enemies: 1.5, speed: 1.3, fire: 0.6, itemEvery: 2, shield: 0.5, onField: 1, hp: 1 };
  /* 面の仕掛け。enemySpeed・fire（撃つ回数）・playerSpeed・spawnGap は掛け算、hp は敵の体力に足す */
  const FX = {
    none: {}, steel: { baseSteel: true }, valley: { enemySpeed: 1.15 }, jungle: { jungle: true }, ice: { ice: true },
    frenzy: { fire: 1.25 }, siege: { siege: true, fire: 1.08 }, rush: { enemySpeed: 1.10, spawnGap: 0.75 },
    snow: { ice: true, playerSpeed: 0.90 }, blood: { hp: 1 }, sand: { playerSpeed: 0.82 }, lava: { lava: true },
    desert: { playerSpeed: 0.92, storm: true },   // 砂漠（ぼうけん）：少し遅い。砂嵐は見た目だけ（tank.html）
    snowland: { ice: true }, volcano: { lava: true },   // 雪山・火山（ぼうけん v0.13）：氷がよくすべる・溶岩のそばで止まると熱い
    fortress: { warp: true }, inferno: { lava: true }   // 機械要塞（v0.14）：ワープ（動く壁・スイッチは地図の文字で出る）・地獄：溶岩
  };
  /* 敵の種類。normal・fast・heavy・armor・chief は TK の 5 種の数値（速さ・弾の速さ・体力・点）。ほかは自作。
     speed・bullet＝升/秒、cd＝撃つ間隔（秒、幅）、from＝自作の敵が出てくる面（1 から） */
  const ENEMY = {
    normal: { hp: 1, speed: 1.00 * K, bullet: 4.0 * K, cd: [1.0, 2.2], score: 100 },
    fast: { hp: 1, speed: 2.00 * K, bullet: 4.0 * K, cd: [1.0, 2.2], score: 200 },
    heavy: { hp: 1, speed: 1.50 * K, bullet: 6.5 * K, cd: [0.8, 1.8], score: 300 },
    armor: { hp: 4, speed: 1.00 * K, bullet: 4.0 * K, cd: [1.0, 2.0], score: 400 },
    chief: { hp: 10, speed: 0.82 * K, bullet: 6.5 * K, cd: [0.7, 1.4], score: 1500, elite: true },
    bouncer: { hp: 1, speed: 3.2, bullet: 9, cd: [1.2, 2.4], from: 3, special: true, score: 300 },
    miner: { hp: 1, speed: 4.0, bullet: 9, cd: [1.6, 3.0], from: 3, special: true, score: 300 },
    mortar: { hp: 2, speed: 2.6, bullet: 0, cd: [3.0, 4.5], from: 4, special: true, score: 300 },
    sniper: { hp: 1, speed: 3.0, bullet: 24, cd: [3.0, 4.0], from: 4, special: true, score: 300 },
    rammer: { hp: 1, speed: 3.6, bullet: 9, cd: [2.0, 3.5], from: 5, special: true, score: 300 },
    boss: { hp: 24, speed: 2.0, bullet: 9, cd: [2.0, 2.0], boss: true, house: 0.4, score: 3000 },
    superboss: { hp: 72, speed: 2.4, bullet: 10, cd: [1.6, 1.6], boss: true, house: 0.6, score: 10000 },
    // ぼうけん（v0.11）。captain＝隊長（王冠。まわりの敵を強くする）。下の 6 体は世界 1・2 のボス（動きは advBoss）
    captain: { hp: 3, speed: 1.1 * K, bullet: 5.0 * K, cd: [0.9, 1.8], score: 800, captain: true },
    twin: { hp: 22, speed: 2.2, bullet: 9, cd: [1.5, 1.5], boss: true, house: 0.3, score: 3000 },
    engineer: { hp: 24, speed: 2.0, bullet: 8.5, cd: [2.4, 2.4], boss: true, house: 0.35, score: 3000 },
    bigtank: { hp: 32, speed: 2.0, bullet: 9, cd: [2.0, 2.0], boss: true, house: 0.4, score: 5000 },
    burrower: { hp: 18, speed: 2.2, bullet: 9.5, cd: [1.1, 1.1], boss: true, house: 0.3, score: 3500 },
    scorpion: { hp: 26, speed: 2.3, bullet: 9.5, cd: [2.1, 2.1], boss: true, house: 0.3, score: 3500 },
    sandship: { hp: 30, speed: 1.6, bullet: 9, cd: [2.0, 2.0], boss: true, house: 0, score: 6000, partHp: 8 },
    // 世界 3 雪山・世界 4 火山（v0.13）。snowkid＝雪だるま戦車が倒れた時に分かれる 2 体（小さい）
    plow: { hp: 24, speed: 2.2, bullet: 8.5, cd: [2.0, 2.0], boss: true, house: 0.3, score: 3500 },
    icegun: { hp: 26, speed: 1.4, bullet: 8.5, cd: [2.0, 2.0], boss: true, house: 0.25, score: 3500 },
    snowman: { hp: 30, speed: 1.8, bullet: 8.5, cd: [2.0, 2.0], boss: true, house: 0.3, score: 5000 },
    snowkid: { hp: 9, speed: 3.0, bullet: 8.5, cd: [1.6, 1.6], boss: true, house: 0.4, score: 1500, half: 1.3 },
    flamer: { hp: 26, speed: 2.4, bullet: 8, cd: [2.0, 2.0], boss: true, house: 0.3, score: 4000 },
    golem: { hp: 32, speed: 1.5, bullet: 7.5, cd: [2.0, 2.0], boss: true, house: 0.35, score: 4000 },
    dragon: { hp: 40, speed: 2.0, bullet: 9, cd: [2.0, 2.0], boss: true, house: 0.3, score: 7000 },
    // 世界 5 機械要塞・地獄（v0.14）。sisA・sisB＝双子戦車（姉・妹）。shade＝闇の戦車の分身（ボスではない。見た目は同じ）
    sisA: { hp: 18, speed: 2.0, bullet: 9, cd: [2.0, 2.0], boss: true, house: 0.3, score: 3500 },
    sisB: { hp: 16, speed: 2.8, bullet: 9, cd: [2.0, 2.0], boss: true, house: 0.25, score: 3500 },
    airship: { hp: 30, speed: 3.0, bullet: 8.5, cd: [2.0, 2.0], boss: true, house: 0.3, score: 5000 },
    core: { hp: 44, speed: 0, bullet: 6.5, cd: [2.0, 2.0], boss: true, house: 0, score: 8000 },
    shadow: { hp: 34, speed: 2.4, bullet: 9, cd: [2.0, 2.0], boss: true, house: 0.3, score: 6000 },
    shade: { hp: 3, speed: 2.4, bullet: 8.5, cd: [1.4, 2.4], score: 200, clone: true },
    superstar: { hp: 46, speed: 2.4, bullet: 10, cd: [2.0, 2.0], boss: true, house: 0.35, score: 10000 },
    king: { hp: 56, speed: 2.2, bullet: 9.5, cd: [2.0, 2.0], boss: true, house: 0.3, score: 20000 }
  };
  const ADV_BOSS = { twin: 1, engineer: 1, bigtank: 1, burrower: 1, scorpion: 1, sandship: 1, plow: 1, icegun: 1, snowman: 1, snowkid: 1, flamer: 1, golem: 1, dragon: 1, sisA: 1, sisB: 1, airship: 1, core: 1, shadow: 1, superstar: 1, king: 1 };
  /* v0.14 の仕掛けの値 */
  const VIEW_H = 26;               // 大きな地図（縦 39・52 升）で、テレビに映す縦の升（カメラ）
  const TRUCK_SPEED = 1.0, ESCORT_R = 7.5, TRUCK_HP = 10;   // 護送：トラックの速さ（升/秒）・味方がこの距離にいる時だけ進む・体力（人数で増える）
  const SCROLL_MIN = 0.2, SCROLL_FAST = 0.45, SCROLL_FIGHT = 0.08;   // 突破：画面が前へ進む速さ（升/秒）。ふつう・先頭が画面の上の方にいる時・画面に敵が 4 台以上いる時
  const GOAL_Y = 4.5;              // 突破：ここまで上がればゴール
  const SHUT_SEC = 7, SWITCH_HOLD = 10, WARP_CD = 1.2;   // 動く壁が入れかわる間隔・スイッチを撃った後の長さ（秒）・ワープの後に次に使えるまで
  /* v0.13 の仕掛けの値 */
  const FLAG_R = 1.9, FLAG_SEC = 6, FLAG_LOSE_SEC = 5;   // 占領：旗の近さ（升）・取るまで（秒、2 人目からは早く）・敵に取り返されるまで（秒）
  const FREEZE_SEC = 1.6;          // 氷の弾：当たると動けない時間（秒。やられはしない）
  const POOL_R = 1.15, POOL_LIFE = 9, POOL_ARM = 0.8, POOL_BURN = 0.45, POOL_MAX = 24;   // 溶岩だまり：大きさ・消えるまで・熱くなるまで・中にいてやられるまで（秒）
  const RAM_FAST = 9, RAM_WARN = 0.9;   // 除雪車・雪だるまの体当たり：速さ（升/秒）・予告の時間
  const CAPTAIN_KINDS = ['heal', 'shield', 'haste', 'call'];   // 隊長の力：回復・盾・速く・呼ぶ
  const AURA_R = 5.5;              // 隊長の力が届く距離（升）
  const TALK_CHAR_SEC = 0.06, TALK_MIN_SEC = 0.6;   // 台詞：1 文字が出る時間・出そろうまでの最短。出そろうまでは「読んだ」を受け付けない
  const MIX_KINDS = ['normal', 'fast', 'heavy', 'armor'];
  const SPECIALS = ['bouncer', 'miner', 'mortar', 'sniper', 'rammer'];
  const SPECIAL_SHARE = 0.25;   // 自作の敵が出る面での、自作の敵の割合
  /* アイテム 7 つ（TK の出やすさの重み）。パワー・よろいが最高まで育つと、2 連射・電波に変わる */
  const ITEM_WEIGHTS = [['shield', 1], ['stop', 1], ['wall', 1], ['power', 1.64], ['bomb', 1], ['extra', 1], ['armor', 1.35]];
  const ITEMS = ['shield', 'stop', 'wall', 'power', 'bomb', 'extra', 'armor', 'twin', 'field'];
  const ITEM_NAME = { shield: ['たて', '护盾'], stop: ['ストップ', '冻结'], wall: ['かべなおし', '修墙'], power: ['パワー', '火力'], bomb: ['ドカン', '炸弹'],
    extra: ['ぞうえん', '增援'], armor: ['よろい', '护甲'], twin: ['2 れんしゃ', '双炮'], field: ['のろのろ電波', '减速电波'] };
  /* 周回の褒美（TK の周回の褒美と同じ中身。名前は自作）。power＝火力 +、life＝台数 + */
  const LOOP_REWARD = { 1: { ja: '火力アップ', zh: '火力提升', power: 1, life: 0 }, 2: { ja: '予備の戦車', zh: '备用坦克', power: 0, life: 1 },
    3: { ja: '補給', zh: '补给', power: 1, life: 1 }, 4: { ja: '最後の周へ', zh: '最终周目', power: 1, life: 1 } };
  /* ======================================================================== */
  const ROWS = 26, HALF = 0.96, BOSS_HALF = 1.92, MOVE_STEPS = 4, BULLET_STEPS = 4;
  const DX = [0, 1, 0, -1], DY = [-1, 0, 1, 0];   // 向き：0 上・1 右・2 下・3 左
  const SOLID = { B: 1, b: 1, S: 1, W: 1, H: 1, G: 1, K: 1 };   // G＝閉じた動く壁・K＝スイッチ（v0.14。g＝開いた動く壁、P＝ワープは床）   // b＝ひびの入ったレンガ（もう 1 発で壊れる）
  const SPAWN_OFFSETS = [-4, 4, -8, 8];         // 味方の出る所（おうちの中心からの升）
  const GATE_AWAY = 4;                          // 敵の出口を、おうちの中心の列からこれだけ離す（升）
  const MINE_LIFE = 10, MINE_ARM = 0.8, MINE_EVERY = 4, MINE_MAX = 3;
  const MORTAR_RING_RATE = 0.3;   // 迫撃がおうちの囲いをねらう割合（残りは味方をねらう）
  const MORTAR_FLIGHT = 1.4, MORTAR_R = 1.6, RAM_RANGE = 8, RAM_SPEED = 8, RAM_SEC = 3, RAM_R = 1.6;
  const SNIPE_AIM = 1.0, LASER_AIM = 1.2, LASER_SEC = 0.6, MISSILE_SPEED = 6, MISSILE_TURN = 2.6, MISSILE_LIFE = 6;
  const ARMOR_GRACE = 0.6;        // よろいが 1 枚はがれた後、続けて当たらない時間（秒）
  const FIELD_STEP = 3;           // 磁場（のろのろ電波）の届く距離：1 段あたりの升
  const FIELD_DEBUFF = 0.1;       // 磁場の弱め方：1 段あたりの割合
  const INPUT_STALE_MS = 1500;   // スマホの向きがこの時間届かなければ止める（Wi-Fi の一瞬の遅れで止まらないよう、1 秒から延ばした）
  const MAX_LIVES = 9;            // 台数の上限（ぞうえん・周回の褒美でもこれより増えない）

  /* 種を決めた乱数（mulberry32） */
  function makeRand(seed) {
    let a = (seed >>> 0) || 1;
    return function () {
      a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
  // 外から来た値（続きからの引き継ぎ）を整数にして範囲に収める。数でなければ def
  const toInt = (v, a, b, def) => { if (v === null || v === undefined || v === '') return def; const n = Number(v); return Number.isFinite(n) ? clamp(Math.trunc(n), a, b) : def; };

  function newGame(seed) {
    const s = (seed === undefined ? 12345 : seed) >>> 0;
    return { ph: 'lobby', mode: 'camp', stageIdx: 0, stage: null, loop: 0, seed: s, rand: makeRand(s), pl: {}, map: [], cols: 26, rows: ROWS,
      tanks: [], bullets: [], shells: [], beams: [], mines: [], missiles: [], items: [], chests: [], pools: [], flags: [], downs: [], fx: [], texts: [], pending: [], queue: [],
      ev: [], t: 0, phT: 0, pauseT: 0, shake: 0, win: -1, why: '', awards: [], praise: null, banner: null, reveal: null, loopReward: null,
      futon: 0, tower: 0, slow: 0, towerCd: 0, stopT: 0, wallT: 0, alertT: 0, alertN: 0, lastAlertT: -99, houseDead: false,
      enemyTotal: 0, spawnT: 0, gateI: 0, spawned: 0, itemDrops: 0, nLoaded: 0, dist: null, distDirty: true, distT: 0, paused: false };
  }
  function playerCount(g) { return Object.keys(g.pl).length; }
  function freeSlot(g) { const used = new Set(Object.values(g.pl).map(p => p.slot)); for (let i = 0; i < CFG.maxPlayers; i++) if (!used.has(i)) return i; return -1; }
  function addPlayer(g, id, name) {
    const slot = freeSlot(g); if (slot < 0) return null;
    const p = g.pl[id] = { id, slot, name, lives: CFG.lives, kills: 0, hits: 0, stuns: 0, power: 0, twin: 0, armor: 0, score: 0, tank: null, respawn: 0,
      in: { d: -1, lastF: 0, at: 0 }, fireQ: 0, combo: 0, lastKillT: -99, bestCombo: 0, shots: 0, landed: 0, houseKills: 0, seen: 0, stunBy: '', lavaT: 0, mods: null, sp: 0, firstShield: 0, shotN: 0 };
    if (g.ph === 'play' || g.ph === 'intro') rescale(g);
    return p;
  }
  function removePlayer(g, id) { const p = g.pl[id]; if (!p) return; if (p.tank) p.tank.alive = false; delete g.pl[id]; if (g.ph === 'play' || g.ph === 'intro') rescale(g); }
  function fxOf(g) { return FX[(g.stage && g.stage.fx) || 'none'] || FX.none; }
  function stageList(g) { if (g.p3dList) return g.p3dList;   // P3D-49：ひみつの面（1 面だけの並び）
    return g.mode === 'adv' ? Stages.ADV : g.mode === 'rand' ? (g.randList || Stages.ADV) : g.mode === 'hell' ? Stages.HELL : g.mode === 'extra' ? Stages.EXTRA : Stages.CAMPAIGN; }
  function mixOf(g) { return (g.stage && g.stage.mix) || Stages.MIX[g.stage.map] || [14, 2, 3, 1]; }

  /* 今の人数・面・周回・地獄で決まる値。s は TK の「面＋周回×6」の進み具合 */
  function diff(g, nOverride) {
    const n = clamp(nOverride || playerCount(g) || 1, 1, 4), sc = SCALE[n], hell = g.mode === 'hell', fx = fxOf(g), adv = (g.mode === 'adv' || g.mode === 'rand') && g.stage;
    const s = adv ? g.stage.s : hell ? 12 + g.stageIdx : g.mode === 'extra' ? 6 + g.stageIdx : g.stageIdx + g.loop * 6;
    const fireTK = clamp(0.85 + s * 0.095, 0.85, 2.8);
    let enemies = Math.round(sc.enemies * (hell ? HELL.enemies : 1));
    if (adv) enemies = Math.round(sc.enemies * g.stage.em * (g.stage.bosses ? 0.55 : 1));
    else if (g.stage && g.stage.boss) enemies = Math.round(enemies * 0.6);
    return p3dDiff(g, {   // P3D-30：2 周目は 敵が 少し つよい
      n, s, enemies,
      onField: sc.onField + Math.min(4, Math.floor(s / 3)) + (hell ? HELL.onField : 0),
      house: Math.min(0.8, sc.house * (fx.siege ? 1.6 : 1)),
      hunt: clamp(0.18 + s * 0.038, 0.18, 0.68) * (fx.siege ? 0.45 : 1),
      speed: sc.speed * (1 + Math.min(0.22, g.loop * 0.045)) * (fx.enemySpeed || 1) * (hell ? HELL.speed : 1),
      fire: sc.fire / fireTK * 0.85 / (fx.fire || 1) * (hell ? HELL.fire : 1),   // 撃つ間隔に掛ける（小さいほどよく撃つ）
      spawnGap: clamp(3.4 - s * 0.17, 1.05, 3.4) * (fx.spawnGap || 1) * (hell ? 0.7 : 1) / Math.sqrt(n / 2 + 0.5),
      hpBonus: adv ? Math.floor(s / 4.5) + (fx.hp || 0) : Math.min(4, g.loop) + (fx.hp || 0) + (hell ? HELL.hp : 0),
      itemEvery: Math.max(2, Math.round(sc.itemEvery * (hell ? HELL.itemEvery : 1) / Math.max(0.9, 1 - g.loop * 0.02))),
      shield: CFG.shieldSec * (hell ? HELL.shield : 1), bossHp: sc.bossHp
    });
  }
  /* 敵の並び。面の割合（ふつう・はやい・どっしり・かたい）を人数の数に合わせ、自作の敵・周回の追加・地獄の首領を足し、3 つに分けて混ぜる（後ほど強い） */
  function buildQueue(g, d) {
    const mix = mixOf(g), sum = mix.reduce((a, b) => a + b, 0), adv = g.mode === 'adv' || g.mode === 'rand';
    const stageNo = g.mode === 'camp' ? g.stageIdx + 1 : 99, specials = adv ? g.stage.specials : SPECIALS.filter(k => ENEMY[k].from <= stageNo);
    const nCap = adv ? Math.min(g.stage.captains || 0, Math.max(0, d.enemies - 4)) : 0;
    const nSpecial = specials.length ? Math.round((d.enemies - nCap) * (adv ? g.stage.share : SPECIAL_SHARE)) : 0, nMix = d.enemies - nSpecial - nCap, q = [];
    MIX_KINDS.forEach((k, i) => { for (let j = 0; j < Math.round(nMix * mix[i] / sum); j++) q.push(k); });
    while (q.length < nMix) q.push('normal');
    while (q.length > nMix) { const cnt = {}; for (const k of q) cnt[k] = (cnt[k] || 0) + 1; const most = Object.keys(cnt).sort((a, b) => cnt[b] - cnt[a])[0]; q.splice(q.lastIndexOf(most), 1); }
    for (let i = 0; i < nSpecial; i++) q.push(specials[i % specials.length]);
    if (g.mode === 'camp') for (let i = 0; i < Math.min(12, g.loop * 3); i++) q.push(MIX_KINDS[(i + g.stageIdx + g.loop) % 4]);
    for (let i = 0; i < nCap; i++) q.push('captain');
    if (g.mode === 'hell') { q.push('chief'); for (let i = 0; i < 1 + g.stageIdx; i++) q.push('armor'); for (let i = 0; i < Math.min(3, g.stageIdx); i++) q.push('heavy'); }
    const seg = Math.ceil(q.length / 3), out = [];
    for (let s = 0; s < 3; s++) { const part = q.slice(s * seg, (s + 1) * seg); for (let i = part.length - 1; i > 0; i--) { const j = Math.floor(g.rand() * (i + 1)); [part[i], part[j]] = [part[j], part[i]]; } out.push(...part); }
    return out;
  }
  /* 試合の途中で人数が変わった時は、地図はそのまま、残りの敵の並びの長さだけを合わせ直す */
  function rescale(g) {
    const n = playerCount(g); if (!n || !g.enemyTotal) return;
    const total = diff(g, n).enemies; if (total === g.enemyTotal) return;
    const want = Math.max(0, Math.round(g.queue.length * total / g.enemyTotal));
    const plain = () => g.queue.map((k, i) => MIX_KINDS.includes(k) ? i : -1).filter(i => i >= 0);
    while (g.queue.length > want) { const idx = plain(); if (!idx.length) break; g.queue.splice(idx[Math.floor(g.rand() * idx.length)], 1); }
    const mix = mixOf(g), sum = mix.reduce((a, b) => a + b, 0);
    while (g.queue.length < want) { let r = g.rand() * sum, k = 0; while (k < 3 && r >= mix[k]) { r -= mix[k]; k++; } g.queue.splice(Math.floor(g.rand() * (g.queue.length + 1)), 0, MIX_KINDS[k]); }
    g.enemyTotal = total;
  }

  /* ---------- 面を作る ---------- */
  /* 地図を作る。ぼうけんの自動の面（st.gen）は部品から作り、敵の出口・味方の出る所からおうちまで道があるか確かめる。
     道が無ければ種をずらして作り直す（8 回まで） */
  function buildMap(g, n) {
    const st = g.stage;
    if (!st.gen) { buildMapOnce(g, n, null); return; }
    const cols = SCALE[clamp(n, 1, 4)].cols;
    // 遊ぶたびに地図を変える（v0.15）：g.vary が true の時（テレビ）は、同じ面でも毎回ちがう種。確かめの道具では同じ地図のまま
    const salt = g.vary ? (g.varyN = ((g.varyN || 0) + 1) % 100000) * 104729 + (g.seed % 9973) : 0;
    for (let k = 0; k < 8; k++) {
      buildMapOnce(g, n, Stages.genRows(st, cols, st.rows || ROWS, st.seed + salt + cols * 101 + k * 7919));
      if (mapOk(g)) return;
    }
  }
  // 敵の出口と味方の出る所から、おうちまで（レンガは撃って通れる扱いで）たどり着けるか
  // 動く壁はぜんぶ閉じた時でも通れるか調べる。護送：トラックの出発点まで、突破：ゴールまで
  function mapOk(g) {
    const open = (g.shutCells || []).filter(c => g.map[c.y][c.x] === 'g'); for (const c of open) g.map[c.y][c.x] = 'G';
    const st = g.stage, mode = st.type === 'escort' ? 'start' : st.type === 'breakthrough' ? 'goal' : 'house';
    buildDist(g, mode);
    let ok = true;
    for (const gt of g.gates) if (distAt(g, gt.x, gt.y) < 0) ok = false;
    for (const sp of g.spawns) if (distAt(g, sp.x, sp.y) < 0) ok = false;
    for (const bx of g.bossXs || []) if (distAt(g, bx, 3) < 0) ok = false;
    for (const f of g.flagPos || []) if (distAt(g, f.x, f.y) < 0) ok = false;
    for (const c of g.corePos || []) if (distAt(g, c.x, c.y + 3) < 0 && distAt(g, c.x - 3, c.y) < 0 && distAt(g, c.x + 3, c.y) < 0) ok = false;
    if (g.goal && distAt(g, g.goal.x, g.goal.y) < 0) ok = false;
    for (const c of open) g.map[c.y][c.x] = 'g';
    g.distDirty = true; return ok;
  }
  function buildMapOnce(g, n, gen) {
    const st = g.stage, sc = SCALE[clamp(n, 1, 4)];
    let cols = sc.cols, rows = ROWS; const map = [];
    if (gen) { rows = gen.length; cols = gen[0].length; for (const r of gen) map.push([...r]); }
    else {
      const A = Stages.MAPS[st.map], B = Stages.MAPS[st.partner] || A; rows = A.length;
      for (let y = 0; y < rows; y++) { let r = A[y]; if (cols === 39) r += B[y].slice(0, 13); else if (cols === 52) r += B[y]; map.push([...r]); }
    }
    const set = (x, y, c) => { if (x >= 0 && y >= 0 && x < cols && y < rows) map[y][x] = c; };
    const clearBox = (x0, y0, w, h) => { for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) set(x, y, '.'); };
    const baseL = Math.floor(cols / 2) - 1, hx = baseL + 1, wall = fxOf(g).baseSteel ? 'S' : 'B';
    const noHouse = st.type === 'escort' || st.type === 'breakthrough';   // 護送・突破（v0.14）はおうちが無い
    clearBox(baseL - 2, rows - 5, 6, 5);
    const ring = [];
    if (!noHouse) {
    for (let x = baseL - 1; x <= baseL + 2; x++) { set(x, rows - 3, wall); ring.push([x, rows - 3]); }
    for (const y of [rows - 2, rows - 1]) { set(baseL - 1, y, wall); set(baseL + 2, y, wall); set(baseL, y, 'H'); set(baseL + 1, y, 'H'); ring.push([baseL - 1, y]); ring.push([baseL + 2, y]); }
    // 外側にもう 1 重のレンガ（家族で守りに戻る時間を作るため。2 重の囲い）
    for (let x = baseL - 2; x <= baseL + 3; x++) { set(x, rows - 4, wall); ring.push([x, rows - 4]); }
    for (const y of [rows - 3, rows - 2, rows - 1]) { set(baseL - 2, y, wall); set(baseL + 3, y, wall); ring.push([baseL - 2, y]); ring.push([baseL + 3, y]); }
    // おうちの真上に鋼の屋根（2 升）。遠くから真下へ撃たれても届かない。敵は横から回り込む
    set(baseL, rows - 5, 'S'); set(baseL + 1, rows - 5, 'S');
    } else clearBox(hx - 6, rows - 4, 12, 4);
    const spawns = SPAWN_OFFSETS.map(o => ({ x: hx + o, y: rows - 1 }));
    for (const s of spawns) clearBox(s.x - 1, rows - 2, 2, 2);
    const gates = [];
    for (let i = 0; i < sc.gates; i++) {
      let x = Math.round(1 + i * (cols - 2) / (sc.gates - 1));
      if (Math.abs(x - hx) < GATE_AWAY) x = hx - GATE_AWAY - 1;   // おうちの真上には出口を置かない
      gates.push({ x, y: 1 }); clearBox(x - 1, 0, 2, 2);
    }
    // 突破：地図の途中にも出口（画面の上の方の出口から出る）。護送：左右のはしの中ほどにも出口
    if (st.type === 'breakthrough') for (const gy of [14, 27]) for (let i = 0; i < sc.gates; i++) { let x = Math.round(1 + i * (cols - 2) / (sc.gates - 1)); if (Math.abs(x - hx) < GATE_AWAY) x = hx - GATE_AWAY - 1; gates.push({ x, y: gy }); clearBox(x - 1, gy - 1, 2, 2); }
    if (st.type === 'escort') for (const x of [1, cols - 1]) { gates.push({ x, y: 14 }); clearBox(x - 1, 13, 2, 2); }
    const bossX = [hx + 7, hx - 7, hx + 10, hx - 10].find(x => x >= 2 && x <= cols - 2 && gates.every(gt => Math.abs(gt.x - x) >= 4)) || hx + 7;
    if (st.boss) clearBox(bossX - 2, 0, 4, 4);
    // ぼうけんのボス：1 体なら上の真ん中寄り、2 体なら左右。砂上戦艦は上に横長の海（砂）を空ける
    let bossXs = [];
    if (st.bosses) {
      if (st.bosses.includes('sandship')) { bossXs = [hx]; clearBox(Math.max(1, hx - 11), 0, Math.min(cols - 2, 22), 6); }
      else if (st.bosses.includes('core')) { bossXs = [hx]; }
      else if (st.bosses.length === 3) { bossXs = [clamp(hx - 10, 3, cols - 3), clamp(hx + 10, 3, cols - 3), hx]; for (const x of bossXs) clearBox(x - 2, 0, 4, 4); }
      else if (st.bosses.length === 1) { bossXs = [bossX]; clearBox(bossX - 2, 0, 4, 4); }
      else { bossXs = [clamp(hx - 9, 3, cols - 3), clamp(hx + 9, 3, cols - 3)]; for (const x of bossXs) clearBox(x - 2, 0, 4, 4); }
    }
    // 占領の旗（v0.13）：左・真ん中の上・右。旗のまわりは戦車が入れるよう空ける
    let flagPos = [];
    if (st.type === 'flags') { flagPos = [[Math.round(cols * 0.17), 13], [hx, 8], [cols - Math.round(cols * 0.17), 13]].map(([x, y]) => ({ x, y })); for (const f of flagPos) clearBox(f.x - 2, f.y - 2, 4, 4); }
    g.flagPos = flagPos;
    // 要塞コア（v0.14）：段階ごとに移る 4 つの部屋。どれも 6 × 6 升を空ける
    let corePos = [];
    if (st.bosses && st.bosses.includes('core')) { corePos = [[hx, 3], [Math.round(cols * 0.22), 9], [cols - Math.round(cols * 0.22), 9], [hx, 12]].map(([x, y]) => ({ x, y })); for (const c of corePos) clearBox(c.x - 3, c.y - 3, 6, 6); }
    g.corePos = corePos;
    // 護送のゴール・突破のゴール（上の真ん中）
    g.goal = noHouse ? { x: hx, y: 2 } : null; if (noHouse) clearBox(hx - 4, 0, 8, 5);
    // ワープ（機械要塞）：部屋と部屋の間の十字路に、左右の 2 つで 1 組
    const warps = [];
    if (fxOf(g).warp) for (const wy of [13, 26, 39]) { if (wy > rows - 8) break; const ax = 13, bx2 = cols - 13; if (bx2 - ax < 8) break;
      const a = { x: ax, y: wy }, b = { x: bx2, y: wy }; for (const q of [a, b]) { clearBox(q.x - 2, q.y - 2, 4, 4); set(q.x - 1, q.y - 1, 'P'); set(q.x, q.y - 1, 'P'); set(q.x - 1, q.y, 'P'); set(q.x, q.y, 'P'); } warps.push({ a, b }); }
    g.warps = warps;
    // 動く壁：G＝はじめ閉じている組（0）、J＝はじめ開いている組（1）
    const shutCells = [];
    for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) { const c = map[y][x]; if (c === 'G') shutCells.push({ x, y, grp: 0 }); else if (c === 'J') { shutCells.push({ x, y, grp: 1 }); map[y][x] = 'g'; } }
    g.shutCells = shutCells;
    g.map = map; g.mapVer = (g.mapVer || 0) + 1; g.cols = cols; g.rows = rows; g.baseL = baseL; g.hx = hx; g.hy = rows - 1; g.noHouse = noHouse; g.ring = ring; g.spawns = spawns; g.gates = gates; g.bossX = bossX; g.bossXs = bossXs; g.wallTile = wall;
  }
  function loadStage(g, idx) {
    const list = stageList(g); g.stageIdx = clamp(idx, 0, list.length - 1); g.stage = list[g.stageIdx];
    const n = Math.max(1, playerCount(g)); g.nLoaded = n; buildMap(g, n);
    const d = diff(g);
    Object.assign(g, { tanks: [], bullets: [], shells: [], beams: [], mines: [], missiles: [], items: [], chests: [], pools: [], downs: [], fx: [], texts: [], pending: [],
      t: 0, phT: CFG.introSec, ph: 'intro', pauseT: 0, shake: 0, win: -1, why: '', awards: [], praise: null, reveal: null, loopReward: null,
      stopT: 0, wallT: 0, alertT: 0, houseDead: false, spawnT: 0.6, gateI: 0, spawned: 0, itemDrops: 0,
      distDirty: true, distT: 0, bossSpawned: false, bossWarned: false, lastAlertT: -99, paused: false,
      bossQ: g.stage.bosses ? g.stage.bosses.slice() : [], talk: null, talkWait: [], houseHits: 0, stars: null, bossKills: 0, lost: 0, stageKills: 0 });
    g.queue = buildQueue(g, d); g.enemyTotal = d.enemies;
    p3dStageInit(g, d);   // P3D-30/49：2 周目の敵の並び・ひみつの かべ・たからの部屋
    g.par = g.mode === 'adv' || g.mode === 'rand' ? Stages.parTime(g.stage, d.enemies) : 0;
    // 占領（旗 3 本）・生き残り（v0.13）
    g.flags = g.stage.type === 'flags' ? (g.flagPos || []).map(f => ({ x: f.x, y: f.y, own: 0, prog: 0, lose: 0 })) : [];
    g.survive = g.stage.type === 'survive' ? g.stage.survive : 0;
    g.killGoal = g.survive ? Stages.killGoal(g.stage, d.enemies) : 0;
    initV14(g);
    initP2A(g);   // P2-A：役わり・ひみつ情報・合体わざ
    g.reunion = null; g.cameo = null;   // P2-22：ボスとの再会（面ごとに 1 回）
    g.banner = { s: g.stage.ja, zh: g.stage.zh, t: CFG.introSec };
    if (g.mode !== 'hell') g.futon = Math.max(g.futon, CFG.startFuton);
    for (const id in g.pl) { const p = g.pl[id]; Object.assign(p, { tank: null, respawn: 0, fireQ: 0, combo: 0, lastKillT: -99, bestCombo: 0, shots: 0, landed: 0, houseKills: 0, kills: 0, lavaT: 0, chestN: 0, spN: 0, bossHits: 0, deaths: 0, rescues: 0, shieldGive: 0 }); }
    applyStartMods(g);
    g.ev.push({ k: 'stage', idx: g.stageIdx, mode: g.mode, boss: !!g.stage.boss, loop: g.loop });
  }
  /* 遊びを始める。mode＝'camp'（ふつう）・'extra'（おまけ）・'hell'（地獄）、idx＝始める面（0 から）。
     carry＝続きから遊ぶ時の引き継ぎ（{ loop, futon, tower, slow, pl: { 枠: { power, twin, armor, lives } } }） */
  function startRun(g, mode, idx, carry) {
    if (!playerCount(g)) return false;
    g.mode = mode === 'hell' ? 'hell' : mode === 'extra' ? 'extra' : mode === 'adv' ? 'adv' : mode === 'rand' ? 'rand' : 'camp';
    const c = carry || {};
    if (g.mode === 'rand' && (!g.randList || c.newRand || idx === 0)) { g.randSeed = toInt(c.seed, 1, 2e9, 1 + Math.floor(g.rand() * 1e9)); g.randList = Stages.makeRandom(g.randSeed, toInt(c.open, 1, 999, 24)); }
    g.loop = g.mode === 'camp' ? toInt(c.loop, 0, CFG.maxLoop - 1, 0) : 0;
    g.futon = toInt(c.futon, 0, CFG.maxFuton, 0); g.tower = toInt(c.tower, 0, CFG.maxTower, 0); g.slow = toInt(c.slow, 0, CFG.maxSlow, 0);
    for (const id in g.pl) {
      const p = g.pl[id], cp = (c.pl && c.pl[p.slot]) || {};
      Object.assign(p, { lives: toInt(cp.lives, 1, MAX_LIVES, CFG.lives), power: toInt(cp.power, 0, CFG.maxPower, 0), twin: toInt(cp.twin, 0, CFG.maxTwin, 0),
        armor: toInt(cp.armor, 0, CFG.maxArmor, 0), hits: 0, stuns: 0, score: 0, sp: toInt(cp.sp, 0, SP_NEED * 2, 0) });
    }
    loadStage(g, toInt(idx, 0, 999, 0)); return true;
  }
  /* 負けた面をやり直す（台数は戻す。火力・強化は今のまま） */
  function retryStage(g) { if (!playerCount(g)) return false; for (const id in g.pl) g.pl[id].lives = CFG.lives; loadStage(g, g.stageIdx); return true; }
  /* 続きから遊ぶための引き継ぎ（画面が覚えておく） */
  function carryOf(g) {
    const pl = {}; for (const id in g.pl) { const p = g.pl[id]; pl[p.slot] = { power: p.power, twin: p.twin, armor: p.armor, lives: p.lives, sp: Math.floor(p.sp) }; }
    return { loop: g.loop, futon: g.futon, tower: g.tower, slow: g.slow, pl };
  }
  /* 一時停止（テレビのリモコン）。止めている間は計算を進めない */
  function setPause(g, on) {
    if (on && (g.ph === 'play' || g.ph === 'intro')) { g.paused = true; g.ev.push({ k: 'pause' }); }
    else if (!on && g.paused) { g.paused = false; g.ev.push({ k: 'resume' }); }
  }

  /* ---------- 当たり判定 ---------- */
  function tileAt(g, x, y) { if (x < 0 || y < 0 || x >= g.cols || y >= g.rows) return '#'; return g.map[y][x]; }
  function solidAt(g, x, y) { const c = tileAt(g, x, y); return c === '#' || !!SOLID[c]; }
  function boxHitsWall(g, x, y, h) {
    const x0 = Math.floor(x - h), x1 = Math.floor(x + h - 1e-6), y0 = Math.floor(y - h), y1 = Math.floor(y + h - 1e-6);
    for (let cy = y0; cy <= y1; cy++) for (let cx = x0; cx <= x1; cx++) if (solidAt(g, cx, cy)) return true; return false;
  }
  function boxHasTile(g, x, y, h, ch) {
    const x0 = Math.floor(x - h), x1 = Math.floor(x + h - 1e-6), y0 = Math.floor(y - h), y1 = Math.floor(y + h - 1e-6);
    for (let cy = y0; cy <= y1; cy++) for (let cx = x0; cx <= x1; cx++) if (tileAt(g, cx, cy) === ch) return true; return false;
  }
  // ほかの戦車とぶつかるか。すでに重なっている相手からは、離れる向きなら動ける
  function boxHitsTank(g, t, x, y, h) {
    for (const o of g.tanks) {
      if (o === t || !o.alive || o.under) continue; const m = h + o.half;
      if (Math.abs(o.x - x) < m && Math.abs(o.y - y) < m) {
        if (t && Math.abs(o.x - t.x) < m && Math.abs(o.y - t.y) < m && Math.hypot(o.x - x, o.y - y) >= Math.hypot(o.x - t.x, o.y - t.y)) continue;
        return true;
      }
    }
    const tr = g.truck;   // 護送のトラックにもぶつかる
    if (tr && !tr.dead && t !== tr) { const m = h + tr.half; if (Math.abs(tr.x - x) < m && Math.abs(tr.y - y) < m) { if (!(t && Math.abs(tr.x - t.x) < m && Math.abs(tr.y - t.y) < m && Math.hypot(tr.x - x, tr.y - y) >= Math.hypot(tr.x - t.x, tr.y - t.y))) return true; } }
    return false;
  }
  function placeFree(g, x, y, h) { return !boxHitsWall(g, x, y, h) && !boxHitsTank(g, null, x, y, h); }
  // (x, y) の近く（r 升以内）で戦車を置ける所を、近い順に探す。無ければ null
  function findFree(g, x, y, r) {
    for (let k = 2; k <= r; k++) for (let dy = -k; dy <= k; dy++) for (let dx = -k; dx <= k; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) !== k) continue; const nx = x + dx, ny = y + dy;
      if (nx >= 1 && ny >= 1 && nx < g.cols && ny < g.rows - 4 && placeFree(g, nx, ny, HALF)) return { x: nx, y: ny };
    }
    return null;
  }
  /* 戦車を動かす。直角に曲がる時は、通路に入りやすいよう升の境目にそろえる */
  function moveTank(g, t, d, spd, dt) {
    t.blocked = false; if (d < 0) { t.moving = false; return; }
    if (d !== t.dir) {
      if ((d & 1) !== (t.dir & 1)) {
        const sx = d & 1 ? t.x : Math.round(t.x), sy = d & 1 ? Math.round(t.y) : t.y;
        if (!boxHitsWall(g, sx, sy, t.half) && !boxHitsTank(g, t, sx, sy, t.half)) { t.x = sx; t.y = sy; }
      }
      t.dir = d;
    }
    t.moving = true; const s = spd * dt / MOVE_STEPS;
    for (let i = 0; i < MOVE_STEPS; i++) {
      const nx = t.x + DX[d] * s, ny = t.y + DY[d] * s;
      if (boxHitsWall(g, nx, ny, t.half) || boxHitsTank(g, t, nx, ny, t.half)) { t.blocked = true; break; }
      if (t.side === 'p' && g.view && ((DY[d] < 0 && ny - t.half < g.view.y) || (DY[d] > 0 && ny + t.half > g.view.y + g.view.h))) { t.blocked = true; t.leash = true; break; }   // 大きな地図：画面の外へは出られない（ひも）
      t.x = nx; t.y = ny;
    }
  }
  function onTile(g, t, ch) { return tileAt(g, Math.floor(t.x), Math.floor(t.y)) === ch; }
  function groundSpeed(g, t) { if (onTile(g, t, 'D')) return 0.6; if (onTile(g, t, 'I')) return fxOf(g).ice ? 1.25 : 1.15; return 1; }
  function inTrees(g, t) { return onTile(g, t, 'T'); }
  function newTank(side, x, y, dir, extra) {
    return Object.assign({ side, x, y, dir, alive: true, half: HALF, cd: 0.3, out: 0, shield: 0, stun: 0, freeze: 0, flash: 0, moving: false, blocked: false, slide: 0 }, extra);
  }

  /* ---------- 敵の道さがし：おうちまでの升の距離（幅優先） ---------- */
  function nodeFree(g, cx, cy) { // 中心が (cx, cy) の戦車が置けるか（レンガは撃って通れるので通れる扱い）
    for (let y = cy - 1; y <= cy; y++) for (let x = cx - 1; x <= cx; x++) { const c = tileAt(g, x, y); if (c === '#' || c === 'S' || c === 'W' || c === 'H' || c === 'G' || c === 'K') return false; }
    return true;
  }
  /* 敵が向かう所（距離 0 の升）。house＝おうち、truck＝トラック（護送）、players＝味方（突破）、start＝トラックの出発点・goal＝ゴール（地図の確かめ） */
  function distSeeds(g, mode) {
    const out = [], near = (x, y, r) => { for (let cy = Math.round(y) - r; cy <= Math.round(y) + r; cy++) for (let cx = Math.round(x) - r; cx <= Math.round(x) + r; cx++) if (cx >= 1 && cy >= 1 && cx < g.cols && cy < g.rows && nodeFree(g, cx, cy)) out.push(cx, cy); };
    if (mode === 'truck' && g.truck) near(g.truck.x, g.truck.y, 2);
    else if (mode === 'players') { for (const t of g.tanks) if (t.side === 'p' && t.alive) near(t.x, t.y, 1); if (!out.length) near(g.hx, g.view ? g.view.y + g.view.h - 3 : g.rows - 3, 3); }
    else if (mode === 'start') near(g.hx, g.rows - 1, 1);
    else if (mode === 'goal' && g.goal) near(g.goal.x, g.goal.y, 2);
    else for (let cy = 1; cy < g.rows; cy++) for (let cx = 1; cx < g.cols; cx++) if (Math.abs(cx - g.hx) <= 3 && cy >= g.rows - 4 && nodeFree(g, cx, cy)) out.push(cx, cy);
    return out;
  }
  function buildDist(g, mode) {
    const W = g.cols + 1, H = g.rows + 1, dist = new Int16Array(W * H).fill(-1), q = [];
    const m = mode || (g.truck ? 'truck' : g.stage && g.stage.type === 'breakthrough' ? 'players' : 'house'), sd = distSeeds(g, m);
    for (let i = 0; i < sd.length; i += 2) { const j = sd[i + 1] * W + sd[i]; if (dist[j] < 0) { dist[j] = 0; q.push(sd[i], sd[i + 1]); } }
    for (let i = 0; i < q.length; i += 2) {
      const x = q[i], y = q[i + 1], d = dist[y * W + x];
      for (let k = 0; k < 4; k++) {
        const nx = x + DX[k], ny = y + DY[k]; if (nx < 1 || ny < 1 || nx >= g.cols || ny >= g.rows) continue;
        const j = ny * W + nx; if (dist[j] >= 0 || !nodeFree(g, nx, ny)) continue; dist[j] = d + 1; q.push(nx, ny);
      }
    }
    g.dist = dist; g.distW = W; g.distDirty = false;
  }
  function distAt(g, cx, cy) { if (!g.dist || cx < 1 || cy < 1 || cx >= g.cols || cy >= g.rows) return -1; return g.dist[cy * g.distW + cx]; }
  // 近くの味方の戦車。森の面では、木の中にいる戦車はねらいにくい（遠い扱い）
  function nearestPlayerTank(g, x, y, forAim) {
    const jungle = fxOf(g).jungle; let best = null, bd = 1e9;
    for (const t of g.tanks) {
      if (t.side !== 'p' || !t.alive) continue; if (forAim && jungle && inTrees(g, t)) continue;
      let d = Math.hypot(t.x - x, t.y - y); if (jungle && inTrees(g, t)) d += 9;
      if (d < bd) { bd = d; best = t; }
    }
    return best;
  }
  function pickMode(g, t, d) { const r = g.rand(), e = ENEMY[t.kind]; if (e.boss) return r < e.house ? 'house' : 'hunt'; return r < d.house ? 'house' : r < d.house + d.hunt ? 'hunt' : 'wander'; }
  function chooseDir(g, t) {
    const r = g.rand();
    if (t.mode === 'house' && r < 0.85) {
      const cx = Math.round(t.x), cy = Math.round(t.y), here = distAt(g, cx, cy); let best = -1, bd = here < 0 ? 1e9 : here;
      for (let k = 0; k < 4; k++) { const d = distAt(g, cx + DX[k], cy + DY[k]); if (d >= 0 && (d < bd || (d === bd && g.rand() < 0.3))) { bd = d; best = k; } }
      if (best >= 0) return best;
    }
    let tg = null;
    if (t.mode === 'hunt' && r < 0.8) tg = nearestPlayerTank(g, t.x, t.y);
    else if (r < 0.25) tg = { x: g.hx, y: g.hy };
    if (!tg) return g.rand() * 4 | 0;
    const dx = tg.x - t.x, dy = tg.y - t.y; let horiz = Math.abs(dx) > Math.abs(dy); if (g.rand() < 0.25) horiz = !horiz;
    return horiz ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0);
  }

  /* ---------- 磁場（のろのろ電波）：味方の戦車のまわり 3 × 段 升の敵を、10 × 段 % 弱める ---------- */
  function fieldRadius(g) { return g.slow * FIELD_STEP; }
  function inField(g, x, y) { if (g.slow <= 0) return false; const r = fieldRadius(g); for (const p of g.tanks) if (p.side === 'p' && p.alive && Math.hypot(p.x - x, p.y - y) < r) return true; return false; }
  function fieldMul(g, t) { return inField(g, t.x, t.y) ? 1 - g.slow * FIELD_DEBUFF : 1; }

  /* ---------- 味方の火力（TK の段と同じ考え） ---------- */
  function playerBulletSpeed(p) { let v = p.power >= 4 ? 8.0 : p.power >= 1 ? 6.5 : 4.0; if (p.twin > 0) v = Math.max(v, 6.5); return v * K * modsOf(p).bullet; }
  function playerMaxOut(p) { const base = p.power >= 2 ? 2 : 1; return p.twin > 0 ? Math.max(2, base) * 2 + (p.twin - 1) * 2 : base; }
  function playerDamage(p) { return (p.power >= 5 ? 3 : 1) * (p.twin >= 3 ? 2 : p.twin >= 2 ? 1.5 : 1) * modsOf(p).dmgMul; }
  function playerCooldown(p) { return p.twin > 0 ? Math.max(0.06, CFG.fireCooldown - (p.twin - 1) * 0.02) : CFG.fireCooldown; }

  /* ---------- 弾・爆発 ---------- */
  function addBullet(g, b) { g.bullets.push(Object.assign({ r: 0.2, pierce: 1, steel: false, bounces: 0, dmg: 1, through: false }, b)); }
  function fire(g, t, p) {
    if (t.cd > 0 || t.stun > 0 || t.freeze > 0) return false;
    if (t.side === 'p') {
      if (t.out >= playerMaxOut(p)) return false;
      t.cd = playerCooldown(p); const m = modsOf(p), sp = playerBulletSpeed(p), ox = t.x + DX[t.dir] * 1.0, oy = t.y + DY[t.dir] * 1.0;
      let dmg = playerDamage(p);
      dmg *= roleDmg(p);   // P2-23：役わり「攻撃」
      if (m.set4.abyss && p.lives <= 1) dmg *= 2;   // 深淵 4：のこり 1 台の時、威力 2 倍
      if (m.set4.bond && g.tanks.some(o => o.side === 'p' && o.alive && o !== t && Math.hypot(o.x - t.x, o.y - t.y) < 6)) dmg *= 1.25;   // きずな 4：仲間が近い
      if (m.team > 0 && (g.tanks.some(o => o.side === 'p' && o.alive && o !== t && Math.hypot(o.x - t.x, o.y - t.y) < 6) || (!g.noHouse && Math.hypot(g.hx - t.x, g.hy - t.y) < 6))) dmg *= 1 + m.team;   // P2-1：ドライバーの「なかま」（一人の時は、おうちの近く）
      const offs = p.twin > 0 ? [-0.45, 0.45] : [0], through = !!m.set4.sand && (++p.shotN % 3 === 0);   // 砂嵐 4：3 発ごとに壁をぬける
      for (const o of offs) { t.out++; p.shots++; addBullet(g, { x: ox + (t.dir & 1 ? 0 : o), y: oy + (t.dir & 1 ? o : 0), vx: DX[t.dir] * sp, vy: DY[t.dir] * sp, side: 'p', owner: t, pid: t.pid, steel: p.power >= 3, dmg, r: p.power >= 3 ? 0.26 : 0.2, bounces: m.bounce, pierce: 1 + m.pierce, through }); }
      if (m.p4b && m.p4b.ice && (p.p4bShot = (p.p4bShot | 0) + 1) % m.p4b.ice === 0) g.bullets[g.bullets.length - 1].p4bIce = 1;   // P4B：こおりの砲
      g.ev.push({ k: 'fire', big: p.power >= 3 }); return true;
    }
    const e = ENEMY[t.kind]; if (t.out >= (e.elite ? 2 : 1)) return false;
    t.cd = (e.cd[0] + g.rand() * (e.cd[1] - e.cd[0])) * t.fireMul; t.out++;
    const sp = e.bullet * Math.sqrt(t.speedMul) * fieldMul(g, t), ox = t.x + DX[t.dir] * t.half, oy = t.y + DY[t.dir] * t.half;
    addBullet(g, { x: ox, y: oy, vx: DX[t.dir] * sp, vy: DY[t.dir] * sp, side: 'e', owner: t, r: t.kind === 'heavy' || e.elite ? 0.26 : 0.2, bounces: t.kind === 'bouncer' ? 1 : 0, kind: t.kind });
    g.ev.push({ k: 'efire' }); return true;
  }
  // 角度のある弾（ボス）。ang は向きからの角度（ラジアン）
  function fireAngle(g, t, ang, speed, extra) {
    if (t.boss && g.stage && g.stage.p4b) { speed *= g.stage.p4b.bul || 1; if (g.stage.p4b.ap) extra = Object.assign({ p4bAp: g.stage.p4b.ap }, extra); }   // P4B
    const base = Math.atan2(DY[t.dir], DX[t.dir]) + ang;
    addBullet(g, Object.assign({ x: t.x + Math.cos(base) * t.half, y: t.y + Math.sin(base) * t.half, vx: Math.cos(base) * speed, vy: Math.sin(base) * speed, side: 'e', owner: null, r: 0.3, kind: 'boss' }, extra));
  }
  function alert(g) { g.alertT = CFG.alertSec; if (g.t - g.lastAlertT > 3) { g.lastAlertT = g.t; g.alertN++; g.ev.push({ k: 'danger' }); } }
  function isRing(g, x, y) { return g.ring.some(r => r[0] === x && r[1] === y); }
  // 升を壊す。レンガは 2 発で壊れる（1 発目でひび）。full＝1 発で壊す（体当たり・レーザー）。steel＝鋼も壊す
  function breakTile(g, x, y, steel, byEnemy, full) {
    const c = tileAt(g, x, y);
    if (c === 'B' && !full && !steel) { g.map[y][x] = 'b'; g.mapVer++; g.fx.push({ k: 'dust', x: x + 0.5, y: y + 0.5, t: 0.25, T: 0.25 }); if (byEnemy && isRing(g, x, y)) alert(g); return true; }
    if (c === 'B' || c === 'b' || (c === 'S' && steel)) {
      g.map[y][x] = '.'; g.distDirty = true; g.mapVer++; g.fx.push({ k: 'dust', x: x + 0.5, y: y + 0.5, t: 0.35, T: 0.35 });
      if (byEnemy && isRing(g, x, y)) alert(g); return true;
    }
    return false;
  }
  function hitHouse(g) {
    if (g.houseDead || g.ph !== 'play') return;
    g.houseHits = (g.houseHits || 0) + 1;   // 星「おうち無傷」：おふとんで守っても 1 回に数える
    if (g.futon > 0) { g.futon--; alert(g); g.ev.push({ k: 'shield' }); g.texts.push({ x: g.hx, y: g.hy - 2.5, s: 'おふとんが守った！', zh: '被子挡住了！', t: 1.2, col: '#9fe0ff' }); return; }
    g.houseDead = true; for (let y = g.rows - 2; y < g.rows; y++) for (let x = g.baseL; x <= g.baseL + 1; x++) g.map[y][x] = 'h'; g.mapVer++;
    g.fx.push({ k: 'boom', x: g.hx, y: g.hy - 0.5, r: 2.5, t: 1, T: 1 }); g.shake = 0.6; g.ev.push({ k: 'bigboom' });
    endGame(g, 0, 'house');
  }
  // 味方の戦車に当てる。たて（無敵）の間は効かない。よろいがあれば 1 枚はがれて助かる
  function killPlayer(g, t, cause) {
    const p4ap = g.p4bApHit | 0; g.p4bApHit = 0;   // P4B
    if (!t.alive || t.shield > 0) return false;
    const p = g.pl[t.pid];
    if (p && p4ap > 1 && p.armor > 1) p.armor = Math.max(1, p.armor - (p4ap - 1));   // P4B：Lv13 から ボスの弾は よろいを 2 まい こわす
    if (p && p.armor > 0) { p.armor--; t.shield = ARMOR_GRACE; t.flash = 0.14; g.ev.push({ k: 'armor', pid: t.pid }); g.texts.push({ x: t.x, y: t.y - 1.4, s: 'よろいが守った！', zh: '护甲挡住了！', t: 1, col: '#9fe0ff' }); return false; }
    t.alive = false; g.lost = (g.lost || 0) + 1; g.fx.push({ k: 'boom', x: t.x, y: t.y, r: 1.4, t: 0.6, T: 0.6 }); g.shake = Math.max(g.shake, 0.3); g.ev.push({ k: 'hurt', pid: t.pid });
    if (p) { p.deaths = (p.deaths || 0) + 1; p.tank = null; p.lives--; p.hits++; p.power = Math.max(0, p.power - 1); p.respawn = CFG.respawnSec; p.combo = 0; p.fireQ = 0; p.lavaT = 0;
      if (modsOf(p).set4.wakaba) for (const o of g.tanks) if (o.side === 'p' && o.alive && Math.hypot(o.x - t.x, o.y - t.y) < 7) o.shield = Math.max(o.shield, 3);   // 若葉 4：近くの仲間に盾
      // v0.17（アイデア No.8）：仲間が生きていれば「たすけて」の印を残す。そばに来てもらうと、その場で起き上がる（台数も戻る）
      p4bFreeDeath(g, p, t);   // P4B：かげの おまもり
      if (Object.values(g.pl).some(q => q !== p && q.tank && q.tank.alive)) { g.downs = g.downs || []; g.downs.push({ pid: p.id, x: t.x, y: t.y, t: p.lives > 0 ? DOWN_SEC : DOWN_OUT_SEC, T: p.lives > 0 ? DOWN_SEC : DOWN_OUT_SEC, prog: 0 }); if (p.lives > 0) p.respawn = DOWN_SEC; } }
    return true;
  }
  // 氷の弾（氷の砲台）：やられはしないが、しばらく動けない。たて・無敵の間は効かない
  function freezePlayer(g, t) {
    if (!t.alive || t.shield > 0) return false;
    t.stun = Math.max(t.stun, FREEZE_SEC); t.iced = FREEZE_SEC; const p = g.pl[t.pid]; if (p) p.fireQ = 0;
    g.texts.push({ x: t.x, y: t.y - 1.4, s: 'こおった！', zh: '冻住了！', t: 1.2, col: '#bfe9ff' }); g.ev.push({ k: 'freeze', pid: t.pid }); return true;
  }
  // 敵に当てる。noAim＝命中の数に入れない（ドカン）
  function damageEnemy(g, t, dmg, pid, noAim, hitX) {
    if (!t.alive || t.under) return;
    const p = pid && g.pl[pid]; if (p && !noAim) p.landed++; if (p && t.boss) p.bossHits = (p.bossHits || 0) + 1;
    if (p && t.boss && p.mods && p.mods.bossDmg > 1) dmg *= p.mods.bossDmg;   // P2-1：ドライバーの「ゆうき」
    if (t.guard > 0) { t.guard = 0; t.flash = 0.1; g.texts.push({ x: t.x, y: t.y - 1.3, s: 'ガード！', zh: '挡住了！', t: 0.8, col: '#9fe0ff' }); g.ev.push({ k: 'steel' }); return; }
    if (g.p3dDuel && g.p3dDuel.cap && t.boss && !t.cloneOf) { dmg = p3dDuelCap(g, t, dmg); if (dmg <= 0) return; }   // P3D-duel：1 秒に 入る ダメージに 上限（うまい人と 小さい子の 差を ちぢめる）
    // 砂上戦艦：砲塔が残っている間は砲塔にだけ当たる（体は効かない）
    if (t.parts && t.parts.some(q => q.hp > 0)) {
      let part = null;
      if (hitX === undefined) part = t.parts.find(q => q.hp > 0);
      else { let bd = 1.4; for (const q of t.parts) if (q.hp > 0 && Math.abs(hitX - (t.x + q.ox)) < bd) { bd = Math.abs(hitX - (t.x + q.ox)); part = q; } }
      if (!part) { g.ev.push({ k: 'steelhit' }); g.fx.push({ k: 'spark', x: hitX === undefined ? t.x : hitX, y: t.y, t: 0.2, T: 0.2 }); return; }
      part.hp -= dmg; part.flash = 0.1; g.ev.push({ k: 'steel' });
      if (part.hp <= 0) {
        g.fx.push({ k: 'boom', x: t.x + part.ox, y: t.y, r: 1.6, t: 0.8, T: 0.8 }); g.shake = Math.max(g.shake, 0.4); g.ev.push({ k: 'bigboom' });
        if (p) p.score += 800;
        if (!t.parts.some(q => q.hp > 0)) { t.phase = 2; g.banner = { s: '砲塔を ぜんぶ こわした！', zh: '炮塔全部摧毁了！', t: 1.8 }; g.ev.push({ k: 'bossphase' }); }
      }
      return;
    }
    t.hp -= dmg; t.flash = 0.08;
    if (t.hp > 0) { if (CFG.feel.freeze && !t.boss) t.freeze = 0.1; if (p && !t.boss && modsOf(p).set4.silver) t.freeze = Math.max(t.freeze, 0.6); g.ev.push({ k: 'steel' }); return; }
    t.alive = false; const big = !!t.boss || !!ENEMY[t.kind].elite; g.stageKills = (g.stageKills || 0) + 1;
    g.fx.push({ k: 'boom', x: t.x, y: t.y, r: t.boss ? 3 : big ? 2 : 1.3, t: big ? 1.2 : 0.5, T: big ? 1.2 : 0.5 });
    g.shake = Math.max(g.shake, t.boss ? 0.7 : big ? 0.4 : 0.18); g.ev.push({ k: big ? 'bigboom' : 'boom' });
    if (t.glow) spawnItem(g);
    dropChest(g, t);
    if (p) {
      const m = modsOf(p); p.sp = Math.min(SP_NEED * m.spMax, p.sp + m.charge * (t.boss ? 4 : t.captain || ENEMY[t.kind].elite ? 2 : 1));
      if (m.p4b && m.p4b.mate && p.tank && g.tanks.some(o => o.side === 'p' && o.alive && o !== p.tank && Math.hypot(o.x - p.tank.x, o.y - p.tank.y) < 4)) p.sp = Math.min(SP_NEED * m.spMax, p.sp + m.charge * m.p4b.mate * (t.boss ? 4 : t.captain || ENEMY[t.kind].elite ? 2 : 1));   // P4B：双子の リボン
      if (m.set4.crimson && !t.boss) for (const o of g.tanks) if (o.side === 'e' && o.alive && o !== t && !o.boss && Math.hypot(o.x - t.x, o.y - t.y) < 2.6) damageEnemy(g, o, 1, null, true);   // 紅蓮 4：倒した敵が爆発
      p.kills++; p.score += ENEMY[t.kind].score; if (Math.hypot(t.x - g.hx, t.y - g.hy) < 7) p.houseKills++;
      p.combo = g.t - p.lastKillT <= CFG.comboSec ? p.combo + 1 : 1; p.lastKillT = g.t; p.bestCombo = Math.max(p.bestCombo, p.combo);
      if (p.combo >= 2) { p.score += p.combo * CFG.comboScore; g.texts.push({ x: t.x, y: t.y - 1, s: p.combo + ' れんぞく！ +' + p.combo * CFG.comboScore, zh: p.combo + ' 连击！+' + p.combo * CFG.comboScore, t: 1.1, col: p.combo >= 5 ? '#ff6a5f' : p.combo >= 3 ? '#ffb347' : '#7fe0ff', big: p.combo }); g.ev.push({ k: 'combo', n: p.combo }); }
    }
    if (t.kind === 'snowman' && !g.p3dDuel) splitSnowman(g, t, d0(g));   // P3D-duel：けっとうでは 分かれない   // 雪だるま：倒れると小さい 2 体に分かれる（台詞は 2 体とも倒した時）
    else if (t.kind === 'snowkid') { if (!g.tanks.some(o => o.alive && (o.kind === 'snowkid' || o.kind === 'snowman'))) { g.banner = { s: 'ボスをたおした！', zh: '打倒了首领！', t: 2 }; g.bossKills = (g.bossKills || 0) + 1; g.ev.push({ k: 'bossdown', x: t.x, y: t.y }); g.talkWait.push({ t: 1.4, kinds: ['snowman'], which: 'defeat' }); } }
    else if (t.kind === 'sisA' || t.kind === 'sisB') { if (!g.tanks.some(o => o.alive && (o.kind === 'sisA' || o.kind === 'sisB'))) { g.banner = { s: 'ボスをたおした！', zh: '打倒了首领！', t: 2 }; g.bossKills = (g.bossKills || 0) + 1; g.ev.push({ k: 'bossdown', x: t.x, y: t.y }); g.talkWait.push({ t: 1.4, kinds: ['sisA'], which: 'defeat' }); } else g.texts.push({ x: t.x, y: t.y - 2.4, s: 'あと ひとり！', zh: '还剩一个！', t: 1.4, col: '#ffd96a', big: 2 }); }
    else if (t.boss) { if (t.kind === 'shadow') for (const o of g.tanks) if (o.alive && o.cloneOf === t) { o.alive = false; g.fx.push({ k: 'dust', x: o.x, y: o.y, t: 0.6, T: 0.6 }); }
      g.banner = { s: 'ボスをたおした！', zh: '打倒了首领！', t: 2 }; g.bossKills = (g.bossKills || 0) + 1; g.ev.push({ k: 'bossdown', x: t.x, y: t.y }); if (ADV_BOSS[t.kind] && Stages.BOSS_TALK[t.kind]) g.talkWait.push({ t: 1.4, kinds: [t.kind], which: 'defeat' }); }
    else if (ENEMY[t.kind].elite) g.texts.push({ x: t.x, y: t.y - 1.6, s: '首領をたおした！', zh: '击破首领！', t: 1.5, col: '#ffd96a' });
  }
  // 爆発。full＝レンガを 1 発で壊す（体当たり）。迫撃・地雷はひびを入れるだけで、おうちに直接は届かない
  function explode(g, x, y, r, side, full) {
    g.fx.push({ k: 'boom', x, y, r, t: 0.5, T: 0.5 }); g.shake = Math.max(g.shake, 0.25); g.ev.push({ k: 'boom' });
    let house = false;
    for (let ty = Math.floor(y - r); ty <= Math.floor(y + r); ty++) for (let tx = Math.floor(x - r); tx <= Math.floor(x + r); tx++) {
      if (Math.hypot(tx + 0.5 - x, ty + 0.5 - y) > r + 0.3) continue;
      const c = tileAt(g, tx, ty); if (c === 'H') house = true; else breakTile(g, tx, ty, false, side === 'e', !!full);
    }
    if (side === 'e') { if (house && full) hitHouse(g); for (const t of g.tanks) if (t.side === 'p' && Math.hypot(t.x - x, t.y - y) < r + 0.6) killPlayer(g, t, 'boom');
      if (g.truck && !g.truck.dead && Math.hypot(g.truck.x - x, g.truck.y - y) < r + 0.8) hitTruck(g, 2); }
  }
  /* 弾が升に当たったか。軸に沿う弾は 2 升の幅で調べる（戦車と同じ幅の穴が開く） */
  function bulletTiles(b) {
    const cx = Math.floor(b.x), cy = Math.floor(b.y), ax = Math.abs(b.vx) < 1e-6, ay = Math.abs(b.vy) < 1e-6;
    if (!ay && ax) return [[Math.floor(b.x - 0.5), cy], [Math.floor(b.x + 0.49), cy]];
    if (!ax && ay) return [[cx, Math.floor(b.y - 0.5)], [cx, Math.floor(b.y + 0.49)]];
    return [[cx, cy]];
  }
  function stepBullet(g, b, dt) {
    if (b.life !== undefined) { b.life -= dt; if (b.life <= 0) { b.dead = true; return; } }   // 炎（火炎放射車）は短い距離で消える
    const s = dt / BULLET_STEPS;
    for (let i = 0; i < BULLET_STEPS && !b.dead; i++) {
      b.x += b.vx * s; b.y += b.vy * s;
      if (b.x < 0 || b.y < 0 || b.x >= g.cols || b.y >= g.rows) {
        if (b.bounces > 0) { b.bounces--; if (b.x < 0 || b.x >= g.cols) b.vx = -b.vx; else b.vy = -b.vy; b.x = clamp(b.x, 0.01, g.cols - 0.01); b.y = clamp(b.y, 0.01, g.rows - 0.01); continue; }
        b.dead = true; break;
      }
      for (const t of g.tanks) {
        if (!t.alive || t === b.owner || t.under) continue; const m = t.half + b.r * 0.5;
        if (Math.abs(b.x - t.x) >= m || Math.abs(b.y - t.y) >= m) continue;
        if (b.side === 'e' && t.side === 'e') continue;
        if (b.side === 'h' && t.side === 'p') continue;   // 陣地の自衛の弾は味方をすり抜ける
        if (b.side === 'p' && t.side === 'p') { // 味方の弾が味方に当たった：しばらく動けない
          b.dead = true; if (t.shield <= 0 && t.stun <= 0) {
            t.stun = CFG.friendlyStunSec; const vp = g.pl[t.pid], sp = g.pl[b.pid]; if (vp) { vp.stuns++; vp.stunBy = sp ? sp.name : ''; vp.fireQ = 0; }
            g.texts.push({ x: t.x, y: t.y - 1.4, s: (sp ? sp.name + ' の弾！' : '') + 'しびれた', zh: (sp ? sp.name + ' 的炮弹！' : '') + '麻痹了', t: 1.4, col: '#c9a8ff' }); g.ev.push({ k: 'stun', pid: t.pid });
          }
          break;
        }
        b.dead = true;
        if (b.p4bAp && t.side === 'p') g.p4bApHit = b.p4bAp;   // P4B
        if (t.side === 'p') { if (b.freeze) freezePlayer(g, t); else killPlayer(g, t, 'bullet'); } else damageEnemy(g, t, weakHit(g, t, b), b.pid, false, b.x);   // P2-39：弱点・部位
        if (b.p4bIce && t.side === 'e' && t.alive) p4bIceHit(g, t);   // P4B：こおらせる弾
        break;
      }
      if (b.dead) break;
      if (b.side === 'e' && g.truck && !g.truck.dead) { const tr = g.truck, m = tr.half + b.r * 0.5; if (Math.abs(b.x - tr.x) < m && Math.abs(b.y - tr.y) < m) { b.dead = true; hitTruck(g, b.dmg > 1 ? 2 : 1); break; } }
      if (b.side !== 'e') {   // ミサイル・地雷は味方の弾で壊せる
        for (const m of g.missiles) if (!m.dead && Math.hypot(m.x - b.x, m.y - b.y) < 0.6) { m.dead = true; b.dead = true; g.fx.push({ k: 'boom', x: m.x, y: m.y, r: 0.8, t: 0.3, T: 0.3 }); g.ev.push({ k: 'boom' }); break; }
        if (b.dead) break;
        for (const m of g.mines) if (!m.dead && Math.hypot(m.x - b.x, m.y - b.y) < 0.6) { m.dead = true; b.dead = true; g.fx.push({ k: 'boom', x: m.x, y: m.y, r: 0.7, t: 0.3, T: 0.3 }); break; }
        if (b.dead) break;
      }
      for (const o of g.bullets) { if (o === b || o.dead || o.ghost || b.ghost || (o.side === 'e') === (b.side === 'e')) continue; if (Math.abs(o.x - b.x) < 0.45 && Math.abs(o.y - b.y) < 0.45) { o.dead = b.dead = true; break; } }
      if (b.dead || b.through) continue;
      let stop = false, broke = false, bounce = false, house = false;
      if (b.soft) { if (bulletTiles(b).some(([tx, ty]) => { const c = tileAt(g, tx, ty); return c === 'B' || c === 'b' || c === 'S' || c === '#' || c === 'H' || c === 'G' || c === 'K'; })) { b.dead = true; break; } continue; }   // 炎は壁で消える（壊さない）
      for (const [tx, ty] of bulletTiles(b)) {
        const c = tileAt(g, tx, ty);
        if (c === 'B' || c === 'b') { breakTile(g, tx, ty, b.steel, b.side === 'e', false); broke = true; }
        else if (c === 'S') { if (b.steel) { breakTile(g, tx, ty, true, false); broke = true; } else if (b.bounces > 0) bounce = true; else stop = true; }
        else if (c === 'H') { house = true; stop = true; }
        else if (c === '#' || c === 'G') stop = true;
        else if (c === 'K') { stop = true; if (b.side === 'p') hitSwitch(g, tx, ty, b.pid); }
      }
      if (house && b.side === 'e' && !b.hitHouse) { b.hitHouse = true; hitHouse(g); }
      if (bounce && !broke) { b.bounces--; b.vx = -b.vx; b.vy = -b.vy; b.x += b.vx * s * 2; b.y += b.vy * s * 2; continue; }
      if (broke) { g.ev.push({ k: 'brick' }); if (--b.pierce <= 0) { b.dead = true; break; } b.x += b.vx * s * 2; b.y += b.vy * s * 2; continue; }
      if (stop) { b.dead = true; g.fx.push({ k: 'spark', x: b.x, y: b.y, t: 0.2, T: 0.2 }); g.ev.push({ k: 'steelhit' }); break; }
    }
  }

  /* ---------- アイテム（TK と同じ：場に 1 つまで。面の最初の 1 つは、よろいが要る人がいれば よろい） ---------- */
  function itemNeeds(g) {
    const ps = Object.values(g.pl);
    return { power: ps.some(p => p.power < CFG.maxPower) || g.tower < CFG.maxTower, armor: ps.some(p => p.armor < CFG.maxArmor) || g.futon < CFG.maxFuton,
      twin: ps.some(p => p.twin < CFG.maxTwin), field: g.slow < CFG.maxSlow };
  }
  function chooseItem(g) {
    const need = itemNeeds(g);
    const list = ITEM_WEIGHTS.map(([k, w]) => [k === 'power' && !need.power ? 'twin' : k === 'armor' && !need.armor ? 'field' : k, w])
      .filter(([k]) => (k !== 'twin' || need.twin) && (k !== 'field' || need.field) && (k !== 'wall' || !g.noHouse));   // おうちの無い面（護送・突破）に「かべなおし」は出さない
    if (!list.length) return null;
    if (g.itemDrops === 0 && need.armor) return 'armor';
    let roll = g.rand() * list.reduce((a, [, w]) => a + w, 0);
    for (const [k, w] of list) { roll -= w; if (roll <= 0) return k; }
    return list[list.length - 1][0];
  }
  function spawnItem(g) {
    if (g.items.some(it => !it.dead)) return;
    const kind = chooseItem(g); if (!kind) return;
    for (let i = 0; i < 60; i++) {
      const v = g.view, y0 = v ? Math.max(3, Math.ceil(v.y) + 3) : 3, y1 = v ? Math.min(g.rows - 6, Math.floor(v.y + v.h) - 5) : g.rows - 6;
      const x = 2 + Math.floor(g.rand() * (g.cols - 4)), y = y0 + Math.floor(g.rand() * Math.max(1, y1 - y0));
      if (Math.abs(x - g.hx) < 4 && y > g.rows - 6) continue;
      let ok = true; for (let yy = y - 1; yy <= y; yy++) for (let xx = x - 1; xx <= x; xx++) { const c = tileAt(g, xx, yy); if (c === 'S' || c === 'W' || c === 'H' || c === '#' || c === 'G' || c === 'K' || c === 'g') ok = false; }
      if (!ok) continue;
      g.itemDrops++; g.items.push({ x, y, kind, t: CFG.itemLifeSec }); g.ev.push({ k: 'item_appear', kind }); return;
    }
  }
  function setRing(g, ch) {
    for (const [x, y] of g.ring) if (!g.tanks.some(o => o.alive && Math.abs(o.x - (x + 0.5)) < o.half + 0.5 && Math.abs(o.y - (y + 0.5)) < o.half + 0.5)) g.map[y][x] = ch;
    g.distDirty = true; g.mapVer++;
  }
  function pickItem(g, p, it) {
    const t = p.tank; let note = '';
    p.score += CFG.itemScore;
    if (it.kind === 'shield') t.shield = Math.max(t.shield, CFG.shieldItemSec);
    else if (it.kind === 'stop') g.stopT = CFG.stopItemSec;
    else if (it.kind === 'wall') { g.wallT = CFG.wallItemSec; setRing(g, 'S'); }
    else if (it.kind === 'power') {
      if (p.power < CFG.maxPower) { p.power++; note = 'power'; }
      else if (g.tower < CFG.maxTower) { g.tower++; note = 'tower'; }
    } else if (it.kind === 'armor') {
      if (p.armor < CFG.maxArmor) { p.armor++; note = 'armor'; }
      else if (g.futon < CFG.maxFuton) { g.futon++; note = 'futon'; }
    } else if (it.kind === 'twin') { p.twin = Math.min(CFG.maxTwin, p.twin + 1); note = 'twin'; }
    else if (it.kind === 'field') { g.slow = Math.min(CFG.maxSlow, g.slow + 1); note = 'slow'; }
    else if (it.kind === 'extra') { p.lives = Math.min(MAX_LIVES, p.lives + 1); note = 'life'; }
    else if (it.kind === 'bomb') {
      for (const e of g.tanks) if (e.side === 'e' && e.alive) damageEnemy(g, e, e.boss ? 5 : 99, p.id, true);
      g.shake = 0.6; g.ev.push({ k: 'bigboom' });
    }
    g.pauseT = CFG.itemPauseSec; g.reveal = { kind: it.kind, note, name: p.name, slot: p.slot, t: 1.2, lv: { power: p.power, armor: p.armor, twin: p.twin, tower: g.tower, futon: g.futon, slow: g.slow } };
    g.ev.push({ k: 'item_get', kind: it.kind, note, pid: p.id });
  }

  /* ---------- 敵 ---------- */
  function spawnEnemy(g, kind, x, y, d, extra) {
    const e = ENEMY[kind], bonus = e.boss ? 0 : d.hpBonus;
    const t = newTank('e', x, y, 2, Object.assign({ kind, hp: e.hp + bonus, maxHp: e.hp + bonus, ai: 0, want: 2, mode: 'wander', modeT: 8, speedMul: d.speed, fireMul: d.fire, mineCd: MINE_EVERY, charge: 0, aim: 0, fieldApplied: 0 }, extra));
    t.mode = pickMode(g, t, d);
    if (e.boss) { t.boss = true; t.half = BOSS_HALF; t.hp = t.maxHp = Math.round(e.hp * d.bossHp); t.mode = 'hunt'; t.spreadCd = 2; t.missileCd = 5; t.laserCd = 8; t.summonCd = 10; t.snipeCd = 12;
      t.phase = 1; t.atkCd = 2; t.sideCd = 1.5; t.buildCd = 3; t.built = 0; t.st = 'surf'; t.stT = 4; t.lzCd = 5; t.talkT = 4 + g.rand() * 3;
      if (e.half) t.half = e.half;
      if (kind === 'sandship') { const ph = Math.max(2, Math.round(e.partHp * d.bossHp)); t.parts = [-1.7, 0, 1.7].map((ox, i) => ({ ox, hp: ph, maxHp: ph, cd: 1.5 + i * 0.6, ang: Math.PI / 2, flash: 0 })); t.dir = 3; t.mode = 'ship'; } }
    if (e.captain) { t.aura = CAPTAIN_KINDS[Math.floor(g.rand() * CAPTAIN_KINDS.length)]; t.auraT = 2; t.captain = true; }
    if (e.elite) { t.hp = t.maxHp = Math.round((e.hp + bonus) * d.bossHp); t.glow = true; }
    if (t.boss) initWeak(g, t);   // P2-39：弱点・こわせる部位
    if (t.boss && g.stage && g.stage.p4b) p4bBossInit(g, t);   // P4B
    g.tanks.push(t); return t;
  }
  function enemyThink(g, t, dt, d) {
    const e = ENEMY[t.kind];
    if (g.stopT > 0 || t.freeze > 0) return;
    // 磁場の中では、速さ・撃つ回数・体力が下がる（体力は 1 段ごとに 1 回だけ）
    const fm = fieldMul(g, t);
    if (fm < 1 && !t.boss) { const want = g.slow * FIELD_DEBUFF; if (want > t.fieldApplied) { const base = t.baseHp || (t.baseHp = t.maxHp); const mx = Math.max(1, base - Math.floor(base * want + 1e-9)); t.hp = Math.max(1, t.hp - (t.maxHp - mx)); t.maxHp = mx; t.fieldApplied = want; } }
    t.cd -= dt * fm; t.modeT -= dt;
    if (t.modeT <= 0) { t.mode = pickMode(g, t, d); t.modeT = 8; }
    let spd = e.speed * t.speedMul * fm * groundSpeed(g, t);
    if (t.kind === 'sniper' && t.aim > 0) { t.aim -= dt; if (t.aim <= 0) { t.dir = t.aimDir; t.cd = 0; t.out = 0; fire(g, t); } return; }
    if (t.kind === 'sniper' && t.cd <= 0) {
      const tgts = [{ x: g.hx, y: g.hy }].concat(g.tanks.filter(o => o.side === 'p' && o.alive && !(fxOf(g).jungle && inTrees(g, o))));
      for (const o of tgts) {
        if (Math.abs(o.x - t.x) < 0.6 && Math.abs(o.y - t.y) < 16) { t.aim = SNIPE_AIM; t.aimDir = o.y > t.y ? 2 : 0; break; }
        if (Math.abs(o.y - t.y) < 0.6 && Math.abs(o.x - t.x) < 16) { t.aim = SNIPE_AIM; t.aimDir = o.x > t.x ? 1 : 3; break; }
      }
      if (t.aim > 0) { t.dir = t.aimDir; g.ev.push({ k: 'aim' }); return; }
    }
    if (t.kind === 'rammer') {
      const tg = nearestPlayerTank(g, t.x, t.y, true);
      if (t.charge <= 0 && tg && Math.hypot(tg.x - t.x, tg.y - t.y) < RAM_RANGE) { t.charge = RAM_SEC; g.texts.push({ x: t.x, y: t.y - 1.4, s: 'とっしん！', zh: '冲撞！', t: 0.9, col: '#ff7a7a' }); }
      if (t.charge > 0) {
        t.charge -= dt;
        if (tg) { const dx = tg.x - t.x, dy = tg.y - t.y; t.want = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0); }
        moveTank(g, t, t.want, RAM_SPEED * t.speedMul * fm, dt);
        if ((tg && Math.hypot(tg.x - t.x, tg.y - t.y) < 2.1) || t.charge <= 0 || t.blocked) { t.alive = false; explode(g, t.x, t.y, RAM_R, 'e', true); }
        return;
      }
    }
    if (t.kind === 'miner') {
      t.mineCd -= dt;
      if (t.mineCd <= 0) { t.mineCd = MINE_EVERY; if (g.mines.filter(m => m.owner === t && !m.dead).length < MINE_MAX) { g.mines.push({ x: t.x, y: t.y, t: MINE_LIFE, arm: MINE_ARM, owner: t }); g.ev.push({ k: 'mine' }); } }
    }
    if (t.kind === 'mortar' && t.cd <= 0) {
      t.cd = (e.cd[0] + g.rand() * (e.cd[1] - e.cd[0])) * t.fireMul;
      let tx, ty; const live = g.tanks.filter(o => o.side === 'p' && o.alive);
      if (g.truck && (g.rand() < MORTAR_RING_RATE || !live.length)) { tx = g.truck.x; ty = g.truck.y; }
      else if (g.ring.length && (g.rand() < MORTAR_RING_RATE || !live.length)) { const r = g.ring[Math.floor(g.rand() * g.ring.length)]; tx = r[0] + 0.5; ty = r[1] + 0.5; }
      else if (!live.length) { t.cd = 1; return; }
      else { const o = live[Math.floor(g.rand() * live.length)]; tx = o.x; ty = o.y; }
      g.shells.push({ x: tx, y: ty, fx: t.x, fy: t.y, t: MORTAR_FLIGHT, T: MORTAR_FLIGHT, r: MORTAR_R }); g.ev.push({ k: 'mortar' });
    }
    if (t.boss) { const bdt = g.p3dDuel && g.p3dDuel.tempo ? dt * g.p3dDuel.tempo : dt;   // P3D-duel：けっとうの ボスは ゆっくり 考える（こうげきの 間が のびる）
      if (g.stage && g.stage.p4b) { if (p4bBossStep(g, t, bdt, d)) return; } else   // P4B：ボスちょうせん（こうげきの間・段階・かりた わざ）
      if (ADV_BOSS[t.kind]) { if (advBoss(g, t, bdt, d)) return; } else bossThink(g, t, bdt, d); }
    if (!t.boss && g.hasteCaps && g.hasteCaps.length) for (const c of g.hasteCaps) if (c !== t && Math.hypot(c.x - t.x, c.y - t.y) < AURA_R) { spd *= 1.3; break; }
    t.ai -= dt;
    const aligned = Math.abs(t.x - Math.round(t.x)) < 0.08 && Math.abs(t.y - Math.round(t.y)) < 0.08;
    if (t.blocked && t.cd <= 0 && g.rand() < 0.6 && t.kind !== 'mortar') fire(g, t);
    if (t.blocked || t.ai <= 0 || (aligned && t.mode === 'house' && g.rand() < 0.08)) { t.want = chooseDir(g, t); t.ai = 0.8 + g.rand() * 1.8; }
    if (t.boss && t.laserAim > 0) return;
    if (t.boss && t.hp < t.maxHp / 2) spd *= 1.5;
    if (t.kind === 'superboss') spd *= 1 + (1 - t.hp / t.maxHp) * 0.6;
    moveTank(g, t, t.want, spd, dt);
    if (!t.boss && t.kind !== 'mortar' && t.kind !== 'sniper' && t.cd <= 0) fire(g, t);
  }
  function bossThink(g, t, dt, d) {
    const rate = t.kind === 'superboss' ? 0.5 + 0.5 * (t.hp / t.maxHp) : 1;
    const tick = cd => cd - dt / rate;
    t.spreadCd = tick(t.spreadCd);
    if (t.spreadCd <= 0) {
      const angs = t.kind === 'superboss' ? [-0.7, -0.35, 0, 0.35, 0.7] : [-0.44, 0, 0.44];
      for (const a of angs) fireAngle(g, t, a, ENEMY[t.kind].bullet); t.spreadCd = ENEMY[t.kind].cd[0]; g.ev.push({ k: 'efire' });
    }
    t.summonCd = tick(t.summonCd);
    const minions = g.tanks.filter(o => o.alive && o.minion).length, maxM = t.kind === 'superboss' ? 3 : 2;
    if (t.summonCd <= 0 && (t.kind === 'superboss' || t.hp < t.maxHp / 2)) {
      t.summonCd = t.kind === 'superboss' ? 10 : 12;
      let made = 0;
      while (made < 2 && minions + made < maxM) {
        const sp = findFree(g, Math.round(t.x), Math.round(t.y), 7) || g.gates.find(gt => placeFree(g, gt.x, gt.y, HALF)); if (!sp) break;
        spawnEnemy(g, g.rand() < 0.5 ? 'fast' : 'normal', sp.x, sp.y, d, { minion: true }); made++;
      }
    }
    if (t.kind !== 'superboss') return;
    t.missileCd = tick(t.missileCd);
    if (t.missileCd <= 0) { t.missileCd = 5; for (const a of [-1.2, 1.2]) { const base = Math.atan2(DY[t.dir], DX[t.dir]) + a; g.missiles.push({ x: t.x, y: t.y, ang: base, t: MISSILE_LIFE }); } g.ev.push({ k: 'missile' }); }
    if (t.laserAim > 0) { t.laserAim -= dt; if (t.laserAim <= 0) { g.beams.push({ x: t.x, y: t.y, dir: t.dir, t: LASER_SEC, owner: t }); g.ev.push({ k: 'laser' }); g.shake = Math.max(g.shake, 0.3); } }
    else { t.laserCd = tick(t.laserCd); if (t.laserCd <= 0) { t.laserCd = 9; t.laserAim = LASER_AIM; } }
    t.snipeCd = tick(t.snipeCd);
    if (t.snipeCd <= 0) {
      if (Math.abs(t.x - g.hx) < 1.2) { t.snipeCd = 12; t.dir = 2; fireAngle(g, t, 0, 22, { r: 0.4, pierce: 3 }); g.ev.push({ k: 'efire' }); g.texts.push({ x: t.x, y: t.y - 2.5, s: 'おうちをねらってる！', zh: '瞄准小屋了！', t: 1.4, col: '#ff7a7a' }); }
      else { t.want = g.hx > t.x ? 1 : 3; t.ai = 1; }
    }
  }
  /* ---------- ぼうけんのボス 6 体（v0.11）。どれも体力が減ると技が変わる（段階）。大きな技の前には必ず予告を出す。
     戻り値 true＝この刻みはふつうの動き（道さがし）をしない ---------- */
  function fireAt(g, t, ang, speed, extra, ox, oy) {
    if (t.boss && g.stage && g.stage.p4b) { speed *= g.stage.p4b.bul || 1; if (g.stage.p4b.ap) extra = Object.assign({ p4bAp: g.stage.p4b.ap }, extra); }   // P4B
    const x = (ox === undefined ? t.x : ox) + Math.cos(ang) * t.half * 0.9, y = (oy === undefined ? t.y : oy) + Math.sin(ang) * t.half * 0.9;
    addBullet(g, Object.assign({ x, y, vx: Math.cos(ang) * speed, vy: Math.sin(ang) * speed, side: 'e', owner: null, r: 0.3, kind: 'boss' }, extra));
  }
  function summon(g, t, d, n, max) {
    if (g.p3dDuel) return;   // P3D-duel：けっとうでは なかまを よばない
    const live = g.tanks.filter(o => o.alive && o.minion).length; let made = 0;
    while (made < n && live + made < max) {
      const sp = findFree(g, Math.round(t.x), Math.round(t.y), 7) || g.gates.find(gt => placeFree(g, gt.x, gt.y, HALF)); if (!sp) break;
      spawnEnemy(g, g.rand() < 0.5 ? 'fast' : 'normal', sp.x, sp.y, d, { minion: true }); made++;
    }
    if (made) g.texts.push({ x: t.x, y: t.y - 2.4, s: 'なかまを よんだ！', zh: '叫来了同伴！', t: 1.1, col: '#ffb347' });
  }
  function phaseUp(g, t, ph, ja, zh) { if (t.phase >= ph) return; t.phase = ph; g.shake = Math.max(g.shake, 0.35); g.texts.push({ x: t.x, y: t.y - 2.6, s: ja, zh, t: 1.6, col: '#ff7a5c', big: 2 }); g.ev.push({ k: 'bossphase' }); }
  function axisDirTo(t, o) { const dx = o.x - t.x, dy = o.y - t.y; return Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0); }
  function findFreeBig(g, x, y, r, h) {
    for (let k = 0; k <= r; k++) for (let dy = -k; dy <= k; dy++) for (let dx = -k; dx <= k; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) !== k) continue; const nx = Math.round(x) + dx, ny = Math.round(y) + dy;
      if (nx >= 2 && ny >= 2 && nx <= g.cols - 2 && ny <= g.rows - 7 && placeFree(g, nx, ny, h)) return { x: nx, y: ny };
    }
    return null;
  }
  // 工兵車：味方の前（味方と自分の間）に 2 × 2 のレンガを積む。おうちのまわり・出口・戦車の上には積まない
  function canBuild(g, cx, cy) {
    if (cy < 3 || cy > g.rows - 7 || cx < 2 || cx > g.cols - 2) return false;
    for (let y = cy - 1; y <= cy; y++) for (let x = cx - 1; x <= cx; x++) { const c = tileAt(g, x, y); if (c !== '.' && c !== 'D') return false; }
    if (g.gates.some(gt => Math.abs(gt.x - cx) < 3 && cy < 5)) return false;
    if (Math.abs(cx - g.hx) < 5 && cy > g.rows - 9) return false;
    for (const o of g.tanks) if (o.alive && Math.abs(o.x - cx) < o.half + 1.1 && Math.abs(o.y - cy) < o.half + 1.1) return false;
    for (const it of g.items) if (Math.abs(it.x - cx) < 2 && Math.abs(it.y - cy) < 2) return false;
    return true;
  }
  function buildWall(g, t) {
    const tg = nearestPlayerTank(g, t.x, t.y) || { x: g.hx, y: g.rows - 8 };
    for (let k = 0; k < 16; k++) {
      const r = 2.6 + g.rand() * 3, a = Math.atan2(t.y - tg.y, t.x - tg.x) + (g.rand() - 0.5) * 1.4;
      const cx = Math.round(tg.x + Math.cos(a) * r), cy = Math.round(tg.y + Math.sin(a) * r);
      if (!canBuild(g, cx, cy)) continue;
      for (let y = cy - 1; y <= cy; y++) for (let x = cx - 1; x <= cx; x++) g.map[y][x] = 'B';
      g.mapVer++; g.distDirty = true; t.built++; g.fx.push({ k: 'dust', x: cx, y: cy, t: 0.35, T: 0.35 }); g.ev.push({ k: 'brick' });
      if (g.rand() < 0.35) g.texts.push({ x: cx, y: cy - 1.2, s: 'かべ、できた！', zh: '墙砌好了！', t: 1, col: '#ffd27a' });
      return true;
    }
    return false;
  }
  function advBoss(g, t, dt, d) {
    const f = t.hp / t.maxHp, e = ENEMY[t.kind], near = nearestPlayerTank(g, t.x, t.y, true), base = Math.atan2(DY[t.dir], DX[t.dir]);
    if (t.kind === 'twin') {
      if (f < 0.5) phaseUp(g, t, 2, 'ふたりで本気だ！', '兄弟认真了！');
      t.sideCd -= dt; t.atkCd -= dt; t.talkT -= dt; t.summonCd -= dt;
      if (t.sideCd <= 0) {   // 左右の砲塔：1 段目は片側ずつ、2 段目は両側と斜め
        t.sideN = (t.sideN || 0) + 1; const side = t.sideN % 2 ? 1 : -1;
        const angs = t.phase >= 2 ? [base + Math.PI / 2, base - Math.PI / 2, base + Math.PI / 2 + 0.35, base - Math.PI / 2 - 0.35] : [base + side * Math.PI / 2, base + side * (Math.PI / 2 + 0.3)];
        for (const a of angs) fireAt(g, t, a, e.bullet); t.sideCd = t.phase >= 2 ? 1.25 : 1.5; g.ev.push({ k: 'efire' });
      }
      if (t.atkCd <= 0) { for (const a of t.phase >= 2 ? [-0.3, 0, 0.3] : [0]) fireAt(g, t, base + a, e.bullet); t.atkCd = 2.1; }
      if (t.phase >= 2 && t.summonCd <= 0) { t.summonCd = 12; summon(g, t, d, 2, 2); }
      if (t.talkT <= 0) { t.talkT = 6 + g.rand() * 4; const L = g.rand() < 0.5; g.texts.push({ x: t.x + (L ? -1.6 : 1.6), y: t.y - 2.2, s: L ? 'みぎだ！' : 'ひだりだ！', zh: L ? '右边！' : '左边！', t: 1.2, col: '#ffe08a' }); }
      return false;
    }
    if (t.kind === 'engineer') {
      if (f < 0.5) phaseUp(g, t, 2, 'もっと つむぞ！', '再多砌点！');
      t.buildCd -= dt; t.atkCd -= dt; t.summonCd -= dt;
      if (t.buildCd <= 0 && t.built < (t.phase >= 2 ? 30 : 20)) { buildWall(g, t); t.buildCd = t.phase >= 2 ? 2.8 : 4.5; }
      if (t.atkCd <= 0) { const a = near ? Math.atan2(near.y - t.y, near.x - t.x) : base; for (const o of [-0.35, 0, 0.35]) fireAt(g, t, a + o, e.bullet); t.atkCd = t.phase >= 2 ? 2.0 : 2.4; g.ev.push({ k: 'efire' }); }
      if (t.phase >= 2 && t.summonCd <= 0) { t.summonCd = 12; summon(g, t, d, 2, 2); }
      return false;
    }
    if (t.kind === 'bigtank') {   // 大型戦車：3 段階（今のボスを作り直した）
      if (f < 0.66) phaseUp(g, t, 2, 'まだまだ！', '还没完！');
      if (f < 0.33) phaseUp(g, t, 3, '本気を見せよう', '让你们见识真本事');
      t.atkCd -= dt; t.summonCd -= dt; t.missileCd -= dt; t.snipeCd -= dt;
      if (t.atkCd <= 0) { const angs = t.phase >= 2 ? [-0.7, -0.35, 0, 0.35, 0.7] : [-0.44, 0, 0.44]; for (const a of angs) fireAt(g, t, base + a, e.bullet); t.atkCd = t.phase >= 2 ? 1.7 : 2.0; g.ev.push({ k: 'efire' }); }
      if (t.phase >= 2 && t.summonCd <= 0) { t.summonCd = 11; summon(g, t, d, 2, 3); }
      if (t.phase >= 3) {
        if (t.missileCd <= 0) { t.missileCd = 6; for (const a of [-1.2, 1.2]) g.missiles.push({ x: t.x, y: t.y, ang: base + a, t: MISSILE_LIFE }); g.ev.push({ k: 'missile' }); }
        if (t.snipeCd <= 0) {
          if (Math.abs(t.x - g.hx) < 1.2 && t.y < g.hy - 6) { t.snipeCd = 10; t.dir = 2; fireAt(g, t, Math.PI / 2, 20, { r: 0.4, pierce: 3 }); g.ev.push({ k: 'efire' }); g.texts.push({ x: t.x, y: t.y - 2.5, s: 'おうちを ねらってる！', zh: '瞄准小屋了！', t: 1.4, col: '#ff7a7a' }); }
          else { t.want = g.hx > t.x ? 1 : 3; t.ai = 1; }
        }
      }
      return false;
    }
    if (t.kind === 'burrower') {   // 砂もぐり：もぐる → 予告の印 → 出てきて輪の弾
      if (f < 0.5) phaseUp(g, t, 2, 'もう かくれない…！', '不躲了…！');
      t.stT -= dt;
      if (t.st === 'surf') {
        t.atkCd -= dt; if (t.atkCd <= 0 && near) { fireAt(g, t, Math.atan2(near.y - t.y, near.x - t.x), e.bullet); t.atkCd = t.phase >= 2 ? 0.9 : 1.2; g.ev.push({ k: 'efire' }); }
        if (t.stT <= 0) { t.st = 'dig'; t.stT = 0.7; g.texts.push({ x: t.x, y: t.y - 2, s: 'ズボッ', zh: '噗', t: 0.8, col: '#e9d3a0' }); g.fx.push({ k: 'dust', x: t.x, y: t.y + 1, t: 0.5, T: 0.5 }); }
        return false;
      }
      if (t.st === 'dig') { if (t.stT <= 0) { t.st = 'under'; t.under = true; t.stT = t.phase >= 2 ? 1.3 : 1.8; const live = g.tanks.filter(o => o.side === 'p' && o.alive);
          const tg = live.length && g.rand() < 0.7 ? live[Math.floor(g.rand() * live.length)] : { x: g.hx + (g.rand() < 0.5 ? -7 : 7), y: g.rows - 9 };
          const a = g.rand() * Math.PI * 2, r = 4 + g.rand() * 2; t.tx = clamp(tg.x + Math.cos(a) * r, 3, g.cols - 3); t.ty = clamp(tg.y + Math.sin(a) * r, 3, g.rows - 8); } return true; }
      if (t.st === 'under') {
        if (t.stT > 0) return true;
        const sp = findFreeBig(g, t.tx, t.ty, 6, BOSS_HALF); if (!sp) { t.stT = 0.3; t.tx = g.cols / 2; t.ty = 6; return true; }
        t.x = sp.x; t.y = sp.y; t.under = false; t.st = 'surf'; t.stT = t.phase >= 2 ? 3 : 4.5; t.atkCd = 0.8;
        const nRing = t.phase >= 2 ? 12 : 8; for (let i = 0; i < nRing; i++) fireAt(g, t, i * Math.PI * 2 / nRing, e.bullet * 0.8);
        g.shake = Math.max(g.shake, 0.4); g.fx.push({ k: 'boom', x: t.x, y: t.y, r: 1.8, t: 0.5, T: 0.5 }); g.ev.push({ k: 'bigboom' });
        return true;
      }
      return false;
    }
    if (t.kind === 'scorpion') {   // さそり戦車：はさみの弾と、予告してから しっぽのレーザー
      if (f < 0.5) phaseUp(g, t, 2, 'しっぽが うなるぞ！', '尾巴要发威了！');
      t.atkCd -= dt;
      if (t.laserAim > 0) { t.laserAim -= dt; if (t.laserAim <= 0) { g.beams.push({ x: t.x, y: t.y, dir: t.dir, t: LASER_SEC, owner: t }); g.ev.push({ k: 'laser' }); g.shake = Math.max(g.shake, 0.3); } return true; }
      t.lzCd -= dt;
      if (t.lzCd <= 0 && near) { t.dir = axisDirTo(t, near); t.laserAim = 1.3; t.lzCd = t.phase >= 2 ? 4.5 : 7; g.texts.push({ x: t.x, y: t.y - 2.4, s: 'しっぽビーム！', zh: '尾巴光束！', t: 1.2, col: '#ff7a7a' }); g.ev.push({ k: 'aim' }); return true; }
      if (t.atkCd <= 0) { const angs = t.phase >= 2 ? [-1.2, -0.45, 0.45, 1.2] : [-0.45, 0.45]; for (const a of angs) fireAt(g, t, base + a, e.bullet); t.atkCd = t.phase >= 2 ? 1.5 : 2.1; g.ev.push({ k: 'efire' }); }
      return false;
    }
    if (t.kind === 'sandship') {   // 砂上戦艦：横に行き来する。砲塔 3 つを壊すと体に当たるようになる
      const armored = t.parts.some(q => q.hp > 0), spd = (armored ? 1.6 : 2.6) * t.speedMul * dt;
      const L = Math.max(3, g.hx - 8), R = Math.min(g.cols - 3, g.hx + 8);
      let dir = t.dir === 1 ? 1 : -1; const nx = t.x + dir * spd;
      if (nx < L || nx > R || boxHitsWall(g, nx, t.y, t.half) || boxHitsTank(g, t, nx, t.y, t.half)) { dir = -dir; t.dir = dir > 0 ? 1 : 3; } else t.x = nx;
      t.moving = true;
      for (const q of t.parts) {
        if (q.flash > 0) q.flash -= dt; if (q.hp <= 0) continue;
        const qx = t.x + q.ox, tg = nearestPlayerTank(g, qx, t.y, true); if (tg) q.ang = Math.atan2(tg.y - t.y, tg.x - qx);
        q.cd -= dt; if (q.cd <= 0 && tg) { q.cd = 2.4 + g.rand() * 0.6; addBullet(g, { x: qx + Math.cos(q.ang) * 0.9, y: t.y + Math.sin(q.ang) * 0.9, vx: Math.cos(q.ang) * e.bullet, vy: Math.sin(q.ang) * e.bullet, side: 'e', owner: null, r: 0.3, kind: 'boss' }); g.ev.push({ k: 'efire' }); }
      }
      if (!armored) {
        t.atkCd -= dt; t.summonCd -= dt;
        if (t.atkCd <= 0) { for (const a of [-0.6, -0.3, 0, 0.3, 0.6]) fireAt(g, t, Math.PI / 2 + a, e.bullet); t.atkCd = 2; g.ev.push({ k: 'efire' }); }
        if (t.summonCd <= 0) { t.summonCd = 10; summon(g, t, d, 2, 3); }
      }
      return true;
    }
    if (V13_BOSS[t.kind]) return V13_BOSS[t.kind](g, t, dt, d, f, e, near, base);
    return false;
  }
  /* ---------- 世界 3 雪山・世界 4 火山のボス（v0.13） ---------- */
  function d0(g) { return diff(g); }
  // 体当たり（除雪車・雪だるま）：予告の帯（laserAim を借りて画面に出す）→ まっすぐ突っ込む。レンガは 1 発で壊す。鋼・水・おうちの囲いで止まる
  function startRam(g, t, tg, ja, zh) { t.dir = axisDirTo(t, tg); t.ram = RAM_WARN; t.laserAim = RAM_WARN; t.ramT = 0; g.texts.push({ x: t.x, y: t.y - 2.4, s: ja, zh, t: 1.1, col: '#ffe08a' }); g.ev.push({ k: 'aim' }); }
  function stepRam(g, t, dt) {
    if (t.ram > 0) { t.ram -= dt; t.laserAim = Math.max(0, t.ram); if (t.ram <= 0) { t.ramT = 2.2; t.laserAim = 0; g.ev.push({ k: 'bossphase' }); } return true; }
    if (!(t.ramT > 0)) return false;
    t.ramT -= dt; const st = RAM_FAST * dt / MOVE_STEPS; t.moving = true;
    for (let i = 0; i < MOVE_STEPS; i++) {
      const nx = t.x + DX[t.dir] * st, ny = t.y + DY[t.dir] * st, h = t.half;
      const x0 = Math.floor(nx - h), x1 = Math.floor(nx + h - 1e-6), y0 = Math.floor(ny - h), y1 = Math.floor(ny + h - 1e-6); let stop = false;
      for (let cy = y0; cy <= y1 && !stop; cy++) for (let cx = x0; cx <= x1; cx++) { const c = tileAt(g, cx, cy);
        if (c === '#' || c === 'S' || c === 'W' || c === 'H' || c === 'G' || c === 'K' || ((c === 'B' || c === 'b') && isRing(g, cx, cy))) { stop = true; break; }
        if (c === 'B' || c === 'b') breakTile(g, cx, cy, false, true, true); }
      if (!stop && g.truck && !g.truck.dead && Math.abs(g.truck.x - nx) < h + g.truck.half && Math.abs(g.truck.y - ny) < h + g.truck.half) { stop = true; hitTruck(g, 2); }
      if (!stop) for (const o of g.tanks) { if (o === t || !o.alive || o.under) continue; const m = h + o.half; if (Math.abs(o.x - nx) < m && Math.abs(o.y - ny) < m) { if (o.side === 'p') { if (!killPlayer(g, o, 'ram') && o.alive) stop = true; } else stop = true; } }
      if (stop || boxHitsWall(g, nx, ny, h)) { t.ramT = 0; t.stun = 0; t.freeze = 0.7; g.shake = Math.max(g.shake, 0.35); g.fx.push({ k: 'dust', x: nx + DX[t.dir] * h, y: ny + DY[t.dir] * h, t: 0.4, T: 0.4 }); g.texts.push({ x: t.x, y: t.y - 2.2, s: 'ゴン！', zh: '咚！', t: 0.8, col: '#ffd27a' }); g.ev.push({ k: 'bigboom' }); break; }
      t.x = nx; t.y = ny;
    }
    return true;
  }
  // 上から落ちてくる物（雪玉・火の玉・溶岩のかたまり）：落ちる所に印を出し、tt 秒後に爆発
  function lob(g, t, x, y, tt, r, kind) { g.shells.push({ x: clamp(x, 1, g.cols - 1), y: clamp(y, 1, g.rows - 1), fx: t.x, fy: t.y, t: tt, T: tt, r, kind }); }
  function lobAtPlayers(g, t, n, tt, r, kind, spread) {
    const live = g.tanks.filter(o => o.side === 'p' && o.alive);
    for (let i = 0; i < n; i++) { const o = live.length ? live[i % live.length] : { x: g.hx, y: g.rows - 8 }, a = g.rand() * Math.PI * 2, rr = i < live.length ? g.rand() * 0.8 : 1.5 + g.rand() * spread;
      lob(g, t, o.x + Math.cos(a) * rr, o.y + Math.sin(a) * rr, tt, r, kind); }
    g.ev.push({ k: 'mortar' });
  }
  function addPool(g, x, y) { if (tileAt(g, Math.floor(x), Math.floor(y)) === 'H') return; g.pools.push({ x, y, r: POOL_R, t: POOL_LIFE, arm: POOL_ARM }); if (g.pools.length > POOL_MAX) g.pools.shift(); }
  function ring(g, t, n, speed, extra) { const o = g.rand() * Math.PI; for (let i = 0; i < n; i++) fireAt(g, t, o + i * Math.PI * 2 / n, speed, extra); g.ev.push({ k: 'efire' }); }
  function splitSnowman(g, t, d) {
    let made = 0;
    for (const ox of [-1.8, 1.8]) { const sp = findFreeBig(g, t.x + ox, t.y, 5, ENEMY.snowkid.half); if (!sp) continue; const k = spawnEnemy(g, 'snowkid', sp.x, sp.y, d); k.cd = 0.6; k.atkCd = 1 + made * 0.5; k.shield = 0; made++; }
    g.texts.push({ x: t.x, y: t.y - 2.6, s: made ? 'ふたつに わかれた！' : 'まだまだ！', zh: made ? '分成两个了！' : '还没完！', t: 1.6, col: '#bfe9ff', big: 2 }); g.ev.push({ k: 'bossphase' });
    if (!made) { const k = spawnEnemy(g, 'snowkid', clamp(Math.round(t.x), 2, g.cols - 2), clamp(Math.round(t.y), 2, g.rows - 7), d); k.atkCd = 1; }
  }
  const V13_BOSS = {
    plow(g, t, dt, d, f, e, near, base) {   // 除雪車：予告してから まっすぐ体当たり（レンガを片づける）。雪玉を投げる
      if (f < 0.5) phaseUp(g, t, 2, 'ぜんりょく じょせつ！', '全力除雪！');
      if (stepRam(g, t, dt)) return true;
      t.ramCd = (t.ramCd === undefined ? 4 : t.ramCd) - dt; t.atkCd -= dt; t.summonCd -= dt;
      if (t.ramCd <= 0 && near && Math.hypot(near.x - t.x, near.y - t.y) < 16) { t.ramCd = t.phase >= 2 ? 4 : 6.5; startRam(g, t, near, 'ブルルン！', '轰隆隆！'); return true; }
      if (t.atkCd <= 0) { t.atkCd = t.phase >= 2 ? 2.6 : 3.2; lobAtPlayers(g, t, t.phase >= 2 ? 3 : 2, 1.3, 1.25, 'snow', 2); }
      if (t.phase >= 2 && t.summonCd <= 0) { t.summonCd = 13; summon(g, t, d, 2, 2); }
      return false;
    },
    icegun(g, t, dt, d, f, e, near, base) {   // 氷の砲台：ふつうの弾と、当たると動けなくなる氷の弾。2 段目は氷の輪と、足もとを凍らせる
      if (f < 0.5) { if (t.phase < 2) iceFloor(g, t); phaseUp(g, t, 2, 'こおりつけ…', '冻住吧…'); }
      t.atkCd -= dt; t.iceCd = (t.iceCd === undefined ? 1.5 : t.iceCd) - dt; t.lzCd -= dt;
      if (t.atkCd <= 0) { const a = near ? Math.atan2(near.y - t.y, near.x - t.x) : base; for (const o of [-0.4, 0, 0.4]) fireAt(g, t, a + o, e.bullet); t.atkCd = 2.3; g.ev.push({ k: 'efire' }); }
      if (t.iceCd <= 0 && near) { t.iceCd = t.phase >= 2 ? 2.4 : 3.2; const a = Math.atan2(near.y - t.y, near.x - t.x); for (const o of t.phase >= 2 ? [-0.2, 0.2] : [0]) fireAt(g, t, a + o, 7.5, { freeze: true, r: 0.38, kind: 'ice' }); g.ev.push({ k: 'efire' }); }
      if (t.phase >= 2 && t.lzCd <= 0) { t.lzCd = 7; ring(g, t, 10, 6.5, { freeze: true, r: 0.36, kind: 'ice' }); }
      return false;
    },
    snowman(g, t, dt, d, f, e, near, base) {   // 雪だるま戦車：雪玉を広く撃つ。2 段目は転がって体当たり
      if (f < 0.5) phaseUp(g, t, 2, 'ころころ いくよー！', '滚过去啦！');
      if (stepRam(g, t, dt)) return true;
      t.atkCd -= dt; t.summonCd -= dt; t.ramCd = (t.ramCd === undefined ? 5 : t.ramCd) - dt;
      if (t.phase >= 2 && t.ramCd <= 0 && near) { t.ramCd = 6; startRam(g, t, near, 'ころころー！', '咕噜咕噜！'); return true; }
      if (t.atkCd <= 0) { for (const a of [-0.7, -0.35, 0, 0.35, 0.7]) fireAt(g, t, base + a, e.bullet, { kind: 'snow' }); t.atkCd = t.phase >= 2 ? 2.0 : 2.4; g.ev.push({ k: 'efire' }); }
      if (t.summonCd <= 0) { t.summonCd = 12; summon(g, t, d, 2, 2); }
      return false;
    },
    snowkid(g, t, dt, d, f, e, near, base) {   // 雪だるまのこども：すばやく近づいて、2 つの雪玉
      t.atkCd -= dt;
      if (t.atkCd <= 0 && near) { const a = Math.atan2(near.y - t.y, near.x - t.x); for (const o of [-0.25, 0.25]) fireAt(g, t, a + o, e.bullet, { kind: 'snow' }); t.atkCd = 1.6; g.ev.push({ k: 'efire' }); }
      return false;
    },
    flamer(g, t, dt, d, f, e, near, base) {   // 火炎放射車：近くで止まって、前に炎（短い距離・壁で消える）。2 段目は まわり全部に炎
      if (f < 0.5) phaseUp(g, t, 2, 'まだ もえたりないィ！', '还没烧够！');
      t.atkCd -= dt; t.summonCd -= dt; t.lzCd -= dt;
      if (t.flame > 0) {   // 予告（0.6 秒）→ 炎
        t.flame -= dt; if (near) t.dir = axisDirTo(t, near);
        if (t.flame < t.flameLen) { t.flT = (t.flT || 0) - dt; while (t.flT <= 0) { t.flT += 0.07; const a = Math.atan2(DY[t.dir], DX[t.dir]) + (g.rand() - 0.5) * 0.65; fireAt(g, t, a, 6.5, { life: 0.75, r: 0.36, kind: 'flame', soft: true, ghost: true }); } }
        return true;
      }
      if (near && t.atkCd <= 0 && Math.hypot(near.x - t.x, near.y - t.y) < 7.5) { t.flameLen = t.phase >= 2 ? 2.4 : 1.8; t.flame = t.flameLen + 0.6; t.flT = 0; t.atkCd = t.phase >= 2 ? 3.2 : 4.2; t.dir = axisDirTo(t, near); g.texts.push({ x: t.x, y: t.y - 2.4, s: 'ゴォォ…', zh: '呼——', t: 0.9, col: '#ffb35a' }); g.ev.push({ k: 'aim' }); return true; }
      if (t.atkCd <= 0) { const a = near ? Math.atan2(near.y - t.y, near.x - t.x) : base; for (const o of [-0.2, 0.2]) fireAt(g, t, a + o, e.bullet); t.atkCd = 2.2; g.ev.push({ k: 'efire' }); }
      if (t.phase >= 2 && t.lzCd <= 0) { t.lzCd = 6.5; ring(g, t, 18, 6, { life: 0.95, r: 0.36, kind: 'flame', soft: true, ghost: true }); g.texts.push({ x: t.x, y: t.y - 2.4, s: 'ぐるっと ファイヤー！', zh: '旋转火焰！', t: 1, col: '#ff8a3a' }); }
      if (t.phase >= 2 && t.summonCd <= 0) { t.summonCd = 13; summon(g, t, d, 2, 2); }
      return false;
    },
    golem(g, t, dt, d, f, e, near, base) {   // 溶岩ごれむ：歩いた所に溶岩だまり。ときどき地面をたたいて輪の弾。2 段目は溶岩のかたまりを投げる
      if (f < 0.5) phaseUp(g, t, 2, 'あつく… なってきた…', '变…热了…');
      t.atkCd -= dt; t.summonCd -= dt; t.lzCd -= dt;
      if (t.lastPool === undefined || Math.hypot(t.x - t.lastPool[0], t.y - t.lastPool[1]) > 1.3) { t.lastPool = [t.x, t.y]; addPool(g, t.x, t.y); }
      if (t.slam > 0) { t.slam -= dt; if (t.slam <= 0) { ring(g, t, t.phase >= 2 ? 14 : 10, 6); g.shake = Math.max(g.shake, 0.45); g.fx.push({ k: 'boom', x: t.x, y: t.y + 0.8, r: 2.2, t: 0.5, T: 0.5 }); g.ev.push({ k: 'bigboom' }); } return true; }
      if (t.atkCd <= 0) { t.atkCd = t.phase >= 2 ? 3.6 : 5; t.slam = 0.8; g.texts.push({ x: t.x, y: t.y - 2.4, s: 'ドスン…！', zh: '咚…！', t: 0.9, col: '#ffb35a' }); return true; }
      if (t.phase >= 2 && t.lzCd <= 0) { t.lzCd = 4.2; lobAtPlayers(g, t, 2, 1.4, 1.2, 'lava', 2); }
      if (t.phase >= 2 && t.summonCd <= 0) { t.summonCd = 14; summon(g, t, d, 2, 2); }
      return false;
    },
    dragon(g, t, dt, d, f, e, near, base) {   // 火竜戦車：空から火の玉（落ちる所に印）。2 段目はほのおの息（予告つき）、3 段目は火の雨
      if (f < 0.66) phaseUp(g, t, 2, 'つばさが なくとも…！', '纵然没有翅膀…！');
      if (f < 0.33) phaseUp(g, t, 3, 'そらよ、もえよ！', '天空啊，燃烧吧！');
      t.atkCd -= dt; t.missileCd -= dt; t.summonCd -= dt; t.lzCd -= dt; t.snipeCd -= dt;
      if (t.laserAim > 0) { t.laserAim -= dt; if (t.laserAim <= 0) { g.beams.push({ x: t.x, y: t.y, dir: t.dir, t: LASER_SEC, owner: t, fire: true }); g.ev.push({ k: 'laser' }); g.shake = Math.max(g.shake, 0.3); } return true; }
      if (t.missileCd <= 0) { t.missileCd = t.phase >= 3 ? 2.2 : t.phase >= 2 ? 2.7 : 3.2; lobAtPlayers(g, t, t.phase + 1, 1.6, 1.5, 'fire', 3); }
      if (t.phase >= 2 && t.lzCd <= 0 && near) { t.lzCd = t.phase >= 3 ? 5 : 6.5; t.dir = axisDirTo(t, near); t.laserAim = 1.3; g.texts.push({ x: t.x, y: t.y - 2.6, s: 'ほのおの いき！', zh: '火焰吐息！', t: 1.2, col: '#ff8a3a' }); g.ev.push({ k: 'aim' }); return true; }
      if (t.phase >= 3 && t.snipeCd <= 0) { t.snipeCd = 8; for (let i = 0; i < 6; i++) lob(g, t, 3 + g.rand() * (g.cols - 6), 4 + g.rand() * (g.rows - 12), 1.8 + g.rand() * 0.6, 1.4, 'fire'); g.texts.push({ x: t.x, y: t.y - 2.6, s: 'ひの あめ！', zh: '火雨！', t: 1.2, col: '#ff6a3a', big: 2 }); }
      if (t.atkCd <= 0) { const angs = t.phase >= 2 ? [-0.6, -0.3, 0, 0.3, 0.6] : [-0.4, 0, 0.4]; for (const a of angs) fireAt(g, t, base + a, e.bullet); t.atkCd = 2.2; g.ev.push({ k: 'efire' }); }
      if (t.phase >= 2 && t.summonCd <= 0) { t.summonCd = 12; summon(g, t, d, 2, 3); }
      return false;
    }
  };
  // 氷の砲台の 2 段目：まわり（4 升）の地面を氷にする
  function iceFloor(g, t) { let n = 0; for (let y = Math.floor(t.y - 4); y <= t.y + 4; y++) for (let x = Math.floor(t.x - 4); x <= t.x + 4; x++) if (Math.hypot(x + 0.5 - t.x, y + 0.5 - t.y) < 4.2 && y < g.rows - 6 && tileAt(g, x, y) === '.') { g.map[y][x] = 'I'; n++; } if (n) g.mapVer++; }
  /* 溶岩だまり：熱くなってから、中に POOL_BURN 秒いるとやられる（たて・よろいは効く） */
  function stepPools(g, dt) {
    for (const q of g.pools) { q.t -= dt; if (q.arm > 0) q.arm -= dt; }
    g.pools = g.pools.filter(q => q.t > 0);
    for (const t of g.tanks) { if (t.side !== 'p' || !t.alive) continue;
      const hot = g.pools.some(q => q.arm <= 0 && Math.hypot(q.x - t.x, q.y - t.y) < q.r + 0.35);
      if (!hot) { t.poolT = 0; continue; } t.poolT = (t.poolT || 0) + dt;
      if (t.poolT >= POOL_BURN) { t.poolT = 0; if (t.shield <= 0) { g.texts.push({ x: t.x, y: t.y - 1.4, s: 'あちち！', zh: '好烫！', t: 1, col: '#ff8a3a' }); killPlayer(g, t, 'lava'); } } }
  }
  /* 占領：旗の近くに味方だけがいると、だんだん取れる（2 人目からは早く）。取った旗に敵だけがいると、だんだん取り返される */
  function stepFlags(g, dt) {
    for (const fl of g.flags) {
      const ps = g.tanks.filter(o => o.side === 'p' && o.alive && Math.hypot(o.x - fl.x, o.y - fl.y) < FLAG_R).length;
      const es = g.tanks.filter(o => o.side === 'e' && o.alive && !o.under && Math.hypot(o.x - fl.x, o.y - fl.y) < FLAG_R + 0.4).length;
      if (fl.own) { if (es && !ps) { fl.lose += dt; if (fl.lose >= FLAG_LOSE_SEC) { fl.own = 0; fl.prog = 0; fl.lose = 0; g.texts.push({ x: fl.x, y: fl.y - 2, s: '旗を とられた！', zh: '旗子被抢走了！', t: 1.5, col: '#ff7a7a' }); g.ev.push({ k: 'flaglost' }); } } else fl.lose = Math.max(0, fl.lose - dt); continue; }
      if (ps && !es) { fl.prog += dt * (1 + (ps - 1) * 0.5); if (fl.prog >= FLAG_SEC) { fl.own = 1; fl.lose = 0; const left = g.flags.filter(x => !x.own).length;
          g.texts.push({ x: fl.x, y: fl.y - 2, s: left ? '旗をとった！ あと ' + left + ' 本' : '旗を ぜんぶ とった！', zh: left ? '夺得旗子！还剩 ' + left + ' 面' : '旗子全部夺得！', t: 1.6, col: '#ffe36a', big: 2 }); g.ev.push({ k: 'flag', left }); } }
      else if (!ps) fl.prog = Math.max(0, fl.prog - dt * 0.5);
    }
  }
  // 面の終わり（旗をぜんぶ取った・時間まで守った）：残った敵はその場で消える（点はつかない）
  function sweepEnemies(g) {
    for (const o of g.tanks) if (o.side === 'e' && o.alive) { o.alive = false; g.fx.push({ k: 'boom', x: o.x, y: o.y, r: o.boss ? 2.4 : 1.2, t: 0.5, T: 0.5 }); }
    g.queue = []; g.pending = []; g.bullets = g.bullets.filter(b => b.side !== 'e'); g.shells = []; g.missiles = []; g.beams = []; g.mines = []; g.pools = []; g.ev.push({ k: 'bigboom' });
    g.tanks = g.tanks.filter(o => o.alive);
  }
  /* 隊長：まわりの敵を強くする（回復・盾・速く・呼ぶ）。速くは enemyThink で効かせる */
  function stepCaptains(g, dt, d) {
    g.hasteCaps = [];
    for (const c of g.tanks) {
      if (!c.alive || !c.captain) continue;
      if (c.aura === 'haste') { g.hasteCaps.push(c); continue; }
      c.auraT -= dt; if (c.auraT > 0) continue;
      const near = g.tanks.filter(o => o.alive && o.side === 'e' && !o.boss && Math.hypot(o.x - c.x, o.y - c.y) < AURA_R);
      if (c.aura === 'heal') { c.auraT = 3; for (const o of near) if (o.hp < o.maxHp) { o.hp++; g.texts.push({ x: o.x, y: o.y - 1.2, s: '+1', zh: '+1', t: 0.7, col: '#7fe08f' }); } }
      else if (c.aura === 'shield') { c.auraT = 6; for (const o of near) o.guard = 1; }
      else if (c.aura === 'call') {
        c.auraT = 9; const mine = g.tanks.filter(o => o.alive && o.callBy === c).length;
        if (mine < 2) { const sp = findFree(g, Math.round(c.x), Math.round(c.y), 6); if (sp) { spawnEnemy(g, 'normal', sp.x, sp.y, d, { callBy: c }); g.texts.push({ x: c.x, y: c.y - 1.4, s: 'こっちだ！', zh: '这边！', t: 0.9, col: '#c9a8ff' }); } }
      }
    }
  }
  /* ---------- 台詞（ボスが出た時・倒れた時）。自動では進まず、飛ばせない。全員がスマホの「読んだ」を押すと次へ（JUN の指示） ---------- */
  const NAME_ENTER = [['{name}… きみたちが うわさの せんしゃたいか！', '{name}…你们就是传说中的坦克队吗！'], ['よくきたな、{name}！', '来得好，{name}！'],
    ['{name}、ここから さきへは いかせないぞ！', '{name}，休想从这里过去！'], ['ほう、{name} か。てかげんは しないぞ', '哦，是{name}啊。我可不会手下留情']];
  const NAME_DEFEAT = [['{name}… おまえの いちげき、きいたぞ…', '{name}…你那一击，真厉害…'], ['{name}、おぼえておくぞ！', '{name}，我记住你了！'], ['まけたよ、{name}。つよく なったな', '我输了，{name}。你变强了']];
  /* ===== P4V BEGIN（v0.21）：ボスの台詞を VOICEVOX の台本（tank-voice.js の appear・defeat）に さしかえる =====
     台本の ある ボスだけ。箱ごとに 話す人（who）・声（vo＝/voice/<vo>.ogg）・声の長さ（sec）を持つ。双子戦車・雪だるまの子は 1 つの台本（同じ台本を 2 回 出さない）。
     名前を呼ぶ ひとこと（NAME_ENTER）は 台本の後ろに 声なしで出す（lines.p4v） */
  const P4V_SEC_EARLY = 0.4;   // 声の 終わる この秒前から「読んだ」を 受け付ける
  let P4V_TV = null;
  function p4vVoice() { if (P4V_TV) return P4V_TV; if (root.TankVoice) return (P4V_TV = root.TankVoice); try { if (typeof require !== 'undefined') P4V_TV = require('./tank-voice.js'); } catch (e) { P4V_TV = null; } return P4V_TV; }
  function p4vTalkLines(g, kinds, which, lines) {
    const V = p4vVoice(), w = which === 'enter' ? 'appear' : which === 'defeat' ? 'defeat' : ''; if (!V || !w) return;
    const out = [], used = {}; let hit = false;
    for (const k of kinds) {
      const b = V.base(k, !!(g.stage && g.stage.p3dGold)), sc = b ? V.script(k, w, !!(g.stage && g.stage.p3dGold)) : null;
      if (sc) { if (used[b]) continue; used[b] = 1; hit = true; for (const x of sc) { const sp = V.spk(x.who), l = { kind: sp.kind || k, who: x.who, ja: x.ja, zh: x.zh, vo: x.vo, sec: x.sec }; if (sp.spk) l.spk = sp.spk; out.push(l); } continue; }
      const tk = Stages.BOSS_TALK[k]; if (tk) for (const l of tk[which]) out.push(Object.assign({ kind: k }, l));
    }
    if (hit) { lines.length = 0; lines.push(...out); lines.p4v = 1; }
  }
  /* ===== P4V END ===== */
  function startTalk(g, kinds, which) {
    if (g.p3dDuel) return;   // P3D-duel：けっとうの 台詞は テレビの まんがで出す
    if (g.stage && g.stage.p4b) { p4bTalk(g, kinds, which); return; }   // P4B：ボスちょうせんは あいさつ 1 行
    if (which === 'defeat' && g.reunion && g.reunion.st === 2 && g.stage.reunion && kinds[0] === g.stage.reunion.kind) { g.reunion.st = 3; reunionTalk(g, g.stage.reunion, 'after'); return; }   // P2-22：ライバルを たおした時の台詞
    const lines = []; for (const k of kinds) { const tk = Stages.BOSS_TALK[k]; if (tk) for (const l of tk[which]) lines.push(Object.assign({ kind: k }, l)); }
    p4vTalkLines(g, kinds, which, lines);   // P4V：VOICEVOX の台本に さしかえる
    if (!lines.length) return;
    // v0.17（アイデア No.3）：ボスがプレイヤーの名前を呼ぶ。登場では全員の名前、たおされた時は一番がんばった人の名前
    const ps = Object.values(g.pl).filter(p => p.name); if (ps.length) {
      const all = ps.map(p => p.name), jaAll = all.join(' と '), zhAll = all.join(' 和 '), top = ps.slice().sort((a, b) => (b.kills || 0) - (a.kills || 0))[0].name;
      const pick = arr => arr[Math.floor(g.rand() * arr.length) % arr.length];
      if (which === 'enter') { const v = pick(NAME_ENTER); lines.splice(lines.p4v ? lines.length : 1, 0, { kind: kinds[0], ja: v[0].replace('{name}', jaAll), zh: v[1].replace('{name}', zhAll) }); }
      else if (which === 'defeat') { const v = pick(NAME_DEFEAT); lines.push({ kind: kinds[0], ja: v[0].replace('{name}', top), zh: v[1].replace('{name}', top) }); }
    }
    g.talk = { lines, i: 0, t: 0, read: {}, which }; g.ev.push({ k: 'talk' });
  }
  function talkReady(g) { const tk = g.talk; if (!tk) return false; const l = tk.lines[tk.i]; return tk.t >= Math.max(TALK_MIN_SEC + [...l.ja].length * TALK_CHAR_SEC, l.sec ? l.sec - P4V_SEC_EARLY : 0); }   // P4V：声が あれば 声が 終わるころまで
  function nextLine(g) { const tk = g.talk; tk.i++; tk.t = 0; tk.read = {}; if (tk.i >= tk.lines.length) { g.talk = null; g.ev.push({ k: 'talkend' }); } else g.ev.push({ k: 'talk' }); }
  function stepTalk(g, dt) {
    g.talk.t += dt; if (!talkReady(g)) return;
    const ids = Object.keys(g.pl); if (!ids.length || ids.every(id => g.talk.read[id])) nextLine(g);
  }
  // スマホの「読んだ」。i＝今の台詞の番号（古い押しを数えない）
  function readTalk(g, pid, i) {
    if (!g.talk || g.talk.i !== i || !g.pl[pid] || !talkReady(g)) return false;
    g.talk.read[pid] = 1; g.ev.push({ k: 'read', pid }); return true;
  }
  /* ===== P2-22 BEGIN：ボスとの再会（アイデア No.22）。面の決まり（Stages.REUNION → stage.reunion）のとおり、たおしたボスが 1 回だけ もどってくる。
     g.reunion＝{ st：1 会った台詞・2 しょうぶ中（rival）・3 終わり }。g.cameo＝テレビに出す ボスの絵（なかまの時。当たりは無い）{ kind, x, y, t, T, role }。
     なかま（help）：台詞 → おくりもの（1 回）→ おれいの台詞。ライバル（rival）：台詞 → 弱いボスが出る → たおすと台詞（BOSS_TALK の defeat の代わり） ===== */
  function reunionLines(g, r, which) {
    const ps = Object.values(g.pl).filter(p => p.name), all = ps.map(p => p.name), top = ps.slice().sort((a, b) => (b.kills || 0) - (a.kills || 0))[0];
    const ja = which === 'meet' ? all.join(' と ') : top ? top.name : '', zh = which === 'meet' ? all.join(' 和 ') : top ? top.name : '';
    return r[which].map(l => ({ kind: r.kind, ja: l.ja.replace('{name}', ja || 'みんな'), zh: l.zh.replace('{name}', zh || '大家'), reunion: r.role }));
  }
  function reunionTalk(g, r, which) { g.talk = { lines: reunionLines(g, r, which), i: 0, t: 0, read: {}, which: 'reunion' }; g.ev.push({ k: 'talk' }); }
  function reunionGift(g, r) {
    const nm = Stages.BOSS_TALK[r.kind].name;
    if (r.gift === 'futon') { g.futon = Math.min(CFG.maxFuton, g.futon + 1); g.texts.push({ x: g.hx, y: g.hy - 2.2, s: 'おうちの守り +1', zh: '小屋防护 +1', t: 2, col: '#cfeeff', big: 2 }); }
    else if (r.gift === 'freeze') { g.stopT = Math.max(g.stopT, 8); g.texts.push({ x: g.cols / 2, y: 6, s: 'てきが こおった！', zh: '敌人被冻住了！', t: 2, col: '#bfe6ff', big: 2 }); }
    else if (r.gift === 'shield') { for (const t of g.tanks) if (t.side === 'p' && t.alive) { t.shield = Math.max(t.shield, 12); g.texts.push({ x: t.x, y: t.y - 1.6, s: 'たて！', zh: '护盾！', t: 1.6, col: '#9fe8ff' }); } }
    g.ev.push({ k: 'reunion_gift', gift: r.gift, kind: r.kind, name: nm });
  }
  function stepReunion(g, dt, d) {
    const r = g.stage.reunion;
    if (g.cameo) { const c = g.cameo; c.t += dt; if (c.leave) { c.leave -= dt; if (c.leave <= 0) g.cameo = null; } }
    if (!r || g.mode !== 'adv') return;
    if (!g.reunion) {
      if (g.t < r.at || g.survive || g.noHouse) return;
      const bx = clamp(Math.round(g.cols / 2), 4, g.cols - 4);
      if (r.role === 'rival' && !placeFree(g, bx, 3, BOSS_HALF)) return;
      g.cameo = { kind: r.kind, x: bx, y: r.role === 'rival' ? 3 : Math.max(6, g.hy - 6.5), t: 0, role: r.role, leave: 0 };
      g.reunion = { st: 1, x: bx }; g.ev.push({ k: 'reunion', role: r.role, kind: r.kind, x: bx, y: g.cameo.y });
      reunionTalk(g, r, 'meet'); return;
    }
    const u = g.reunion;
    if (u.st === 1) {   // 会った台詞が終わった
      if (r.role === 'help') { reunionGift(g, r); u.st = 3; u.wait = 1.6; }
      else { if (!placeFree(g, u.x, 3, BOSS_HALF)) return; const t = spawnEnemy(g, r.kind, u.x, 3, d); t.hp = t.maxHp = Math.max(4, Math.round(t.maxHp * r.hp)); t.rival = true; g.cameo = null; u.st = 2; }
    } else if (u.st === 3 && u.wait > 0) { u.wait -= dt; if (u.wait <= 0) { reunionTalk(g, r, 'after'); if (g.cameo) g.cameo.leave = 1.2; } }
  }
  /* ===== P2-22 END ===== */
  function stepBeams(g, dt) {
    for (const bm of g.beams) {
      bm.t -= dt; if (bm.owner && bm.owner.alive) { bm.x = bm.owner.x; bm.y = bm.owner.y; bm.dir = bm.owner.dir; }
      const len = Math.max(g.cols, g.rows); let end = len;
      for (let i = 2; i < len; i++) {
        const px = bm.x + DX[bm.dir] * i, py = bm.y + DY[bm.dir] * i; let stop = false;
        for (const o of [-0.5, 0.49]) {
          const tx = Math.floor(px + (bm.dir & 1 ? 0 : o)), ty = Math.floor(py + (bm.dir & 1 ? o : 0)), c = tileAt(g, tx, ty);
          if (c === 'S' || c === '#' || c === 'G' || c === 'K') stop = true; else if (c === 'B' || c === 'b') breakTile(g, tx, ty, false, true, true); else if (c === 'H' && !bm.hitHouse) { bm.hitHouse = true; hitHouse(g); }
        }
        if (stop) { end = i; break; }
      }
      bm.len = end;
      const tr = g.truck; if (tr && !tr.dead && !bm.hitTruck) { const along = (tr.x - bm.x) * DX[bm.dir] + (tr.y - bm.y) * DY[bm.dir], across = Math.abs((tr.x - bm.x) * DY[bm.dir] - (tr.y - bm.y) * DX[bm.dir]); if (along > 0 && along < end + 1 && across < 1.8) { bm.hitTruck = true; hitTruck(g, 3); } }
      for (const t of g.tanks) {
        if (t.side !== 'p' || !t.alive) continue;
        const along = (t.x - bm.x) * DX[bm.dir] + (t.y - bm.y) * DY[bm.dir], across = Math.abs((t.x - bm.x) * DY[bm.dir] - (t.y - bm.y) * DX[bm.dir]);
        if (along > 0 && along < end + 1 && across < 1.8) { bm.hit = bm.hit || []; if (!bm.hit.includes(t)) { bm.hit.push(t); killPlayer(g, t, 'laser'); } }
      }
    }
    g.beams = g.beams.filter(b => b.t > 0);
  }
  function stepMissiles(g, dt) {
    for (const m of g.missiles) {
      if (m.dead) continue; m.t -= dt; if (m.t <= 0) { m.dead = true; continue; }
      if (g.stopT > 0) continue;
      const tg = nearestPlayerTank(g, m.x, m.y);
      if (tg) { const want = Math.atan2(tg.y - m.y, tg.x - m.x); let da = want - m.ang; while (da > Math.PI) da -= 2 * Math.PI; while (da < -Math.PI) da += 2 * Math.PI; m.ang += clamp(da, -MISSILE_TURN * dt, MISSILE_TURN * dt); }
      m.x += Math.cos(m.ang) * MISSILE_SPEED * dt; m.y += Math.sin(m.ang) * MISSILE_SPEED * dt;
      if (tg && Math.hypot(tg.x - m.x, tg.y - m.y) < 1.1) { m.dead = true; g.fx.push({ k: 'boom', x: m.x, y: m.y, r: 1, t: 0.4, T: 0.4 }); killPlayer(g, tg, 'missile'); g.ev.push({ k: 'boom' }); }
      if (m.x < -1 || m.y < -1 || m.x > g.cols + 1 || m.y > g.rows + 1) m.dead = true;
    }
    g.missiles = g.missiles.filter(m => !m.dead);
  }
  /* 陣地の自衛（おうちが近くの敵を撃つ）。届く距離 6＋2×段 升、間隔 1.7−0.26×段 秒（TK と同じ）。3 段から鋼を抜け、5 段で 3 倍 */
  function stepTower(g, dt) {
    if (g.tower <= 0 || g.houseDead || (g.noHouse && !g.truck)) return;
    g.towerCd -= dt; if (g.towerCd > 0) return;
    const L = g.tower, range = 6 + L * 2, hy = g.hy - 0.5; let best = null, bd = range;
    for (const e of g.tanks) if (e.side === 'e' && e.alive) { const dd = Math.abs(e.x - g.hx) + Math.abs(e.y - hy); if (dd < bd) { bd = dd; best = e; } }
    if (!best) { g.towerCd = 0; return; }
    const a = Math.atan2(best.y - hy, best.x - g.hx), sp = (5 + L * 0.5) * K;
    addBullet(g, { x: g.hx, y: hy, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, side: 'h', owner: null, through: true, r: 0.25, dmg: L >= 5 ? 3 : 1 });
    g.towerCd = 1.7 - L * 0.26; g.ev.push({ k: 'fire', big: L >= 3 });
  }
  /* 溶岩の面：水のそばで止まっていると熱い（TK と同じ：3 秒で知らせ、5 秒でたて→よろい→やられる） */
  function stepLava(g, p, t, dt) {
    if (!fxOf(g).lava) return;
    const near = boxHasTile(g, t.x, t.y, t.half + 0.6, 'W');
    if (!near || t.moving) { p.lavaT = 0; return; }
    const before = p.lavaT; p.lavaT += dt;
    { const m4 = modsOf(p).p4b; if (m4 && m4.lava) p.lavaT -= dt * m4.lava / (CFG.lavaBurnSec + m4.lava); }   // P4B：溶岩で あつくなるまで おそい
    if (before < CFG.lavaWarnSec && p.lavaT >= CFG.lavaWarnSec) { g.texts.push({ x: t.x, y: t.y - 1.4, s: 'あつい！ 動いて！', zh: '好烫！快移动！', t: 1.2, col: '#ff9a5c' }); g.ev.push({ k: 'lavawarn', pid: p.id }); }
    if (p.lavaT >= CFG.lavaBurnSec) {
      p.lavaT = 0; g.fx.push({ k: 'boom', x: t.x, y: t.y, r: 1, t: 0.4, T: 0.4 });
      if (t.shield > 0) t.shield = 0; else killPlayer(g, t, 'lava');
    }
  }
  function enemiesOnField(g) { return g.tanks.filter(t => t.side === 'e' && t.alive).length; }
  function enemiesRemaining(g) { return g.queue.length + g.pending.length + enemiesOnField(g) + (g.stage && g.stage.boss && !g.bossSpawned ? 1 : 0) + (g.bossQ ? g.bossQ.length : 0); }
  function bossOf(g) { return g.tanks.find(t => t.boss && t.alive) || null; }
  function bossesOf(g) { return g.tanks.filter(t => t.boss && t.alive); }
  function endGame(g, win, why) { if (g.ph !== 'play') return; g.ph = 'over'; g.win = win; g.why = why; g.ev.push({ k: win ? 'win' : 'lose', why }); }
  /* 面のクリア。勲章と点を決め、1 台もどす */
  function finishStage(g) {
    g.ph = 'clear'; g.phT = CFG.clearSec; g.clearTime = g.t; g.awards = makeAwards(g); g.praise = makePraise(g);
    collectChests(g);
    // 星 3 つ（ぼうけん）：クリア・おうち無傷（1 回も当たらない）・時間内
    // 護送の 2 つ目は「トラックの体力が半分より上」、突破の 2 つ目は「やられたのが 2 台まで」
    const star2 = g.truck ? (g.truck.hp * 2 > g.truck.max ? 1 : 0) : g.goalY ? ((g.lost || 0) <= 2 ? 1 : 0) : g.houseHits ? 0 : 1;
    g.stars = g.mode === 'adv' || g.mode === 'rand' ? [1, star2, (g.survive ? (g.stageKills || 0) >= g.killGoal : g.t <= g.par) ? 1 : 0] : null;   // 生き残りの 3 つ目は「敵を目標の数たおす」
    for (const a of g.awards) if (a.bonus) for (const id in g.pl) g.pl[id].score += a.bonus;
    for (const id in g.pl) { const p = g.pl[id]; if (p.lives < CFG.lives) p.lives++; }
    const list = stageList(g);
    g.ev.push({ k: 'clear', idx: g.stageIdx, mode: g.mode, loop: g.loop, last: g.stageIdx >= list.length - 1, time: g.t, stars: g.stars });
  }
  /* 賞。命中 7 割（みんなの合計）と 4 れんぞくは TK の勲章（点つき）。げきつい王・まもり神は自作 */
  function makeAwards(g) {
    const ps = Object.values(g.pl), a = [];
    const top = (f, min) => { let best = null; for (const p of ps) if (f(p) >= min && (!best || f(p) > f(best))) best = p; return best; };
    const shots = ps.reduce((s, p) => s + p.shots, 0), landed = ps.reduce((s, p) => s + p.landed, 0);
    if (shots >= 8 && landed / shots >= CFG.medalAcc) a.push({ key: 'meijin', v: Math.min(100, Math.round(landed / shots * 100)), bonus: CFG.medalAccBonus });
    const c = top(p => p.bestCombo, CFG.medalCombo); if (c) a.push({ key: 'renzoku', pid: c.id, v: c.bestCombo, bonus: CFG.medalComboBonus });
    const k = top(p => p.kills, 1); if (k) a.push({ key: 'gekitsui', pid: k.id, v: k.kills });
    const m = top(p => p.houseKills, 1); if (m) a.push({ key: 'mamori', pid: m.id, v: m.houseKills });
    return a;
  }
  /* v0.17（アイデア No.47）：一人ずつほめる。全員に必ず 1 つ、ちがう賞をあげる（数が多い順に、まだもらっていない人へ） */
  const PRAISE_ORDER = [
    ['boss', p => p.bossHits, 1], ['gekitsui', p => p.kills, 1], ['rescue', p => p.rescues, 1], ['house', p => p.houseKills, 1], ['chest', p => p.chestN, 1],
    ['sharp', p => (p.shots >= 5 ? p.landed / p.shots : 0), 0.35], ['combo', p => p.bestCombo, 2], ['special', p => p.spN, 1], ['shield', p => p.shieldGive, 1],
    ['nodie', p => (p.deaths ? 0 : 1), 1], ['shots', p => p.shots, 5]];
  function makePraise(g) {
    const ps = Object.values(g.pl), out = {};
    for (const [key, f, min] of PRAISE_ORDER) {
      let best = null; for (const p of ps) { if (out[p.id]) continue; const v = f(p) || 0; if (v >= min && (!best || v > (f(best) || 0))) best = p; }
      if (best) out[best.id] = { key, v: Math.round((f(best) || 0) * (key === 'sharp' ? 100 : 1)) };
    }
    const rest = ['team', 'never', 'cheer']; let i = 0; for (const p of ps) if (!out[p.id]) out[p.id] = { key: rest[i++ % rest.length], v: 0 };
    return out;
  }
  /* 面のクリアの後：次の面・周回・全部クリア */
  function afterClear(g) {
    const list = stageList(g);
    // ぼうけん：1 面ごとに結果の画面へ（次の面・ワールドマップは画面が選ぶ）
    if (g.mode === 'adv' || g.mode === 'rand') { g.ph = 'over'; g.win = 1; g.why = g.stageIdx >= list.length - 1 ? 'complete' : 'stage'; g.ev.push({ k: 'advdone', idx: g.stageIdx, last: g.why === 'complete' }); return; }
    if (g.stageIdx < list.length - 1) { loadStage(g, g.stageIdx + 1); return; }
    if (g.mode === 'camp' && g.loop < CFG.maxLoop - 1) {
      const r = LOOP_REWARD[Math.min(4, g.loop + 1)];
      g.ph = 'loop'; g.phT = CFG.loopSec; g.loopReward = Object.assign({ loop: g.loop + 2 }, r);
      g.ev.push({ k: 'loop', loop: g.loop + 1 }); return;
    }
    g.ph = 'over'; g.win = 1; g.why = 'complete'; g.ev.push({ k: 'win', why: 'complete', mode: g.mode });
  }
  function nextLoop(g) {
    const r = g.loopReward || {}; g.loop++;
    for (const id in g.pl) { const p = g.pl[id]; p.power = Math.min(CFG.maxPower, p.power + (r.power || 0)); p.lives = Math.min(MAX_LIVES, p.lives + (r.life || 0)); }
    loadStage(g, 0);
  }


  /* ---------- 育ち（v0.12）：装備の強さ（mods）・必殺技・宝箱。mods は tank-gear.js が作る。無ければ今までどおり ---------- */
  const SP_NEED = 8;   // 必殺技がたまるまで（敵 1 体＝1、隊長 2、ボス 4。tank-gear.js の SP_NEED と同じ）
  const DEF_MODS = Object.freeze({ car: 'a', sp: 'bomb', speed: 1, bullet: 1, power: 0, armor: 0, inv: 0, coin: 1, charge: 1, dmgMul: 1, bounce: 0, pierce: 0, grip: false, lifeUp: 0, tower: 0, futon: 0, spMax: 1, set4: Object.freeze({}), buff: null });
  const SP_KINDS = ['bomb', 'dash', 'wall', 'heal'];
  function modsOf(p) { return (p && p.mods) || DEF_MODS; }
  // 外から来た mods を数の範囲に収めて覚える（上限は tank-gear.js と同じ）
  function setMods(g, id, m) {
    const p = g.pl[id]; if (!p) return; if (!m || typeof m !== 'object') { p.mods = null; return; }
    const num = (v, a, b, d) => { const n = Number(v); return Number.isFinite(n) ? clamp(n, a, b) : d; }, s4 = {};
    if (m.set4 && typeof m.set4 === 'object') for (const k of ['wakaba', 'sand', 'silver', 'crimson', 'steel', 'king', 'abyss', 'bond', 'thunder']) if (m.set4[k]) s4[k] = 1;
    p.mods = { car: ['a', 'b', 'c', 'd'].includes(m.car) ? m.car : 'a', sp: SP_KINDS.includes(m.sp) ? m.sp : 'bomb', speed: num(m.speed, 0.7, 1.5, 1), bullet: num(m.bullet, 0.8, 1.8, 1),
      power: toInt(m.power, 0, 2, 0), armor: toInt(m.armor, 0, 2, 0), inv: num(m.inv, 0, 6.5, 0), coin: num(m.coin, 1, 1.8, 1), charge: num(m.charge, 0.5, 2.1, 1), dmgMul: num(m.dmgMul, 1, 1.7, 1),
      bounce: m.bounce ? 1 : 0, pierce: m.pierce ? 1 : 0, grip: !!m.grip, lifeUp: m.lifeUp ? 1 : 0, tower: toInt(m.tower, 0, 2, 0), futon: toInt(m.futon, 0, 2, 0), spMax: m.spMax === 2 ? 2 : 1,
      set4: s4, buff: m.buff === 'shield' || m.buff === 'power' ? m.buff : null,
      lv: toInt(m.lv, 1, 30, 1), spLv: toInt(m.spLv, 0, 3, 0) };   // v0.19：戦車のレベル（Lv10・20・30 の必殺技）が戦いに届くように。上限は装備の上限＋レベル・ドライバーの分
    // P2-1 BEGIN：ドライバーの力（ゆうき＝ボスへの威力、なかま＝仲間かおうちの近くで威力）。どちらも小さく、範囲を決めて覚える
    p.mods.bossDmg = num(m.bossDmg, 1, 1.15, 1); p.mods.team = num(m.team, 0, 0.075, 0);
    // P2-1 END
    if (P3D_CARS.includes(m.car)) p.mods.car = m.car; if (P3D_SP[m.sp]) p.mods.sp = m.sp;   // P3D-2：ボス戦車と その必殺技
    p.mods.p4b = p4bModsIn(m.p4b);   // P4B：ボス装備の 決まった効果
  }
  // 面の始め：装備の「始めから」の強さ（よろい・火力・台数・おうち）と、ルーレットの次の面だけの効果
  function applyStartMods(g) {
    let tower = 0, futon = 0;
    for (const id in g.pl) {
      const p = g.pl[id], m = modsOf(p);
      p.armor = Math.max(p.armor, m.armor); p.power = Math.min(CFG.maxPower, Math.max(p.power, m.power + (m.buff === 'power' ? 1 : 0)));
      if (m.lifeUp) p.lives = Math.max(p.lives, Math.min(MAX_LIVES, CFG.lives + 1));
      p.firstShield = m.buff === 'shield' ? 8 : 0; p.shotN = 0;
      p.p4bFree = 0; p.p4bShot = 0; if (m.p4b) { if (m.p4b.twin) p.twin = Math.max(p.twin, 1); if (m.p4b.sh) p.firstShield = Math.max(p.firstShield, m.p4b.sh); }   // P4B
      tower = Math.max(tower, m.tower); futon = Math.max(futon, m.futon);
    }
    g.tower = Math.min(CFG.maxTower, Math.max(g.tower, tower)); if (futon && g.mode !== 'hell') g.futon = Math.min(CFG.maxFuton, g.futon + futon);
  }
  function spReady(g, id) { const p = g.pl[id]; return !!p && p.sp >= SP_NEED; }
  // 必殺技（スマホの「必殺」）。たまっていて、戦車が出ている時だけ
  function useSpecial(g, id) {
    const p = g.pl[id]; if (!p || g.ph !== 'play' || g.talk || g.paused || g.pauseT > 0 || !p.tank || !p.tank.alive || p.sp < SP_NEED) return false;
    if (!g.soloSp && comboGate(g, id)) return true;   // P2-7：合体わざ（近くの仲間と つづけて押す）
    const m = modsOf(p), t = p.tank; p.sp -= SP_NEED; p.spN = (p.spN || 0) + 1; const L = m.spLv | 0;   // 戦車のレベル（v0.16）：Lv10・20・30 で必殺技が強くなる
    if (p3dSpecial(g, p, t, m, L, id)) { /* P3D-2：ボス戦車の必殺技 */ }
    else if (m.sp === 'bomb') { const BR = 6.5 + L * 0.8;
      g.fx.push({ k: 'boom', x: t.x, y: t.y, r: 5, t: 1, T: 1 }); g.shake = Math.max(g.shake, 0.6); g.ev.push({ k: 'bigboom' });
      g.fx[g.fx.length - 1].r = BR - 1.5;
      for (const o of g.tanks.slice()) if (o.side === 'e' && o.alive && Math.hypot(o.x - t.x, o.y - t.y) < BR) damageEnemy(g, o, (o.boss ? 5 : 3) + L, id, true);
      for (const s of g.missiles) if (Math.hypot(s.x - t.x, s.y - t.y) < BR) s.dead = true;
      for (const b of g.bullets) if (b.side === 'e' && Math.hypot(b.x - t.x, b.y - t.y) < BR) b.dead = true;
    } else if (m.sp === 'dash') { t.dashT = 3 + L * 0.7; t.shield = Math.max(t.shield, 3.2 + L * 0.7); }
    else if (m.sp === 'wall') { for (const o of g.tanks) if (o.side === 'p' && o.alive) o.shield = Math.max(o.shield, 5 + L * 1.5); }
    else {
      for (const qid in g.pl) { const q = g.pl[qid]; if (q.lives <= 0 && !q.tank) q.respawn = 1; q.lives = Math.min(MAX_LIVES, q.lives + (L >= 2 ? 2 : 1)); }
      if (L >= 1) for (const o of g.tanks) if (o.side === 'p' && o.alive) o.shield = Math.max(o.shield, 2 + L);
      if (g.mode !== 'hell') g.futon = Math.min(CFG.maxFuton, g.futon + 1);
    }
    const nm = { bomb: ['ばくげき！', '轰炸！'], dash: ['きゅうかそく！', '冲刺！'], wall: ['みんなに盾！', '全队护盾！'], heal: ['おたすけ！', '支援！'] }[m.sp] || P3D_SP[m.sp];
    g.texts.push({ x: t.x, y: t.y - 1.6, s: p.name + '：' + nm[0], zh: p.name + '：' + nm[1], t: 1.6, col: '#ffe36a', big: 4 });
    g.ev.push({ k: 'special', pid: id, sp: m.sp }); return true;
  }
  /* 宝箱：ふつうの敵 8 %（木）・隊長 50 %（銀）・ボス 100 %（ワールドの最後のボスは金、ほかは銀）・とても低い確率で金。場に 6 つまで */
  const CHEST_LIFE = { wood: 10, silver: 12, gold: 15 };
  function dropChest(g, t) {
    if (g.chests.length >= 6 || g.ph !== 'play') return;
    if (t.kind === 'snowman' || (t.kind === 'snowkid' && g.tanks.some(o => o.alive && (o.kind === 'snowkid' || o.kind === 'snowman')))) return;   // 雪だるまは最後の 1 体だけ
    if (ENEMY[t.kind].clone) return;   // 闇の戦車の分身は落とさない
    let kind = null; const r = g.rand(), lastBoss = (g.mode === 'adv' || g.mode === 'rand') && Stages && (g.stageIdx + 1) % Stages.PER_WORLD === 0;
    if (t.boss) kind = lastBoss || t.kind === 'superboss' ? 'gold' : 'silver';
    else if (t.captain || ENEMY[t.kind].elite) kind = r < 0.5 ? 'silver' : null;
    else kind = r < 0.005 ? 'gold' : r < 0.085 ? 'wood' : null;
    if (!kind) return;
    g.chests.push({ x: clamp(t.x, 1, g.cols - 1), y: clamp(t.y, 1, g.rows - 1), kind, t: CHEST_LIFE[kind], T: CHEST_LIFE[kind] }); g.ev.push({ k: 'chest_drop', kind });
  }
  function takeChest(g, pid, c) {
    const p = g.pl[pid]; if (p) p.chestN = (p.chestN || 0) + 1; g.ev.push({ k: 'chest', pid, kind: c.kind });
    g.fx.push({ k: 'spark', x: c.x, y: c.y, t: 0.4, T: 0.4 });
    g.texts.push({ x: c.x, y: c.y - 1.2, s: (p ? p.name + '：' : '') + { wood: '木の宝箱！', silver: '銀の宝箱！', gold: '金の宝箱！' }[c.kind], zh: (p ? p.name + '：' : '') + { wood: '木宝箱！', silver: '银宝箱！', gold: '金宝箱！' }[c.kind], t: 1.4, col: c.kind === 'gold' ? '#ffd23a' : c.kind === 'silver' ? '#dfe8f2' : '#e0a060' });
  }
  // 面が終わった時に残っている宝箱は、いちばん近い人のもの（最後のボスの宝箱を取りのがさないように）
  function collectChests(g) {
    const ids = Object.keys(g.pl); if (!ids.length) { g.chests = []; return; }
    for (const c of g.chests) {
      if (c.dead) continue; let best = ids[0], bd = 1e9;
      for (const id of ids) { const t = g.pl[id].tank; const dd = t ? Math.hypot(t.x - c.x, t.y - c.y) : 1e8; if (dd < bd) { bd = dd; best = id; } }
      c.dead = true; takeChest(g, best, c);
    }
    g.chests = [];
  }

  /* ---------- v0.14：護送・突破・大きな地図のカメラ・動く壁・スイッチ・ワープ ---------- */
  function initV14(g) {
    const st = g.stage, n = Math.max(1, playerCount(g));
    g.view = g.rows > VIEW_H ? { y: g.rows - VIEW_H, h: VIEW_H } : null;
    g.truck = null; g.btProg = 0; g.truckProg = 0; g.tdist = null; g.tdistVer = -1;
    if (st.type === 'escort') {
      const hp = TRUCK_HP + 4 * (n - 1);
      g.truck = { x: g.hx, y: g.rows - 1, half: HALF, hp, max: hp, dir: 0, moving: false, wait: false, flash: 0, dead: false, done: false, nx: g.hx, ny: g.rows - 1 };
      buildTruckDist(g); g.truckStart = Math.max(1, tdistAt(g, g.hx, g.rows - 1));
    }
    g.shut = g.shutCells && g.shutCells.length ? { cells: g.shutCells, open: 1, t: SHUT_SEC, cool: 0 } : null;
    g.goalY = st.type === 'breakthrough' ? GOAL_Y : 0;
    if (g.truck) { g.hx = Math.round(g.truck.x); g.hy = g.truck.y + 0.5; }
  }
  // トラックの道：ゴールまでの升の距離（レンガはトラックが押しつぶして通る。鋼・水・閉じた動く壁は通れない）
  function buildTruckDist(g) {
    const W = g.cols + 1, H = g.rows + 1, D = new Int16Array(W * H).fill(-1), q = [];
    const free = (cx, cy) => nodeFree(g, cx, cy);
    for (let cy = g.goal.y - 1; cy <= g.goal.y + 1; cy++) for (let cx = g.goal.x - 1; cx <= g.goal.x + 1; cx++) if (free(cx, cy)) { D[cy * W + cx] = 0; q.push(cx, cy); }
    for (let i = 0; i < q.length; i += 2) { const x = q[i], y = q[i + 1], dd = D[y * W + x];
      for (let k = 0; k < 4; k++) { const nx = x + DX[k], ny = y + DY[k]; if (nx < 1 || ny < 1 || nx >= g.cols || ny >= g.rows) continue; const j = ny * W + nx; if (D[j] >= 0 || !free(nx, ny)) continue; D[j] = dd + 1; q.push(nx, ny); } }
    g.tdist = D; g.tdistW = W; g.tdistVer = g.mapVer;
  }
  function tdistAt(g, cx, cy) { if (!g.tdist || cx < 1 || cy < 1 || cx >= g.cols || cy >= g.rows) return -1; return g.tdist[cy * g.tdistW + cx]; }
  function hitTruck(g, dmg) {
    const tr = g.truck; if (!tr || tr.dead || tr.done || g.ph !== 'play') return;
    g.houseHits = (g.houseHits || 0) + 1; alert(g);
    if (g.futon > 0) { g.futon--; g.ev.push({ k: 'shield' }); g.texts.push({ x: tr.x, y: tr.y - 1.8, s: 'おふとんが守った！', zh: '被子挡住了！', t: 1.2, col: '#9fe0ff' }); return; }
    tr.hp -= dmg; tr.flash = 0.15; tr.hurt = (tr.hurt || 0) + dmg; g.ev.push({ k: 'steel' });
    if (tr.hp <= 0) { tr.hp = 0; tr.dead = true; g.fx.push({ k: 'boom', x: tr.x, y: tr.y, r: 2.5, t: 1, T: 1 }); g.shake = 0.6; g.ev.push({ k: 'bigboom' }); endGame(g, 0, 'truck'); }
  }
  // トラック：味方が近くにいる時だけ、道にそって 1 升ずつ進む。前に戦車がいれば待つ。レンガは押しつぶす
  function stepTruck(g, dt) {
    const tr = g.truck; if (!tr || tr.dead || tr.done) return;
    if (tr.flash > 0) tr.flash -= dt;
    if (g.tdistVer !== g.mapVer) buildTruckDist(g);
    const near = g.tanks.some(o => o.side === 'p' && o.alive && Math.hypot(o.x - tr.x, o.y - tr.y) < ESCORT_R);
    tr.wait = !near; tr.moving = false;
    const cx = Math.round(tr.x), cy = Math.round(tr.y), here = tdistAt(g, cx, cy);
    if (here === 0 && Math.abs(tr.x - cx) < 0.05 && Math.abs(tr.y - cy) < 0.05) { tr.done = true; return; }
    if (!near || g.stopT > 0) return;
    if (Math.abs(tr.x - tr.nx) < 0.02 && Math.abs(tr.y - tr.ny) < 0.02) {   // 升の真ん中：次の升を決める
      tr.x = tr.nx; tr.y = tr.ny; let best = -1, bd = here < 0 ? 1e9 : here;
      for (let k = 0; k < 4; k++) { const v = tdistAt(g, cx + DX[k], cy + DY[k]); if (v >= 0 && v < bd) { bd = v; best = k; } }
      if (best < 0) return;
      tr.nx = cx + DX[best]; tr.ny = cy + DY[best]; tr.dir = best;
    }
    const k = tr.dir, s = TRUCK_SPEED * dt, nx = tr.x + DX[k] * Math.min(s, Math.abs(tr.nx - tr.x) + Math.abs(tr.ny - tr.y)), ny = tr.y + DY[k] * Math.min(s, Math.abs(tr.nx - tr.x) + Math.abs(tr.ny - tr.y));
    // 行く先のレンガをつぶす
    let wall = false;
    for (let yy = Math.floor(ny - tr.half); yy <= Math.floor(ny + tr.half - 1e-6); yy++) for (let xx = Math.floor(nx - tr.half); xx <= Math.floor(nx + tr.half - 1e-6); xx++) {
      const c = tileAt(g, xx, yy); if (c === 'B' || c === 'b') breakTile(g, xx, yy, false, false, true); else if (SOLID[c] || c === '#') wall = true; }
    if (wall) { g.tdistVer = -1; return; }
    for (const o of g.tanks) { if (!o.alive || o.under) continue; const m = tr.half + o.half; if (Math.abs(o.x - nx) < m && Math.abs(o.y - ny) < m && Math.hypot(o.x - nx, o.y - ny) < Math.hypot(o.x - tr.x, o.y - tr.y) + 1e-6) return; }
    tr.x = nx; tr.y = ny; tr.moving = true;
    if (Math.round(tr.x) !== cx || Math.round(tr.y) !== cy) g.distDirty = true;
    g.hx = Math.round(tr.x); g.hy = tr.y + 0.5;
    g.truckProg = Math.max(g.truckProg, clamp(1 - tdistAt(g, Math.round(tr.x), Math.round(tr.y)) / g.truckStart, 0, 1));
  }
  // カメラ（大きな地図）：護送は味方とトラックの真ん中、突破は前へだけ進む（ひとりでにも少しずつ）。画面から出た味方は押しもどす
  function stepView(g, dt) {
    const v = g.view; if (!v) return;
    const ps = g.tanks.filter(o => o.side === 'p' && o.alive), maxY = g.rows - v.h;
    if (g.goalY) {
      const lead = ps.length ? Math.min(...ps.map(o => o.y)) : v.y + v.h, foes = g.tanks.filter(o => o.side === 'e' && o.alive && o.y > v.y - 1 && o.y < v.y + v.h).length;
      const sp = foes >= 4 ? SCROLL_FIGHT : lead < v.y + v.h * 0.4 ? SCROLL_FAST : SCROLL_MIN;
      v.y = clamp(v.y - sp * dt, 0, maxY);
    } else {
      let fy = null; if (ps.length) fy = ps.reduce((a, o) => a + o.y, 0) / ps.length; if (g.truck) fy = fy === null ? g.truck.y : (fy + g.truck.y) / 2;
      if (fy !== null) { const tg = clamp(fy - v.h / 2, 0, maxY); v.y += clamp(tg - v.y, -5 * dt, 5 * dt); }
    }
    for (const t of ps) {
      const lo = v.y + t.half, hi = v.y + v.h - t.half; if (t.y >= lo - 0.01 && t.y <= hi + 0.01) continue;
      const ny = clamp(t.y, lo, hi);
      if (!boxHitsWall(g, t.x, ny, t.half) && !boxHitsTank(g, t, t.x, ny, t.half)) { t.y = ny; continue; }
      const sp = findFreeIn(g, Math.round(t.x), Math.round(ny), 6); if (sp) { t.x = sp.x; t.y = sp.y; g.fx.push({ k: 'dust', x: t.x, y: t.y, t: 0.3, T: 0.3 }); }
    }
    if (g.goalY) for (const t of g.tanks) if (t.side === 'e' && t.alive && !t.boss && t.y > v.y + v.h + 6) { t.alive = false; }   // 突破：ずっと後ろに残った敵は消す
    if (g.goalY) g.hy = v.y + v.h - 1;
    if (ps.length && g.goalY) { const lead = Math.min(...ps.map(o => o.y)); g.btProg = Math.max(g.btProg, clamp(1 - (lead - GOAL_Y) / (g.rows - 1 - GOAL_Y), 0, 1)); }
  }
  // (x, y) の近くで、画面の中の空いている所
  function findFreeIn(g, x, y, r) {
    const v = g.view;
    for (let k = 0; k <= r; k++) for (let dy = -k; dy <= k; dy++) for (let dx = -k; dx <= k; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) !== k) continue; const nx = x + dx, ny = y + dy;
      if (nx < 1 || ny < 1 || nx >= g.cols || ny >= g.rows) continue;
      if (v && (ny - HALF < v.y || ny + HALF > v.y + v.h)) continue;
      if (placeFree(g, nx, ny, HALF)) return { x: nx, y: ny };
    }
    return null;
  }
  // 味方の出る所。大きな地図では画面の中（護送はトラックのそば、突破は画面の下）
  function spawnPoint(g, p) {
    const base = g.spawns[p.slot]; if (!g.view && !g.truck) return base;
    const off = SPAWN_OFFSETS[p.slot] / 2;
    if (g.truck && !g.truck.dead) return findFreeIn(g, Math.round(g.truck.x + off), Math.round(g.truck.y + 2), 7) || findFreeIn(g, Math.round(g.truck.x), Math.round(g.truck.y), 9);
    const v = g.view; return findFreeIn(g, g.hx + SPAWN_OFFSETS[p.slot], Math.round(v.y + v.h - 2), 8);
  }
  // 動く壁：SHUT_SEC 秒ごとに、開いている組と閉じている組が入れかわる。戦車がいる升は、空くまで閉じない
  function cellBusy(g, x, y) {
    for (const o of g.tanks) if (o.alive && !o.under && Math.abs(o.x - (x + 0.5)) < o.half + 0.5 && Math.abs(o.y - (y + 0.5)) < o.half + 0.5) return true;
    const tr = g.truck; if (tr && !tr.dead && Math.abs(tr.x - (x + 0.5)) < tr.half + 0.5 && Math.abs(tr.y - (y + 0.5)) < tr.half + 0.5) return true;
    return false;
  }
  function stepShutters(g, dt) {
    const sh = g.shut; if (!sh) return;
    sh.t -= dt; if (sh.cool > 0) sh.cool -= dt;
    if (sh.t <= 0) { sh.open ^= 1; sh.t = SHUT_SEC; g.ev.push({ k: 'shutter' }); }
    let ch = false;
    for (const c of sh.cells) { const want = c.grp === sh.open ? 'g' : 'G', cur = g.map[c.y][c.x]; if (cur === want) continue; if (want === 'G' && cellBusy(g, c.x, c.y)) continue; g.map[c.y][c.x] = want; ch = true; }
    if (ch) { g.mapVer++; g.distDirty = true; }
  }
  // スイッチ（味方の弾）：動く壁がすぐ入れかわり、しばらくそのまま
  function hitSwitch(g, x, y, pid) {
    const sh = g.shut; if (!sh || sh.cool > 0) return;
    sh.open ^= 1; sh.t = SWITCH_HOLD; sh.cool = 0.8; const p = pid && g.pl[pid];
    g.texts.push({ x: x + 0.5, y: y - 0.6, s: (p ? p.name + '：' : '') + 'カシャン！', zh: (p ? p.name + '：' : '') + '咔嚓！', t: 1.1, col: '#8fe8ff' }); g.ev.push({ k: 'switch' });
    g.fx.push({ k: 'spark', x: x + 0.5, y: y + 0.5, t: 0.3, T: 0.3 });
  }
  // ワープ：真ん中に乗ると、組のもう片方へ。続けて使えないよう、一度離れるまで待つ
  function stepWarps(g, dt) {
    if (!g.warps || !g.warps.length) return;
    for (const t of g.tanks) {
      if (!t.alive || t.boss || t.under) continue; if (t.warpCd > 0) t.warpCd -= dt;
      if (t.padLock) { if (Math.hypot(t.x - t.padLock.x, t.y - t.padLock.y) > 1.4) t.padLock = null; else continue; }
      if (t.warpCd > 0) continue;
      for (const w of g.warps) { let done = false; for (const [a, b] of [[w.a, w.b], [w.b, w.a]]) {
        if (Math.abs(t.x - a.x) > 0.55 || Math.abs(t.y - a.y) > 0.55) continue;
        if (!placeFree(g, b.x, b.y, t.half)) continue;
        if (t.side === 'p' && g.view && (b.y - t.half < g.view.y || b.y + t.half > g.view.y + g.view.h)) continue;
        g.fx.push({ k: 'spark', x: t.x, y: t.y, t: 0.35, T: 0.35 }); t.x = b.x; t.y = b.y; t.warpCd = WARP_CD; t.padLock = b; t.slide = 0;
        g.fx.push({ k: 'spark', x: b.x, y: b.y, t: 0.35, T: 0.35 }); g.ev.push({ k: 'warp', side: t.side }); done = true; break; }
        if (done) break; }
    }
  }
  // 突破の出口：画面の上の方（少し先）の出口だけを使う
  // 出られない敵の救い（v0.15、JUN さんの報告）：鋼などに囲まれて動けず、味方の弾も届かない敵は、
  // 15 秒たったら出口（敵の出る所）へワープさせる。(a) 体が壁にめりこんでいる (b) 味方のいる所から道がない
  // (c) 40 秒まったく動かない（ボスと動かない敵は (c) をしない）。地図は変えないので、ほかの面の遊び方は同じ
  /* v0.17（アイデア No.8）：たすけ起こし。仲間の戦車が印のそばに RESCUE_SEC いると起き上がる */
  const DOWN_SEC = 5, DOWN_OUT_SEC = 8, RESCUE_SEC = 1, RESCUE_R = 1.9;
  function stepDowns(g, dt) {
    if (!g.downs || !g.downs.length) return;
    for (const d of g.downs.slice()) {
      const p = g.pl[d.pid]; d.t -= dt;
      if (!p || p.tank || d.t <= 0) { g.downs.splice(g.downs.indexOf(d), 1); continue; }
      let by = null; for (const id in g.pl) { const q = g.pl[id], o = q.tank; if (q !== p && o && o.alive && Math.hypot(o.x - d.x, o.y - d.y) < RESCUE_R) { by = q; break; } }
      if (by) { d.prog += dt; d.by = by.id; } else d.prog = Math.max(0, d.prog - dt * 0.5);
      if (d.prog < RESCUE_SEC || !by) continue;   // P4B：たすける 人が はなれた 時に 止まらないように（前から ある 落ち方）
      let x = d.x, y = d.y; if (!placeFree(g, x, y, HALF)) { const o = by.tank; x = o.x; y = o.y; if (!placeFree(g, x, y, HALF)) { const f = findFreeIn(g, d.x, d.y, 3); if (!f) continue; x = f.x; y = f.y; } }
      const m = modsOf(p); p.lives = Math.min(MAX_LIVES, p.lives + 1); p.respawn = 0;
      p.tank = newTank('p', x, y, 0, { pid: p.id, slot: p.slot, shield: 3 + m.inv * 0.5, car: m.car, dashT: 0 }); g.tanks.push(p.tank);
      by.rescues = (by.rescues || 0) + 1; g.downs.splice(g.downs.indexOf(d), 1);
      g.texts.push({ x, y: y - 1.6, s: by.name + ' が ' + p.name + ' を たすけた！', zh: by.name + ' 救起了 ' + p.name + '！', t: 1.8, col: '#7fe08f', big: 3 });
      g.fx.push({ k: 'spark', x, y, t: 0.5, T: 0.5 }); g.ev.push({ k: 'rescue', pid: p.id, by: by.id });
    }
  }
  function rescueStuck(g, dt) {
    g.rescueT = (g.rescueT || 0) - dt; if (g.rescueT > 0) return; g.rescueT = 1;
    const cand = [];
    for (const t of g.tanks) {
      if (t.side !== 'e' || !t.alive || t.under || t.fly) continue; const e = ENEMY[t.kind]; if (e && e.speed === 0) continue;
      if (t._rx === undefined || Math.hypot(t.x - t._rx, t.y - t._ry) > 0.6) { t._rx = t.x; t._ry = t.y; t._rt = g.t; continue; }
      const still = g.t - t._rt; if (still >= 15) cand.push([t, still]);
    }
    if (!cand.length) return;
    // 味方の戦車から行ける升（レンガは撃って通れる扱い）
    const W = g.cols + 1, H = g.rows + 1, R = new Uint8Array(W * H), q = [];
    for (const p of g.tanks) if (p.side === 'p' && p.alive) { const cx = Math.round(p.x), cy = Math.round(p.y); if (cx >= 1 && cy >= 1 && cx < g.cols && cy < g.rows && !R[cy * W + cx]) { R[cy * W + cx] = 1; q.push(cx, cy); } }
    if (!q.length) return;
    for (let i = 0; i < q.length; i += 2) { const x = q[i], y = q[i + 1]; for (let k = 0; k < 4; k++) { const nx = x + DX[k], ny = y + DY[k]; if (nx < 1 || ny < 1 || nx >= g.cols || ny >= g.rows) continue; const j = ny * W + nx; if (R[j] || !nodeFree(g, nx, ny)) continue; R[j] = 1; q.push(nx, ny); } }
    const reach = t => { const cx = Math.round(t.x), cy = Math.round(t.y); for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const x = cx + dx, y = cy + dy; if (x >= 1 && y >= 1 && x < g.cols && y < g.rows && R[y * W + x]) return true; } return false; };
    for (const [t, still] of cand) {
      const nearHome = Math.hypot(t.x - g.hx, t.y - (g.truck ? g.truck.y : g.rows - 1)) < 7, idleKind = t.kind === 'sniper' || t.kind === 'mortar';
      const stuck = boxHitsWall(g, t.x, t.y, t.half) || !reach(t) || (!t.boss && !idleKind && !nearHome && still >= 40);
      if (!stuck) continue;
      let spot = null;
      for (let k = 0; k < g.gates.length && !spot; k++) { const gt = gateFor(g); const f = findFreeIn(g, gt.x, gt.y, 6); if (f && reach({ x: f.x, y: f.y })) spot = f; }
      if (!spot) continue;
      g.fx.push({ k: 'boom', x: t.x, y: t.y, t: 0.4, T: 0.4, r: 0.6 });
      t.x = spot.x; t.y = spot.y; t._rx = t.x; t._ry = t.y; t._rt = g.t; t.blocked = false; t.slide = 0;
      g.texts.push({ x: t.x, y: t.y - 1.3, s: 'ワープで でてきた！', zh: '传送出来了！', t: 1.2, col: '#c9a0ff' }); g.rescued = (g.rescued || 0) + 1;
    }
  }
  function gateFor(g) {
    if (!g.goalY || !g.view) return g.gates[g.gateI++ % g.gates.length];
    const v = g.view, ok = g.gates.filter(gt => gt.y >= v.y - 13 && gt.y <= v.y + 4);
    const list = ok.length ? ok : g.gates.slice().sort((a, b) => Math.abs(a.y - v.y) - Math.abs(b.y - v.y)).slice(0, 3);
    return list[g.gateI++ % list.length];
  }

  /* ---------- v0.14 のボス（世界 5 機械要塞・地獄） ---------- */
  function liveKind(g, k) { return g.tanks.find(o => o.alive && o.kind === k) || null; }
  function rage(g, t, ja, zh) { if (t.rage) return; t.rage = true; t.speedMul *= 1.35; t.fireMul *= 0.7; t.phase = 3; g.shake = Math.max(g.shake, 0.4); g.texts.push({ x: t.x, y: t.y - 2.6, s: ja, zh, t: 1.8, col: '#ff5a5a', big: 3 }); g.ev.push({ k: 'bossphase' }); }
  function aimAt(t, o, base) { return o ? Math.atan2(o.y - t.y, o.x - t.x) : base; }
  function startLaser(g, t, near, ja, zh) { t.dir = axisDirTo(t, near); t.laserAim = 1.3; g.texts.push({ x: t.x, y: t.y - 2.4, s: ja, zh, t: 1.2, col: '#ff7a7a' }); g.ev.push({ k: 'aim' }); }
  function stepLaser(g, t, dt, fire) { if (!(t.laserAim > 0)) return false; t.laserAim -= dt; if (t.laserAim <= 0) { g.beams.push({ x: t.x, y: t.y, dir: t.dir, t: LASER_SEC, owner: t, fire: !!fire }); g.ev.push({ k: 'laser' }); g.shake = Math.max(g.shake, 0.3); } return true; }
  function spawnClone(g, t, d) {
    if (g.p3dDuel) return false;   // P3D-duel：分身なし
    const sp = findFreeBig(g, t.x + (g.rand() - 0.5) * 8, t.y + (g.rand() - 0.5) * 6, 6, BOSS_HALF); if (!sp) return false;
    const c = spawnEnemy(g, 'shade', sp.x, sp.y, d, { cloneOf: t }); c.half = BOSS_HALF; c.hp = c.maxHp = 3 + t.phase; c.mode = 'hunt'; c.cd = 1;
    g.fx.push({ k: 'dust', x: sp.x, y: sp.y, t: 0.5, T: 0.5 }); return true;
  }
  // 地中にもぐって別の所から出る（戦車の王が 砂もぐりの技を使う）
  function stepBurrow(g, t, dt, nRing, bullet) {
    if (t.st === 'dig') { t.stT -= dt; if (t.stT <= 0) { t.st = 'under'; t.under = true; t.stT = 1.3; const live = g.tanks.filter(o => o.side === 'p' && o.alive);
        const tg = live.length ? live[Math.floor(g.rand() * live.length)] : { x: g.cols / 2, y: g.rows / 2 }, a = g.rand() * Math.PI * 2, r = 4 + g.rand() * 2;
        t.tx = clamp(tg.x + Math.cos(a) * r, 3, g.cols - 3); t.ty = clamp(tg.y + Math.sin(a) * r, 3, g.rows - 8); } return true; }
    if (t.st === 'under') { t.stT -= dt; if (t.stT > 0) return true;
      const sp = findFreeBig(g, t.tx, t.ty, 6, t.half); if (!sp) { t.stT = 0.3; t.tx = g.cols / 2; t.ty = 6; return true; }
      t.x = sp.x; t.y = sp.y; t.under = false; t.st = 'surf';
      for (let i = 0; i < nRing; i++) fireAt(g, t, i * Math.PI * 2 / nRing, bullet * 0.8);
      g.shake = Math.max(g.shake, 0.4); g.fx.push({ k: 'boom', x: t.x, y: t.y, r: 1.8, t: 0.5, T: 0.5 }); g.ev.push({ k: 'bigboom' }); return true; }
    return false;
  }
  const V14_BOSS = {
    sisA(g, t, dt, d, f, e, near, base) {   // 双子戦車の姉：しっかりねらう 2〜3 発。妹がやられると本気（速く・よく撃つ・輪の弾）
      if (!liveKind(g, 'sisB')) rage(g, t, 'いもうとを よくも！', '竟敢欺负我妹妹！'); else if (f < 0.5) phaseUp(g, t, 2, 'ほんきで いくわよ', '要认真了哦');
      t.atkCd -= dt; t.sideCd -= dt;
      if (t.atkCd <= 0) { const a = aimAt(t, near, base); for (const o of t.phase >= 2 ? [-0.3, 0, 0.3] : [-0.16, 0.16]) fireAt(g, t, a + o, e.bullet); t.atkCd = t.rage ? 1.15 : t.phase >= 2 ? 1.7 : 2.1; g.ev.push({ k: 'efire' }); }
      if (t.rage && t.sideCd <= 0) { t.sideCd = 4; ring(g, t, 10, 7); }
      return false;
    },
    sisB(g, t, dt, d, f, e, near, base) {   // 妹：すばやく動き、はね返る弾を 2 つ。姉がやられると本気
      if (!liveKind(g, 'sisA')) rage(g, t, 'ねえさん！ ゆるさない！', '姐姐！我不会原谅你们！'); else if (f < 0.5) phaseUp(g, t, 2, 'もう あそびじゃ ないよ！', '不是闹着玩的了！');
      t.atkCd -= dt; t.sideCd -= dt;
      if (t.atkCd <= 0) { const a = aimAt(t, near, base); for (const o of [-0.25, 0.25]) fireAt(g, t, a + o, e.bullet, { bounces: 1 }); t.atkCd = t.rage ? 1.0 : 1.6; g.ev.push({ k: 'efire' }); }
      if ((t.phase >= 2 || t.rage) && t.sideCd <= 0) { t.sideCd = t.rage ? 3.5 : 5; ring(g, t, 8, 5.5, { bounces: 1 }); }
      if (g.rand() < dt * 0.6) { t.want = g.rand() * 4 | 0; t.ai = 0.6; }   // 気まぐれに向きを変える
      return false;
    },
    airship(g, t, dt, d, f, e, near, base) {   // 空中艇：飛んでいる間は当たらない（爆弾を落とす）。予告の印の所に降りた時だけ当たる
      if (f < 0.5) phaseUp(g, t, 2, 'もう、しつこいですわね！', '真是的，好烦人！');
      const p2 = t.phase >= 2;
      if (t.st === 'surf') { t.st = 'fly'; t.stT = 4; t.under = true; t.fly = true; t.atkCd = 1.5; }
      t.stT -= dt; t.moving = t.st !== 'ground';
      if (t.st === 'fly') {
        if (!t.tgt || Math.hypot(t.tgt.x - t.x, t.tgt.y - t.y) < 0.6) { const live = g.tanks.filter(o => o.side === 'p' && o.alive), o = live.length ? live[Math.floor(g.rand() * live.length)] : { x: g.hx, y: g.rows - 8 };
          t.tgt = { x: clamp(o.x + (g.rand() - 0.5) * 8, 3, g.cols - 3), y: clamp(o.y - 3 + (g.rand() - 0.5) * 6, 3, g.rows - 8) }; }
        const a = Math.atan2(t.tgt.y - t.y, t.tgt.x - t.x), sp = (p2 ? 3.6 : 3.0) * dt; t.x += Math.cos(a) * sp; t.y += Math.sin(a) * sp;
        t.dir = Math.abs(Math.cos(a)) > Math.abs(Math.sin(a)) ? (Math.cos(a) > 0 ? 1 : 3) : (Math.sin(a) > 0 ? 2 : 0);
        t.atkCd -= dt;
        if (t.atkCd <= 0) { t.atkCd = p2 ? 1.8 : 2.4; lobAtPlayers(g, t, p2 ? 3 : 2, 1.4, 1.3, 'bomb', 2); if (g.ring.length && g.rand() < 0.3) { const r = g.ring[Math.floor(g.rand() * g.ring.length)]; lob(g, t, r[0] + 0.5, r[1] + 0.5, 1.5, 1.2, 'bomb'); } }
        if (t.stT <= 0) { const sp2 = findFreeBig(g, t.x, t.y, 7, t.half); if (sp2) { t.st = 'land'; t.stT = 1.1; t.lx = sp2.x; t.ly = sp2.y; g.texts.push({ x: t.x, y: t.y - 2.4, s: 'おりますわ…', zh: '要降落了…', t: 1.1, col: '#ffe08a' }); g.ev.push({ k: 'aim' }); } else t.stT = 0.5; }
        return true;
      }
      if (t.st === 'land') {
        const a = Math.atan2(t.ly - t.y, t.lx - t.x), dd = Math.hypot(t.lx - t.x, t.ly - t.y); if (dd > 0.05) { const sp = Math.min(dd, 6 * dt); t.x += Math.cos(a) * sp; t.y += Math.sin(a) * sp; }
        if (t.stT > 0) return true;
        if (!placeFree(g, t.lx, t.ly, t.half)) { const sp2 = findFreeBig(g, t.lx, t.ly, 6, t.half); if (!sp2) { t.st = 'fly'; t.stT = 1; return true; } t.lx = sp2.x; t.ly = sp2.y; }
        t.x = t.lx; t.y = t.ly; t.under = false; t.st = 'ground'; t.stT = p2 ? 3.5 : 4.5; t.atkCd = 0.8;
        ring(g, t, p2 ? 12 : 8, 7); g.shake = Math.max(g.shake, 0.4); g.fx.push({ k: 'dust', x: t.x, y: t.y + 1, t: 0.6, T: 0.6 }); g.ev.push({ k: 'bigboom' });
        if (p2) summon(g, t, d, 2, 3);
        return true;
      }
      if (t.st === 'ground') {
        t.atkCd -= dt; if (t.atkCd <= 0) { const a = aimAt(t, near, base); for (const o of [-0.35, 0, 0.35]) fireAt(g, t, a + o, e.bullet); t.atkCd = 1.6; g.ev.push({ k: 'efire' }); }
        if (t.stT <= 0) { t.st = 'fly'; t.under = true; t.stT = p2 ? 5 : 6.5; t.tgt = null; g.texts.push({ x: t.x, y: t.y - 2.4, s: 'めんどうですわ', zh: '好麻烦哦', t: 1.1, col: '#ffe08a' }); }
        return true;
      }
      return true;
    },
    core(g, t, dt, d, f, e, near, base) {   // 要塞コア：動かない。うずまきの弾。段階ごとに別の部屋へ移る（4 段階）
      t.moving = false;
      const ph = f < 0.25 ? 4 : f < 0.5 ? 3 : f < 0.75 ? 2 : 1;
      if (ph > t.phase && t.st !== 'warp') {
        const msg = { 2: ['だい 2 ぼうえいせん、きどう', '第 2 防线，启动'], 3: ['エラー… エラー… へやを うつります', '错误…错误…转移房间'], 4: ['さいごの へや。…まもる りゆうを おしえて', '最后的房间。…告诉我守护的理由'] }[ph];
        phaseUp(g, t, ph, msg[0], msg[1]);
        const pos = (g.corePos && g.corePos[ph - 1]) || { x: g.hx, y: 4 }; t.st = 'warp'; t.stT = 1.2; t.under = true; t.tx = pos.x; t.ty = pos.y; g.ev.push({ k: 'aim' });
        return true;
      }
      if (t.st === 'warp') { t.stT -= dt; if (t.stT > 0) return true;
        const sp = placeFree(g, t.tx, t.ty, t.half) ? { x: t.tx, y: t.ty } : findFreeBig(g, t.tx, t.ty, 6, t.half); if (!sp) { t.stT = 0.3; return true; }
        t.x = sp.x; t.y = sp.y; t.under = false; t.st = 'on'; ring(g, t, 14, 6.5); g.fx.push({ k: 'boom', x: t.x, y: t.y, r: 2, t: 0.5, T: 0.5 }); g.ev.push({ k: 'bigboom' }); return true; }
      if (stepLaser(g, t, dt)) return true;
      t.spin = (t.spin || 0) + dt * (t.phase >= 4 ? 2.2 : 1.5); t.atkCd -= dt; t.lzCd -= dt; t.summonCd -= dt; t.missileCd -= dt; t.snipeCd -= dt;
      if (t.atkCd <= 0) { t.atkCd = t.phase >= 3 ? 0.26 : 0.34; const arms = t.phase >= 3 ? 3 : 2; for (let i = 0; i < arms; i++) fireAt(g, t, t.spin + i * Math.PI * 2 / arms, e.bullet, { kind: 'dark' }); }
      if (t.phase >= 2 && t.lzCd <= 0 && near) { t.lzCd = 7; startLaser(g, t, near, 'ビーム はっしゃ じゅんび', '光束发射准备'); return true; }
      if (t.phase >= 3 && t.summonCd <= 0) { t.summonCd = 11; summon(g, t, d, 2, 3); }
      if (t.phase >= 3 && t.missileCd <= 0) { t.missileCd = 7; for (const a of [-1.2, 1.2]) g.missiles.push({ x: t.x, y: t.y, ang: base + a, t: MISSILE_LIFE }); g.ev.push({ k: 'missile' }); }
      if (t.phase >= 4 && t.snipeCd <= 0) { t.snipeCd = 5; for (let i = 0; i < 5; i++) lob(g, t, 3 + g.rand() * (g.cols - 6), 4 + g.rand() * (g.rows - 12), 1.6 + g.rand() * 0.5, 1.3, 'bomb'); g.ev.push({ k: 'mortar' }); }
      return true;
    },
    shadow(g, t, dt, d, f, e, near, base) {   // 闇の戦車：分身（同じ見た目）を出し、ときどき分身と入れかわる
      if (f < 0.66) phaseUp(g, t, 2, 'まだ たりない… もっと ふやす', '还不够…再多变几个');
      if (f < 0.33) phaseUp(g, t, 3, 'ぼくたちは、ひとりじゃ ない…', '我们，不是一个人…');
      const clones = g.tanks.filter(o => o.alive && o.cloneOf === t), want = t.phase + 1;
      t.cloneCd = (t.cloneCd === undefined ? 1 : t.cloneCd) - dt; t.swapCd = (t.swapCd === undefined ? 5 : t.swapCd) - dt; t.atkCd -= dt; t.lzCd -= dt;
      if (clones.length < want && t.cloneCd <= 0) { t.cloneCd = 4.5; if (spawnClone(g, t, d)) g.texts.push({ x: t.x, y: t.y - 2.4, s: 'ふえた…', zh: '变多了…', t: 1, col: '#c9a8ff' }); }
      if (clones.length && t.swapCd <= 0) { t.swapCd = 6.5 - t.phase; const c = clones[Math.floor(g.rand() * clones.length)]; const x = t.x, y = t.y; t.x = c.x; t.y = c.y; c.x = x; c.y = y;
        g.fx.push({ k: 'dust', x: t.x, y: t.y, t: 0.5, T: 0.5 }); g.fx.push({ k: 'dust', x: c.x, y: c.y, t: 0.5, T: 0.5 }); g.ev.push({ k: 'warp', side: 'e' }); }
      if (t.atkCd <= 0) { const a = aimAt(t, near, base); for (const o of [-0.3, 0, 0.3]) fireAt(g, t, a + o, e.bullet, { kind: 'dark' }); t.atkCd = t.phase >= 2 ? 1.7 : 2.1; g.ev.push({ k: 'efire' }); }
      if (t.phase >= 3 && t.lzCd <= 0) { t.lzCd = 5; ring(g, t, 12, 6.5, { kind: 'dark' }); for (const c of clones) ring(g, c, 6, 5.5, { kind: 'dark' }); }
      return false;
    },
    superstar(g, t, dt, d, f, e, near, base) {   // 超ボス（作り直し）：星の弾（はね返る）・スポットライトの印に大きな爆発・ミサイル・ビーム・花火
      if (f < 0.66) phaseUp(g, t, 2, 'もりあがって きたァ！', '气氛热起来了！');
      if (f < 0.33) phaseUp(g, t, 3, 'フィナーレだァ！', '压轴登场！');
      if (stepLaser(g, t, dt)) return true;
      t.atkCd -= dt; t.spotCd = (t.spotCd === undefined ? 4 : t.spotCd) - dt; t.missileCd -= dt; t.lzCd -= dt; t.summonCd -= dt; t.snipeCd -= dt;
      if (t.atkCd <= 0) { const a = aimAt(t, near, base); for (const o of [-0.6, -0.3, 0, 0.3, 0.6]) fireAt(g, t, a + o, e.bullet * 0.85, { kind: 'star', bounces: 1 }); t.atkCd = t.phase >= 3 ? 1.5 : 2.0; g.ev.push({ k: 'efire' }); }
      if (t.spotCd <= 0) { t.spotCd = t.phase >= 2 ? 4.5 : 6; const live = g.tanks.filter(o => o.side === 'p' && o.alive); if (live.length) { const o = live[Math.floor(g.rand() * live.length)]; lob(g, t, o.x, o.y, 1.5, 1.8, 'star');
          g.texts.push({ x: o.x, y: o.y - 2, s: 'スポットライト！', zh: '聚光灯！', t: 1.2, col: '#ffe36a' }); g.ev.push({ k: 'aim' }); } }
      if (t.phase >= 2 && t.missileCd <= 0) { t.missileCd = 6; for (const a of [-1.2, 1.2]) g.missiles.push({ x: t.x, y: t.y, ang: base + a, t: MISSILE_LIFE }); g.ev.push({ k: 'missile' }); }
      if (t.phase >= 2 && t.lzCd <= 0 && near) { t.lzCd = 8; startLaser(g, t, near, 'スター ビーム！', '巨星光束！'); return true; }
      if (t.phase >= 3 && t.snipeCd <= 0) { t.snipeCd = 7; for (let i = 0; i < 7; i++) lob(g, t, 3 + g.rand() * (g.cols - 6), 4 + g.rand() * (g.rows - 12), 1.6 + g.rand() * 0.6, 1.3, 'star'); g.texts.push({ x: t.x, y: t.y - 2.6, s: 'はなび だァ！', zh: '放烟花啦！', t: 1.2, col: '#ffe36a', big: 2 }); }
      if (t.summonCd <= 0) { t.summonCd = 12; summon(g, t, d, 2, 3); }
      return false;
    },
    king(g, t, dt, d, f, e, near, base) {   // 戦車の王：これまでのボス（子どもたち）の技を順に使う。段階ごとに使える技が増える
      if (f < 0.75) phaseUp(g, t, 2, 'わがこの わざを みせよう', '让你们看看我孩子们的招式');
      if (f < 0.5) phaseUp(g, t, 3, 'まだ おわらんぞ', '还没结束');
      if (f < 0.25) phaseUp(g, t, 4, 'これが おうの ちからだ！', '这就是王的力量！');
      if (stepBurrow(g, t, dt, 12, e.bullet)) return true;
      if (stepRam(g, t, dt)) return true;
      if (stepLaser(g, t, dt, t.fireBeam)) return true;
      t.atkCd -= dt; t.skillCd = (t.skillCd === undefined ? 2.5 : t.skillCd) - dt;
      if (t.atkCd <= 0) { const a = aimAt(t, near, base); for (const o of [-0.3, 0, 0.3]) fireAt(g, t, a + o, e.bullet); t.atkCd = t.phase >= 3 ? 1.6 : 2.0; g.ev.push({ k: 'efire' }); }
      if (t.skillCd <= 0 && near) {
        t.skillCd = t.phase >= 4 ? 2.6 : 3.4;
        const list = ['side', 'laser'].concat(t.phase >= 2 ? ['burrow', 'ice'] : [], t.phase >= 3 ? ['fire', 'ram'] : [], t.phase >= 4 ? ['summon', 'missile'] : []);
        const sk = list[(t.skillI = (t.skillI || 0) + 1) % list.length];
        const NAME = { side: ['ふたご砲の わざ！', '双炮坦克的招式！'], laser: ['さそりの しっぽ！', '蝎子的尾巴！'], burrow: ['砂もぐりの わざ！', '钻沙者的招式！'], ice: ['氷の砲台の わざ！', '冰之炮台的招式！'],
          fire: ['火竜の ほのお！', '火龙的火焰！'], ram: ['除雪車の 体当たり！', '除雪车的冲撞！'], summon: ['大型戦車の なかま よび！', '大型坦克的召唤！'], missile: ['超ボスの ミサイル！', '超级首领的导弹！'] }[sk];
        g.texts.push({ x: t.x, y: t.y - 2.8, s: NAME[0], zh: NAME[1], t: 1.3, col: '#ffd23a', big: 1 });
        if (sk === 'side') { for (const a of [base + Math.PI / 2, base - Math.PI / 2, base + Math.PI / 2 + 0.35, base - Math.PI / 2 - 0.35]) fireAt(g, t, a, e.bullet); g.ev.push({ k: 'efire' }); }
        else if (sk === 'laser') { t.fireBeam = false; startLaser(g, t, near, 'しっぽビーム！', '尾巴光束！'); return true; }
        else if (sk === 'burrow') { t.st = 'dig'; t.stT = 0.7; g.fx.push({ k: 'dust', x: t.x, y: t.y + 1, t: 0.5, T: 0.5 }); return true; }
        else if (sk === 'ice') ring(g, t, 10, 6.5, { freeze: true, r: 0.36, kind: 'ice' });
        else if (sk === 'fire') lobAtPlayers(g, t, 3, 1.6, 1.5, 'fire', 3);
        else if (sk === 'ram') { startRam(g, t, near, 'どけどけー！', '让开让开！'); return true; }
        else if (sk === 'summon') summon(g, t, d, 2, 3);
        else if (sk === 'missile') { for (const a of [-1.2, 1.2]) g.missiles.push({ x: t.x, y: t.y, ang: base + a, t: MISSILE_LIFE }); g.ev.push({ k: 'missile' }); }
      }
      return false;
    }
  };
  Object.assign(V13_BOSS, V14_BOSS);

  /* ==================== P2-A BEGIN：家族のチームプレイ（v0.19） ====================
     No.23 役わり（攻撃・修理・偵察・指揮）／No.24 スマホだけの ひみつ情報／No.7 ふたりの合体わざ／No.39 ボスの弱点と部位こわし。
     - ここの乱数は g.rand2（別の種）だけを使う。前からある乱数（g.rand）の並びは変えない
     - 役わりは 車種・必殺技と別（どの車でも選べる）。選ばなければ ''（何も変わらない） */
  const ROLES = ['atk', 'fix', 'scout', 'lead'];
  const ROLE_ATK_DMG = 1.2;                 // 攻撃：弾の威力（体力 1 の敵には差が出ない。よろい・ボスに少し効く）
  const FIX_R = 7, FIX_TILE_SEC = 1.2;      // 修理：おうちからこの升より近くで「必殺」を押している間、この秒ごとに囲いを 1 升なおす
  const FIX_MATE_R = 3, FIX_MATE_SEC = 8;   // 修理：よろいの無い仲間のそばに この秒いると、よろいを 1 枚つける
  const SCOUT_R = 9, MARK_SEC = 1.2;        // 偵察：この升より近い敵に印（テレビ）
  const SIG_KINDS = ['gather', 'here', 'run'], SIG_SEC = 3, SIG_CD = 1;   // 指揮：合図 3 つ・テレビに出す秒・次に出せるまで
  const HINT_FIRST = [14, 22], HINT_GAP = [25, 40], HINT_SHOW = 7;       // ひみつ情報：最初・間隔（秒の幅）・スマホに出す秒
  const SECRET_LIFE = 30, SECRET_MAX = 3, SECRET_R = 1.6;                // かくれた宝箱：消えるまで・1 面の数・見つける距離
  const COMBO_WINDOW = 1.2, COMBO_NEAR = 4.5, COMBO_BLAST_R = 9;         // 合体わざ：待つ秒・ふたりの距離（升）・爆発の大きさ
  const COMBO_DMG = 6, COMBO_BOSS_DMG = 10, COMBO_BOSS_CAP = 0.3, COMBO_SHIELD = 3;   // 威力（ふつう・ボス）・ボスは最大体力のこの割合まで・みんなの盾（秒）
  const WEAK_MUL = 1.5, WEAK_HP_UP = 1.1;   // 弱点（うしろ）に当てた時の倍率・その分ボスの体力を少し増やす（ふつうの家族で 前と同じくらい）
  const PART_FRAC = 0.22, PART_R = 1.5, PART_STUN = 1.0, PART_SCORE = 500;   // 部位：体力（ボスの最大体力の割合）・当たる距離・こわれた時にボスが止まる秒・点
  /* 弱点の場所。back＝うしろ（向きの反対）。spin＝動かないボス：5 秒ごとに回る。null＝弱点なし（砂上戦艦は砲塔 3 つが先） */
  const WEAK_KIND = { sandship: null, core: 'spin' };
  /* こわせる部位。side＝向きから見た場所（F 前・B 後ろ・L 左・R 右）、pin＝こわれると使えなくなる技（その技の待ち時間を止める） */
  const BREAK = {
    superboss: { id: 'pod', side: 'L', pin: 'missileCd' }, bigtank: { id: 'pod', side: 'L', pin: 'missileCd' }, superstar: { id: 'pod', side: 'R', pin: 'missileCd' }, core: { id: 'pod', side: 'R', pin: 'missileCd' },
    twin: { id: 'gun', side: 'R', pin: 'sideCd' }, engineer: { id: 'crane', side: 'R', pin: 'buildCd' }, scorpion: { id: 'tail', side: 'B', pin: 'lzCd' },
    icegun: { id: 'icegun', side: 'F', pin: 'iceCd' }, flamer: { id: 'fuel', side: 'L', pin: 'lzCd' }, golem: { id: 'arm', side: 'R', pin: 'lzCd' }, dragon: { id: 'horn', side: 'F', pin: 'lzCd' }
  };
  const PART_NAME = { pod: ['ミサイルポッド', '导弹舱'], gun: ['よこの 砲', '侧炮'], crane: ['クレーン', '吊臂'], tail: ['しっぽ', '尾巴'], icegun: ['こおりの 砲', '冰炮'], fuel: ['ねんりょうタンク', '燃料罐'], arm: ['うで', '手臂'], horn: ['つの', '角'] };
  /* ボスの「つぎの わざ」（ひみつ情報）：[待ち時間の名前, わざ, 使える段階] */
  const BOSS_MOVES = {
    boss: [['summonCd', 'summon', 1]], superboss: [['missileCd', 'missile', 1], ['laserCd', 'laser', 1], ['summonCd', 'summon', 1]],
    twin: [['sideCd', 'side', 1], ['summonCd', 'summon', 2]], engineer: [['buildCd', 'wall', 1], ['summonCd', 'summon', 2]], bigtank: [['summonCd', 'summon', 2], ['missileCd', 'missile', 3]],
    scorpion: [['lzCd', 'laser', 1]], plow: [['ramCd', 'ram', 1], ['summonCd', 'summon', 2]], icegun: [['iceCd', 'ice', 1], ['lzCd', 'ring', 2]], snowman: [['ramCd', 'ram', 2], ['summonCd', 'summon', 1]],
    flamer: [['lzCd', 'ring', 2], ['summonCd', 'summon', 2]], golem: [['atkCd', 'slam', 1], ['lzCd', 'lob', 2]], dragon: [['missileCd', 'lob', 1], ['lzCd', 'laser', 2], ['snipeCd', 'rain', 3]],
    core: [['lzCd', 'laser', 2], ['missileCd', 'missile', 3], ['summonCd', 'summon', 3]], superstar: [['spotCd', 'lob', 1], ['missileCd', 'missile', 2], ['lzCd', 'laser', 2], ['summonCd', 'summon', 1]],
    shadow: [['swapCd', 'swap', 1], ['lzCd', 'ring', 3]], sisA: [['atkCd', 'shot', 1]], sisB: [['atkCd', 'shot', 1]], king: [['skillCd', 'skill', 1]], sandship: [['summonCd', 'summon', 2]]
  };
  function roleOf(p) { return (p && p.role) || ''; }
  function setRole(g, id, k) { const p = g.pl[id]; if (!p) return false; p.role = ROLES.includes(k) ? k : ''; return true; }
  function roleDmg(p) { return roleOf(p) === 'atk' ? ROLE_ATK_DMG : 1; }
  // 修理：スマホの「必殺」を押している間（スマホが 0.4 秒ごとに送り直す。届かなくなったら 1.2 秒で止まる）
  function setHold(g, id, on) { const p = g.pl[id]; if (p) p.holdT = on ? 1.2 : 0; }
  function initP2A(g) {
    g.rand2 = makeRand(((g.seed ^ 0x5bd1e995) + (g.stageIdx + 1) * 977 + (g.loop || 0) * 31) >>> 0);
    g.signals = []; g.hint = null; g.hintN = g.hintN || 0; g.hintT = HINT_FIRST[0] + g.rand2() * (HINT_FIRST[1] - HINT_FIRST[0]); g.hintLast = ''; g.hintKind = '';
    g.secret = null; g.secretN = 0; g.combo = null; g.evI2 = g.ev.length;
    for (const id in g.pl) { const p = g.pl[id]; p.holdT = 0; p.fixT = 0; p.fixing = 0; p.fixN = 0; p.mateT = 0; p.sigCd = 0; p.cmbT = 0; p.cmbN = 0; p.weakHits = 0; p.hintN = 0; }
  }
  /* ---------- No.23 役わり ---------- */
  function ringBroken(g) { if (!g.ring || g.noHouse || g.houseDead || g.wallT > 0) return []; return g.ring.filter(([x, y]) => { const c = tileAt(g, x, y); return c === '.' || c === 'b'; }); }
  function stepRoles(g, dt) {
    for (const t of g.tanks) if (t.side === 'e' && t.mark > 0) t.mark -= dt;
    // 仲間をたすけ起こした人が修理なら、起きた仲間に よろいを 1 枚（知らせ rescue を読む）
    if (g.evI2 > g.ev.length) g.evI2 = 0;
    for (; g.evI2 < g.ev.length; g.evI2++) { const e = g.ev[g.evI2]; if (e.k !== 'rescue') continue; const by = g.pl[e.by], q = g.pl[e.pid];
      if (by && q && roleOf(by) === 'fix' && q.armor < 1) { q.armor = 1; if (q.tank) g.texts.push({ x: q.tank.x, y: q.tank.y - 2.3, s: 'よろいも なおした！', zh: '护甲也修好了！', t: 1.4, col: '#9fe0ff' }); } }
    for (const id in g.pl) {
      const p = g.pl[id], t = p.tank, r = roleOf(p); if (p.sigCd > 0) p.sigCd -= dt; if (p.holdT > 0) p.holdT -= dt; p.fixing = 0;
      if (!t || !t.alive) { p.fixT = 0; continue; }
      if (r === 'fix') {
        if (p.holdT > 0 && !(t.stun > 0) && Math.hypot(t.x - g.hx, t.y - g.hy) < FIX_R) {
          const br = ringBroken(g);
          if (br.length) {
            p.fixing = 1; p.fixT += dt;
            if (p.fixT >= FIX_TILE_SEC) {
              // ひびのレンガを先に、次に戦車に近い穴。戦車が乗っている升は なおせない
              const free = br.filter(([x, y]) => !g.tanks.some(o => o.alive && Math.abs(o.x - (x + 0.5)) < o.half + 0.5 && Math.abs(o.y - (y + 0.5)) < o.half + 0.5));
              free.sort((a, b) => Math.hypot(a[0] + 0.5 - t.x, a[1] + 0.5 - t.y) - Math.hypot(b[0] + 0.5 - t.x, b[1] + 0.5 - t.y));
              const c = free[0];
              if (c) { p.fixT = 0; g.map[c[1]][c[0]] = 'B'; g.mapVer++; g.distDirty = true; p.fixN = (p.fixN || 0) + 1; g.fx.push({ k: 'spark', x: c[0] + 0.5, y: c[1] + 0.5, t: 0.4, T: 0.4 }); g.fx.push({ k: 'fix', x: c[0] + 0.5, y: c[1] + 0.5, t: 0.7, T: 0.7 }); g.ev.push({ k: 'fix', pid: id }); }
              else p.fixT = FIX_TILE_SEC;
            }
          } else p.fixT = 0;
        } else p.fixT = Math.max(0, p.fixT - dt);
        // よろいの無い仲間のそばにいると、よろいを 1 枚つける（自分には つかない）
        let mate = null; for (const qid in g.pl) { const q = g.pl[qid], o = q.tank; if (q !== p && o && o.alive && q.armor < 1 && Math.hypot(o.x - t.x, o.y - t.y) < FIX_MATE_R) { mate = q; break; } }
        if (mate) { p.mateT = (p.mateT || 0) + dt; p.mateId = mate.id;
          if (p.mateT >= FIX_MATE_SEC) { p.mateT = 0; mate.armor = 1; p.fixN = (p.fixN || 0) + 1; const o = mate.tank; g.texts.push({ x: o.x, y: o.y - 1.6, s: p.name + ' が よろいを なおした！', zh: p.name + ' 修好了护甲！', t: 1.5, col: '#9fe0ff' }); g.fx.push({ k: 'spark', x: o.x, y: o.y, t: 0.4, T: 0.4 }); g.ev.push({ k: 'fix', pid: id, mate: mate.id }); } }
        else { p.mateT = 0; p.mateId = null; }
      } else if (r === 'scout') {
        for (const o of g.tanks) if (o.side === 'e' && o.alive && !o.under && Math.hypot(o.x - t.x, o.y - t.y) < SCOUT_R) { if (!(o.mark > 0)) p.markN = (p.markN || 0) + 1; o.mark = MARK_SEC; o.markBy = p.slot; }
      }
    }
    for (const s of g.signals) s.t -= dt; if (g.signals.length) g.signals = g.signals.filter(s => s.t > 0);
  }
  // 指揮の合図（スマホの大きなボタン）。x・y が無ければ自分の戦車の所。テレビに 3 秒、大きな印が出る
  function signal(g, id, k, x, y) {
    const p = g.pl[id]; if (!p || g.ph !== 'play' || roleOf(p) !== 'lead' || !SIG_KINDS.includes(k) || p.sigCd > 0) return false;
    const t = p.tank; let sx = Number(x), sy = Number(y);
    if (!Number.isFinite(sx) || !Number.isFinite(sy)) { if (t) { sx = t.x; sy = t.y; } else { sx = g.hx; sy = g.hy - 4; } }
    sx = clamp(sx, 1.5, g.cols - 1.5); sy = clamp(sy, 1.5, g.rows - 1.5); p.sigCd = SIG_CD; p.sigN = (p.sigN || 0) + 1;
    g.signals = g.signals.filter(s => s.pid !== id); g.signals.push({ k, x: sx, y: sy, pid: id, slot: p.slot, name: p.name, t: SIG_SEC, T: SIG_SEC, n: ++g.hintN });
    g.ev.push({ k: 'signal', sig: k, pid: id }); return true;
  }
  /* ---------- No.24 ひみつ情報：ひとりのスマホにだけ出る（テレビには出さない）。試合は止まらない ---------- */
  function bossNextMove(g) {
    let best = null;
    for (const t of bossesOf(g)) {
      if (t.under && t.kind !== 'burrower' && t.kind !== 'airship') continue;
      const c = [];
      if (t.kind === 'burrower') { if (t.st === 'surf') c.push([t.stT, 'dig']); else c.push([Math.max(0.5, t.stT), 'pop']); }
      else if (t.kind === 'airship') { if (t.st === 'fly') c.push([t.stT, 'land']); else if (t.st === 'ground') c.push([t.stT, 'fly']); }
      else for (const [f, mv, ph] of BOSS_MOVES[t.kind] || []) {
        if ((t.phase || 1) < ph || t[f] === undefined) continue; if (t.bp && t.bp.some(q => q.hp <= 0 && q.pin === f)) continue;
        if (t.kind === 'boss' && t.hp >= t.maxHp / 2) continue;
        c.push([t[f], mv]);
      }
      if (t.p4bMv) for (const [f, mv] of t.p4bMv) if (t[f] > 0) c.push([t[f], mv]);   // P4B：かりた わざ
      // 2 秒より先の技を先に（読む時間がある）。無ければ、すぐ来る技（くり返す技）
      for (const [cd, mv] of c) if (cd > 0.2 && cd < 9 && (!best || (cd >= 2) > (best.sec >= 2) || ((cd >= 2) === (best.sec >= 2) && cd < best.sec))) best = { mv, sec: cd, kind: t.kind };
    }
    return best;
  }
  function placeSecret(g) {
    const y0 = g.view ? Math.ceil(g.view.y) + 2 : 3, y1 = (g.view ? Math.floor(g.view.y + g.view.h) : g.rows) - 3; let best = null, bd = -1;
    for (let i = 0; i < 40; i++) {
      const x = 2 + Math.floor(g.rand2() * (g.cols - 3)), y = y0 + Math.floor(g.rand2() * Math.max(1, y1 - y0)); if (!placeFree(g, x, y, HALF)) continue;
      if (Math.hypot(x - g.hx, y - g.hy) < 4) continue;
      let md = 1e9; for (const o of g.tanks) if (o.side === 'p' && o.alive) md = Math.min(md, Math.hypot(o.x - x, o.y - y));
      if (md >= 6 && md <= 16) return { x, y }; const sc = md < 6 ? md : 6 - (md - 16) * 0.1; if (sc > bd) { bd = sc; best = { x, y }; }
    }
    return best && bd >= 3 ? best : null;
  }
  function hintTarget(g) {
    const ps = Object.values(g.pl); if (!ps.length) return null;
    const live = ps.filter(p => p.tank && p.tank.alive), pool = live.length ? live : ps;
    const sc = pool.filter(p => roleOf(p) === 'scout'); if (sc.length) return sc[Math.floor(g.rand2() * sc.length)];   // 偵察がいれば偵察へ
    const rest = pool.length > 1 ? pool.filter(p => p.id !== g.hintLast) : pool;                                        // いなければ順番に（同じ人が続かない）
    return rest[Math.floor(g.rand2() * rest.length)];
  }
  function makeHint(g) {
    const to = hintTarget(g); if (!to) return null; const opts = [];
    const bm = bossNextMove(g); if (bm) opts.push('boss', 'boss');
    if (g.queue.length && !g.goalY && g.gates && g.gates.length) opts.push('gate');
    if (!g.secret && g.secretN < SECRET_MAX && !g.truck && !g.goalY) opts.push('chest');
    let pick = opts.filter(k => k !== g.hintKind); if (!pick.length) pick = opts; if (!pick.length) return null;
    const k = pick[Math.floor(g.rand2() * pick.length)], h = { id: ++g.hintN, to: to.id, slot: to.slot, k, t: HINT_SHOW, T: HINT_SHOW };
    if (k === 'boss') { h.mv = bm.mv; h.sec = Math.round(bm.sec * 10) / 10; h.boss = bm.kind; }
    else if (k === 'gate') { const gt = g.gates[g.gateI % g.gates.length], g2 = g.gates[(g.gateI + 1) % g.gates.length]; h.x = gt.x; h.y = gt.y; h.kind = g.queue[0]; if (g.queue.length > 1 && g2 !== gt) { h.x2 = g2.x; h.y2 = g2.y; h.kind2 = g.queue[1]; } }
    else { const sp = placeSecret(g); if (!sp) return null; const r = g.rand2(); g.secret = { x: sp.x, y: sp.y, kind: r < 0.25 ? 'silver' : 'wood', t: SECRET_LIFE, hint: h.id }; g.secretN++; h.x = sp.x; h.y = sp.y; h.kind = g.secret.kind; }
    return h;
  }
  function stepHints(g, dt) {
    if (g.hint) { g.hint.t -= dt; if (g.hint.t <= 0 || !g.pl[g.hint.to]) g.hint = null; }
    if (g.secret) { const s = g.secret; s.t -= dt;
      const by = Object.values(g.pl).find(p => p.tank && p.tank.alive && Math.hypot(p.tank.x - s.x, p.tank.y - s.y) < SECRET_R);
      if (by) {   // 見つけた：ふつうの宝箱になって出てくる（次の刻みで取る）
        g.secret = null; g.secretFound = (g.secretFound || 0) + 1; g.chests.push({ x: s.x, y: s.y, kind: s.kind, t: CHEST_LIFE[s.kind], T: CHEST_LIFE[s.kind], secret: true });
        g.texts.push({ x: s.x, y: s.y - 2, s: 'ひみつの 宝箱を 見つけた！', zh: '发现了秘密宝箱！', t: 1.8, col: '#ffe36a', big: 3 }); g.fx.push({ k: 'spark', x: s.x, y: s.y, t: 0.5, T: 0.5 }); g.ev.push({ k: 'secret', pid: by.id });
      } else if (s.t <= 0) g.secret = null;
    }
    if (!playerCount(g)) return;
    g.hintT -= dt; if (g.hintT > 0) return;
    const h = makeHint(g);
    if (!h) { g.hintT = 5; return; }
    g.hint = h; g.hintLast = h.to; g.hintKind = h.k; g.hintT = HINT_GAP[0] + g.rand2() * (HINT_GAP[1] - HINT_GAP[0]); g.pl[h.to].hintN = (g.pl[h.to].hintN || 0) + 1; g.ev.push({ k: 'hint', pid: h.to });
  }
  /* ---------- No.7 ふたりの合体わざ：近くのふたりが、1 秒くらいの間に つづけて「必殺」を押す ----------
     先に押した人は、近くに「たまっている仲間」がいる時だけ COMBO_WINDOW 秒待つ（いなければ すぐ自分の必殺技）。
     待っている間に仲間が押せば合体わざ。押さなければ、自分の必殺技がそのまま出る */
  function comboMate(g, p, waiting) {
    const t = p.tank; let best = null, bd = COMBO_NEAR;
    for (const qid in g.pl) { const q = g.pl[qid], o = q.tank; if (q === p || !o || !o.alive) continue; if (waiting ? !(q.cmbT > 0) : q.sp < SP_NEED) continue;
      const dd = Math.hypot(o.x - t.x, o.y - t.y); if (dd <= bd) { bd = dd; best = q; } }
    return best;
  }
  function comboGate(g, id) {
    const p = g.pl[id]; if (p.cmbT > 0) return true;   // もう待っている
    const w = comboMate(g, p, true); if (w) { fireCombo(g, w, p); return true; }
    if (comboMate(g, p, false)) { p.cmbT = COMBO_WINDOW; g.ev.push({ k: 'combowait', pid: id }); return true; }
    return false;
  }
  function fireCombo(g, a, b) {
    const ta = a.tank, tb = b.tank, x = (ta.x + tb.x) / 2, y = (ta.y + tb.y) / 2, L = (modsOf(a).spLv | 0) + (modsOf(b).spLv | 0), R = COMBO_BLAST_R + L * 0.4;
    a.cmbT = 0; b.cmbT = 0; a.sp -= SP_NEED; b.sp -= SP_NEED; a.spN = (a.spN || 0) + 1; b.spN = (b.spN || 0) + 1; a.cmbN = (a.cmbN || 0) + 1; b.cmbN = (b.cmbN || 0) + 1;
    g.fx.push({ k: 'combo', x, y, r: R, t: 1.4, T: 1.4, sa: a.slot, sb: b.slot, ax: ta.x, ay: ta.y, bx: tb.x, by: tb.y }); g.shake = Math.max(g.shake, 0.8);
    let i = 0;
    for (const o of g.tanks.slice()) if (o.side === 'e' && o.alive && Math.hypot(o.x - x, o.y - y) < R)
      damageEnemy(g, o, o.boss ? Math.max(3, Math.min(COMBO_BOSS_DMG + L, Math.ceil(o.maxHp * COMBO_BOSS_CAP))) : COMBO_DMG + L, (i++ % 2 ? b : a).id, true);
    for (const s of g.missiles) if (Math.hypot(s.x - x, s.y - y) < R) s.dead = true;
    for (const s of g.bullets) if (s.side === 'e' && Math.hypot(s.x - x, s.y - y) < R) s.dead = true;
    for (const o of g.tanks) if (o.side === 'p' && o.alive) o.shield = Math.max(o.shield, COMBO_SHIELD);
    g.combo = { a: a.name, b: b.name, sa: a.slot, sb: b.slot, t: 2.4, T: 2.4 }; g.comboN = (g.comboN || 0) + 1;
    g.ev.push({ k: 'combo2', a: a.id, b: b.id });
  }
  function stepCombo(g, dt) {
    if (g.combo) { g.combo.t -= dt; if (g.combo.t <= 0) g.combo = null; }
    for (const id in g.pl) { const p = g.pl[id]; if (!(p.cmbT > 0)) continue; p.cmbT -= dt;
      if (p.cmbT <= 0) { p.cmbT = 0; g.soloSp = true; try { useSpecial(g, id); } finally { g.soloSp = false; } } }
  }
  /* ---------- No.39 弱点と部位こわし ---------- */
  function initWeak(g, t) {
    const w = WEAK_KIND[t.kind] === undefined ? 'back' : WEAK_KIND[t.kind];
    if (w) { t.weak = w; t.hp = t.maxHp = Math.round(t.maxHp * WEAK_HP_UP); }
    const b = BREAK[t.kind]; if (b) { const hp = Math.max(3, Math.round(t.maxHp * PART_FRAC)); t.bp = [{ id: b.id, side: b.side, pin: b.pin, hp, maxHp: hp, flash: 0 }]; }
  }
  function weakDirOf(g, t) { return t.weak === 'spin' ? Math.floor(g.t / 5) % 4 : (t.dir + 2) % 4; }
  function partPos(t, q) {
    const f = q.side === 'F' ? 1 : q.side === 'B' ? -1 : 0, r = q.side === 'R' ? 1 : q.side === 'L' ? -1 : 0, o = t.half * 0.7, d = t.dir;
    return { x: t.x + (DX[d] * f - DY[d] * r) * o, y: t.y + (DY[d] * f + DX[d] * r) * o };
  }
  // 味方の弾がボスに当たった時の威力。弱点（うしろから）は WEAK_MUL 倍。部位のそばに当たれば、体と同時に部位も けずる
  function weakHit(g, t, b) {
    if (!t.boss || t.guard > 0 || (t.parts && t.parts.some(q => q.hp > 0))) return b.dmg;
    let dmg = b.dmg; const p = b.pid && g.pl[b.pid];
    if (t.weak) { const wd = weakDirOf(g, t), ox = DX[wd], oy = DY[wd], sp = Math.hypot(b.vx, b.vy) || 1;
      if ((b.x - t.x) * ox + (b.y - t.y) * oy > t.half * 0.4 && (b.vx * ox + b.vy * oy) < -0.7 * sp) {
        dmg *= WEAK_MUL; if (p) p.weakHits = (p.weakHits || 0) + 1; g.fx.push({ k: 'weak', x: b.x, y: b.y, t: 0.35, T: 0.35 }); g.ev.push({ k: 'weak' });
        if (!(g.t - (t.weakTxtT || -9) < 1.5)) { t.weakTxtT = g.t; g.texts.push({ x: t.x, y: t.y - 2.9, s: 'じゃくてん！ ×1.5', zh: '弱点！×1.5', t: 0.9, col: '#ff5ad0', big: 2 }); }
      } }
    if (t.bp) for (const q of t.bp) { if (q.hp <= 0) continue; const pp = partPos(t, q); if (Math.hypot(b.x - pp.x, b.y - pp.y) >= PART_R) continue;
      q.hp -= b.dmg; q.flash = 0.12; if (q.hp <= 0) breakPart(g, t, q, p); }
    return dmg;
  }
  function breakPart(g, t, q, p) {
    q.hp = 0; const pp = partPos(t, q), nm = PART_NAME[q.id];
    g.fx.push({ k: 'boom', x: pp.x, y: pp.y, r: 1.5, t: 0.8, T: 0.8 }); g.fx.push({ k: 'partbreak', x: pp.x, y: pp.y, t: 1.1, T: 1.1, id: q.id }); g.shake = Math.max(g.shake, 0.45);
    t.freeze = Math.max(t.freeze || 0, PART_STUN); t[q.pin] = 9; if (p) { p.score += PART_SCORE; p.partN = (p.partN || 0) + 1; } g.partBreaks = (g.partBreaks || 0) + 1;
    g.banner = { s: nm[0] + 'を こわした！', zh: '打坏了' + nm[1] + '！', t: 1.8 }; g.ev.push({ k: 'partbreak', id: q.id, pid: p ? p.id : null });
  }
  // こわれた部位の技は、待ち時間を止めて使えなくする（ボスの動きのコードは変えない）
  function stepBossParts(g, dt) { for (const t of g.tanks) { if (!t.bp || !t.alive) continue; for (const q of t.bp) { if (q.flash > 0) q.flash -= dt; if (q.hp <= 0) t[q.pin] = 9; } } }
  function stepP2A(g, dt) { if (!g.rand2) initP2A(g); stepRoles(g, dt); stepHints(g, dt); stepCombo(g, dt); stepBossParts(g, dt); }
  /* ==================== P2-A END ==================== */

  /* ---------- 1 刻み ---------- */
  function step(g, dt, now) {
    if (g.paused) return;
    if (g.ph === 'intro') { g.phT -= dt; if (g.banner) g.banner.t -= dt; if (g.phT <= 0) { g.ph = 'play'; g.banner = null; g.ev.push({ k: 'go' }); } return; }
    if (g.ph === 'clear') { g.phT -= dt; if (g.phT <= 0) afterClear(g); return; }
    if (g.ph === 'loop') { g.phT -= dt; if (g.phT <= 0) nextLoop(g); return; }
    if (g.ph !== 'play') return;
    if (g.talk) { stepTalk(g, dt); return; }   // 台詞の間は戦いを止める
    if (g.reveal) { g.reveal.t -= dt; if (g.reveal.t <= 0) g.reveal = null; }
    if (g.banner) { g.banner.t -= dt; if (g.banner.t <= 0) g.banner = null; }
    if (g.pauseT > 0) { g.pauseT -= dt; return; }   // アイテムを取った時の一拍
    g.t += dt; const d = diff(g), n = playerCount(g), fx = fxOf(g);
    if (g.shake > 0) g.shake = Math.max(0, g.shake - dt);
    if (g.alertT > 0) g.alertT -= dt;
    if (g.stopT > 0) g.stopT -= dt;
    if (g.wallT > 0) { g.wallT -= dt; if (g.wallT <= 0) setRing(g, g.wallTile); }
    g.distT -= dt; if (g.goalY && g.distT <= 0) g.distDirty = true;   // 突破：敵は味方へ向かう（味方が動くので作り直す）
    if (g.distDirty && g.distT <= 0) { buildDist(g); g.distT = g.goalY ? 0.8 : 0.5; }
    if (g.shut) stepShutters(g, dt);
    rescueStuck(g, dt); stepDowns(g, dt);
    stepP2A(g, dt);   // P2-A
    p3dStep(g, dt);   // P3D-49：ひみつの かべ
    // 味方
    for (const id in g.pl) {
      const p = g.pl[id];
      if (now - p.in.at > INPUT_STALE_MS) p.in.d = -1;
      if (!p.tank && p.lives > 0) {
        p.respawn -= dt; const sp = p.respawn <= 0 ? spawnPoint(g, p) : null;
        if (sp && placeFree(g, sp.x, sp.y, HALF) && !(g.p3dDuel && g.p3dDuel.pid !== id)) { const m = modsOf(p); p.tank = newTank('p', sp.x, sp.y, 0, { pid: id, slot: p.slot, shield: d.shield + m.inv + p.firstShield, car: m.car, dashT: 0 }); p.firstShield = 0; g.tanks.push(p.tank); }   // P3D-duel：けっとうは その人だけ
      }
      const t = p.tank; if (!t) continue;
      if (t.shield > 0) t.shield -= dt; if (t.flash > 0) t.flash -= dt; if (t.iced > 0) t.iced -= dt;
      if (t.stun > 0) { t.stun -= dt; t.moving = false; continue; }
      t.cd -= dt;
      const onIce = onTile(g, t, 'I');
      let dir = p.in.d;
      const m = modsOf(p); if (t.dashT > 0) t.dashT -= dt;
      if (dir >= 0) t.slide = onIce && !m.grip ? (fx.ice ? 0.7 : 0.4) : 0; else if (t.slide > 0) { t.slide -= dt; dir = t.dir; }
      const gs = m.grip ? Math.max(1, groundSpeed(g, t)) : groundSpeed(g, t), fs = m.grip ? Math.max(1, fx.playerSpeed || 1) : (fx.playerSpeed || 1);
      moveTank(g, t, dir, CFG.playerSpeed * fs * gs * m.speed * (t.dashT > 0 ? 1.6 : 1), dt);
      if (p.fireQ > 0) { if (fire(g, t, p)) p.fireQ = 0; else p.fireQ -= dt; }
      for (const it of g.items) if (!it.dead && Math.hypot(it.x - t.x, it.y - t.y) < 1.4) { it.dead = true; pickItem(g, p, it); }
      for (const c of g.chests) if (!c.dead && Math.hypot(c.x - t.x, c.y - t.y) < 1.5) { c.dead = true; takeChest(g, id, c); }
      for (const m of g.mines) if (!m.dead && m.arm <= 0 && Math.hypot(m.x - t.x, m.y - t.y) < 1.1) { m.dead = true; explode(g, m.x, m.y, 1.4, 'e'); }
      if (t.alive) stepLava(g, p, t, dt);
    }
    stepTruck(g, dt); stepView(g, dt); stepWarps(g, dt);
    g.items = g.items.filter(it => !it.dead && (it.t -= dt) > 0);
    g.chests = g.chests.filter(c => !c.dead && (c.t -= dt) > 0);
    // 敵を出す
    if (g.stage.boss && !g.bossSpawned && g.t > 3) {
      if (!g.bossWarned) { g.bossWarned = true; g.banner = { s: g.mode === 'hell' ? '超ボスがくる！' : 'ボスがくる！', zh: g.mode === 'hell' ? '超级首领来了！' : '首领来了！', t: 2 }; g.ev.push({ k: 'bosswarn' }); }
      if (g.t > 5 && placeFree(g, g.bossX, 2, BOSS_HALF)) { g.bossSpawned = true; spawnEnemy(g, g.stage.boss, g.bossX, 2, d); }
    }
    // ぼうけんのボス（1〜2 体）。出たら台詞
    if (g.bossQ && g.bossQ.length && g.t > 3) {
      if (!g.bossWarned) { g.bossWarned = true; g.banner = { s: 'ボスがくる！', zh: '首领来了！', t: 2 }; g.ev.push({ k: 'bosswarn' }); }
      if (g.t > 5) {
        const came = [];
        for (let i = 0; i < g.bossQ.length; i++) {
          const kind = g.bossQ[i]; let bx = g.bossXs[Math.min(g.stage.bosses.indexOf(kind), g.bossXs.length - 1)] || g.bossX, by = kind === 'sandship' ? 3 : 2;
          if (kind === 'core' && g.corePos && g.corePos.length) { bx = g.corePos[0].x; by = g.corePos[0].y; }
          if (!placeFree(g, bx, by, BOSS_HALF)) continue;
          spawnEnemy(g, kind, bx, by, d); came.push(kind); g.bossQ.splice(i, 1); i--;
        }
        if (came.length) { g.bossSpawned = true; startTalk(g, came, 'enter'); if (g.talk) return; }
      }
    }
    if (g.stage.reunion || g.cameo) { stepReunion(g, dt, d); if (g.talk) return; }   // P2-22：ボスとの再会
    if (g.talkWait && g.talkWait.length) { for (const w of g.talkWait) w.t -= dt; const w = g.talkWait.find(x => x.t <= 0); if (w) { g.talkWait.splice(g.talkWait.indexOf(w), 1); startTalk(g, w.kinds, w.which); if (g.talk) return; } }
    if (g.mode === 'adv' || g.mode === 'rand') stepCaptains(g, dt, d);
    if (g.survive && !g.queue.length && g.t < g.survive - 6) g.queue = buildQueue(g, d);   // 生き残り：時間まで敵が来つづける
    if ((g.truck || g.goalY) && !g.queue.length) g.queue = buildQueue(g, d);   // 護送・突破：着くまで敵が来つづける
    g.spawnT -= dt;
    if (g.spawnT <= 0 && g.queue.length && enemiesOnField(g) + g.pending.length < d.onField) {
      const gt = gateFor(g); g.pending.push({ x: gt.x, y: gt.y, t: CFG.spawnWarnSec, kind: g.queue.shift() });
      g.spawnT = d.spawnGap;
    }
    for (const s of g.pending) {
      s.t -= dt;
      // 出口に戦車がいて出られない時：3 秒待ったら、空いている別の出口（無ければ出口の近く）から出す
      if (s.t <= -3 && !placeFree(g, s.x, s.y, HALF)) {
        const alt = g.gates.find(gt => placeFree(g, gt.x, gt.y, HALF)) || findFree(g, s.x, s.y + 2, 5);
        if (alt) { s.x = alt.x; s.y = alt.y; s.t = Math.min(s.t, 0); }
      }
      if (s.t <= 0 && placeFree(g, s.x, s.y, HALF)) {
        g.spawned++; const t = spawnEnemy(g, s.kind, s.x, s.y, d, { glow: g.spawned % d.itemEvery === 0 }); t.cd = 0.8; s.done = true;
        if (ENEMY[s.kind].elite) g.ev.push({ k: 'bosswarn' });
      }
    }
    g.pending = g.pending.filter(s => !s.done);
    for (const t of g.tanks) { if (!t.alive || t.side !== 'e') continue; if (t.flash > 0) t.flash -= dt; if (t.freeze > 0) t.freeze -= dt; enemyThink(g, t, dt, d); }
    stepTower(g, dt);
    for (const b of g.bullets) if (!b.dead) stepBullet(g, b, dt);
    for (const b of g.bullets) if (b.dead && !b.counted) { b.counted = true; if (b.owner) b.owner.out = Math.max(0, b.owner.out - 1); }
    g.bullets = g.bullets.filter(b => !b.dead);
    for (const s of g.shells) { if (g.stopT > 0) continue; s.t -= dt; if (s.t <= 0) { s.dead = true; explode(g, s.x, s.y, s.r, 'e'); if (s.kind === 'lava') addPool(g, s.x, s.y); } }
    g.shells = g.shells.filter(s => !s.dead);
    for (const m of g.mines) { if (m.arm > 0) m.arm -= dt; m.t -= dt; if (m.t <= 0) m.dead = true; }
    g.mines = g.mines.filter(m => !m.dead);
    stepMissiles(g, dt); stepBeams(g, dt);
    if (g.pools.length) stepPools(g, dt);
    if (g.flags.length) stepFlags(g, dt);
    g.tanks = g.tanks.filter(t => t.alive);
    for (const f of g.fx) f.t -= dt; g.fx = g.fx.filter(f => f.t > 0);
    for (const x of g.texts) { x.t -= dt; x.y -= dt * 0.8; } g.texts = g.texts.filter(x => x.t > 0);
    if (g.ph !== 'play') return;
    if (g.p3dDuel && p3dDuelEnd(g)) return;   // P3D-duel
    if (n && Object.values(g.pl).every(p => p.lives <= 0 && !p.tank)) { endGame(g, 0, 'out'); return; }
    if (g.truck) { if (g.truck.done) { sweepEnemies(g); finishStage(g); } return; }   // 護送：トラックがゴールに着けば勝ち
    if (g.goalY) { if (g.tanks.some(t => t.side === 'p' && t.alive && t.y <= g.goalY)) { g.btProg = 1; sweepEnemies(g); finishStage(g); } return; }   // 突破：だれかがゴールに着けば勝ち
    if (g.flags.length) { if (g.flags.every(f => f.own)) { sweepEnemies(g); finishStage(g); } return; }   // 占領：旗 3 本で勝ち
    if (g.survive) { if (g.t >= g.survive) { sweepEnemies(g); finishStage(g); } return; }        // 生き残り：時間まで守れば勝ち
    if (enemiesRemaining(g) === 0 && !g.talk && !(g.talkWait && g.talkWait.length)) finishStage(g);
  }

  /* 確かめ・画面の上の表示に使う、状態のまとめ */
  function summary(g) {
    const b = bossOf(g);
    return { ph: g.ph, mode: g.mode, stage: g.stageIdx, loop: g.loop, fx: g.stage ? g.stage.fx : '', cols: g.cols, players: playerCount(g), left: g.ph === 'play' ? enemiesRemaining(g) : 0,
      enemyTotal: g.enemyTotal, onField: enemiesOnField(g), futon: g.futon, tower: g.tower, slow: g.slow, paused: g.paused,
      boss: b ? { hp: b.hp, max: b.maxHp, kind: b.kind } : null, win: g.win, why: g.why, t: Math.round(g.t * 10) / 10,
      talk: g.talk ? { i: g.talk.i, n: g.talk.lines.length, ready: talkReady(g) } : null, stars: g.stars, par: g.par, houseHits: g.houseHits, bosses: bossesOf(g).map(t => t.kind),
      chests: g.chests.length, flags: g.flags.map(f => f.own), type: g.stage ? g.stage.type || null : null, rows: g.rows,
      truck: g.truck ? { hp: g.truck.hp, max: g.truck.max, prog: Math.round(g.truckProg * 100), wait: g.truck.wait, done: g.truck.done } : null, view: g.view ? Math.round(g.view.y * 10) / 10 : null, prog: g.goalY ? Math.round(g.btProg * 100) : null, survive: g.survive, kills: g.stageKills || 0, killGoal: g.killGoal, pools: g.pools.length, pl: Object.values(g.pl).map(p => ({ slot: p.slot, sp: p.sp, lives: p.lives, power: p.power, twin: p.twin, armor: p.armor, score: p.score, kills: p.kills, stuns: p.stuns, alive: !!p.tank })) };
  }

  /* ==================== P3D BEGIN（v0.20：物語）====================
     No.2 ボス戦車の必殺技／No.30 2 周目（g.p3dLap）／No.49 ひみつの かべ・たからの部屋（g.stage.p3dSec・p3dChests、g.p3dList）。
     - どれも g.rand を使わない（面の種から作る自分の乱数）。p3dLap・p3dSec・p3dList が無ければ、今までと まったく同じ動き
     - ボス戦車の必殺技の弾は side 'h'（味方をすり抜ける。味方を しびれさせない） */
  const P3D_CARS = ['kk', 'kb', 'kw', 'kn', 'kd', 'kc'];
  const P3D_SP = { royal: ['王のごうれい！', '王之号令！'], bigshot: ['どっかん砲！', '轰天大炮！'], broadside: ['いっせいほうげき！', '齐射！'], guard: ['まもりの ひかり！', '守护之光！'], snow: ['ゆきやこんこ！', '漫天飞雪！'], flame: ['ほのおの いき！', '火焰吐息！'] };
  const P3D_LAP = { hp: 1, speed: 1.1, fire: 0.9, bossHp: 1.3, special: 0.2 };   // 2 周目：体力 +1・速さ 1.1 倍・撃つ間隔 0.9 倍・ボスの体力 1.3 倍・ふつうの敵の 2 割が 自作の敵に
  const P3D_FLAME_R = 7, P3D_FLAME_ANG = 0.6, P3D_SNOW_SEC = 4, P3D_SNOW_R = 5, P3D_GUARD = [2, 4];   // guard：みんなの盾 2 秒・じぶん 4 秒（＋ 0.5 × 強化）
  function p3dRng(seed) { let a = (seed >>> 0) || 1; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function p3dLapOn(g) { return !!g.p3dLap && g.mode === 'adv' && !g.p3dList && !!g.stage; }
  function p3dDiff(g, d) {
    const du = g.stage && g.stage.p3dDuel;
    if (du) { d.bossHp = du.hpMul; d.fire *= du.fireMul; d.speed *= du.spdMul; return d; }   // けっとう：人数・2 周目の 強さは 使わない
    if (g.stage && g.stage.p4b) return p4bDiff(g, d);   // P4B：ボスちょうせん（2 周目・けっとうの後の 弱りは 使わない）
    if (p3dLapOn(g)) { d.hpBonus += P3D_LAP.hp; d.speed *= P3D_LAP.speed; d.fire *= P3D_LAP.fire; d.bossHp *= P3D_LAP.bossHp; }
    if (g.p3dBossCut && g.mode === 'adv' && g.stage && g.stage.bosses && !g.p3dList) d.bossHp *= g.p3dBossCut;   // けっとうの後：ボスが つかれている
    return d; }
  function p3dSpecial(g, p, t, m, L, id) {
    const sp = m.sp; if (!P3D_SP[sp]) return false;
    const fwd = Math.atan2(DY[t.dir], DX[t.dir]); let n = 0;
    const shot = (ang, speed, extra) => { n++; addBullet(g, Object.assign({ x: t.x + Math.cos(ang) * 1.1, y: t.y + Math.sin(ang) * 1.1, vx: Math.cos(ang) * speed, vy: Math.sin(ang) * speed, side: 'h', owner: null, pid: id, r: 0.26, dmg: 2, kind: 'p3d', slot: p.slot }, extra)); };
    if (sp === 'royal') { const k = 12 + L * 2; for (let i = 0; i < k; i++) shot(i * Math.PI * 2 / k, 9, { dmg: 2 }); t.shield = Math.max(t.shield, 2 + L * 0.5); }
    else if (sp === 'bigshot') shot(fwd, 10, { r: 0.5, dmg: 4 + L, steel: true, pierce: 4 });
    else if (sp === 'broadside') for (const a of [-0.22, 0, 0.22]) shot(fwd + a, 13, { dmg: 2 + L * 0.5, pierce: 2 });
    else if (sp === 'guard') { for (const o of g.tanks) if (o.side === 'p' && o.alive) o.shield = Math.max(o.shield, o === t ? P3D_GUARD[1] + L * 0.5 : P3D_GUARD[0] + L * 0.5); }   // 盾だけ（「みんなに盾」wall より 弱い）
    else if (sp === 'snow') {
      g.stopT = Math.max(g.stopT, P3D_SNOW_SEC + L);
      for (const o of g.tanks.slice()) if (o.side === 'e' && o.alive && Math.hypot(o.x - t.x, o.y - t.y) < P3D_SNOW_R) damageEnemy(g, o, 1, id, true);
      g.ev.push({ k: 'freeze' });
    } else if (sp === 'flame') {
      const R = P3D_FLAME_R + L * 0.5, inCone = (x, y) => { const dx = x - t.x, dy = y - t.y, dd = Math.hypot(dx, dy); if (dd > R) return false; if (dd < 1.6) return true; let a = Math.abs(Math.atan2(dy, dx) - fwd); if (a > Math.PI) a = Math.PI * 2 - a; return a < P3D_FLAME_ANG; };
      for (const o of g.tanks.slice()) if (o.side === 'e' && o.alive && inCone(o.x, o.y)) damageEnemy(g, o, (o.boss ? 4 : 3) + L, id, true);
      for (const b of g.bullets) if (b.side === 'e' && inCone(b.x, b.y)) b.dead = true;
      g.ev.push({ k: 'bigboom' });
    }
    p.shots += n;   // 命中の割合が 100% を こえないように、撃った数に入れる
    g.fx.push({ k: 'p3dsp', sp, x: t.x, y: t.y, dir: t.dir, slot: p.slot, r: sp === 'flame' ? P3D_FLAME_R + L * 0.5 : sp === 'snow' ? P3D_SNOW_R : 3, t: 0.7, T: 0.7 });
    return true;
  }
  // 2 × 2 升が ぜんぶ ch か
  function p3dBlock(g, x, y, chs) { for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) { if (x + dx < 1 || y + dy < 1 || x + dx >= g.cols - 1 || y + dy >= g.rows - 1) return false; if (!chs.includes(g.map[y + dy][x + dx])) return false; } return true; }
  function p3dFarFromDoors(g, cx, cy) {
    for (const gt of g.gates || []) if (Math.hypot(gt.x - cx, gt.y - cy) < 4) return false;
    for (const sp of g.spawns || []) if (Math.hypot(sp.x - cx, sp.y - cy) < 4) return false;
    return g.noHouse || Math.hypot(g.hx - cx, g.hy - cy) >= 7;
  }
  function p3dStageInit(g, d) {
    g.p3dDuel = null; g.p3dArena = null; if (g.stage.p3dDuel) { p3dDuelInit(g, d); return; }
    g.p3dSec = null; const st = g.stage, R = p3dRng((st.seed | 0) * 31 + g.cols * 7 + 12345);
    // 2 周目：ふつうの敵の 2 割を 自作の敵に かえる。ボスの いない面は 隊長を 1 台 足す（ふつうの敵と 入れかえるので、数は同じ）
    if (p3dLapOn(g)) {
      const ns = []; g.queue.forEach((k, i) => { if (k === 'normal') ns.push(i); });
      for (let n = Math.ceil(ns.length * P3D_LAP.special); n > 0 && ns.length; n--) g.queue[ns.splice(Math.floor(R() * ns.length), 1)[0]] = SPECIALS[Math.floor(R() * SPECIALS.length)];
      if (!st.bosses && !g.truck && !g.goalY) { const i = g.queue.lastIndexOf('normal'); if (i >= 0) g.queue[i] = 'captain'; }
    }
    // ひみつの かべ：ふつうの面の どこかの レンガの となりに、レンガを 1 かたまり（2 × 2 升）足す。こわすと 見つかる
    if (g.mode === 'adv' && !g.p3dList && st.p3dSec && !g.truck && !g.goalY && g.map.length) {
      let pos = null, alt = null; const par = st.gen ? 1 : 0;
      for (let k = 0; k < 400 && !pos; k++) {
        const x = 2 + Math.floor(R() * (g.cols - 5)), y = 5 + Math.floor(R() * Math.max(1, g.rows - 15)), bx = x - ((x - par) & 1), by = y - ((y - par) & 1);
        if (!p3dBlock(g, bx, by, ['.']) || !p3dFarFromDoors(g, bx + 1, by + 1)) continue;
        if (!alt) alt = { x: bx, y: by };
        if (p3dBlock(g, bx - 2, by, ['B']) || p3dBlock(g, bx + 2, by, ['B']) || p3dBlock(g, bx, by - 2, ['B']) || p3dBlock(g, bx, by + 2, ['B'])) pos = { x: bx, y: by };
      }
      pos = pos || alt;
      if (pos) { for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) g.map[pos.y + dy][pos.x + dx] = 'B'; g.mapVer = (g.mapVer || 0) + 1; g.distDirty = true;
        g.p3dSec = { id: st.p3dSec.id, kind: st.p3dSec.kind, x: pos.x + 1, y: pos.y + 1, cx: pos.x, cy: pos.y, found: false }; }
    }
    // たからの部屋（ひみつの面）：宝箱が はじめから おいてある（面が終わるまで 消えない）
    if (st.p3dChests && g.map.length) {
      let n = 0; for (let k = 0; k < 300 && n < st.p3dChests.length; k++) {
        const x = 3 + Math.floor(R() * (g.cols - 6)), y = 5 + Math.floor(R() * Math.max(1, g.rows - 14));
        if (!placeFree(g, x, y, HALF) || !p3dFarFromDoors(g, x, y) || g.chests.some(c => Math.hypot(c.x - x, c.y - y) < 5)) continue;
        g.chests.push({ x, y, kind: st.p3dChests[n++], t: 9999, T: 9999 });
      }
    }
  }
  /* ---------- けっとう（1 対 1）：g.stage.p3dDuel のある面（tank-story.js の duelStage）----------
     広場：まん中に 19 × 13 升（まわりは 鉄、その外は 木）。レンガの かたまり 4 つ。おうち・出口・ほかの敵は なし。ボスは 上の まん中、けっとうする人は 下の まん中。
     g.p3dDuel＝{ pid, kind, tier, t：のこり秒, max：ボスの体力（砲塔も 入れる）, cd：おたすけの 待ち秒, fix：かいふくの 回数, cheer：おうえん 0〜100, cheerN, res：結果 } */
  const P3D_ARENA = { w: 19, h: 13 };
  function p3dDuelInit(g, d) {
    const du = g.stage.p3dDuel, W = P3D_ARENA.w, H = P3D_ARENA.h, x0 = Math.floor((g.cols - W) / 2), y0 = Math.floor((g.rows - H) / 2), cx = x0 + Math.floor(W / 2), cy = y0 + Math.floor(H / 2);
    for (let y = 0; y < g.rows; y++) for (let x = 0; x < g.cols; x++) { const inX = x >= x0 && x < x0 + W, inY = y >= y0 && y < y0 + H, ring = x >= x0 - 1 && x <= x0 + W && y >= y0 - 1 && y <= y0 + H; g.map[y][x] = inX && inY ? '.' : ring ? 'S' : 'T'; }
    for (const [ox, oy] of [[-4, -3], [4, -3], [-4, 3], [4, 3]]) for (let y = cy + oy - 1; y <= cy + oy; y++) for (let x = cx + ox - 1; x <= cx + ox; x++) g.map[y][x] = 'B';
    g.mapVer = (g.mapVer || 0) + 1; g.distDirty = true; g.noHouse = true; g.ring = []; g.warps = []; g.shutCells = []; g.shut = null; g.flagPos = []; g.goal = null; g.p3dSec = null;
    g.hx = cx; g.hy = y0 + H - 1; g.spawns = [0, 1, 2, 3].map(() => ({ x: cx, y: y0 + H - 1 })); g.gates = [{ x: cx, y: y0 + 1 }]; g.bossX = cx; g.bossXs = [cx];
    g.corePos = [[cx, y0 + 3], [x0 + 4, cy], [x0 + W - 4, cy], [cx, cy]].map(([x, y]) => ({ x, y }));
    g.p3dArena = { x0, y0, w: W, h: H, cx, cy };
    g.queue = []; g.enemyTotal = 0; g.bossQ = []; g.bossSpawned = true; g.bossWarned = true; g.chests = [];
    const kind = du.kind, b = spawnEnemy(g, kind, cx, kind === 'sandship' ? y0 + 3 : kind === 'core' ? y0 + 3 : y0 + 2, d);
    b.hp = b.maxHp = du.hp; if (b.bp) for (const q of b.bp) q.hp = q.maxHp = Math.max(3, Math.round(du.hp * PART_FRAC));
    if (b.parts) { const tier = du.tier ? 0.55 : 0.45; for (const q of b.parts) q.hp = q.maxHp = Math.max(2, Math.round(ENEMY[kind].partHp * tier)); }
    const p = g.pl[du.pid]; if (p) Object.assign(p, { lives: du.hearts, power: 0, twin: 0, armor: 0 });
    g.p3dDuel = { pid: du.pid, kind, tier: du.tier, t: du.sec, sec: du.sec, max: p3dDuelHp(g, kind), cd: 0, fix: 0, cheer: 0, cheerN: 0, res: null, cap: du.cap || null, tempo: du.tempo || 0, arm: du.arm || 0, armTank: null, bud: du.cap ? du.cap[1] : 0, capTxt: -9 };
  }
  function p3dDuelBoss(g, kind) { return g.tanks.find(t => t.alive && t.boss && t.kind === (kind || (g.p3dDuel && g.p3dDuel.kind)) && !t.cloneOf) || null; }
  // ボスの のこりの 体力（砂上戦艦は 砲塔も 足す）
  function p3dDuelHp(g, kind) { const b = p3dDuelBoss(g, kind); if (!b) return 0; return Math.max(0, b.hp) + (b.parts ? b.parts.reduce((a, q) => a + Math.max(0, q.hp), 0) : 0); }
  function p3dDuelEnd(g) {
    const D = g.p3dDuel; if (D.res) return true; const p = g.pl[D.pid];
    let r = null; if (!p) r = 'void'; else { const hp = p3dDuelHp(g); r = hp <= 0 ? 'ko' : (p.lives <= 0 && !p.tank) ? 'lose' : D.t <= 0 ? (hp <= D.max * 0.5 ? 'dec' : 'draw') : null; }
    if (!r) return false;
    D.res = r; g.ph = 'over'; g.win = r === 'ko' || r === 'dec' ? 1 : 0; g.why = 'duel-' + r; g.ev.push({ k: 'p3d_duel', res: r, pid: D.pid, kind: D.kind });   // 'win'・'lose' は 出さない（ふつうの面の 結果・経験値に しない）
    return true;
  }
  // おうえん・おたすけ（テレビが 呼ぶ）。k＝'shield'｜'fix'｜'ice'｜'cheer'。できない時は false
  function p3dDuelHelp(g, k) {
    const D = g.p3dDuel; if (!D || D.res || g.ph !== 'play') return false; const p = g.pl[D.pid], t = p && p.tank;
    if (k === 'cheer') { if (!p) return false; p.sp = Math.min(SP_NEED * modsOf(p).spMax, p.sp + SP_NEED * 0.5); return true; }
    if (D.cd > 0) return false;
    if (k === 'shield') { if (!t || !t.alive) return false; t.shield = Math.max(t.shield, P3D_HELP.shield); }
    else if (k === 'fix') { if (!p || p.lives >= g.stage.p3dDuel.hearts || D.fix >= P3D_HELP.fixMax) return false; p.lives++; D.fix++; }
    else if (k === 'ice') { const b = p3dDuelBoss(g); if (!b) return false; b.freeze = Math.max(b.freeze || 0, P3D_HELP.ice); g.stopT = Math.max(g.stopT, P3D_HELP.ice); }
    else return false;
    D.cd = P3D_HELP.cd; g.ev.push({ k: 'p3d_help', h: k }); return true;
  }
  const P3D_HELP = { shield: 3, ice: 2, fixMax: 2, cd: 6 };
  function p3dDuelStep(g, dt) { const D = g.p3dDuel; if (!D || D.res) return; D.t = Math.max(0, D.t - dt); if (D.cd > 0) D.cd = Math.max(0, D.cd - dt); if (D.cap) D.bud = Math.min(D.cap[1], D.bud + D.cap[0] * dt);
    const p = g.pl[D.pid]; if (D.arm && p && p.tank && D.armTank !== p.tank) { D.armTank = p.tank; p.armor = Math.max(p.armor, D.arm); } }   // 出るたびに よろい（♥ 1 つで 何回か うけられる）
  // けっとうの ボス：たまっている分（cap＝[1 秒に たまる量, いちばん多い量]）までしか 体力が へらない。へらなかった時は「かたい！」
  function p3dDuelCap(g, t, dmg) { const D = g.p3dDuel, d = Math.min(dmg, D.bud); D.bud -= d;
    if (d < dmg && g.t - D.capTxt > 1.6) { D.capTxt = g.t; t.flash = 0.06; g.texts.push({ x: t.x, y: t.y - 1.6, s: 'かたい！', zh: '好硬！', t: 0.7, col: '#cfe3ff' }); if (d <= 0) g.ev.push({ k: 'steelhit' }); }
    return d; }
  function p3dStep(g, dt) {
    p3dDuelStep(g, dt);
    const s = g.p3dSec; if (!s || s.found) return;
    for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) { const c = g.map[s.cy + dy][s.cx + dx]; if (c === 'B' || c === 'b') return; }
    s.found = true; const again = !!(g.p3dDone && g.p3dDone[s.id]);
    g.fx.push({ k: 'spark', x: s.x, y: s.y, t: 0.6, T: 0.6 }); g.shake = Math.max(g.shake, 0.3);
    g.texts.push({ x: s.x, y: s.y - 1.4, s: s.kind === 'door' ? '✨ ひみつの いりぐち！' : '✨ かくし たからばこ！', zh: s.kind === 'door' ? '✨ 秘密入口！' : '✨ 隐藏宝箱！', t: 2.4, col: '#ffe36a', big: 4 });
    if (s.kind === 'item') { const kind = again ? 'wood' : 'gold'; g.chests.push({ x: s.x, y: s.y, kind, t: CHEST_LIFE[kind] + 10, T: CHEST_LIFE[kind] + 10 }); }
    g.ev.push({ k: 'p3d_secret', id: s.id, kind: s.kind, x: s.x, y: s.y, again });
  }
  /* ==================== P3D END ==================== */

  /* ==================== P4B BEGIN（v0.21：ボスちょうせん）====================
     g.stage.p4b（tank-bosslv.js の stage が 作る）が ある面だけ。無い面は 今までと まったく同じ動き。
     - 強さ：ボスの体力（d.bossHp）・手下の数（onField）・手下の体力（hpBonus）・アイテムの間（itemEvery）。2 周目・けっとうの後の 弱りは 使わない
     - ボス：速さ（speedMul）・弾の速さ（fireAt）・こうげきの間（ボスの 時間を はやく すすめる＝わざの 待ちも ぜんぶ）・Lv13 から よろいを 2 まい こわす弾
     - M5：段階が はやく 変わる・なかまを よばない ボスは 14 秒ごとに 2 台。M10：わざ A（9 秒）。M15：はじめから 2 段目・わざ B（11 秒）・体力が 1/4 へるごとに 12 発の 輪。
       M20：はじめから さいごの 段・体力 2 わりで「さいごの おおあばれ」（間 ×0.8、A と B を 5 秒ごとに かわりばんこ）
     - わざは 今ある 物だけ（ring・missile・lob・laser・rain）。大きな わざの 前には かならず 予告
     - ボス装備の 決まった効果（mods.p4b）：twin・ice・sh・free・fi・lava・mate・gold（どの面でも） */
  const P4B_KNOT = [[0, 0], [0.45, 0.33], [0.65, 0.5], [0.75, 0.66], [1, 1]];   // M5：段階の 境目を はやめる（0.5→0.65、0.66/0.33→0.75/0.45）
  function p4bRemap(f) { for (let i = 1; i < P4B_KNOT.length; i++) { const [a, A] = P4B_KNOT[i - 1], [b, B] = P4B_KNOT[i]; if (f <= b) return A + (B - A) * (f - a) / (b - a); } return 1; }
  function p4bDiff(g, d) { const P = g.stage.p4b; d.bossHp *= (P.hp || 1) * (P.sh && Object.keys(g.pl).length === 1 ? P.sh : 1); d.onField += P.field | 0; d.hpBonus += P.mhp | 0; d.itemEvery += P.item | 0; return d; }
  function p4bModsIn(x) {
    if (!x || typeof x !== 'object') return null; const n = (v, a, b) => { const k = Number(v); return Number.isFinite(k) ? clamp(k, a, b) : 0; };
    return { twin: x.twin ? 1 : 0, ice: x.ice === 5 || x.ice === 6 ? x.ice : 0, sh: n(x.sh, 0, 3), free: x.free ? 1 : 0, fi: n(x.fi, 0, 2), lava: n(x.lava, 0, 2), mate: n(x.mate, 0, 0.15), gold: n(x.gold, 0, 0.05) };
  }
  function p4bBossInit(g, t) {
    const P = g.stage.p4b, T = P.T || {}; t.speedMul *= P.mv || 1;
    t.p4b = { lite: !!(P.prim && t.kind !== P.prim), q: 3, sT: (T.summonSec || 14) * 0.5, altT: T.altSec || 5, alt: 0, rage: false, lz: 0 };
    t.p4bMv = [];
    if (!t.p4b.lite) { if (P.a) { t.p4bA = (T.aSec || 9) * 0.6; t.p4bMv.push(['p4bA', P.a]); } if (P.b) { t.p4bB = (T.bSec || 11) * 0.8; t.p4bMv.push(['p4bB', P.b]); } }
  }
  // かりた わざ。true＝この刻みは ボスの いつもの 動きを しない（ビームの 予告）
  function p4bMove(g, t, d, mv) {
    const P = g.stage.p4b, e = ENEMY[t.kind], s = t.p4b, base = Math.atan2(DY[t.dir], DX[t.dir]);
    if (mv === 'ring') { ring(g, t, (P.T && P.T.ring) || 12, (e.bullet || 9) * 0.8); g.texts.push({ x: t.x, y: t.y - 2.4, s: 'ぐるっと！', zh: '环形弹！', t: 0.9, col: '#ffb3a0' }); return false; }
    if (mv === 'missile') { for (const a of [-1.2, 1.2]) g.missiles.push({ x: t.x, y: t.y, ang: base + a, t: MISSILE_LIFE }); g.ev.push({ k: 'missile' }); return false; }
    if (mv === 'lob') { lobAtPlayers(g, t, 3, 1.4, 1.3, 'bomb', 2); return false; }
    if (mv === 'rain') { for (let i = 0; i < 6; i++) lob(g, t, 3 + g.rand() * (g.cols - 6), 4 + g.rand() * (g.rows - 12), 1.6 + g.rand() * 0.5, 1.3, 'bomb'); g.texts.push({ x: t.x, y: t.y - 2.6, s: 'ばくだんの あめ！', zh: '炸弹雨！', t: 1.2, col: '#ffb347' }); g.ev.push({ k: 'mortar' }); return false; }
    if (mv === 'laser') { const near = nearestPlayerTank(g, t.x, t.y, true); if (!near || t.laserAim > 0 || t.ram > 0) return false;
      s.dir0 = t.dir; t.dir = axisDirTo(t, near); s.lz = LASER_AIM + 0.1; t.laserAim = s.lz; g.texts.push({ x: t.x, y: t.y - 2.4, s: 'ビーム！', zh: '光束！', t: 1.2, col: '#ff7a7a' }); g.ev.push({ k: 'aim' }); return true; }
    return false;
  }
  function p4bThink(g, t, dt, d) { if (ADV_BOSS[t.kind]) return advBoss(g, t, dt, d); bossThink(g, t, dt, d); return false; }
  function p4bBossStep(g, t, dt, d) {
    const P = g.stage.p4b, T = P.T || {}; if (!t.p4b) p4bBossInit(g, t); const s = t.p4b, f = Math.max(0, t.hp) / t.maxHp;
    const rage = !!P.m20 && !s.lite && f < (T.rageAt || 0.2);
    if (rage && !s.rage) { s.rage = true; g.shake = Math.max(g.shake, 0.5); g.texts.push({ x: t.x, y: t.y - 2.8, s: 'さいごの おおあばれ！', zh: '最后的大暴走！', t: 1.8, col: '#ffd23a', big: 3 }); g.ev.push({ k: 'bossphase' }); }
    const bdt = dt / Math.max(0.3, (P.int || 1) * (P.si && Object.keys(g.pl).length === 1 ? P.si : 1) * (rage ? T.rage || 0.8 : 1));
    if (s.lz > 0) { s.lz -= bdt; t.laserAim = Math.max(0.01, s.lz);
      if (s.lz <= 0) { t.laserAim = 0; g.beams.push({ x: t.x, y: t.y, dir: t.dir, t: LASER_SEC, owner: t }); g.ev.push({ k: 'laser' }); g.shake = Math.max(g.shake, 0.3); if (s.dir0 !== undefined) { t.dir = s.dir0; s.dir0 = undefined; } }
      return true; }
    if (!s.lite && !t.under) {
      if (P.m15) while (s.q > 0 && f <= s.q * 0.25) { s.q--; ring(g, t, 12, (ENEMY[t.kind].bullet || 9) * 0.8); g.shake = Math.max(g.shake, 0.3); }
      if (P.sum) { s.sT -= bdt; if (s.sT <= 0) { s.sT = T.summonSec || 14; summon(g, t, d, 2, 2 + (P.field | 0)); } }
      if (rage && (P.a || P.b)) { s.altT -= bdt; if (t.p4bA !== undefined) t.p4bA = s.altT; if (t.p4bB !== undefined) t.p4bB = s.altT;
        if (s.altT <= 0) { s.altT = T.altSec || 5; const mv = (s.alt++ % 2 ? P.b : P.a) || P.a || P.b; if (p4bMove(g, t, d, mv)) return true; } }
      else {
        if (P.a) { t.p4bA -= bdt; if (t.p4bA <= 0) { t.p4bA = T.aSec || 9; if (p4bMove(g, t, d, P.a)) return true; } }
        if (P.b) { t.p4bB -= bdt; if (t.p4bB <= 0) { t.p4bB = T.bSec || 11; if (p4bMove(g, t, d, P.b)) return true; } }
      }
    }
    let fe = f; if (P.m5) fe = p4bRemap(f); if (P.ph) fe = Math.min(fe, P.ph); if (P.m15) fe = Math.min(fe, 0.49); if (P.m20) fe = Math.min(fe, 0.2);
    if (fe >= f - 1e-9 && fe <= f + 1e-9) return p4bThink(g, t, bdt, d);
    const hp0 = t.hp, fake = Math.max(0.01, fe) * t.maxHp; t.hp = fake; let r = false;
    try { r = p4bThink(g, t, bdt, d); } finally { t.hp = hp0 + (t.hp - fake); }
    return r;
  }
  // ボス装備：こおらせる弾（ボスは 0.5 秒・2 秒に 1 回まで、ほかの敵は 1.5 秒）
  function p4bIceHit(g, t) {
    if (t.boss) { if (g.t - (t.p4bIceT === undefined ? -99 : t.p4bIceT) < 2) return; t.p4bIceT = g.t; t.freeze = Math.max(t.freeze || 0, 0.5); }
    else t.freeze = Math.max(t.freeze || 0, 1.5);
    g.fx.push({ k: 'spark', x: t.x, y: t.y, t: 0.25, T: 0.25 });
  }
  // ボス装備：かげの おまもり（1 面に 1 回、やられても 台数が へらない）
  function p4bFreeDeath(g, p, t) {
    const m = p.mods && p.mods.p4b; if (!m || !m.free || p.p4bFree) return; p.p4bFree = 1; p.lives = Math.min(MAX_LIVES, p.lives + 1);
    if (m.fi) p.firstShield = Math.max(p.firstShield || 0, m.fi);
    g.texts.push({ x: t.x, y: t.y - 1.8, s: 'かげが まもった！', zh: '影子守护了你！', t: 1.4, col: '#c9a8ff' });
  }
  // ボスちょうせんの 台詞：あいさつ 1 行・たおした時 1 行（なかよしの さいせん）
  function p4bTalk(g, kinds, which) {
    const hi = g.stage.p4bHi, k = kinds[0];
    const line = which === 'enter' && hi ? { kind: k, ja: hi.ja, zh: hi.zh } : which === 'defeat' ? { kind: k, ja: 'まいった！ また あそぼうね！', zh: '认输了！下次再一起玩吧！' } : null;
    if (!line) return; g.talk = { lines: [line], i: 0, t: 0, read: {}, which }; g.ev.push({ k: 'talk' });
  }
  /* ==================== P4B END ==================== */

  const api = { CFG, SCALE, HELL, FX, ENEMY, ITEMS, ITEM_WEIGHTS, ITEM_NAME, LOOP_REWARD, K, DX, DY, newGame, addPlayer, removePlayer, playerCount, startRun, retryStage, loadStage, step, diff,
    enemiesRemaining, enemiesOnField, bossOf, summary, stageList, spawnEnemy, spawnItem, chooseItem, pickItem, killPlayer, newTank, makeAwards, buildDist, distAt, tileAt,
    carryOf, setPause, fieldRadius, MAX_LIVES, buildQueue, playerBulletSpeed, playerMaxOut, playerDamage, afterClear, nextLoop,
    bossesOf, makePraise, readTalk, talkReady, startTalk, setMods, modsOf, useSpecial, spReady, DEF_MODS, SP_NEED, CHEST_LIFE, dropChest, ADV_BOSS, AURA_R, TALK_CHAR_SEC, TALK_MIN_SEC, mapOk, FLAG_R, FLAG_SEC, FLAG_LOSE_SEC, POOL_R, freezePlayer, VIEW_H, ESCORT_R, SHUT_SEC, GOAL_Y, tdistAt };
  // P2-A
  Object.assign(api, { ROLES, setRole, roleOf, setHold, signal, SIG_KINDS, SIG_SEC, initP2A, weakDirOf, partPos, PART_NAME, BREAK, WEAK_MUL, WEAK_HP_UP, SCOUT_R, FIX_R, FIX_TILE_SEC, FIX_MATE_SEC, COMBO_WINDOW, COMBO_NEAR, HINT_SHOW, bossNextMove, makeHint, fireCombo, ringBroken });
  Object.assign(api, { p4bRemap, p4bDiff, p4bModsIn, p4bBossStep, P4B_KNOT });   // P4B
  Object.assign(api, { P3D_CARS, P3D_SP, P3D_LAP, p3dSpecial, p3dStageInit, p3dDuelHelp, p3dDuelHp, p3dDuelBoss, P3D_HELP, P3D_ARENA, p3dRng, WEAK_HP_UP });   // P3D
  root.TankSim = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
